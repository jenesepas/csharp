Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Imaging
Imports System.Drawing.Drawing2D

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents ViewFile As System.Windows.Forms.MenuItem
    Friend WithEvents CreateFileMenu As System.Windows.Forms.MenuItem
    Friend WithEvents EnumerateMetaFile As System.Windows.Forms.MenuItem
    Friend WithEvents EmfTypes As System.Windows.Forms.MenuItem
    Friend WithEvents MetafileHeaderInfo As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.ViewFile = New System.Windows.Forms.MenuItem
        Me.CreateFileMenu = New System.Windows.Forms.MenuItem
        Me.EnumerateMetaFile = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.EmfTypes = New System.Windows.Forms.MenuItem
        Me.MetafileHeaderInfo = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem2})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.ViewFile, Me.CreateFileMenu, Me.EnumerateMetaFile})
        Me.MenuItem1.Text = "Metafile"
        '
        'ViewFile
        '
        Me.ViewFile.Index = 0
        Me.ViewFile.Text = "View"
        '
        'CreateFileMenu
        '
        Me.CreateFileMenu.Index = 1
        Me.CreateFileMenu.Text = "Create a MetaFile"
        '
        'EnumerateMetaFile
        '
        Me.EnumerateMetaFile.Index = 2
        Me.EnumerateMetaFile.Text = "EnumerateMetaFile"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.EmfTypes, Me.MetafileHeaderInfo})
        Me.MenuItem2.Text = "EMF"
        '
        'EmfTypes
        '
        Me.EmfTypes.Index = 0
        Me.EmfTypes.Text = "EmfTypes"
        '
        'MetafileHeaderInfo
        '
        Me.MetafileHeaderInfo.Index = 1
        Me.MetafileHeaderInfo.Text = "Metafile Header Info"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(352, 262)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ViewFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewFile.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a MetaFile object from a file name
        Dim curMetafile As New Metafile("mtfile.wmf")
        ' Draw metafile using DrawImage
        g.DrawImage(curMetafile, 0, 0)
        ' Dispose
        g.Dispose()
    End Sub

    Private Sub CreateFileMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateFileMenu.Click
        Dim curMetafile As Metafile = Nothing
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        ' Get HDC
        Dim hdc As IntPtr = g.GetHdc()
        ' Xreate a rectangle
        Dim rect As New Rectangle(0, 0, 200, 200)
        ' Create a metafile with a name using HDC
        Try
            curMetafile = New Metafile("newFile.wmf", hdc)
        Catch exp As Exception
            MessageBox.Show(exp.Message)
            g.ReleaseHdc(hdc)
            g.Dispose()
            Return
        End Try
        ' Create a Graphics object from the Metafile object
        Dim g1 As Graphics = Graphics.FromImage(curMetafile)
        ' Set smoothing mode
        g1.SmoothingMode = SmoothingMode.HighQuality
        ' Fill a Rectanlge on the Metafile
        g1.FillRectangle(Brushes.Green, rect)
        rect.Y += 110
        '  Draw an ellipse on the Metafile
        Dim lgBrush As New LinearGradientBrush(rect, Color.Red, Color.Blue, 45.0F)
        g1.FillEllipse(lgBrush, rect)
        ' Draw text on the metafile
        rect.Y += 110
        g1.DrawString("MetaFile Sample", New Font("Verdana", 20), lgBrush, 200, 200, StringFormat.GenericTypographic)
        'Release objects
        g.ReleaseHdc(hdc)
        g1.Dispose()
        g.Dispose()

    End Sub

    Private Sub EnumerateMetaFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EnumerateMetaFile.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a Metafile object from a file
        Dim curMetafile As New Metafile("mtfile.wmf")
        ' Set EnumerateMetafileProc property
        Dim enumMetaCB1 As New Graphics.EnumerateMetafileProc(AddressOf EnumMetaCB)
        ' Enumerate metafile
        g.EnumerateMetafile(curMetafile, New Point(0, 0), EnumMetaCB1)
        ' Dispose
        curMetafile.Dispose()
        g.Dispose()
    End Sub

    Private Function EnumMetaCB(ByVal recordType As EmfPlusRecordType, ByVal flags As Integer, ByVal dataSize As Integer, ByVal data As IntPtr, ByVal callbackData As PlayRecordCallback) As Boolean '

        Dim str As String = ""
        ' Play only EmfPlusRecordType.FillEllipse records.
        If recordType = EmfPlusRecordType.FillEllipse Or recordType = EmfPlusRecordType.FillRects Or recordType = EmfPlusRecordType.DrawEllipse Or recordType = EmfPlusRecordType.DrawRects Then
            str = "Record type:" + recordType.ToString() + ", Flags:" + flags.ToString() + ", DataSize:" + dataSize.ToString() + ", Data:" + data.ToString()
            MessageBox.Show(str)
        End If
        Return True
    End Function 'EnumMetaCB
End Class

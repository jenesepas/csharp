Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Imaging

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(424, 349)
        Me.Name = "Form1"
        Me.Text = "Bitmap Rendering Sample"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        ' Create an Image and Bitmap
        Dim img As Image = Image.FromFile("roses.jpg")
        Dim curImage As New Bitmap(img, New Size(img.Width, img.Height))
        ' Call LockBits, which returns a BitmapData
        'Rectangle lockedRect = new Rectangle(50,50,200,200);
        Dim lockedRect As New Rectangle(0, 0, curImage.Width, curImage.Height)
        'Find out starting time
        'DateTime startTime = DateTime.Now;
        ' Create a BitmapData 
        Dim bmpData As BitmapData = curImage.LockBits(lockedRect, ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb)
        ' Set the format of BitmapData pixels
        bmpData.PixelFormat = PixelFormat.Max
        ' Unlock the locked bits
        curImage.UnlockBits(bmpData)
        ' Draw Image with new pixel format
        e.Graphics.DrawImage(curImage, 0, 0, curImage.Width, curImage.Height)
        ' End time
        'DateTime endTime = DateTime.Now;
        ' Time difference
        'TimeSpan diffTime = endTime - startTime;
        'MessageBox.Show(diffTime.TotalMilliseconds.ToString());
    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D
Imports System.Drawing.Imaging

Public Class Form1
    Inherits System.Windows.Forms.Form
    Private mainMenu1 As System.Windows.Forms.MainMenu
    Private menuItem1 As System.Windows.Forms.MenuItem
    Private ColorBlending As System.Windows.Forms.MenuItem
    Private AlphaBlending As System.Windows.Forms.MenuItem
    Private menuItem2 As System.Windows.Forms.MenuItem
    Private EllipseMenu As System.Windows.Forms.MenuItem
    Private RectangleMenu As System.Windows.Forms.MenuItem
    Private menuItem3 As System.Windows.Forms.MenuItem
    Private MixedBlendingMenu As System.Windows.Forms.MenuItem
    Private menuItem4 As System.Windows.Forms.MenuItem
    Private SetBlendTriangularShapeMenu As System.Windows.Forms.MenuItem
    Private SetSigmaBellShapeMenu As System.Windows.Forms.MenuItem
    Private BlendPropMenu As System.Windows.Forms.MenuItem
    Private InterpolationColorsMenu As System.Windows.Forms.MenuItem
    Private GammaCorrectionMenu As System.Windows.Forms.MenuItem
    Private menuItem5 As System.Windows.Forms.MenuItem
    Private PathGradientProsMenu As System.Windows.Forms.MenuItem
    Private PathGBBlend As System.Windows.Forms.MenuItem
    Private PathGBInterPol As System.Windows.Forms.MenuItem
    Private AlphaBPensBrushes As System.Windows.Forms.MenuItem
    Private AlphaBImages As System.Windows.Forms.MenuItem
    Private AlphaBCompGammaCorr As System.Windows.Forms.MenuItem
    Private AlphaBMatrix As System.Windows.Forms.MenuItem


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer = Nothing

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.ColorBlending = New System.Windows.Forms.MenuItem
        Me.AlphaBlending = New System.Windows.Forms.MenuItem
        Me.MixedBlendingMenu = New System.Windows.Forms.MenuItem
        Me.menuItem2 = New System.Windows.Forms.MenuItem
        Me.EllipseMenu = New System.Windows.Forms.MenuItem
        Me.RectangleMenu = New System.Windows.Forms.MenuItem
        Me.menuItem3 = New System.Windows.Forms.MenuItem
        Me.SetBlendTriangularShapeMenu = New System.Windows.Forms.MenuItem
        Me.SetSigmaBellShapeMenu = New System.Windows.Forms.MenuItem
        Me.BlendPropMenu = New System.Windows.Forms.MenuItem
        Me.InterpolationColorsMenu = New System.Windows.Forms.MenuItem
        Me.GammaCorrectionMenu = New System.Windows.Forms.MenuItem
        Me.menuItem5 = New System.Windows.Forms.MenuItem
        Me.PathGradientProsMenu = New System.Windows.Forms.MenuItem
        Me.PathGBBlend = New System.Windows.Forms.MenuItem
        Me.PathGBInterPol = New System.Windows.Forms.MenuItem
        Me.menuItem4 = New System.Windows.Forms.MenuItem
        Me.AlphaBPensBrushes = New System.Windows.Forms.MenuItem
        Me.AlphaBImages = New System.Windows.Forms.MenuItem
        Me.AlphaBCompGammaCorr = New System.Windows.Forms.MenuItem
        Me.AlphaBMatrix = New System.Windows.Forms.MenuItem
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1, Me.menuItem2, Me.menuItem4})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.ColorBlending, Me.AlphaBlending, Me.MixedBlendingMenu})
        Me.menuItem1.Text = "Blending"
        '
        'ColorBlending
        '
        Me.ColorBlending.Index = 0
        Me.ColorBlending.Text = "Color Blending"
        AddHandler ColorBlending.Click, AddressOf ColorBlending_Click
        '
        'AlphaBlending
        '
        Me.AlphaBlending.Index = 1
        Me.AlphaBlending.Text = "Alpha Blending"
        AddHandler AlphaBlending.Click, AddressOf AlphaBlending_Click
        '
        'MixedBlendingMenu
        '
        Me.MixedBlendingMenu.Index = 2
        Me.MixedBlendingMenu.Text = "Mixed Blending"
        AddHandler MixedBlendingMenu.Click, AddressOf MixedBlendingMenu_Click
        '
        'menuItem2
        '
        Me.menuItem2.Index = 1
        Me.menuItem2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.EllipseMenu, Me.RectangleMenu, Me.menuItem3, Me.menuItem5})
        Me.menuItem2.Text = "Color Blending"
        '
        'EllipseMenu
        '
        Me.EllipseMenu.Index = 0
        Me.EllipseMenu.Text = "Ellipse"
        AddHandler EllipseMenu.Click, AddressOf EllipseMenu_Click
        '
        'RectangleMenu
        '
        Me.RectangleMenu.Index = 1
        Me.RectangleMenu.Text = "Rectangle"
        AddHandler RectangleMenu.Click, AddressOf RectangleMenu_Click
        '
        'menuItem3
        '
        Me.menuItem3.Index = 2
        Me.menuItem3.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.SetBlendTriangularShapeMenu, Me.SetSigmaBellShapeMenu, Me.BlendPropMenu, Me.InterpolationColorsMenu, Me.GammaCorrectionMenu})
        Me.menuItem3.Text = "LinearGradientBrush"
        '
        'SetBlendTriangularShapeMenu
        '
        Me.SetBlendTriangularShapeMenu.Index = 0
        Me.SetBlendTriangularShapeMenu.Text = "SetBlendTriangularShape"
        AddHandler SetBlendTriangularShapeMenu.Click, AddressOf SetBlendTriangularShapeMenu_Click
        '
        'SetSigmaBellShapeMenu
        '
        Me.SetSigmaBellShapeMenu.Index = 1
        Me.SetSigmaBellShapeMenu.Text = "SetSigmaBellShape"
        AddHandler SetSigmaBellShapeMenu.Click, AddressOf SetSigmaBellShapeMenu_Click
        '
        'BlendPropMenu
        '
        Me.BlendPropMenu.Index = 2
        Me.BlendPropMenu.Text = "Blend"
        AddHandler BlendPropMenu.Click, AddressOf BlendPropMenu_Click
        '
        'InterpolationColorsMenu
        '
        Me.InterpolationColorsMenu.Index = 3
        Me.InterpolationColorsMenu.Text = "InterpolationColors"
        AddHandler InterpolationColorsMenu.Click, AddressOf InterpolationColorsMenu_Click
        '
        'GammaCorrectionMenu
        '
        Me.GammaCorrectionMenu.Index = 4
        Me.GammaCorrectionMenu.Text = "GammaCorrection"
        AddHandler GammaCorrectionMenu.Click, AddressOf GammaCorrectionMenu_Click
        '
        'menuItem5
        '
        Me.menuItem5.Index = 3
        Me.menuItem5.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.PathGradientProsMenu, Me.PathGBBlend, Me.PathGBInterPol})
        Me.menuItem5.Text = "PathGradientBrush"
        '
        'PathGradientProsMenu
        '
        Me.PathGradientProsMenu.Index = 0
        Me.PathGradientProsMenu.Text = "Properties"
        AddHandler PathGradientProsMenu.Click, AddressOf PathGradientProsMenu_Click
        '
        'PathGBBlend
        '
        Me.PathGBBlend.Index = 1
        Me.PathGBBlend.Text = "Blend"
        AddHandler PathGBBlend.Click, AddressOf PathGBBlend_Click
        '
        'PathGBInterPol
        '
        Me.PathGBInterPol.Index = 2
        Me.PathGBInterPol.Text = "InterpolationColors"
        AddHandler PathGBInterPol.Click, AddressOf PathGBInterPol_Click
        '
        'menuItem4
        '
        Me.menuItem4.Index = 2
        Me.menuItem4.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.AlphaBPensBrushes, Me.AlphaBImages, Me.AlphaBCompGammaCorr, Me.AlphaBMatrix})
        Me.menuItem4.Text = "Alpha Blending"
        '
        'AlphaBPensBrushes
        '
        Me.AlphaBPensBrushes.Index = 0
        Me.AlphaBPensBrushes.Text = "Pens and Brushes"
        AddHandler AlphaBPensBrushes.Click, AddressOf AlphaBPensBrushes_Click
        '
        'AlphaBImages
        '
        Me.AlphaBImages.Index = 1
        Me.AlphaBImages.Text = "Images and Alpha Blending"
        AddHandler AlphaBImages.Click, AddressOf AlphaBImages_Click
        '
        'AlphaBCompGammaCorr
        '
        Me.AlphaBCompGammaCorr.Index = 2
        Me.AlphaBCompGammaCorr.Text = "CompositeMode and GammaCorrection"
        AddHandler AlphaBCompGammaCorr.Click, AddressOf AlphaBCompGammaCorr_Click
        '
        'AlphaBMatrix
        '
        Me.AlphaBMatrix.Index = 3
        Me.AlphaBMatrix.Text = "Matrix In Alpha Blending"
        AddHandler AlphaBMatrix.Click, AddressOf AlphaBMatrix_Click
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(424, 317)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Blending Sample"

    End Sub

#End Region

    Private Sub ColorBlending_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim rgBrush As New LinearGradientBrush(New RectangleF(20, 20, 100, 100), Color.Red, Color.Green, LinearGradientMode.Horizontal)
        Dim yrBrush As New LinearGradientBrush(New RectangleF(140, 20, 150, 300), Color.Yellow, Color.Red, LinearGradientMode.ForwardDiagonal)
        Dim rbBrush As New LinearGradientBrush(New RectangleF(10, 10, 50, 50), Color.Red, Color.Blue, LinearGradientMode.ForwardDiagonal)

        g.FillRectangle(rgBrush, 20, 20, 100, 100)
        g.FillEllipse(yrBrush, 140, 20, 200, 200)
        g.DrawString("Color Blending", New Font("Tahoma", 30), rbBrush, New RectangleF(100, 240, 300, 300))


        ' Dispose
        g.Dispose()

    End Sub

    Private Sub AlphaBlending_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim curImage As Image = Image.FromFile("f:\myphoto.jpg")
        g.DrawImage(curImage, 0, 0, curImage.Width, curImage.Height) '
        'ToDo: Error processing original source shown below
        '
        '
        '------------------------------------------^--- Bad escape sequence
        '
        'ToDo: Error processing original source shown below
        '
        '
        '--------------------------------------------------------^--- Illegal whitespace in constant

        Dim opqPen As New Pen(Color.FromArgb(255, 0, 255, 0), 10)
        Dim transPen As New Pen(Color.FromArgb(128, 0, 255, 0), 10)
        Dim totTransPen As New Pen(Color.FromArgb(40, 0, 255, 0), 10)

        g.DrawLine(opqPen, 10, 10, 200, 10)
        g.DrawLine(transPen, 10, 30, 200, 30)
        g.DrawLine(totTransPen, 10, 50, 200, 50)
        Dim semiTransBrush As New SolidBrush(Color.FromArgb(90, 255, 255, 0))
        g.DrawString("Atlanta Photo " + ControlChars.Lf + "Date: 04/09/2001", New Font("Verdana", 14), semiTransBrush, New RectangleF(20, 100, 300, 100))

        ' Dispose
        g.Dispose()

    End Sub

    Private Sub MixedBlendingMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim curImage As Image = Image.FromFile("f:\myphoto.jpg")
        g.DrawImage(curImage, 0, 0, curImage.Width, curImage.Height) '
        'ToDo: Error processing original source shown below
        '
        '
        '------------------------------------------^--- Bad escape sequence
        '
        'ToDo: Error processing original source shown below
        '
        '
        '--------------------------------------------------------^--- Illegal whitespace in constant

        Dim path As New GraphicsPath
        path.AddRectangle(New Rectangle(0, 0, 182, 300))

        Dim grBrush As New PathGradientBrush(path)
        Dim transBlackColor As Color = color.FromArgb(60, 0, 255, 0)

        Dim color1() As Color = {transBlackColor}
        grBrush.SurroundColors = color1
        grBrush.CenterColor = color.Yellow
        g.FillPath(grBrush, path)

        ' Dispose
        g.Dispose()

    End Sub

    Private Sub EllipseMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        g.SmoothingMode = SmoothingMode.AntiAlias
        g.CompositingQuality = CompositingQuality.HighQuality

        Dim path As New GraphicsPath
        path.AddEllipse(20, 20, 200, 200)

        Dim pthGrBrush As New PathGradientBrush(path)
        Dim transBlackColor As Color = color.FromArgb(90, 255, 255, 255)

        Dim color2() As Color = {Color.Black}
        pthGrBrush.SurroundColors = color2
        pthGrBrush.CenterColor = color.Red
        g.FillPath(pthGrBrush, path)

        ' Dispose
        g.Dispose()

    End Sub

    Private Sub RectangleMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim rgBrush As New LinearGradientBrush(New RectangleF(0, 0, 50, 50), Color.Red, Color.Green, LinearGradientMode.Horizontal)
        g.FillRectangle(rgBrush, 0, 0, 200, 50)

        ' Dispose
        g.Dispose()
    End Sub

    Private Sub SetBlendTriangularShapeMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim rect As New Rectangle(20, 20, 100, 50)
        Dim rgBrush As New LinearGradientBrush(rect, Color.Red, Color.Green, 0.0F, True)
        g.FillRectangle(rgBrush, rect)
        rect.Y = 90
        rgBrush.SetBlendTriangularShape(0.5F, 1.0F)
        g.FillRectangle(rgBrush, rect)

        ' Dispose
        g.Dispose()

    End Sub

    Private Sub SetSigmaBellShapeMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim rect As New Rectangle(20, 20, 100, 50)
        Dim rgBrush As New LinearGradientBrush(rect, Color.Red, Color.Green, 0.0F, True)
        g.FillRectangle(rgBrush, rect)
        rect.Y = 90
        rgBrush.SetSigmaBellShape(0.5F, 1.0F)
        g.FillRectangle(rgBrush, rect)


        ' Dispose
        g.Dispose()

    End Sub

    Private Sub BlendPropMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim brBrush As New LinearGradientBrush(New Point(0, 0), New Point(50, 20), Color.Blue, Color.Red)

        Dim blend As New Blend
        Dim factArray As Single() = {0.0F, 0.3F, 0.5F, 1.0F}
        Dim posArray As Single() = {0.0F, 0.2F, 0.6F, 1.0F}
        blend.Factors = factArray
        blend.Positions = posArray
        brBrush.Blend = blend

        g.FillRectangle(brBrush, 10, 20, 200, 100)
        g.FillEllipse(brBrush, 10, 150, 120, 120)

        ' Dispose
        g.Dispose()
    End Sub

    Private Sub InterpolationColorsMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim brBrush As New LinearGradientBrush(New Point(0, 0), New Point(50, 20), Color.Blue, Color.Red)
        Dim rect As New Rectangle(20, 20, 200, 100)
        ' Create color and points array
        Dim clrArray As Color() = {Color.Red, Color.Blue, Color.Green, Color.Pink, Color.Yellow, Color.DarkTurquoise}
        Dim posArray As Single() = {0.0F, 0.2F, 0.4F, 0.6F, 0.8F, 1.0F}
        ' Create a ColorBlend object and set its Colors and 
        ' positions
        Dim colorBlend As New ColorBlend
        colorBlend.Colors = clrArray
        colorBlend.Positions = posArray
        ' Set LinearGradientBrush's InterpolationColors property
        brBrush.InterpolationColors = colorBlend
        ' Draw shapes		
        g.FillRectangle(brBrush, rect)
        rect.Y = 150
        rect.Width = 100
        rect.Height = 100
        g.FillEllipse(brBrush, rect)

        ' Dispose
        g.Dispose()

    End Sub

    Private Sub GammaCorrectionMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim rect As New Rectangle(20, 20, 100, 50)
        Dim rgBrush As New LinearGradientBrush(rect, Color.Red, Color.Green, 0.0F, True)
        g.FillRectangle(rgBrush, rect)
        rect.Y = 90
        rgBrush.GammaCorrection = True
        g.FillRectangle(rgBrush, rect)

        ' Dispose
        g.Dispose()

    End Sub

    Private Sub PathGradientProsMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        g.SmoothingMode = SmoothingMode.AntiAlias
        Dim path As New GraphicsPath
        Dim rect As New Rectangle(10, 20, 200, 200)
        path.AddRectangle(rect)
        Dim rgBrush As New PathGradientBrush(path)
        rgBrush.CenterColor = Color.Red
        rgBrush.FocusScales = New PointF(0.6F, 0.2F)
        Dim colors As Color() = {Color.Green, Color.Blue, Color.Red, Color.Yellow}
        rgBrush.SurroundColors = colors
        g.FillEllipse(rgBrush, rect)
        ' Dispose
        g.Dispose()

    End Sub

    Private Sub PathGBBlend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim blend As New Blend
        Dim factArray As Single() = {0.0F, 0.3F, 0.5F, 1.0F}
        Dim posArray As Single() = {0.0F, 0.2F, 0.6F, 1.0F}
        blend.Factors = factArray
        blend.Positions = posArray
        g.SmoothingMode = SmoothingMode.AntiAlias
        Dim path As New GraphicsPath
        Dim rect As New Rectangle(10, 20, 200, 200)
        path.AddRectangle(rect)
        Dim rgBrush As New PathGradientBrush(path)
        rgBrush.Blend = blend
        rgBrush.FocusScales = New PointF(0.6F, 0.2F)
        Dim colors() As Color = {Color.Green}
        rgBrush.CenterColor = Color.Red
        rgBrush.SurroundColors = colors
        g.FillEllipse(rgBrush, rect)
        ' Dispose
        g.Dispose()


    End Sub

    Private Sub PathGBInterPol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)


        ' Create color and points array
        Dim clrArray As Color() = {Color.Red, Color.Blue, Color.Green, Color.Pink, Color.Yellow, Color.DarkTurquoise}
        Dim posArray As Single() = {0.0F, 0.2F, 0.4F, 0.6F, 0.8F, 1.0F}
        ' Create a ColorBlend object and set its Colors and 
        ' positions
        Dim colorBlend As New ColorBlend
        colorBlend.Colors = clrArray
        colorBlend.Positions = posArray
        g.SmoothingMode = SmoothingMode.AntiAlias
        Dim path As New GraphicsPath
        Dim rect As New Rectangle(10, 20, 200, 200)
        path.AddRectangle(rect)
        Dim rgBrush As New PathGradientBrush(path)
        rgBrush.InterpolationColors = colorBlend
        rgBrush.FocusScales = New PointF(0.6F, 0.2F)
        Dim colors() As Color = {Color.Green}
        rgBrush.CenterColor = Color.Red
        rgBrush.SurroundColors = colors
        g.FillEllipse(rgBrush, rect)
        ' Dispose
        g.Dispose()

    End Sub

    Private Sub AlphaBPensBrushes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim rect As New Rectangle(220, 30, 100, 50)
        Dim transPen As New Pen(Color.FromArgb(128, 255, 255, 255), 10)
        Dim totTransPen As New Pen(Color.FromArgb(40, 0, 255, 0), 10)
        g.DrawLine(transPen, 10, 30, 200, 30)
        g.DrawLine(totTransPen, 10, 50, 200, 50)
        g.FillRectangle(New SolidBrush(Color.FromArgb(40, 0, 0, 255)), rect)
        rect.Y += 60
        g.FillEllipse(New SolidBrush(Color.FromArgb(20, 255, 255, 0)), rect)
        Dim semiTransBrush As New SolidBrush(Color.FromArgb(90, 0, 50, 255))
        g.DrawString("Some Photo " + ControlChars.Lf + "Date: 04/09/2001", New Font("Verdana", 14), semiTransBrush, New RectangleF(20, 100, 300, 100))

        ' Dispose
        g.Dispose()

    End Sub

    Private Sub AlphaBImages_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        ' Draw an image 
        Dim curImage As Image = Image.FromFile("f:\myphoto.jpg")
        g.DrawImage(curImage, 0, 0, curImage.Width, curImage.Height) '
        'ToDo: Error processing original source shown below
        '
        '
        '------------------------------------------^--- Bad escape sequence
        '
        'ToDo: Error processing original source shown below
        '
        '
        '--------------------------------------------------------^--- Illegal whitespace in constant
        ' Create pens and a rectangle
        Dim rect As New Rectangle(220, 30, 100, 50)
        Dim opqPen As New Pen(Color.FromArgb(255, 0, 255, 0), 10)
        Dim transPen As New Pen(Color.FromArgb(128, 255, 255, 255), 10)
        Dim totTransPen As New Pen(Color.FromArgb(40, 0, 255, 0), 10)
        ' Draw lines, rectangle, ellipse and string
        g.DrawLine(opqPen, 10, 10, 200, 10)
        g.DrawLine(transPen, 10, 30, 200, 30)
        g.DrawLine(totTransPen, 10, 50, 200, 50)
        g.FillRectangle(New SolidBrush(Color.FromArgb(40, 0, 0, 255)), rect)
        rect.Y += 60
        g.FillEllipse(New SolidBrush(Color.FromArgb(50, 255, 255, 255)), rect)
        Dim semiTransBrush As New SolidBrush(Color.FromArgb(90, 255, 255, 50))
        g.DrawString("Some Photo " + ControlChars.Lf + "Date: 04/09/2001", New Font("Verdana", 14), semiTransBrush, New RectangleF(20, 100, 300, 100))

        ' Dispose
        g.Dispose()

    End Sub

    Private Sub AlphaBCompGammaCorr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim rect1 As New Rectangle(20, 20, 100, 100)
        Dim rect2 As New Rectangle(200, 20, 100, 100)
        Dim redBrush As New SolidBrush(Color.FromArgb(150, 255, 0, 0))
        Dim greenBrush As New SolidBrush(Color.FromArgb(180, 0, 255, 0))

        Dim tempBmp As New Bitmap(200, 150)
        Dim tempGraphics As Graphics = Graphics.FromImage(tempBmp)
        tempGraphics.CompositingMode = CompositingMode.SourceOver
        tempGraphics.CompositingQuality = CompositingQuality.GammaCorrected
        'tempGraphics.CompositingMode = CompositingMode.SourceCopy;
        tempGraphics.FillRectangle(redBrush, rect1)
        rect1.X += 30
        rect1.Y += 30
        tempGraphics.FillEllipse(greenBrush, rect1)
        g.CompositingQuality = CompositingQuality.GammaCorrected
        g.DrawImage(tempBmp, 0, 0)

        g.FillRectangle(Brushes.Red, rect2)
        rect2.X += 30
        rect2.Y += 30
        g.FillEllipse(Brushes.Green, rect2)
        ' Dispose
        tempBmp.Dispose()
        g.Dispose()

    End Sub

    Private Sub AlphaBMatrix_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim rect As New Rectangle(20, 20, 200, 100)
        Dim bitmap As New Bitmap("f:\myphoto.jpg")
        Dim ptsArray As Single()() = {New Single() {1, 0, 0, 0, 0}, New Single() {0, 1, 0, 0, 0}, New Single() {0, 0, 1, 0, 0}, New Single() {0, 0, 0, 0.5F, 0}, New Single() {0, 0, 0, 0, 1}}  '
        'ToDo: Error processing original source shown below
        '
        '
        '-------------------------------------^--- Bad escape sequence
        '
        'ToDo: Error processing original source shown below
        '
        '
        '---------------------------------------------------^--- Illegal whitespace in constant
        '
        'ToDo: Error processing original source shown below
        '
        '
        '-------------------------------------^--- Syntax error: ')' expected
        '
        'ToDo: Error processing original source shown below
        '
        '
        '-----------------------------------------^--- Syntax error: ';' expected
        '
        'ToDo: Error processing original source shown below
        '
        '
        '----------------------------------------------------^--- Syntax error: ';' expected
        '
        'ToDo: Error processing original source shown below
        '
        '
        '----^--- Syntax error: ';' expected
        '
        'ToDo: Error processing original source shown below
        '
        '
        '-------------------------------------^--- Syntax error: ')' expected
        '
        'ToDo: Error processing original source shown below
        '
        '
        '-----------------------------------------^--- Syntax error: ';' expected
        '
        'ToDo: Error processing original source shown below
        '
        '
        '----------------------------------------------------^--- Syntax error: ';' expected
        '
        'ToDo: Error processing original source shown below
        '
        '
        '----^--- Syntax error: ';' expected
        '
        'ToDo: Error processing original source shown below
        '
        '
        '-------------------------------------^--- Syntax error: ')' expected
        '
        'ToDo: Error processing original source shown below
        '
        '
        '-----------------------------------------^--- Syntax error: ';' expected
        '
        'ToDo: Error processing original source shown below
        '
        '
        '----------------------------------------------------^--- Syntax error: ';' expected
        '
        'ToDo: Error processing original source shown below
        '
        '
        '----^--- Syntax error: ';' expected
        '
        'ToDo: Error processing original source shown below
        '
        '
        '--------------------------------^--- Syntax error: ')' expected
        '
        'ToDo: Error processing original source shown below
        '
        '
        '------------------------------------^--- Syntax error: ';' expected
        '
        'ToDo: Error processing original source shown below
        '
        '
        '-----------------------------------------------^--- Syntax error: ';' expected
        '
        'ToDo: Error processing original source shown below
        '
        '
        '----^--- Syntax error: ';' expected
        Dim clrMatrix As New ColorMatrix(ptsArray)
        Dim imgAttributes As New ImageAttributes
        imgAttributes.SetColorMatrix(clrMatrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap)
        g.FillRectangle(Brushes.Red, rect)
        rect.Y += 120
        g.FillEllipse(Brushes.Black, rect)
        g.DrawImage(bitmap, New Rectangle(0, 0, bitmap.Width, bitmap.Height), 0, 0, bitmap.Width, bitmap.Height, GraphicsUnit.Pixel, imgAttributes)

        ' Dispose
        g.Dispose()

    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms

Public Class ImagePropertyForm
    Inherits System.Windows.Forms.Form
    Public imgHeight As Single
    Public imgWidht As Single
    Public imgColorDepth As Short
    Public imgFormat As String
    Public imgCompression As String
    Public imgTransformation As String
    'Private OkBtn As System.Windows.Forms.Button
    'Private CancelBtn As System.Windows.Forms.Button
    ' Private comboBox2 As System.Windows.Forms.ComboBox
    'Private comboBox3 As System.Windows.Forms.ComboBox

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents comboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents comboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents CancelBtn As System.Windows.Forms.Button
    Friend WithEvents OkBtn As System.Windows.Forms.Button
    Friend WithEvents label6 As System.Windows.Forms.Label
    Friend WithEvents label5 As System.Windows.Forms.Label
    Friend WithEvents textBox3 As System.Windows.Forms.TextBox
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents comboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents textBox2 As System.Windows.Forms.TextBox
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    Friend WithEvents label1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.comboBox3 = New System.Windows.Forms.ComboBox
        Me.comboBox2 = New System.Windows.Forms.ComboBox
        Me.CancelBtn = New System.Windows.Forms.Button
        Me.OkBtn = New System.Windows.Forms.Button
        Me.label6 = New System.Windows.Forms.Label
        Me.label5 = New System.Windows.Forms.Label
        Me.textBox3 = New System.Windows.Forms.TextBox
        Me.label4 = New System.Windows.Forms.Label
        Me.comboBox1 = New System.Windows.Forms.ComboBox
        Me.label3 = New System.Windows.Forms.Label
        Me.textBox2 = New System.Windows.Forms.TextBox
        Me.label2 = New System.Windows.Forms.Label
        Me.textBox1 = New System.Windows.Forms.TextBox
        Me.label1 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'comboBox3
        '
        Me.comboBox3.Location = New System.Drawing.Point(144, 174)
        Me.comboBox3.Name = "comboBox3"
        Me.comboBox3.Size = New System.Drawing.Size(96, 21)
        Me.comboBox3.TabIndex = 27
        '
        'comboBox2
        '
        Me.comboBox2.Location = New System.Drawing.Point(144, 142)
        Me.comboBox2.Name = "comboBox2"
        Me.comboBox2.Size = New System.Drawing.Size(96, 21)
        Me.comboBox2.TabIndex = 26
        '
        'CancelBtn
        '
        Me.CancelBtn.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(128, Byte), CType(0, Byte))
        Me.CancelBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CancelBtn.Location = New System.Drawing.Point(160, 334)
        Me.CancelBtn.Name = "CancelBtn"
        Me.CancelBtn.Size = New System.Drawing.Size(80, 24)
        Me.CancelBtn.TabIndex = 25
        Me.CancelBtn.Text = "Cancel"
        '
        'OkBtn
        '
        Me.OkBtn.BackColor = System.Drawing.Color.DarkSeaGreen
        Me.OkBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.OkBtn.Location = New System.Drawing.Point(32, 334)
        Me.OkBtn.Name = "OkBtn"
        Me.OkBtn.Size = New System.Drawing.Size(104, 24)
        Me.OkBtn.TabIndex = 24
        Me.OkBtn.Text = "Save Settings"
        '
        'label6
        '
        Me.label6.Location = New System.Drawing.Point(24, 174)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(96, 16)
        Me.label6.TabIndex = 23
        Me.label6.Text = "Transformation:"
        '
        'label5
        '
        Me.label5.Location = New System.Drawing.Point(24, 142)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(80, 16)
        Me.label5.TabIndex = 22
        Me.label5.Text = "Compression:"
        '
        'textBox3
        '
        Me.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.textBox3.Location = New System.Drawing.Point(144, 110)
        Me.textBox3.Name = "textBox3"
        Me.textBox3.Size = New System.Drawing.Size(96, 20)
        Me.textBox3.TabIndex = 21
        Me.textBox3.Text = ""
        '
        'label4
        '
        Me.label4.Location = New System.Drawing.Point(24, 110)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(72, 16)
        Me.label4.TabIndex = 20
        Me.label4.Text = "Color Depth:"
        '
        'comboBox1
        '
        Me.comboBox1.Location = New System.Drawing.Point(144, 78)
        Me.comboBox1.Name = "comboBox1"
        Me.comboBox1.Size = New System.Drawing.Size(96, 21)
        Me.comboBox1.TabIndex = 19
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(24, 78)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(48, 16)
        Me.label3.TabIndex = 18
        Me.label3.Text = "Format:"
        '
        'textBox2
        '
        Me.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.textBox2.Location = New System.Drawing.Point(144, 46)
        Me.textBox2.Name = "textBox2"
        Me.textBox2.Size = New System.Drawing.Size(96, 20)
        Me.textBox2.TabIndex = 17
        Me.textBox2.Text = ""
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(24, 46)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(40, 16)
        Me.label2.TabIndex = 16
        Me.label2.Text = "Height:"
        '
        'textBox1
        '
        Me.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.textBox1.Location = New System.Drawing.Point(144, 14)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(96, 20)
        Me.textBox1.TabIndex = 15
        Me.textBox1.Text = ""
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(24, 14)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(40, 16)
        Me.label1.TabIndex = 14
        Me.label1.Text = "Width:"
        '
        'ImagePropertyForm
        '
        Me.AutoScale = False
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.Desktop
        Me.ClientSize = New System.Drawing.Size(264, 373)
        Me.Controls.Add(Me.comboBox3)
        Me.Controls.Add(Me.comboBox2)
        Me.Controls.Add(Me.CancelBtn)
        Me.Controls.Add(Me.OkBtn)
        Me.Controls.Add(Me.label6)
        Me.Controls.Add(Me.label5)
        Me.Controls.Add(Me.textBox3)
        Me.Controls.Add(Me.label4)
        Me.Controls.Add(Me.comboBox1)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.textBox2)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.textBox1)
        Me.Controls.Add(Me.label1)
        Me.Name = "ImagePropertyForm"
        Me.Text = "ImagePropertyForm"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub OkBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OkBtn.Click
        imgHeight = Convert.ToInt16(textBox2.Text.ToString())
        imgWidht = Convert.ToInt16(textBox1.Text.ToString())
        imgColorDepth = Convert.ToInt16(textBox3.Text.ToString())
        imgFormat = comboBox1.SelectedText
        imgCompression = comboBox2.SelectedText
        imgTransformation = comboBox3.SelectedText
    End Sub

    Private Sub ImagePropertyForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Add items to file types combo
        comboBox1.Items.Add("bmp")
        comboBox1.Items.Add("gif")
        comboBox1.Items.Add("tif")
        comboBox1.Items.Add("png")
        comboBox1.Items.Add("jpg")
        ' Add items to compression combo
        comboBox2.Items.Add("CCITT3")
        comboBox2.Items.Add("CCITT4")
        comboBox2.Items.Add("LGW")
        comboBox2.Items.Add("None")
        comboBox2.Items.Add("Rle")
        ' Adding items to transformation combo
        comboBox3.Items.Add("90")
        comboBox3.Items.Add("180")
        comboBox3.Items.Add("270")
        comboBox3.Items.Add("Flip HRZ")
        comboBox3.Items.Add("Flip VERT")
    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Imaging
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents ColorMap As System.Windows.Forms.MenuItem
    Friend WithEvents ColorMatrix As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.ColorMap = New System.Windows.Forms.MenuItem
        Me.ColorMatrix = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.ColorMap, Me.ColorMatrix})
        Me.MenuItem1.Text = "Color Objects"
        '
        'ColorMap
        '
        Me.ColorMap.Index = 0
        Me.ColorMap.Text = "Color Map"
        '
        'ColorMatrix
        '
        Me.ColorMatrix.Index = 1
        Me.ColorMatrix.Text = "Color Matrix"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(400, 306)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub ColorMap_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ColorMap.Click
        ' Create a Graphics
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create an Image object
        Dim image = New Bitmap("Sample.bmp")
        ' Create ImageAttributes
        Dim imageAttributes As New ImageAttributes
        ' Create three ColorMap objects
        Dim colorMap1 As New ColorMap
        Dim colorMap2 As New ColorMap
        Dim colorMap3 As New ColorMap
        ' Set ColorMap objects properties
        colorMap1.OldColor = Color.Red
        colorMap1.NewColor = Color.Green
        colorMap2.OldColor = Color.Yellow
        colorMap2.NewColor = Color.Navy
        colorMap3.OldColor = Color.Blue
        colorMap3.NewColor = Color.Aqua
        ' Create an array of ColorMap objects
        ' because SetRemapTable takes an array
        Dim remapTable As ColorMap() = {colorMap1, colorMap2, colorMap3}
        imageAttributes.SetRemapTable(remapTable, ColorAdjustType.Bitmap)
        ' Draw Image
        g.DrawImage(image, 10, 10, image.Width, image.Height)
        ' Draw Image with color map
        g.DrawImage(image, New Rectangle(150, 10, image.Width, image.Height), 0, 0, image.Width, image.Height, GraphicsUnit.Pixel, imageAttributes)
        ' Dispose
        image.Dispose()
        g.Dispose()
    End Sub

    Private Sub ColorMatrix_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ColorMatrix.Click

    End Sub
End Class

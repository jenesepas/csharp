Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Imaging

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents JPEGCompression As System.Windows.Forms.MenuItem
    Friend WithEvents ConverttoPNG As System.Windows.Forms.MenuItem
    Friend WithEvents button1 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.JPEGCompression = New System.Windows.Forms.MenuItem
        Me.ConverttoPNG = New System.Windows.Forms.MenuItem
        Me.button1 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.JPEGCompression, Me.ConverttoPNG})
        Me.MenuItem1.Text = "Encoder/Decoder"
        '
        'JPEGCompression
        '
        Me.JPEGCompression.Index = 0
        Me.JPEGCompression.Text = "JPEG Compression"
        '
        'ConverttoPNG
        '
        Me.ConverttoPNG.Index = 1
        Me.ConverttoPNG.Text = "Convert to PNG"
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(56, 208)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(96, 32)
        Me.button1.TabIndex = 1
        Me.button1.Text = "Save Image"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(384, 294)
        Me.Controls.Add(Me.button1)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub JPEGCompression_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles JPEGCompression.Click
        Dim curBitmap As Bitmap
        Dim imgCodecInfo As ImageCodecInfo = Nothing
        Dim encoder As Encoder
        Dim encoderParam As EncoderParameter
        Dim encoderParams As New EncoderParameters(1)
        ' Create a Bitmap object based on a BMP file.
        curBitmap = New Bitmap("f:\Shapes.bmp")

        Dim j As Integer
        Dim mimeType As String = "image/jpeg"
        Dim encoders() As ImageCodecInfo
        encoders = ImageCodecInfo.GetImageEncoders()

        j = 0
        While j < encoders.Length
            If encoders(j).MimeType = mimeType Then
                imgCodecInfo = encoders(j)
            End If
        End While ' Jpeg Compression 
        encoder = encoder.Compression
        encoderParam = New EncoderParameter(encoder, 1, CInt(EncoderParameterValueType.ValueTypeLong), 0)
        encoderParams.Param(0) = encoderParam '
        curBitmap.Save("Shape0.jpg", imgCodecInfo, encoderParams)
    End Sub

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        Dim imgCodecInfo As ImageCodecInfo = Nothing
        Dim encoder As Encoder = Nothing
        Dim encoderParam As EncoderParameter = Nothing
        Dim encoderParams As New EncoderParameters(3)
        ' Create a Bitmap object from a file.
        Dim curBitmap As New Bitmap("roses.jpg")
        ' Define mimeType		   
        Dim mimeType As String = "image/tiff"
        Dim encoders() As ImageCodecInfo
        encoders = ImageCodecInfo.GetImageEncoders()
        Dim i As Integer

        While i < encoders.Length
            If encoders(i).MimeType = mimeType Then
                imgCodecInfo = encoders(i)
            End If
        End While ' Set color depth to 24 pixels
        encoder = encoder.ColorDepth
        encoderParam = New EncoderParameter(encoder, CLng(EncoderValue.CompressionLZW))
        encoderParams.Param(0) = encoderParam '
        ' Compression mode LZW
        encoder = encoder.Compression
        encoderParam = New EncoderParameter(encoder, CLng(EncoderValue.CompressionLZW))
        encoderParams.Param(1) = encoderParam '
        ' Set transformation 180 degrees
        encoder = encoder.Transformation
        encoderParam = New EncoderParameter(encoder, CLng(EncoderValue.TransformRotate180))
        encoderParams.Param(2) = encoderParam '
        ' Save file as a tif file
        curBitmap.Save("newFile.tif", imgCodecInfo, encoderParams)
        ' Dispose
        curBitmap.Dispose()
    End Sub

    Private Sub ConverttoPNG_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ConverttoPNG.Click
        Dim imgCodecInfo As ImageCodecInfo = Nothing
        ' Create a Bitmap from a file
        Dim curBitmap As New Bitmap("Shapes.bmp")
        Dim j As Integer
        ' Set mime type. This defines the format of
        ' the new file
        Dim mimeType As String = "image/png"
        Dim encoders() As ImageCodecInfo
        ' Get GDI+ built in image encoders 
        encoders = ImageCodecInfo.GetImageEncoders()
        ' Compare with our mime type and copy it to 
        ' ImageCodecInfo

        j = 0
        While j < encoders.Length
            If encoders(j).MimeType = mimeType Then
                imgCodecInfo = encoders(j)
            End If
        End While ' Save as png
        curBitmap.Save("Shape0.png", imgCodecInfo, Nothing)
        ' Dispose
        curBitmap.Dispose()
    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Imaging
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents GrayScaleMenu As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.GrayScaleMenu = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.GrayScaleMenu})
        Me.MenuItem1.Text = "Bitmap"
        '
        'GrayScaleMenu
        '
        Me.GrayScaleMenu.Index = 0
        Me.GrayScaleMenu.Text = "GrayScale - GetPixel SetPixel"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(392, 350)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub GrayScaleMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GrayScaleMenu.Click
        ' Create a Graphics object from a button
        ' or menu click event handler
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a Bitmap object 
        Dim curBitmap As New Bitmap("roses.jpg")
        ' Draw bitmap in its original color 
        g.DrawImage(curBitmap, 0, 0, curBitmap.Width, curBitmap.Height)
        ' Find out how much time it takes
        Dim startTime As DateTime = DateTime.Now
        ' Set each pixel to gray scale using GetPixel
        ' and SetPixel
        Dim i As Integer
        For i = 0 To curBitmap.Width - 1
            Dim j As Integer
            For j = 0 To curBitmap.Height - 1
                Dim curColor As Color = curBitmap.GetPixel(i, j)
                Dim ret As Integer = CInt((CInt(curColor.R) + CInt(curColor.G) + CInt(curColor.B)) / 3)
                curBitmap.SetPixel(i, j, Color.FromArgb(ret, ret, ret))
            Next j
        Next i
        ' Draw bitmap again with gray settings
        g.DrawImage(curBitmap, 0, 0, curBitmap.Width, curBitmap.Height)
        Dim endTime As DateTime = DateTime.Now
        Dim diffTime As TimeSpan = endTime.Subtract(startTime)
        MessageBox.Show(("Conversion time:" & diffTime.TotalMilliseconds.ToString()))
        'Dispose
        g.Dispose()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Imaging
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents NestedMenu As System.Windows.Forms.MenuItem
    Friend WithEvents MultipleCatchesMenu As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.NestedMenu = New System.Windows.Forms.MenuItem
        Me.MultipleCatchesMenu = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.NestedMenu, Me.MultipleCatchesMenu})
        Me.MenuItem1.Text = "Exception"
        '
        'NestedMenu
        '
        Me.NestedMenu.Index = 0
        Me.NestedMenu.Text = "Nested"
        '
        'MultipleCatchesMenu
        '
        Me.MultipleCatchesMenu.Index = 1
        Me.MultipleCatchesMenu.Text = "Multiple catches"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(464, 418)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub NestedMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NestedMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Try
            ' Create an Image from a file
            Dim curImage As Image = Image.FromFile("roses.jpg")
            ' Draw Image
            g.DrawImage(curImage, AutoScrollPosition.X, AutoScrollPosition.Y, curImage.Width, curImage.Height)
            ' Create second Image from a file
            Dim smallImage As Image = Image.FromFile("smallRoses.gif")
            ' Draw second image many times
            Dim x1, y1, x2, y2, w, h As Integer
            x1 = (x2 <= AutoScrollPosition.X) 'ToDo: Unsupported feature: assignment within expression. "=" changed to "<="
            y1 = AutoScrollPosition.Y
            y2 = 300
            w = 20
            h = 20
            ' Make a look to draw second image
            ' on top of the first image
            Dim i As Integer
            For i = 0 To 15
                Try
                    ' Draw top left to bottom right
                    g.DrawImage(smallImage, New Rectangle(x1, y1, w, h), 0, 0, smallImage.Width, smallImage.Height, GraphicsUnit.Pixel)
                    ' Draw top right to bottom left
                    g.DrawImage(smallImage, New Rectangle(x2, y2, w, h), 0, 0, smallImage.Width, smallImage.Height, GraphicsUnit.Pixel)
                    x1 += 20
                    y1 += 20
                    x2 += 20
                    y2 -= 20
                Catch memExp As OutOfMemoryException
                    MessageBox.Show(memExp.Message)
                End Try
            Next i
        Catch exp As Exception
            MessageBox.Show(exp.Message)
        Finally
            ' Dispose objects
            g.Dispose()
        End Try
    End Sub

    Private Sub MultipleCatchesMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MultipleCatchesMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Try
            ' Create an Image from a file
            Dim curImage As Image = Image.FromFile("roses.jpg")
            ' Draw Image
            g.DrawImage(curImage, AutoScrollPosition.X, AutoScrollPosition.Y, curImage.Width, curImage.Height)
            ' Create second Image from a file
            Dim smallImage As Image = Image.FromFile("smallRoses.gif")
            ' Draw second image many times
            Dim x1, y1, x2, y2, w, h As Integer
            x1 = (x2 <= AutoScrollPosition.X) 'ToDo: Unsupported feature: assignment within expression. "=" changed to "<="
            y1 = AutoScrollPosition.Y
            y2 = 300
            w = 20
            h = 20
            ' Make a look to draw second image
            ' on top of the first image
            Dim i As Integer
            For i = 0 To 15
                ' Draw top left to bottom right
                g.DrawImage(smallImage, New Rectangle(x1, y1, w, h), 0, 0, smallImage.Width, smallImage.Height, GraphicsUnit.Pixel)
                ' Draw top right to bottom left
                g.DrawImage(smallImage, New Rectangle(x2, y2, w, h), 0, 0, smallImage.Width, smallImage.Height, GraphicsUnit.Pixel)
                x1 += 20
                y1 += 20
                x2 += 20
                y2 -= 20
            Next i
        Catch memExp As OutOfMemoryException
            MessageBox.Show(memExp.Message)
        Catch exp As Exception
            MessageBox.Show(exp.Message)
        Finally
            ' Dispose objects
            g.Dispose()
        End Try
    End Sub
End Class

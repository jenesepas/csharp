
Imports System
Imports System.IO

Module Module1

    Sub Main()

        Try
            File.Open("c:\ErrorLog.txt", FileMode.Open)
        Catch exp As Exception
            Console.WriteLine(exp.Message)
        End Try
    End Sub

End Module



Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents CreateRectMenu As System.Windows.Forms.MenuItem
    Friend WithEvents CreaterectFmenu As System.Windows.Forms.MenuItem
    Friend WithEvents Propertiesmenu As System.Windows.Forms.MenuItem
    Friend WithEvents MethodsMenu As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.CreateRectMenu = New System.Windows.Forms.MenuItem
        Me.CreaterectFmenu = New System.Windows.Forms.MenuItem
        Me.Propertiesmenu = New System.Windows.Forms.MenuItem
        Me.MethodsMenu = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.CreateRectMenu, Me.CreaterectFmenu, Me.Propertiesmenu, Me.MethodsMenu})
        Me.MenuItem1.Text = "Rectangles"
        '
        'CreateRectMenu
        '
        Me.CreateRectMenu.Index = 0
        Me.CreateRectMenu.Text = "Create Rectangles"
        '
        'CreaterectFmenu
        '
        Me.CreaterectFmenu.Index = 1
        Me.CreaterectFmenu.Text = "Create RectangleF"
        '
        'Propertiesmenu
        '
        Me.Propertiesmenu.Index = 2
        Me.Propertiesmenu.Text = "Properties"
        '
        'MethodsMenu
        '
        Me.MethodsMenu.Index = 3
        Me.MethodsMenu.Text = "Methods"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(336, 322)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub CreateRectMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateRectMenu.Click
        Dim x As Integer = 20
        Dim y As Integer = 30
        Dim height As Integer = 30
        Dim width As Integer = 30
        ' Create a Point
        Dim pt As New Point(10, 10)
        ' Create a Size
        Dim sz As New Size(60, 40)
        ' Create a Rectangle from point
        ' and size
        Dim rect1 As New Rectangle(pt, sz)
        Dim rect2 As New Rectangle(x, y, width, height)
    End Sub

    Private Sub CreaterectFmenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreaterectFmenu.Click
        ' Create a Point
        Dim pt As New PointF(30.8F, 20.7F)
        ' Create a Size
        Dim sz As New SizeF(60.0F, 40.0F)
        ' Create a Rectangle from a Point and 
        ' a Size
        Dim rect1 As New RectangleF(pt, sz)
        ' Create a Rectangle from floating points
        Dim rect2 As New RectangleF(40.2F, 40.6F, 100.5F, 100.0F)
    End Sub

    Private Sub Propertiesmenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Propertiesmenu.Click
        ' Create a Point
        Dim pt As New PointF(30.8F, 20.7F)
        ' Create a Size
        Dim sz As New SizeF(60.0F, 40.0F)
        ' Create a Rectangle from a Point and 
        ' a Size
        Dim rect1 As New RectangleF(pt, sz)
        ' Create a Rectangle from floating points
        Dim rect2 As New RectangleF(40.2F, 40.6F, 100.5F, 100.0F)
        ' If rectangle is empty
        ' Set its Location, Widht, and Height
        ' Properties
        If rect1.IsEmpty Then
            rect1.Location = pt
            rect1.Width = sz.Width
            rect1.Height = sz.Height
        End If
        ' Read properties and display
        Dim str As String = "Location:" + rect1.Location.ToString()
        str += "X:" + rect1.X.ToString() + ControlChars.Lf
        str += "Y:" + rect1.Y.ToString() + ControlChars.Lf
        str += "Left:" + rect1.Left.ToString() + ControlChars.Lf
        str += "Right:" + rect1.Right.ToString() + ControlChars.Lf
        str += "Top:" + rect1.Top.ToString() + ControlChars.Lf
        str += "Bottom:" + rect1.Bottom.ToString()
        MessageBox.Show(str)
    End Sub

    Private Sub MethodsMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MethodsMenu.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        ' Create a Point & Size
        Dim pt As New PointF(30.8F, 20.7F)
        Dim sz As New SizeF(60.0F, 40.0F)
        ' Create two rectangles
        Dim rect1 As New RectangleF(pt, sz)
        Dim rect2 As New RectangleF(40.2F, 40.6F, 100.5F, 100.0F)
        ' Ceiling a rectangle
        Dim rect3 As Rectangle = Rectangle.Ceiling(rect1)
        ' Truncate a rectangle
        Dim rect4 As Rectangle = Rectangle.Truncate(rect1)
        ' Round a rectangle
        Dim rect5 As Rectangle = Rectangle.Round(rect2)
        ' Draw rectangles
        g.DrawRectangle(Pens.Black, rect3)
        g.DrawRectangle(Pens.Red, rect5)
        ' Intersect a rectangle
        Dim isectRect As Rectangle = Rectangle.Intersect(rect3, rect5)
        ' Fill rectangle
        g.FillRectangle(New SolidBrush(Color.Blue), isectRect)
        ' Inflate a recntangle
        Dim inflateSize As New Size(0, 40)
        isectRect.Inflate(inflateSize)
        ' Draw rectangle
        g.DrawRectangle(Pens.Blue, isectRect)
        ' Empty rectangle and set its properties
        rect4 = Rectangle.Empty
        rect4.Location = New Point(50, 50)
        rect4.X = 30
        rect4.Y = 40
        ' Union rectangles
        Dim unionRect As Rectangle = Rectangle.Union(rect4, rect5)
        ' Draw rectangle
        g.DrawRectangle(Pens.Green, unionRect)
        ' Displose 
        g.Dispose()
    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D

Public Class Form1
    Inherits System.Windows.Forms.Form
    Private originalSize As Size

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents AnimationBtn As System.Windows.Forms.Button
    Friend WithEvents VideoBtn As System.Windows.Forms.Button
    Friend WithEvents AudioBtn As System.Windows.Forms.Button
    Friend WithEvents ContextMenu1 As System.Windows.Forms.ContextMenu
    Friend WithEvents Circlemenu As System.Windows.Forms.MenuItem
    Friend WithEvents RectMenu As System.Windows.Forms.MenuItem
    Friend WithEvents TriangleMenu As System.Windows.Forms.MenuItem
    Friend WithEvents CloseMenu As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.AnimationBtn = New System.Windows.Forms.Button
        Me.VideoBtn = New System.Windows.Forms.Button
        Me.AudioBtn = New System.Windows.Forms.Button
        Me.ContextMenu1 = New System.Windows.Forms.ContextMenu
        Me.Circlemenu = New System.Windows.Forms.MenuItem
        Me.RectMenu = New System.Windows.Forms.MenuItem
        Me.TriangleMenu = New System.Windows.Forms.MenuItem
        Me.CloseMenu = New System.Windows.Forms.MenuItem
        Me.SuspendLayout()
        '
        'AnimationBtn
        '
        Me.AnimationBtn.BackColor = System.Drawing.Color.Blue
        Me.AnimationBtn.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold)
        Me.AnimationBtn.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.AnimationBtn.Location = New System.Drawing.Point(120, 146)
        Me.AnimationBtn.Name = "AnimationBtn"
        Me.AnimationBtn.Size = New System.Drawing.Size(152, 104)
        Me.AnimationBtn.TabIndex = 6
        Me.AnimationBtn.Text = "Animation"
        '
        'VideoBtn
        '
        Me.VideoBtn.BackColor = System.Drawing.Color.Green
        Me.VideoBtn.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold)
        Me.VideoBtn.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.VideoBtn.Location = New System.Drawing.Point(208, 26)
        Me.VideoBtn.Name = "VideoBtn"
        Me.VideoBtn.Size = New System.Drawing.Size(160, 96)
        Me.VideoBtn.TabIndex = 5
        Me.VideoBtn.Text = "Play Video"
        '
        'AudioBtn
        '
        Me.AudioBtn.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(128, Byte), CType(0, Byte))
        Me.AudioBtn.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold)
        Me.AudioBtn.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.AudioBtn.Location = New System.Drawing.Point(96, 26)
        Me.AudioBtn.Name = "AudioBtn"
        Me.AudioBtn.Size = New System.Drawing.Size(160, 96)
        Me.AudioBtn.TabIndex = 4
        Me.AudioBtn.Text = "Play Audio"
        '
        'ContextMenu1
        '
        Me.ContextMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.Circlemenu, Me.RectMenu, Me.TriangleMenu, Me.CloseMenu})
        '
        'Circlemenu
        '
        Me.Circlemenu.Index = 0
        Me.Circlemenu.Text = "Circle"
        '
        'RectMenu
        '
        Me.RectMenu.Index = 1
        Me.RectMenu.Text = "Original"
        '
        'TriangleMenu
        '
        Me.TriangleMenu.Index = 2
        Me.TriangleMenu.Text = "TriangleMenu"
        '
        'CloseMenu
        '
        Me.CloseMenu.Index = 3
        Me.CloseMenu.Text = "Close"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(464, 277)
        Me.Controls.Add(Me.AnimationBtn)
        Me.Controls.Add(Me.VideoBtn)
        Me.Controls.Add(Me.AudioBtn)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        originalSize = Me.Size
        ' Create a Region object from the path
        Dim path1 As New GraphicsPath(FillMode.Alternate)
        path1.AddEllipse(New Rectangle(30, 30, AudioBtn.Width - 60, AudioBtn.Height - 60))
        AudioBtn.Region = New [Region](path1)

        Dim path2 As New GraphicsPath(FillMode.Alternate)
        path2.AddEllipse(New Rectangle(30, 30, VideoBtn.Width - 60, VideoBtn.Height - 60))
        VideoBtn.Region = New [Region](path2)

        Dim path3 As New GraphicsPath(FillMode.Alternate)
        path3.AddEllipse(New Rectangle(20, 20, VideoBtn.Width - 40, VideoBtn.Height - 40))
        AnimationBtn.Region = New [Region](path3)
    End Sub

    Private Sub Circlemenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Circlemenu.Click
        ' Create a rectangle
        Dim rect As New Rectangle(50, 0, 300, 300)
        ' Create a Shape object and call 
        ' GetRectRegion method 
        Dim shp As New Shape
        Me.Region = shp.GetRectRegion(rect)
        Me.BackColor = Color.BurlyWood
    End Sub

    Private Sub RectMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RectMenu.Click
        ' A Points array for a rectangle
        ' Same points as the original form
        Dim pts As Point() = {New Point(0, 0), New Point(0, originalSize.Height), New Point(originalSize.Width, originalSize.Height), New Point(originalSize.Width, 0)}
        ' Create a Shape object and call 
        ' GetPolyRegion method 
        Dim shp As New Shape
        Me.Region = shp.GetPolyRegion(pts)
        ' Set background color
        Me.BackColor = Color.DarkGoldenrod
    End Sub

    Private Sub TriangleMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TriangleMenu.Click
        ' Add three lines to the path representing
        ' three sides of a triangle
        Dim pts As Point() = {New Point(50, 0), New Point(0, 300), New Point(300, 300), New Point(50, 0)}
        Me.BackColor = Color.CornflowerBlue
        ' Create a Shape object and call 
        ' GetPolyRegion method 
        Dim shp As New Shape
        Me.Region = shp.GetPolyRegion(pts)
    End Sub

    Protected Overrides Sub OnMouseDown(ByVal e As MouseEventArgs)
        If e.Button = MouseButtons.Right Then
            Me.ContextMenu = Me.ContextMenu1
        End If
    End Sub

    Private Sub CloseMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CloseMenu.Click
        Me.Close()
    End Sub


    Private Sub AudioBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AudioBtn.Click
        MessageBox.Show("Play Audio Button clicked!")
    End Sub

    Private Sub VideoBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles VideoBtn.Click
        MessageBox.Show("Play Video Button clicked!")
    End Sub

    Private Sub AnimationBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AnimationBtn.Click
        MessageBox.Show("Play Animation Button clicked!")
    End Sub
End Class

Public Class Shape
    Public Sub New()
    End Sub 'New

    Public Function GetPolyRegion(ByVal pts() As Point) As [Region]
        ' Create a graphics path
        Dim path As New GraphicsPath(FillMode.Alternate)
        path.AddPolygon(pts)
        ' Create a Region object from the path
        ' and set it as the form's region
        Dim rgn As New [Region](path)
        Return rgn
    End Function 'GetPolyRegion

    Public Function GetRectRegion(ByVal rct As Rectangle) As [Region]
        ' Create a graphics path
        Dim path As New GraphicsPath(FillMode.Alternate)
        path.AddEllipse(rct)
        ' Create a Region object from the path
        ' and set it as the form's region
        Dim rgn As New [Region](path)
        Return rgn
    End Function 'GetRectRegion
End Class 'Shape

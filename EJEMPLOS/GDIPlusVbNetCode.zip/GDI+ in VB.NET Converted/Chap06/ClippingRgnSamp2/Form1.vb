Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents xormenu As System.Windows.Forms.MenuItem
    Friend WithEvents UnionMenu As System.Windows.Forms.MenuItem
    Friend WithEvents ExcludeMenu As System.Windows.Forms.MenuItem
    Friend WithEvents IntersectMenu As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.xormenu = New System.Windows.Forms.MenuItem
        Me.UnionMenu = New System.Windows.Forms.MenuItem
        Me.ExcludeMenu = New System.Windows.Forms.MenuItem
        Me.IntersectMenu = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.xormenu, Me.UnionMenu, Me.ExcludeMenu, Me.IntersectMenu})
        Me.MenuItem1.Text = "Operation"
        '
        'xormenu
        '
        Me.xormenu.Index = 0
        Me.xormenu.Text = "XOR"
        '
        'UnionMenu
        '
        Me.UnionMenu.Index = 1
        Me.UnionMenu.Text = "Union"
        '
        'ExcludeMenu
        '
        Me.ExcludeMenu.Index = 2
        Me.ExcludeMenu.Text = "Exclude"
        '
        'IntersectMenu
        '
        Me.IntersectMenu.Index = 3
        Me.IntersectMenu.Text = "Intersect"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(272, 230)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Clipping Regions Sample"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub xormenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles xormenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim pen As New Pen(Color.Red, 5)
        Dim brush As New SolidBrush(Color.Red)
        Dim rect1 As New Rectangle(50, 0, 50, 150)
        Dim rect2 As New Rectangle(0, 50, 150, 50)
        Dim [region] As New [Region](rect1)
        [region].Xor(rect2)
        g.FillRegion(brush, [region])
        g.Dispose()
    End Sub

    Private Sub UnionMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UnionMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim pen As New Pen(Color.Red, 5)
        Dim brush As New SolidBrush(Color.Red)
        Dim rect1 As New Rectangle(50, 0, 50, 150)
        Dim rect2 As New Rectangle(0, 50, 150, 50)
        Dim [region] As New [Region](rect1)
        [region].Union(rect2)
        g.FillRegion(brush, [region])
        g.Dispose()
    End Sub

    Private Sub ExcludeMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExcludeMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim pen As New Pen(Color.Red, 5)
        Dim brush As New SolidBrush(Color.Red)
        Dim rect1 As New Rectangle(50, 0, 50, 150)
        Dim rect2 As New Rectangle(0, 50, 150, 50)
        Dim [region] As New [Region](rect1)
        [region].Exclude(rect2)
        g.FillRegion(brush, [region])
        g.Dispose()
    End Sub

    Private Sub IntersectMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles IntersectMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim pen As New Pen(Color.Red, 5)
        Dim brush As New SolidBrush(Color.Red)
        Dim rect1 As New Rectangle(50, 0, 50, 150)
        Dim rect2 As New Rectangle(0, 50, 150, 50)
        Dim [region] As New [Region](rect1)
        [region].Intersect(rect2)
        g.FillRegion(brush, [region])
        g.Dispose()
    End Sub
End Class

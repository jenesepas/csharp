Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D

Public Class Form1
    Inherits System.Windows.Forms.Form
    Private options As Integer = 0

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem7 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem8 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem9 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem10 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem11 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem12 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem13 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem14 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem15 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem16 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem17 As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.MenuItem5 = New System.Windows.Forms.MenuItem
        Me.MenuItem6 = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.MenuItem3 = New System.Windows.Forms.MenuItem
        Me.MenuItem7 = New System.Windows.Forms.MenuItem
        Me.MenuItem8 = New System.Windows.Forms.MenuItem
        Me.MenuItem9 = New System.Windows.Forms.MenuItem
        Me.MenuItem10 = New System.Windows.Forms.MenuItem
        Me.MenuItem11 = New System.Windows.Forms.MenuItem
        Me.MenuItem12 = New System.Windows.Forms.MenuItem
        Me.MenuItem13 = New System.Windows.Forms.MenuItem
        Me.MenuItem14 = New System.Windows.Forms.MenuItem
        Me.MenuItem4 = New System.Windows.Forms.MenuItem
        Me.MenuItem15 = New System.Windows.Forms.MenuItem
        Me.MenuItem16 = New System.Windows.Forms.MenuItem
        Me.MenuItem17 = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem2, Me.MenuItem3, Me.MenuItem4})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem5, Me.MenuItem6})
        Me.MenuItem1.Text = "Rectangle"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 0
        Me.MenuItem5.Text = "Round, Trancate and other methods  "
        '
        'MenuItem6
        '
        Me.MenuItem6.Index = 1
        Me.MenuItem6.Text = "Contains"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.Text = "RectangleF"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 2
        Me.MenuItem3.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem7, Me.MenuItem8, Me.MenuItem9, Me.MenuItem10, Me.MenuItem11, Me.MenuItem12, Me.MenuItem13, Me.MenuItem14})
        Me.MenuItem3.Text = "Region"
        '
        'MenuItem7
        '
        Me.MenuItem7.Index = 0
        Me.MenuItem7.Text = "Construct"
        '
        'MenuItem8
        '
        Me.MenuItem8.Index = 1
        Me.MenuItem8.Text = "Complement"
        '
        'MenuItem9
        '
        Me.MenuItem9.Index = 2
        Me.MenuItem9.Text = "Empty and Others"
        '
        'MenuItem10
        '
        Me.MenuItem10.Index = 3
        Me.MenuItem10.Text = "Exclude"
        '
        'MenuItem11
        '
        Me.MenuItem11.Index = 4
        Me.MenuItem11.Text = "Union"
        '
        'MenuItem12
        '
        Me.MenuItem12.Index = 5
        Me.MenuItem12.Text = "Xor"
        '
        'MenuItem13
        '
        Me.MenuItem13.Index = 6
        Me.MenuItem13.Text = "Intersect"
        '
        'MenuItem14
        '
        Me.MenuItem14.Index = 7
        Me.MenuItem14.Text = "Excl"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 3
        Me.MenuItem4.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem15, Me.MenuItem16, Me.MenuItem17})
        Me.MenuItem4.Text = "Clipping"
        '
        'MenuItem15
        '
        Me.MenuItem15.Index = 0
        Me.MenuItem15.Text = "Exclude Clip"
        '
        'MenuItem16
        '
        Me.MenuItem16.Index = 1
        Me.MenuItem16.Text = "Set Clip"
        '
        'MenuItem17
        '
        Me.MenuItem17.Index = 2
        Me.MenuItem17.Text = "Translate Clip"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(368, 294)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        If options = 1 Then
            Dim pt As New PointF(30.8F, 20.7F)
            Dim sz As New SizeF(60.0F, 40.0F)
            Dim rect2 As New RectangleF(40.2F, 40.6F, 100.5F, 100.0F)
            Dim rect1 As New RectangleF(pt, sz)

            Dim rect3 As Rectangle = Rectangle.Ceiling(rect1)
            Dim rect4 As Rectangle = Rectangle.Truncate(rect1)
            Dim rect5 As Rectangle = Rectangle.Round(rect2)
            e.Graphics.DrawRectangle(Pens.Black, rect3)
            e.Graphics.DrawRectangle(Pens.Red, rect5)
            Dim isectRect As Rectangle = Rectangle.Intersect(rect3, rect5)
            e.Graphics.FillRectangle(New SolidBrush(Color.Blue), isectRect)
            Dim inflateSize As New Size(0, 40)
            isectRect.Inflate(inflateSize)
            e.Graphics.DrawRectangle(Pens.Blue, isectRect)
            rect4 = Rectangle.Empty
            rect4.Location = New Point(50, 50)
            rect4.X = 30
            rect4.Y = 40
            Dim unionRect As Rectangle = Rectangle.Union(rect4, rect5)
            e.Graphics.DrawRectangle(Pens.Green, unionRect)
        End If
        If options = 2 Then
            Dim pt As New Point(0, 0)
            Dim sz As New Size(200, 200)
            Dim bigRect As New Rectangle(pt, sz)
            Dim smallRect As New Rectangle(30, 20, 100, 100)
            'if (bigRect.Contains(smallRect) )
            '	MessageBox.Show("Rectangle "+smallRect.ToString() 
            '	+" is inside Rectangle "+ bigRect.ToString() )
            e.Graphics.DrawRectangle(Pens.Green, bigRect)
        End If
    End Sub

    Private Sub MenuItem5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem5.Click
        options = 1
        Me.Invalidate(Me.ClientRectangle)
    End Sub

    Private Sub MenuItem6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem6.Click
        options = 2
        Me.Invalidate(Me.ClientRectangle)
    End Sub
    Protected Overrides Sub OnMouseDown(ByVal e As MouseEventArgs)
        If e.Button = MouseButtons.Left Then '
            Dim pt As New Point(0, 0)
            Dim sz As New Size(200, 200)
            Dim bigRect As New Rectangle(pt, sz)
            If bigRect.Contains(New Point(e.X, e.Y)) Then
                MessageBox.Show("Clicked inside rectangle")
            Else
                MessageBox.Show("Clicked outside rectangle")
            End If
        End If
    End Sub

    Private Sub MenuItem7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem7.Click
        ' Create two rectangle
        Dim rect1 As New Rectangle(20, 20, 60, 80)
        Dim rect2 As New RectangleF(100, 20, 60, 100)
        ' Create a Graphics path
        Dim path As New GraphicsPath
        ' Add a rectangle to graphics path
        path.AddRectangle(rect1)
        ' Create a Region from rect1
        Dim rectRgn1 As New [Region](rect1)
        ' Create a Region from rect2
        Dim rectRgn2 As New [Region](rect2)
        ' Create a Region from GraphicsPath
        Dim pathRgn As New [Region](path)
    End Sub

    Private Sub MenuItem8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem8.Click
        ' Create a Graphics
        Dim g As Graphics = Me.CreateGraphics()
        ' Create two Rectangles
        Dim rect1 As New Rectangle(20, 20, 60, 80)
        Dim rect2 As New Rectangle(50, 30, 60, 80)
        ' Create two Regions
        Dim rgn1 As New [Region](rect1)
        Dim rgn2 As New [Region](rect2)
        ' Draw rectangles
        g.DrawRectangle(Pens.Green, rect1)
        g.DrawRectangle(Pens.Black, rect2)
        ' Complement can take a Rectangle, RectangleF,
        ' Region or a GraphicsPath as an argument
        rgn1.Complement(rgn2)
        ' rgn1.Complement(rect2);			
        g.FillRegion(Brushes.Blue, rgn1)
        ' Dispose 
        g.Dispose()
    End Sub

    Private Sub MenuItem9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem9.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create Rectangles and Regions
        Dim rect1 As New Rectangle(20, 20, 60, 80)
        Dim rect2 As New Rectangle(50, 30, 60, 80)
        Dim rgn1 As New [Region](rect1)
        Dim rgn2 As New [Region](rect2)
        ' If Region is not empty, empty it
        If Not rgn1.IsEmpty(g) Then
            rgn1.MakeEmpty()
        End If ' If Region is not infinite, infinite 
        ' it
        If Not rgn2.IsInfinite(g) Then
            rgn2.MakeInfinite()
        End If ' Get bounds of the infinite region
        Dim rect As RectangleF = rgn2.GetBounds(g)
        ' Display
        MessageBox.Show(rect.ToString())
        ' Fill the region			
        g.FillRegion(Brushes.Red, rgn2)
        ' Dispose 
        g.Dispose()
    End Sub

    Private Sub MenuItem10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem10.Click
        ' Create Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create Rectangles
        Dim rect1 As New Rectangle(20, 20, 60, 80)
        Dim rect2 As New Rectangle(50, 30, 60, 80)
        ' Create Regions
        Dim rgn1 As New [Region](rect1)
        Dim rgn2 As New [Region](rect2)
        ' Draw rectangles
        g.DrawRectangle(Pens.Green, rect1)
        g.DrawRectangle(Pens.Black, rect2)
        ' Exclued the region
        rgn1.Exclude(rgn2)
        ' Fill region after exclude	
        g.FillRegion(Brushes.Blue, rgn1)
        ' Dispose 
        g.Dispose()
    End Sub

    Private Sub MenuItem11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem11.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim rect1 As New Rectangle(20, 20, 60, 80)
        Dim rect2 As New Rectangle(50, 30, 60, 80)
        Dim rgn1 As New [Region](rect1)
        Dim rgn2 As New [Region](rect2)
        g.DrawRectangle(Pens.Green, rect1)
        g.DrawRectangle(Pens.Black, rect2)
        ' Complement can take a Rectangle, RectangleF,
        ' Region or a GraphicsPath as an argument
        rgn1.Union(rgn2)
        ' rgn1.Complement(rect2);			
        g.FillRegion(Brushes.Blue, rgn1)

        ' Dispose 
        g.Dispose()
    End Sub

    Private Sub MenuItem12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem12.Click
        ' Create Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create Rectangles
        Dim rect1 As New Rectangle(20, 20, 60, 80)
        Dim rect2 As New Rectangle(50, 30, 60, 80)
        ' Create Regions
        Dim rgn1 As New [Region](rect1)
        Dim rgn2 As New [Region](rect2)
        ' Draw Rectangles
        g.DrawRectangle(Pens.Green, rect1)
        g.DrawRectangle(Pens.Black, rect2)
        ' Xoring two regions
        rgn1.Xor(rgn2)
        ' Fill the region after Xoring
        g.FillRegion(Brushes.Blue, rgn1)
        ' Dispose 
        g.Dispose()
    End Sub

    Private Sub MenuItem13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem13.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim rect1 As New Rectangle(20, 20, 60, 80)
        Dim rect2 As New Rectangle(50, 30, 60, 80)
        Dim rgn1 As New [Region](rect1)
        Dim rgn2 As New [Region](rect2)
        g.DrawRectangle(Pens.Green, rect1)
        g.DrawRectangle(Pens.Black, rect2)
        ' Complement can take a Rectangle, RectangleF,
        ' Region or a GraphicsPath as an argument
        rgn1.Intersect(rgn2)
        ' rgn1.Complement(rect2);			
        g.FillRegion(Brushes.Blue, rgn1)

        ' Dispose 
        g.Dispose()
    End Sub

    Private Sub MenuItem15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem15.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create Rectangles
        Dim rect1 As New Rectangle(20, 20, 60, 80)
        Dim rect2 As New Rectangle(100, 100, 30, 40)
        ' Create a Region
        Dim rgn1 As New [Region](rect2)
        ' Exclued Clip
        g.ExcludeClip(rect1)
        g.ExcludeClip(rgn1)
        ' Fill rectangle
        g.FillRectangle(Brushes.Red, 0, 0, 200, 200)
        ' Dispose 
        g.Dispose()
    End Sub

    Private Sub MenuItem16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem16.Click
        ' Create the Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create Rectangles and Regions
        Dim rect1 As New Rectangle(20, 20, 200, 200)
        Dim rect2 As New Rectangle(100, 100, 200, 200)
        Dim rgn1 As New [Region](rect1)
        Dim rgn2 As New [Region](rect2)
        ' Call SetClip
        g.SetClip(rgn1, CombineMode.Exclude)
        ' Call IntersetClip
        g.IntersectClip(rgn2)
        ' Fill Rectangle
        g.FillRectangle(Brushes.Red, 0, 0, 300, 300)
        ' ResetClip
        g.ResetClip()
        ' Draw rectangles
        g.DrawRectangle(Pens.Green, rect1)
        g.DrawRectangle(Pens.Yellow, rect2)
        ' Dispose 
        g.Dispose()
    End Sub

    Private Sub MenuItem17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem17.Click
        ' Create the Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a RectangleF
        Dim rect1 As New RectangleF(20.0F, 20.0F, 200.0F, 200.0F)
        ' Create a Region
        Dim rgn1 As New [Region](rect1)
        ' Call SetClip
        g.SetClip(rgn1, CombineMode.Exclude)
        Dim h As Single = 20.0F
        Dim w As Single = 30.0F
        ' Call TranslateClip
        g.TranslateClip(h, w)
        ' Fill rectangle
        g.FillRectangle(Brushes.Green, 20, 20, 300, 300)
    End Sub
End Class

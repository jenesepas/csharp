Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Text
Imports System.Drawing.Printing
Imports System.IO

Public Class Form1
    Inherits System.Windows.Forms.Form
    Private comboBox1 As System.Windows.Forms.ComboBox
    Private label1 As System.Windows.Forms.Label
    Private numericUpDown1 As System.Windows.Forms.NumericUpDown
    Private label2 As System.Windows.Forms.Label
    Private button1 As System.Windows.Forms.Button
    Private richTextBox1 As System.Windows.Forms.RichTextBox
    Private button2 As System.Windows.Forms.Button
    Private textColor As Color
    Private textSize As Integer
    Private mainMenu1 As System.Windows.Forms.MainMenu
    Private menuItem1 As System.Windows.Forms.MenuItem
    Private OpenFile As System.Windows.Forms.MenuItem
    Private fileSystemWatcher1 As System.IO.FileSystemWatcher

    Private Shared noFilename As String = "Untitled"
    Private curFilename As String = Nothing
    Private dirty As Boolean = False
    Private fileOnDiskModified As Boolean = False
    Private storedPageSettings As PageSettings = Nothing


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.comboBox1 = New System.Windows.Forms.ComboBox
        Me.label1 = New System.Windows.Forms.Label
        Me.numericUpDown1 = New System.Windows.Forms.NumericUpDown
        Me.label2 = New System.Windows.Forms.Label
        Me.button1 = New System.Windows.Forms.Button
        Me.richTextBox1 = New System.Windows.Forms.RichTextBox
        Me.button2 = New System.Windows.Forms.Button
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.OpenFile = New System.Windows.Forms.MenuItem
        Me.fileSystemWatcher1 = New System.IO.FileSystemWatcher
        CType(Me.numericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.fileSystemWatcher1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'comboBox1
        '
        Me.comboBox1.Location = New System.Drawing.Point(8, 112)
        Me.comboBox1.Name = "comboBox1"
        Me.comboBox1.Size = New System.Drawing.Size(152, 24)
        Me.comboBox1.TabIndex = 0
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(8, 88)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(104, 24)
        Me.label1.TabIndex = 1
        Me.label1.Text = "Available Fonts"
        '
        'numericUpDown1
        '
        Me.numericUpDown1.Location = New System.Drawing.Point(184, 112)
        Me.numericUpDown1.Name = "numericUpDown1"
        Me.numericUpDown1.Size = New System.Drawing.Size(48, 24)
        Me.numericUpDown1.TabIndex = 2
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(184, 88)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(56, 24)
        Me.label2.TabIndex = 3
        Me.label2.Text = "Size"
        '
        'button1
        '
        Me.button1.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(128, Byte), CType(0, Byte))
        Me.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.button1.Location = New System.Drawing.Point(240, 112)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(80, 24)
        Me.button1.TabIndex = 6
        Me.button1.Text = "Color"
        AddHandler button1.Click, AddressOf button1_Click
        '
        'richTextBox1
        '
        Me.richTextBox1.BackColor = System.Drawing.SystemColors.Info
        Me.richTextBox1.Location = New System.Drawing.Point(8, 144)
        Me.richTextBox1.Name = "richTextBox1"
        Me.richTextBox1.Size = New System.Drawing.Size(648, 248)
        Me.richTextBox1.TabIndex = 7
        Me.richTextBox1.Text = "richTextBox1"
        '
        'button2
        '
        Me.button2.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold)
        Me.button2.Location = New System.Drawing.Point(408, 112)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(80, 32)
        Me.button2.TabIndex = 8
        Me.button2.Text = "Apply"
        AddHandler button2.Click, AddressOf button2_Click
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.OpenFile})
        Me.menuItem1.Text = "&File"
        '
        'OpenFile
        '
        Me.OpenFile.Index = 0
        Me.OpenFile.Text = "&Open File"
        AddHandler OpenFile.Click, AddressOf OpenFile_Click
        '
        'fileSystemWatcher1
        '
        Me.fileSystemWatcher1.EnableRaisingEvents = True
        Me.fileSystemWatcher1.SynchronizingObject = Me
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(7, 17)
        Me.BackColor = System.Drawing.Color.Teal
        Me.ClientSize = New System.Drawing.Size(664, 397)
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.richTextBox1)
        Me.Controls.Add(Me.button1)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.numericUpDown1)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.comboBox1)
        Me.Font = New System.Drawing.Font("Tahoma", 10.0!)
        Me.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "GDI+ Editor - A Simple Text Editor"
        CType(Me.numericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.fileSystemWatcher1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
   

#End Region

    '<STAThread()> _
    'Sub Main()
    '    Application.Run(New Form1)
    'End Sub 'Main
    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim colorDlg As New ColorDialog
        If colorDlg.ShowDialog() = DialogResult.OK Then
            textColor = colorDlg.Color
        End If
    End Sub

    Private Sub button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        textSize = CInt(numericUpDown1.Value)
        Dim selFont As String = comboBox1.SelectedText
        Dim textFont As New Font(selFont, textSize)
        richTextBox1.ForeColor = textColor
        richTextBox1.Font = textFont

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        numericUpDown1.Value = 10

        ' Create InstalledFontCollection object
        Dim sysFontCollection As New InstalledFontCollection

        ' Get the array of FontFamily objects.
        Dim fontFamilies() As FontFamily = sysFontCollection.Families
        ' Read all font familes and add to the combo box
        Dim i As Integer

        While i < fontFamilies.Length
            comboBox1.Items.Add(fontFamilies(i).Name)
            i = i + 1
        End While
        comboBox1.Select(0, 20)

    End Sub

    Private Sub OpenFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim openDlg As New OpenFileDialog
        If openDlg.ShowDialog() = DialogResult.OK Then
            curFilename = openDlg.FileName
            ReadTextFile()
        End If
    End Sub
    Private Sub ReadTextFile()
        AddHandler richTextBox1.TextChanged, AddressOf richTextBox1_TextChanged
        fileSystemWatcher1.EnableRaisingEvents = False
        Try
            ' Open the file as a stream
            Dim fs = New FileStream(curFilename, FileMode.Open)
            Dim filInfo As New FileInfo(curFilename)
            ' Get the file extension
            Dim extn As String = filInfo.Extension.ToUpper()
            ' See if file is rich text format, Load it with 
            ' RichText option. Otherwise PlainText
            If extn.Equals(".RTF") Then
                richTextBox1.LoadFile(fs, RichTextBoxStreamType.RichText)
            Else
                richTextBox1.LoadFile(fs, RichTextBoxStreamType.PlainText)
            End If ' Close stream
            fs.Close()
            fileSystemWatcher1.Path = filInfo.DirectoryName
            fileSystemWatcher1.Filter = filInfo.Name

        Catch exp As Exception
            MessageBox.Show(exp.Message.ToString())
        Finally
            AddHandler richTextBox1.TextChanged, AddressOf richTextBox1_TextChanged
            fileSystemWatcher1.EnableRaisingEvents = True
        End Try
    End Sub 'ReadTextFile




    Private Sub richTextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub


End Class

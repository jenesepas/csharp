Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Text

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem2})
        Me.MenuItem1.Text = "PFC"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 0
        Me.MenuItem2.Text = "Add"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(328, 294)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub MenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem2.Click
        Dim g As Graphics = Me.CreateGraphics()
        Dim pointF As New PointF(10, 20)
        Dim fontName As String
        ' Create a PrivateFontCollection
        Dim pfc As New PrivateFontCollection
        ' Add font files to the private font collection
        pfc.AddFontFile("tekhead.ttf")
        pfc.AddFontFile("DELUSION.TTF")
        pfc.AddFontFile("HEMIHEAD.TTF")
        pfc.AddFontFile("C:\WINNT\Fonts\Verdana.ttf")
        ' Return all font families from the collection
        Dim fontFamilies As FontFamily() = pfc.Families
        ' Get font families one by one, 
        ' add new styles and draw 
        ' text using DrawString
        Dim j As Integer

        While j < fontFamilies.Length
            ' Get the font family name.
            fontName = fontFamilies(j).Name

            If fontFamilies(j).IsStyleAvailable(FontStyle.Italic) And fontFamilies(j).IsStyleAvailable(FontStyle.Bold) And fontFamilies(j).IsStyleAvailable(FontStyle.Underline) And fontFamilies(j).IsStyleAvailable(FontStyle.Strikeout) Then
                ' Create a font from font name
                Dim newFont As New Font(fontName, 20, FontStyle.Italic Or FontStyle.Bold Or FontStyle.Underline, GraphicsUnit.Pixel)
                ' Draw string using the current font
                g.DrawString(fontName, newFont, New SolidBrush(Color.Red), pointF)
                ' Set location
                pointF.Y += newFont.Height
            End If
        End While
        ' Dispose
        g.Dispose()
    End Sub
End Class

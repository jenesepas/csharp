Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Text

Public Class FontCollectionSamp
    Inherits System.Windows.Forms.Form
    Private textColor As Color
    Private textSize As Integer

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents comboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents numericUpDown1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents richTextBox1 As System.Windows.Forms.RichTextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.comboBox1 = New System.Windows.Forms.ComboBox
        Me.numericUpDown1 = New System.Windows.Forms.NumericUpDown
        Me.label2 = New System.Windows.Forms.Label
        Me.button1 = New System.Windows.Forms.Button
        Me.button2 = New System.Windows.Forms.Button
        Me.richTextBox1 = New System.Windows.Forms.RichTextBox
        CType(Me.numericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Available Fonts"
        '
        'comboBox1
        '
        Me.comboBox1.Location = New System.Drawing.Point(16, 32)
        Me.comboBox1.Name = "comboBox1"
        Me.comboBox1.Size = New System.Drawing.Size(152, 24)
        Me.comboBox1.TabIndex = 1
        '
        'numericUpDown1
        '
        Me.numericUpDown1.Location = New System.Drawing.Point(184, 32)
        Me.numericUpDown1.Name = "numericUpDown1"
        Me.numericUpDown1.Size = New System.Drawing.Size(48, 24)
        Me.numericUpDown1.TabIndex = 3
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(184, 8)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(56, 24)
        Me.label2.TabIndex = 4
        Me.label2.Text = "Size"
        '
        'button1
        '
        Me.button1.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(128, Byte), CType(0, Byte))
        Me.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.button1.Location = New System.Drawing.Point(240, 32)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(80, 24)
        Me.button1.TabIndex = 7
        Me.button1.Text = "Color"
        '
        'button2
        '
        Me.button2.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold)
        Me.button2.Location = New System.Drawing.Point(352, 32)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(80, 32)
        Me.button2.TabIndex = 9
        Me.button2.Text = "Apply"
        '
        'richTextBox1
        '
        Me.richTextBox1.Location = New System.Drawing.Point(8, 88)
        Me.richTextBox1.Name = "richTextBox1"
        Me.richTextBox1.Size = New System.Drawing.Size(480, 304)
        Me.richTextBox1.TabIndex = 10
        Me.richTextBox1.Text = "richTextBox1"
        '
        'FontCollectionSamp
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(7, 17)
        Me.BackColor = System.Drawing.Color.Teal
        Me.ClientSize = New System.Drawing.Size(496, 413)
        Me.Controls.Add(Me.richTextBox1)
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.button1)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.numericUpDown1)
        Me.Controls.Add(Me.comboBox1)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Tahoma", 10.0!)
        Me.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Name = "FontCollectionSamp"
        Me.Text = "FontCollectionSamp"
        CType(Me.numericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub FontCollectionSamp_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        numericUpDown1.Value = 10
        ' Create InstalledFontCollection object
        Dim sysFontCollection As New InstalledFontCollection
        ' Get the array of FontFamily objects.
        Dim fontFamilies As FontFamily() = sysFontCollection.Families
        ' Read all font familes and 
        ' add to the combo box
        Dim ff As FontFamily
        For Each ff In fontFamilies
            comboBox1.Items.Add(ff.Name)
        Next ff
        comboBox1.Text = fontFamilies(0).Name
    End Sub

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        '
        ' Create a Color dialog and let
        ' the user select a color 
        ' Save the selected color
        Dim colorDlg As New ColorDialog
        If colorDlg.ShowDialog() = DialogResult.OK Then
            textColor = colorDlg.Color
        End If
    End Sub

    Private Sub button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button2.Click
        ' Get the size of text from 
        ' numeric up down control
        textSize = CInt(numericUpDown1.Value)
        ' Get current font name from the list
        Dim selFont As String = comboBox1.Text
        ' Create a new font from the current selection
        Dim textFont As New Font(selFont, textSize)
        ' Set color and font of richtext box
        richTextBox1.ForeColor = textColor
        richTextBox1.Font = textFont
    End Sub
End Class

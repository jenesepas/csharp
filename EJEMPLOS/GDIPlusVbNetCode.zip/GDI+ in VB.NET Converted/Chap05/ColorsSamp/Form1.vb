Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents ColorStructMenu As System.Windows.Forms.MenuItem
    Friend WithEvents ColorTansMenu As System.Windows.Forms.MenuItem
    Friend WithEvents ColorConvertMenu As System.Windows.Forms.MenuItem
    Friend WithEvents HSBMenu As System.Windows.Forms.MenuItem
    Friend WithEvents SystemColorsMenu As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.ColorStructMenu = New System.Windows.Forms.MenuItem
        Me.ColorTansMenu = New System.Windows.Forms.MenuItem
        Me.ColorConvertMenu = New System.Windows.Forms.MenuItem
        Me.HSBMenu = New System.Windows.Forms.MenuItem
        Me.SystemColorsMenu = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.ColorStructMenu, Me.ColorTansMenu, Me.ColorConvertMenu, Me.HSBMenu, Me.SystemColorsMenu})
        Me.MenuItem1.Text = "Color Preperties"
        '
        'ColorStructMenu
        '
        Me.ColorStructMenu.Index = 0
        Me.ColorStructMenu.Text = "Color Structure"
        '
        'ColorTansMenu
        '
        Me.ColorTansMenu.Index = 1
        Me.ColorTansMenu.Text = "Color Translator"
        '
        'ColorConvertMenu
        '
        Me.ColorConvertMenu.Index = 2
        Me.ColorConvertMenu.Text = "Color Convertor"
        '
        'HSBMenu
        '
        Me.HSBMenu.Index = 3
        Me.HSBMenu.Text = "HSB"
        '
        'SystemColorsMenu
        '
        Me.SystemColorsMenu.Index = 4
        Me.SystemColorsMenu.Text = "System Colors"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(408, 294)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub ColorStructMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ColorStructMenu.Click
        ' Create Graphics object 
        Dim g As Graphics = Me.CreateGraphics()
        ' Create Color object from Argb
        Dim redColor As Color = Color.FromArgb(120, 255, 0, 0)
        ' Create Color object form color name
        Dim blueColor As Color = Color.FromName("Blue")
        ' Create Color object from known color
        Dim greenColor As Color = Color.FromKnownColor(KnownColor.Green)
        ' Create empty color
        Dim tstColor As Color = Color.Empty
        ' See if a color is empty
        If greenColor.IsEmpty Then
            tstColor = Color.DarkGoldenrod
        End If
        ' Create brushes and pens from colors
        Dim redBrush As New SolidBrush(redColor)
        Dim blueBrush As New SolidBrush(blueColor)
        Dim greenBrush As New SolidBrush(greenColor)
        Dim greenPen As New Pen(greenBrush, 4)
        ' Draw GDI+ ojbects
        g.FillEllipse(redBrush, 10, 10, 50, 50)
        g.FillRectangle(blueBrush, 60, 10, 50, 50)
        g.DrawLine(greenPen, 20, 60, 200, 60)
        ' Check properties values
        MessageBox.Show(("Color Name :" + blueColor.Name + ", A:" + blueColor.A.ToString() + ", R:" + blueColor.R.ToString() + ", B:" + blueColor.B.ToString() + ", G:" + blueColor.G.ToString()))
        ' Dispose GDI+ objects
        redBrush.Dispose()
        blueBrush.Dispose()
        greenBrush.Dispose()
        greenPen.Dispose()
        g.Dispose()
    End Sub

    Private Sub ColorTansMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ColorTansMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim str As String = "#FF00FF"
        Dim clrConverter As New ColorConverter
        Dim clr1 As Color = CType(clrConverter.ConvertFromString(str), Color)
        ' Using colors
        Dim redBrush As New SolidBrush(clr1)
        Dim blueBrush As New SolidBrush(clr1)
        ' Drawing GDI+ objects
        g.FillEllipse(redBrush, 10, 10, 50, 50)
        g.FillRectangle(blueBrush, 60, 10, 50, 50)
        'Dispose
        redBrush.Dispose()
        blueBrush.Dispose()
        g.Dispose()
    End Sub

    Private Sub ColorConvertMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ColorConvertMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        ' Translate colors
        Dim win32Color As Color = ColorTranslator.FromWin32(&HFF0033)
        Dim htmlColor As Color = ColorTranslator.FromHtml("#00AAFF")
        ' Using colors
        Dim redBrush As New SolidBrush(win32Color)
        Dim blueBrush As New SolidBrush(htmlColor)
        ' Drawing GDI+ objects
        g.FillEllipse(redBrush, 10, 10, 50, 50)
        g.FillRectangle(blueBrush, 60, 10, 50, 50)
        'Dispose
        redBrush.Dispose()
        blueBrush.Dispose()
        g.Dispose()
    End Sub

    Private Sub HSBMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HSBMenu.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        ' Create a color 
        Dim clr As Color = Color.FromArgb(255, 200, 0, 100)
        ' Get hue, saturation, and brightness components
        Dim h As Single = clr.GetHue()
        Dim s As Single = clr.GetSaturation()
        Dim v As Single = clr.GetBrightness()
        Dim str As String = "Hue: " + h.ToString() + ControlChars.Lf + "Saturation: " + s.ToString() + ControlChars.Lf + "Brightness: " + v.ToString()
        ' Display data
        g.DrawString(str, New Font("verdana", 12), Brushes.Blue, 50, 50)
        ' Dispose
        g.Dispose()
    End Sub

    Private Sub SystemColorsMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SystemColorsMenu.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        ' Create brushes and pens
        Dim brush1 As SolidBrush = CType(SystemBrushes.FromSystemColor(SystemColors.ActiveCaption), SolidBrush)
        Dim pn1 As Pen = SystemPens.FromSystemColor(SystemColors.HighlightText)
        Dim pn2 As Pen = SystemPens.FromSystemColor(SystemColors.ControlLightLight)
        Dim pn3 As Pen = SystemPens.FromSystemColor(SystemColors.ControlDarkDark)
        ' Draw and fill graphics objects
        g.DrawLine(pn1, 10, 10, 10, 200)
        g.FillRectangle(brush1, 60, 60, 100, 100)
        g.DrawEllipse(pn3, 20, 20, 170, 170)
        g.DrawLine(pn2, 10, 10, 200, 10)
        ' Dispose
        g.Dispose()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Invalidate(Me.ClientRectangle)
    End Sub
End Class

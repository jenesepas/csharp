Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Text


Public Class Form1
    Inherits System.Windows.Forms.Form

    Private Shared Function GetStockObject(ByVal fnObj As Integer) As IntPtr

    End Function

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub


    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents CreateFontsMenu As System.Windows.Forms.MenuItem
    Friend WithEvents SystemFontsMenu As System.Windows.Forms.MenuItem
    Friend WithEvents GetFamiliesMenu As System.Windows.Forms.MenuItem
    Friend WithEvents FormattingTextMenu As System.Windows.Forms.MenuItem
    Friend WithEvents PvtFontMenu As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents DrawTextMenu As System.Windows.Forms.MenuItem
    Friend WithEvents AlignmentMenu As System.Windows.Forms.MenuItem
    Friend WithEvents TabStopsMenu As System.Windows.Forms.MenuItem
    Friend WithEvents DigitalSubMenu As System.Windows.Forms.MenuItem
    Friend WithEvents StringFormatMenu As System.Windows.Forms.MenuItem
    Friend WithEvents AntiAliasMenu As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents FontMembersMenu As System.Windows.Forms.MenuItem
    Friend WithEvents fromHFontMenu As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.CreateFontsMenu = New System.Windows.Forms.MenuItem
        Me.SystemFontsMenu = New System.Windows.Forms.MenuItem
        Me.GetFamiliesMenu = New System.Windows.Forms.MenuItem
        Me.FormattingTextMenu = New System.Windows.Forms.MenuItem
        Me.PvtFontMenu = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.DrawTextMenu = New System.Windows.Forms.MenuItem
        Me.AlignmentMenu = New System.Windows.Forms.MenuItem
        Me.TabStopsMenu = New System.Windows.Forms.MenuItem
        Me.DigitalSubMenu = New System.Windows.Forms.MenuItem
        Me.StringFormatMenu = New System.Windows.Forms.MenuItem
        Me.AntiAliasMenu = New System.Windows.Forms.MenuItem
        Me.MenuItem3 = New System.Windows.Forms.MenuItem
        Me.FontMembersMenu = New System.Windows.Forms.MenuItem
        Me.fromHFontMenu = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem2, Me.MenuItem3})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.CreateFontsMenu, Me.SystemFontsMenu, Me.GetFamiliesMenu, Me.FormattingTextMenu, Me.PvtFontMenu})
        Me.MenuItem1.Text = "Font"
        '
        'CreateFontsMenu
        '
        Me.CreateFontsMenu.Index = 0
        Me.CreateFontsMenu.Text = "Create Fonts"
        '
        'SystemFontsMenu
        '
        Me.SystemFontsMenu.Index = 1
        Me.SystemFontsMenu.Text = "System Fonts"
        '
        'GetFamiliesMenu
        '
        Me.GetFamiliesMenu.Index = 2
        Me.GetFamiliesMenu.Text = "GetFamilies"
        '
        'FormattingTextMenu
        '
        Me.FormattingTextMenu.Index = 3
        Me.FormattingTextMenu.Text = "Formatting Text"
        '
        'PvtFontMenu
        '
        Me.PvtFontMenu.Index = 4
        Me.PvtFontMenu.Text = "Private Font Collection"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.DrawTextMenu, Me.AlignmentMenu, Me.TabStopsMenu, Me.DigitalSubMenu, Me.StringFormatMenu, Me.AntiAliasMenu})
        Me.MenuItem2.Text = "Text"
        '
        'DrawTextMenu
        '
        Me.DrawTextMenu.Index = 0
        Me.DrawTextMenu.Text = "Draw Text"
        '
        'AlignmentMenu
        '
        Me.AlignmentMenu.Index = 1
        Me.AlignmentMenu.Text = "Alignment_Trimming"
        '
        'TabStopsMenu
        '
        Me.TabStopsMenu.Index = 2
        Me.TabStopsMenu.Text = "Tab Stops"
        '
        'DigitalSubMenu
        '
        Me.DigitalSubMenu.Index = 3
        Me.DigitalSubMenu.Text = "Digital Substitution"
        '
        'StringFormatMenu
        '
        Me.StringFormatMenu.Index = 4
        Me.StringFormatMenu.Text = "String Format Flags"
        '
        'AntiAliasMenu
        '
        Me.AntiAliasMenu.Index = 5
        Me.AntiAliasMenu.Text = "Anti Aliasing Text"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 2
        Me.MenuItem3.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FontMembersMenu, Me.fromHFontMenu})
        Me.MenuItem3.Text = "Font"
        '
        'FontMembersMenu
        '
        Me.FontMembersMenu.Index = 0
        Me.FontMembersMenu.Text = "Font Members"
        '
        'fromHFontMenu
        '
        Me.fromHFontMenu.Index = 1
        Me.fromHFontMenu.Text = "FromHFont"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(512, 366)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub CreateFontsMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateFontsMenu.Click
        ' Create Font Families
        Dim verdanaFamily As New FontFamily("Verdana")
        Dim arialFamily As New FontFamily("Arial")
        ' Construct Font objects
        Dim verdanaFont As New Font(verdanaFamily, 14, FontStyle.Regular, GraphicsUnit.Pixel)
        Dim tahomaFont As New Font(New FontFamily("Tahoma"), 10, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Pixel)
        Dim arialFont As New Font(arialFamily, 16, FontStyle.Bold, GraphicsUnit.Point)
        Dim tnwFont As New Font("Times New Roman", 12)
    End Sub

    Private Sub SystemFontsMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SystemFontsMenu.Click


    End Sub

    Private Sub GetFamiliesMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetFamiliesMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        ' Get an array of the available font families.
        Dim families As FontFamily() = FontFamily.GetFamilies(g)
        ' Draw text using each of the font families.
        Dim familiesFont As Font
        Dim familyString As String
        Dim spacing As Single = 0
        Dim family As FontFamily
        For Each family In families
            familiesFont = New Font(family, 16, FontStyle.Bold)
            familyString = "This is the " + family.Name + "family."
            g.DrawString(familyString, familiesFont, Brushes.Black, New PointF(0, spacing))
            spacing += familiesFont.Height
        Next family

        ' Dispose GDI+ objects
        g.Dispose()
    End Sub

    Private Sub FormattingTextMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FormattingTextMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        ' Create Font Families
        Dim verdanaFamily As New FontFamily("Verdana")
        Dim arialFamily As New FontFamily("Arial")
        ' Construct Font objects
        Dim verdanaFont As New Font("Verdana", 10)
        Dim arialFont As New Font(arialFamily, 16, FontStyle.Bold)
        Dim tahomaFont As New Font("Tahoma", 24, FontStyle.Underline Or FontStyle.Italic)

        ' Create Brush and other objects
        Dim pointF As New PointF(30, 10)
        Dim solidBrush As New SolidBrush(Color.FromArgb(255, 0, 0, 255))
        ' Drawing text using DrawString
        g.DrawString("Drawing Text", verdanaFont, New SolidBrush(Color.Red), New PointF(20, 20))
        g.DrawString("Drawing Text", arialFont, New SolidBrush(Color.Blue), New PointF(20, 50))
        g.DrawString("Drawing Text", tahomaFont, New SolidBrush(Color.Green), New PointF(20, 80))
        ' Dispose GDI+ objects
        g.Dispose()
    End Sub

    Private Sub PvtFontMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PvtFontMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create font fa
        Dim verdanaFamily As New FontFamily("Verdana")
        Dim arialFamily As New FontFamily("Arial")

        Dim verdanaFont As New Font(verdanaFamily, 14, FontStyle.Regular, GraphicsUnit.Pixel)
        Dim tahomaFont As New Font(New FontFamily("Tahoma"), 10, FontStyle.Bold Or FontStyle.Italic, GraphicsUnit.Pixel)

        Dim arialFont As New Font(arialFamily, 16, FontStyle.Bold, GraphicsUnit.Point)

        Dim pointF As New PointF(30, 10)
        Dim solidBrush As New SolidBrush(Color.FromArgb(255, 0, 0, 255))

        g.DrawString("Drawing Text", verdanaFont, New SolidBrush(Color.Red), New PointF(20, 20))

        g.DrawString("Drawing Text", tahomaFont, New SolidBrush(Color.Blue), New PointF(50, 20))

        g.DrawString("Drawing Text", arialFont, New SolidBrush(Color.Green), New PointF(80, 20))

        ' Dispose GDI+ objects
        g.Dispose()
    End Sub

    Private Sub DrawTextMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DrawTextMenu.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        ' Create Font Families
        Dim verdanaFamily As New FontFamily("Verdana")
        Dim arialFamily As New FontFamily("Arial")
        ' Construct Font objects
        Dim verdanaFont As New Font("Verdana", 10)
        Dim arialFont As New Font(arialFamily, 16, FontStyle.Bold)
        Dim tahomaFont As New Font("Tahoma", 24, FontStyle.Underline Or FontStyle.Italic)
        ' Create Brush and other objects
        Dim pointF As New PointF(30, 10)
        Dim solidBrush As New SolidBrush(Color.FromArgb(255, 0, 0, 255))
        ' Drawing text using DrawString
        g.DrawString("Drawing Text", verdanaFont, New SolidBrush(Color.Red), New PointF(20, 20))
        g.DrawString("Drawing Text", arialFont, New SolidBrush(Color.Blue), New PointF(20, 50))
        g.DrawString("Drawing Text", tahomaFont, New SolidBrush(Color.Green), New PointF(20, 80))
        ' Dispose
        solidBrush.Dispose()
        g.Dispose()
    End Sub

    Private Sub AlignmentMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AlignmentMenu.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim [text] As String = "Testing GDI+ Text and Font" + " functioanlity for alignment and trimming."
        ' Create Font Families
        Dim verdanaFamily As New FontFamily("Verdana")
        Dim arialFamily As New FontFamily("Arial")
        ' Construct Font objects
        Dim verdanaFont As New Font("Verdana", 10, FontStyle.Bold)
        Dim arialFont As New Font(arialFamily, 16)
        ' Creating rectangles
        Dim rect1 As New Rectangle(10, 10, 150, 150)
        Dim rect2 As New Rectangle(10, 165, 150, 100)
        ' Construct StringFormat and alignment 
        Dim strFormat1 As New StringFormat
        Dim strFormat2 As New StringFormat
        ' Set alignment, line triming, and trimming 
        ' propertoes of string format
        strFormat1.Alignment = StringAlignment.Center
        strFormat1.LineAlignment = StringAlignment.Center
        strFormat1.Trimming = StringTrimming.EllipsisCharacter
        strFormat2.Alignment = StringAlignment.Far
        strFormat2.LineAlignment = StringAlignment.Near
        strFormat2.Trimming = StringTrimming.Character
        ' Draw GDI+ objects
        g.FillEllipse(New SolidBrush(Color.Blue), rect1)
        g.DrawRectangle(New Pen(Color.Black), rect2)
        g.DrawString([text], verdanaFont, New SolidBrush(Color.White), rect1.Location.X, rect1.Location.Y, strFormat1)
        g.DrawString([text], arialFont, New SolidBrush(Color.Red), rect2.Location.X, rect2.Location.Y, strFormat2)
        ' Dispose objects
        g.Dispose()
    End Sub

    Private Sub TabStopsMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabStopsMenu.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Some text data
        Dim [text] As String = "ID" + ControlChars.Tab + "Maths" + ControlChars.Tab + "Physics" + ControlChars.Tab + "Chemistry " + ControlChars.Lf
        [text] = [text] + "---------" + ControlChars.Tab + "---------" + ControlChars.Tab + "---------" + ControlChars.Tab + "---------" + ControlChars.Lf
        [text] = [text] + "1002" + ControlChars.Tab + "76" + ControlChars.Tab + "89" + ControlChars.Tab + "92" + ControlChars.Lf
        [text] = [text] + "1003" + ControlChars.Tab + "53" + ControlChars.Tab + "98" + ControlChars.Tab + "90" + ControlChars.Lf
        [text] = [text] + "1008" + ControlChars.Tab + "99" + ControlChars.Tab + "78" + ControlChars.Tab + "65" + ControlChars.Lf
        ' Create a font 
        Dim verdanaFont As New Font("Verdana", 10, FontStyle.Bold)
        ' Create a rectangle
        Dim rect As New Rectangle(10, 50, 350, 250)
        ' Create StringFormat
        Dim strFormat As New StringFormat
        ' Set tab stops of string format
        strFormat.SetTabStops(5, New Single() {80, 100, 80, 80})
        ' Draw string 
        g.DrawString("Students Marks Table", New Font("Tahoma", 16), New SolidBrush(Color.Black), New RectangleF(10, 10, 300, 100))
        g.DrawString("=============", New Font("Tahoma", 16), New SolidBrush(Color.Black), New RectangleF(10, 23, 300, 100))
        ' Draw string with tab stops
        g.DrawString([text], verdanaFont, New SolidBrush(Color.Red), rect.Location.X, rect.Location.Y, strFormat)
        ' Dispose GDI+ objects
        g.Dispose()
    End Sub

    Private Sub DigitalSubMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DigitalSubMenu.Click

    End Sub

    Private Sub StringFormatMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StringFormatMenu.Click
        ' Creat a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        ' Create a rectangle
        Dim rect As New Rectangle(50, 50, 350, 250)
        ' Create two StringFormat objects
        Dim strFormat1 As New StringFormat
        Dim strFormat2 As New StringFormat
        ' Set Format flags of StringFormat objects
        ' with direction right to left
        strFormat1.FormatFlags = StringFormatFlags.DirectionRightToLeft
        ' Direction vertical
        strFormat2.FormatFlags = StringFormatFlags.DirectionVertical
        ' Set alignment
        strFormat2.Alignment = StringAlignment.Far
        ' Draw rectangle
        g.DrawRectangle(New Pen(Color.Blue), rect)
        Dim str As String = "Horizontal Text: This is horizontal" + "text inside a rectangle"
        ' Draw strings
        g.DrawString(str, New Font("Verdana", 10, FontStyle.Bold), New SolidBrush(Color.Green), rect.Location.X, rect.Location.Y, strFormat1)
        g.DrawString("Vertical: Text String", New Font("Arial", 14), New SolidBrush(Color.Red), rect.Location.X, rect.Location.Y, strFormat2)
        ' Dispose GDI+ objects
        g.Dispose()
    End Sub

    Private Sub AntiAliasMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AntiAliasMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim redBrush As New SolidBrush(Color.Red)
        Dim verdana16 As New Font("Verdana", 16)
        Dim text1 As String = "Text with SingleBitPerPixel"
        Dim text2 As String = "Text with ClearTypeGridFit"
        Dim text3 As String = "Text with AntiAliasing"
        Dim text4 As String = "Text with SystemDefault"
        ' Set TextRenderingHint property of surface
        ' to single bit per pixel
        g.TextRenderingHint = TextRenderingHint.SingleBitPerPixel
        ' Draw string
        g.DrawString(text1, verdana16, redBrush, New PointF(10, 10))
        ' Set TextRenderingHint property of surface
        ' to clear type grid fit
        g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit
        ' Draw string 
        g.DrawString(text2, verdana16, redBrush, New PointF(10, 60))
        ' Set TextRenderingHint property of surface
        ' to anti alias
        g.TextRenderingHint = TextRenderingHint.AntiAlias
        ' Draw string
        g.DrawString(text3, verdana16, redBrush, New PointF(10, 100))
        ' Set TextRenderingHint property of surface
        ' to system default
        g.TextRenderingHint = TextRenderingHint.SystemDefault
        ' Draw string
        g.DrawString(text4, verdana16, redBrush, New PointF(10, 150))
        ' Dispose
        redBrush.Dispose()
        g.Dispose()
    End Sub

    Private Sub FontMembersMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FontMembersMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim arialFont As New Font("Arial", 16, FontStyle.Bold Or FontStyle.Underline Or FontStyle.Italic)
        MessageBox.Show(("Font Properties = Name:" + arialFont.Name + " Size:" + arialFont.Size.ToString() + " Style:" + arialFont.Style.ToString() + " Default Unit:" + arialFont.Unit.ToString() + " Size in Points:" + arialFont.SizeInPoints.ToString()))

        ' Dispose GDI+ objects
        g.Dispose()
    End Sub

    Private Sub fromHFontMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles fromHFontMenu.Click
        ' Greate the Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        ' Create a brush
        Dim brush As New SolidBrush(Color.Red)
        ' Get a handle 
        Dim hFont As IntPtr = GetStockObject(0)
        ' Create a font from handle
        Dim hfontFont As Font = Font.FromHfont(hFont)
        ' Draw text 
        g.DrawString("GDI HFONT", hfontFont, brush, 20, 20)
        ' Dispose
        brush.Dispose()
        g.Dispose()
    End Sub
End Class

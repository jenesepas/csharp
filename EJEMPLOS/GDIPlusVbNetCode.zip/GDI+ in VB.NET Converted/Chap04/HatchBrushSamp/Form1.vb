Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D

Public Class Form1
    Inherits System.Windows.Forms.Form
    Private style As New HatchStyle
    Private forClr As Color = Color.Blue
    Private backClr As Color = Color.Red

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents ForColorBtn As System.Windows.Forms.Button
    Friend WithEvents BackGroundBtn As System.Windows.Forms.Button
    Friend WithEvents ApplyBtn As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.ForColorBtn = New System.Windows.Forms.Button
        Me.BackGroundBtn = New System.Windows.Forms.Button
        Me.ApplyBtn = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Select Style:"
        '
        'ComboBox1
        '
        Me.ComboBox1.Location = New System.Drawing.Point(96, 8)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 1
        Me.ComboBox1.Text = "ComboBox1"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 23)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Forground Color:"
        '
        'TextBox1
        '
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.Location = New System.Drawing.Point(112, 40)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(32, 20)
        Me.TextBox1.TabIndex = 3
        Me.TextBox1.Text = ""
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(0, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(104, 23)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Background Color:"
        '
        'TextBox2
        '
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.Location = New System.Drawing.Point(112, 72)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(32, 20)
        Me.TextBox2.TabIndex = 5
        Me.TextBox2.Text = ""
        '
        'ForColorBtn
        '
        Me.ForColorBtn.Location = New System.Drawing.Point(152, 40)
        Me.ForColorBtn.Name = "ForColorBtn"
        Me.ForColorBtn.Size = New System.Drawing.Size(48, 23)
        Me.ForColorBtn.TabIndex = 6
        Me.ForColorBtn.Text = "Pick..."
        '
        'BackGroundBtn
        '
        Me.BackGroundBtn.Location = New System.Drawing.Point(152, 72)
        Me.BackGroundBtn.Name = "BackGroundBtn"
        Me.BackGroundBtn.Size = New System.Drawing.Size(48, 23)
        Me.BackGroundBtn.TabIndex = 7
        Me.BackGroundBtn.Text = "Pic..."
        '
        'ApplyBtn
        '
        Me.ApplyBtn.Location = New System.Drawing.Point(224, 72)
        Me.ApplyBtn.Name = "ApplyBtn"
        Me.ApplyBtn.TabIndex = 8
        Me.ApplyBtn.Text = "Apply"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(416, 325)
        Me.Controls.Add(Me.ApplyBtn)
        Me.Controls.Add(Me.BackGroundBtn)
        Me.Controls.Add(Me.ForColorBtn)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Hatch Brushes"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Fill combo box with hatch styles
        FillHatchStyles()
        ' Set foreground and background color
        ' text boxes's backgrond color
        TextBox1.BackColor = forClr
        TextBox2.BackColor = backClr
    End Sub

    Private Sub FillHatchStyles()
        ' Add hatch styles
        comboBox1.Items.Add(HatchStyle.BackwardDiagonal.ToString())
        comboBox1.Items.Add(HatchStyle.Cross.ToString())
        comboBox1.Items.Add(HatchStyle.DashedVertical.ToString())
        comboBox1.Items.Add(HatchStyle.DiagonalCross.ToString())
        comboBox1.Items.Add(HatchStyle.HorizontalBrick.ToString())
        comboBox1.Items.Add(HatchStyle.LightDownwardDiagonal.ToString())
        comboBox1.Items.Add(HatchStyle.LightUpwardDiagonal.ToString())
        comboBox1.Text = HatchStyle.BackwardDiagonal.ToString()
    End Sub 'FillHatchStyles


    Private Sub ApplyBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ApplyBtn.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Read curretnt style from combo box
        Dim str As String = ComboBox1.Text
        ' Find out the style and set it as the 
        ' current style
        Select Case str
            Case "BackwardDiagonal"
                style = HatchStyle.BackwardDiagonal
            Case "DashedVertical"
                style = HatchStyle.DashedVertical
            Case "Cross"
                style = HatchStyle.Cross
            Case "DiagonalCross"
                style = HatchStyle.DiagonalCross
            Case "HorizontalBrick"
                style = HatchStyle.HorizontalBrick
            Case "LightDownwardDiagonal"
                style = HatchStyle.LightDownwardDiagonal
            Case "LightUpwardDiagonal"
                style = HatchStyle.LightUpwardDiagonal
            Case Else
        End Select
        ' Create a hatch brush with selected 
        ' hatch style and colors
        Dim brush As New HatchBrush(style, forClr, backClr)
        ' fill rectangle
        g.FillRectangle(brush, 50, 100, 200, 200)
        ' Dispose
        brush.Dispose()
        g.Dispose()
    End Sub

    Private Sub ForColorBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ForColorBtn.Click
        ' Use Color dialog to select a color
        Dim clrDlg As New ColorDialog
        If clrDlg.ShowDialog() = DialogResult.OK Then
            ' Save color as foreground color
            ' fill text box as this color
            forClr = clrDlg.Color
            TextBox1.BackColor = forClr
        End If
    End Sub

    Private Sub BackGroundBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackGroundBtn.Click
        ' Use Color dialog to select a color
        Dim clrDlg As New ColorDialog
        If clrDlg.ShowDialog() = DialogResult.OK Then
            ' Save color as background color
            ' fill text box as this color
            backClr = clrDlg.Color
            TextBox2.BackColor = backClr
        End If
    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D

Public Class Form1
    Inherits System.Windows.Forms.Form
    Public f As Single = 0
    Private pn As New Pen(New SolidBrush(Color.Red), 3)

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private WithEvents Timer1 As System.Windows.Forms.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.Desktop
        Me.ClientSize = New System.Drawing.Size(292, 273)
        Me.ForeColor = System.Drawing.Color.Yellow
        Me.Name = "Form1"
        Me.Text = "GDI+ Clock"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        e.Graphics.DrawEllipse(pn, 10, 10, 230, 230)
        Dim gp As New GraphicsPath
        gp.AddLine(45, 45, 125, 125)
        Dim rect As New Rectangle(45, 45, 5, 5)
        gp.AddRectangle(rect)
        Dim RotationTransform As New Matrix(1, 0, 0, 1, 1, 1)
        'rotation matrix
        Dim TheRotationPoint As New PointF(125.0F, 125.0F)

        'rotation point			
        RotationTransform.RotateAt(f, TheRotationPoint)
        gp.Transform(RotationTransform)
        e.Graphics.DrawPath(Pens.Blue, gp)
        f = f + 10
        If f = 360 Then
            f = 0
        End If
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Me.Refresh()
    End Sub
End Class

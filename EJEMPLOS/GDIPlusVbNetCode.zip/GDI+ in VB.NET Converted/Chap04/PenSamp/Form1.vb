Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents GetPenTypes As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.MenuItem3 = New System.Windows.Forms.MenuItem
        Me.MenuItem4 = New System.Windows.Forms.MenuItem
        Me.MenuItem5 = New System.Windows.Forms.MenuItem
        Me.MenuItem6 = New System.Windows.Forms.MenuItem
        Me.GetPenTypes = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem2, Me.MenuItem3, Me.MenuItem4, Me.MenuItem5, Me.MenuItem6, Me.GetPenTypes})
        Me.MenuItem1.Text = "Menu Samples"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 0
        Me.MenuItem2.Text = "Constructor"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 1
        Me.MenuItem3.Text = "Width_Other Preperties"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 2
        Me.MenuItem4.Text = "Caps"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 3
        Me.MenuItem5.Text = "Transformation"
        '
        'MenuItem6
        '
        Me.MenuItem6.Index = 4
        Me.MenuItem6.Text = "Other Objects"
        '
        'GetPenTypes
        '
        Me.GetPenTypes.Index = 5
        Me.GetPenTypes.Text = "Get Pen Types"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(400, 318)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub GetPenTypes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetPenTypes.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create three different types of brushes
        Dim img = New Bitmap("roses.jpg")
        Dim redBrush As New SolidBrush(Color.Red)
        Dim txtrBrush As New TextureBrush(img)
        Dim lgBrush As New LinearGradientBrush(New Rectangle(10, 10, 10, 10), Color.Red, Color.Black, 45.0F)
        ' Create pens from brushes
        Dim pn1 As New Pen(redBrush, 4)
        Dim pn2 As New Pen(txtrBrush, 20)
        Dim pn3 As New Pen(lgBrush, 20)
        ' Drawing objects      
        g.DrawEllipse(pn1, 100, 100, 50, 50)
        g.DrawRectangle(pn2, 80, 80, 100, 100)
        g.DrawEllipse(pn3, 30, 30, 200, 200)

        ' Get pen types 
        Dim str As String = "Pen1 Type: " + pn1.PenType.ToString() + ControlChars.Lf
        str += "Pen2 Type: " + pn2.PenType.ToString() + ControlChars.Lf
        str += "Pen3 Type: " + pn3.PenType.ToString()
        MessageBox.Show(str)

        ' Dispose
        redBrush.Dispose()
        txtrBrush.Dispose()
        lgBrush.Dispose()
        img.Dispose()
        pn1.Dispose()
        pn2.Dispose()
        pn3.Dispose()
        g.Dispose()
    End Sub

    Private Sub MenuItem6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem6.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim redPen As New Pen(New SolidBrush(Color.Red), 4)
        Dim bluePen As New Pen(New SolidBrush(Color.Blue), 5)
        Dim blackPen As New Pen(New SolidBrush(Color.Black), 3)
        ' Setting line styles    
        redPen.DashStyle = DashStyle.Dash
        redPen.SetLineCap(LineCap.DiamondAnchor, LineCap.ArrowAnchor, DashCap.Flat)
        bluePen.DashStyle = DashStyle.DashDotDot
        bluePen.StartCap = LineCap.Triangle
        bluePen.EndCap = LineCap.Triangle
        bluePen.DashCap = DashCap.Triangle
        blackPen.DashStyle = DashStyle.Dot
        blackPen.DashOffset = 3.4F
        blackPen.SetLineCap(LineCap.RoundAnchor, LineCap.Square, DashCap.Round)
        ' Drawing objects      
        g.DrawArc(redPen, 10.0F, 10.0F, 50, 100, 45.0F, 90.0F)
        g.DrawRectangle(bluePen, 60, 80, 140, 50)
        g.DrawBezier(blackPen, 20.0F, 30.0F, 100.0F, 200.0F, 40.0F, 400.0F, 100.0F, 200.0F)
        g.DrawEllipse(redPen, 50, 50, 200, 100)
        ' Dispose
        redPen.Dispose()
        bluePen.Dispose()
        blackPen.Dispose()
        g.Dispose()
    End Sub

    Private Sub MenuItem5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem5.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a Pen object.
        Dim bluePen As New Pen(Color.Blue, 10)
        Dim redPen As New Pen(Color.Red, 5)
        ' Applying rotate and scale transformation
        bluePen.ScaleTransform(3, 1)
        g.DrawEllipse(bluePen, 20, 20, 100, 50)
        g.DrawRectangle(redPen, 20, 120, 100, 50)
        bluePen.RotateTransform(90, MatrixOrder.Append)
        redPen.ScaleTransform(4, 2, MatrixOrder.Append)
        g.DrawEllipse(bluePen, 220, 20, 100, 50)
        g.DrawRectangle(redPen, 220, 120, 100, 50)
        ' Dispose
        redPen.Dispose()
        bluePen.Dispose()
        g.Dispose()
    End Sub

    Private Sub MenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem4.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create three pens
        Dim redPen As New Pen(Color.Red, 6)
        Dim bluePen As New Pen(Color.Blue, 7)
        Dim greenPen As New Pen(Color.Green, 7)
        redPen.Width = 8
        ' Setting line styles    
        redPen.DashStyle = DashStyle.Dash
        redPen.SetLineCap(LineCap.DiamondAnchor, LineCap.ArrowAnchor, DashCap.Flat)
        greenPen.DashStyle = DashStyle.DashDotDot
        greenPen.StartCap = LineCap.Triangle
        greenPen.EndCap = LineCap.Triangle
        greenPen.DashCap = DashCap.Triangle
        greenPen.DashStyle = DashStyle.Dot
        greenPen.DashOffset = 3.4F
        bluePen.StartCap = LineCap.Square
        bluePen.EndCap = LineCap.SquareAnchor
        greenPen.SetLineCap(LineCap.RoundAnchor, LineCap.Square, DashCap.Round)
        ' Drawing Lines
        g.DrawLine(redPen, New Point(20, 50), New Point(150, 50))
        g.DrawLine(greenPen, New Point(30, 80), New Point(200, 80))
        g.DrawLine(bluePen, New Point(30, 120), New Point(250, 120))
        ' Releasing resorces. If you don't release 
        ' using Dispose, 
        ' GC (Garbase Collector) takes care for you
        redPen.Dispose()
        greenPen.Dispose()
        greenPen.Dispose()
        g.Dispose()
    End Sub

    Private Sub MenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem3.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create three pens
        Dim pn1 As New Pen(Color.Red, 3)
        Dim pn2 As New Pen(Color.Blue)
        Dim pn3 As New Pen(Color.Red)
        Dim greenBrush As New SolidBrush(Color.Green)
        ' Setting Pen1 properties
        pn1.Color = Color.Black
        ' CAUTION: Setting Brush property of the Pen
        ' object will remove the color set by using Color
        ' property and vice versa.
        pn1.Brush = greenBrush
        pn1.Width = 4
        pn1.Alignment = PenAlignment.Left
        ' Getting PenType value
        Dim style As PenType = pn1.PenType
        ' Setting Pen2 and Pen3 properties
        pn2.Width = 3
        pn2.Alignment = PenAlignment.Inset
        pn3.Width = 3
        pn3.Alignment = PenAlignment.Outset
        ' Drawing Lines
        g.DrawLine(pn1, New Point(10, 10), New Point(150, 10))
        g.DrawLine(pn2, New Point(10, 30), New Point(200, 30))
        g.DrawLine(pn3, New Point(10, 50), New Point(250, 50))
        ' Releasing resorces. If you don't release using Dispose, 
        ' GC (Garbase Collector) takes care for you
        pn1.Dispose()
        pn2.Dispose()
        pn3.Dispose()
        g.Dispose()
    End Sub

    Private Sub MenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem2.Click
        ' Create a Graphics object and set it clear
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a solid and hatch brush
        Dim blueBrush As New SolidBrush(Color.Blue)
        Dim hatchBrush As New HatchBrush(HatchStyle.DashedVertical, Color.Black, Color.Green)
        ' Create a pen from a solid brush with
        ' width 3
        Dim pn1 As New Pen(blueBrush, 3)
        ' Create a pen from a hatch brush
        Dim pn2 As New Pen(hatchBrush, 8)
        ' Create a pen from a Color structure
        Dim pn3 As New Pen(Color.Red)
        ' Draw a line, ellipse, and rectangle
        g.DrawLine(pn1, New Point(10, 40), New Point(10, 90))
        g.DrawEllipse(pn2, 20, 50, 100, 100)
        g.DrawRectangle(pn3, 40, 90, 100, 100)
        ' Dispose
        pn1.Dispose()
        pn2.Dispose()
        pn3.Dispose()
        blueBrush.Dispose()
        hatchBrush.Dispose()
        g.Dispose()
    End Sub
End Class

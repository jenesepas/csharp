Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D

Public Class Form1
    Inherits System.Windows.Forms.Form
    Private penColor As Color = Color.Red
    Dim penWidth As Integer = 5

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents numericUpDown1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ColorBtn As System.Windows.Forms.Button
    Friend WithEvents Draw As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.numericUpDown1 = New System.Windows.Forms.NumericUpDown
        Me.Label3 = New System.Windows.Forms.Label
        Me.ColorBtn = New System.Windows.Forms.Button
        Me.Draw = New System.Windows.Forms.Button
        CType(Me.numericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(80, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Pen Alignment"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 23)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Pen Width"
        '
        'ComboBox1
        '
        Me.ComboBox1.Location = New System.Drawing.Point(96, 16)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 2
        Me.ComboBox1.Text = "ComboBox1"
        '
        'numericUpDown1
        '
        Me.numericUpDown1.Location = New System.Drawing.Point(96, 56)
        Me.numericUpDown1.Name = "numericUpDown1"
        Me.numericUpDown1.Size = New System.Drawing.Size(32, 20)
        Me.numericUpDown1.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(136, 56)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 23)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Pen Color"
        '
        'ColorBtn
        '
        Me.ColorBtn.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(0, Byte), CType(0, Byte))
        Me.ColorBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ColorBtn.Location = New System.Drawing.Point(192, 56)
        Me.ColorBtn.Name = "ColorBtn"
        Me.ColorBtn.Size = New System.Drawing.Size(24, 16)
        Me.ColorBtn.TabIndex = 9
        '
        'Draw
        '
        Me.Draw.Location = New System.Drawing.Point(56, 104)
        Me.Draw.Name = "Draw"
        Me.Draw.Size = New System.Drawing.Size(120, 40)
        Me.Draw.TabIndex = 10
        Me.Draw.Text = "DrawGraphics"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(360, 349)
        Me.Controls.Add(Me.Draw)
        Me.Controls.Add(Me.ColorBtn)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.numericUpDown1)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Pen Alignment and Pen Types Sample"
        CType(Me.numericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        AddPenAlignments()
    End Sub

    Private Sub AddPenAlignments()
        ' Add pen alignment 
        comboBox1.Items.Add(PenAlignment.Center)
        comboBox1.Text = PenAlignment.Center.ToString()
        comboBox1.Items.Add(PenAlignment.Inset)
        comboBox1.Items.Add(PenAlignment.Left)
        comboBox1.Items.Add(PenAlignment.Outset)
        comboBox1.Items.Add(PenAlignment.Right)
    End Sub 'AddPenAlignments

    Private Sub Draw_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Draw.Click
        ' Create a Graphics object and set it clear
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a solid and hatch brush
        Dim pn1 As New Pen(Color.Blue, 3)
        pn1.Width = CSng(numericUpDown1.Value)
        pn1.Color = ColorBtn.BackColor
        ' Find out current pen alignment
        Dim str As String = ComboBox1.Text
        Select Case str
            Case "Center"
                pn1.Alignment = PenAlignment.Center
            Case "Inset"
                pn1.Alignment = PenAlignment.Inset
            Case "Left"
                pn1.Alignment = PenAlignment.Left
            Case "Outset"
                pn1.Alignment = PenAlignment.Outset
            Case "Right"
                pn1.Alignment = PenAlignment.Right
            Case Else
        End Select
        ' Create a pen from a hatch brush
        ' Draw a rectangle
        g.DrawRectangle(pn1, 80, 150, 150, 150)
        ' Create a brush
        Dim brush As New LinearGradientBrush(New Rectangle(10, 10, 20, 20), Color.Blue, Color.Green, 45.0F)
        g.FillRectangle(brush, 90, 160, 130, 130)
        ' Dispose
        pn1.Dispose()
        g.Dispose()

    End Sub

    Private Sub ColorBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ColorBtn.Click
        ' Use Color dialog to select a color
        Dim clrDlg As New ColorDialog
        If clrDlg.ShowDialog() = DialogResult.OK Then
            ' Save color as background color
            ' fill text box as this color
            penColor = clrDlg.Color
            ColorBtn.BackColor = penColor
        End If
    End Sub
End Class

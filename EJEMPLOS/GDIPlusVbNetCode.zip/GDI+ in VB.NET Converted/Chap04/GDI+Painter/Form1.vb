Imports System
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Windows.Forms
Imports System.IO
Public Class Form1
    Inherits System.Windows.Forms.Form
    Private bitmap As bitmap = Nothing
    Private curBitmap As bitmap = Nothing
    Private dragMode As Boolean = False
    Private drawIndex As Integer = 1
    Private curX, curY, x, y As Integer
    Private diffX, diffY As Integer
    Private curGraphics As Graphics
    Public curPen As Pen
    Private curBrush As SolidBrush
    Private fullSize As Size
    Private penReader As TextReader = Nothing
    Private brushReader As TextReader = Nothing

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents DrawLine As System.Windows.Forms.Button
    Friend WithEvents FilledEllipse As System.Windows.Forms.Button
    Friend WithEvents Filledrect As System.Windows.Forms.Button
    Friend WithEvents DrawRect As System.Windows.Forms.Button
    Friend WithEvents DrawEllipse As System.Windows.Forms.Button
    Friend WithEvents SaveBtn As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PenWidthCounter As System.Windows.Forms.NumericUpDown
    Friend WithEvents PenBtn As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TransCounter As System.Windows.Forms.NumericUpDown
    Friend WithEvents BrushBtn As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.SaveBtn = New System.Windows.Forms.Button
        Me.FilledEllipse = New System.Windows.Forms.Button
        Me.Filledrect = New System.Windows.Forms.Button
        Me.DrawRect = New System.Windows.Forms.Button
        Me.DrawEllipse = New System.Windows.Forms.Button
        Me.DrawLine = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.PenWidthCounter = New System.Windows.Forms.NumericUpDown
        Me.PenBtn = New System.Windows.Forms.Button
        Me.Label2 = New System.Windows.Forms.Label
        Me.TransCounter = New System.Windows.Forms.NumericUpDown
        Me.BrushBtn = New System.Windows.Forms.Button
        Me.Panel1.SuspendLayout()
        CType(Me.PenWidthCounter, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TransCounter, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.BrushBtn)
        Me.Panel1.Controls.Add(Me.TransCounter)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.PenBtn)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.SaveBtn)
        Me.Panel1.Controls.Add(Me.FilledEllipse)
        Me.Panel1.Controls.Add(Me.Filledrect)
        Me.Panel1.Controls.Add(Me.DrawRect)
        Me.Panel1.Controls.Add(Me.DrawEllipse)
        Me.Panel1.Controls.Add(Me.DrawLine)
        Me.Panel1.Controls.Add(Me.PenWidthCounter)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(640, 32)
        Me.Panel1.TabIndex = 0
        '
        'SaveBtn
        '
        Me.SaveBtn.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(128, Byte), CType(0, Byte))
        Me.SaveBtn.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold)
        Me.SaveBtn.ForeColor = System.Drawing.Color.White
        Me.SaveBtn.Location = New System.Drawing.Point(536, 0)
        Me.SaveBtn.Name = "SaveBtn"
        Me.SaveBtn.Size = New System.Drawing.Size(104, 40)
        Me.SaveBtn.TabIndex = 5
        Me.SaveBtn.Text = "&SaveImage"
        '
        'FilledEllipse
        '
        Me.FilledEllipse.BackColor = System.Drawing.Color.Yellow
        Me.FilledEllipse.ForeColor = System.Drawing.Color.Green
        Me.FilledEllipse.Image = CType(resources.GetObject("FilledEllipse.Image"), System.Drawing.Image)
        Me.FilledEllipse.Location = New System.Drawing.Point(128, 0)
        Me.FilledEllipse.Name = "FilledEllipse"
        Me.FilledEllipse.Size = New System.Drawing.Size(32, 30)
        Me.FilledEllipse.TabIndex = 4
        '
        'Filledrect
        '
        Me.Filledrect.BackColor = System.Drawing.Color.Yellow
        Me.Filledrect.ForeColor = System.Drawing.Color.Green
        Me.Filledrect.Image = CType(resources.GetObject("Filledrect.Image"), System.Drawing.Image)
        Me.Filledrect.Location = New System.Drawing.Point(96, 0)
        Me.Filledrect.Name = "Filledrect"
        Me.Filledrect.Size = New System.Drawing.Size(32, 30)
        Me.Filledrect.TabIndex = 3
        '
        'DrawRect
        '
        Me.DrawRect.BackColor = System.Drawing.Color.Yellow
        Me.DrawRect.ForeColor = System.Drawing.Color.Green
        Me.DrawRect.Image = CType(resources.GetObject("DrawRect.Image"), System.Drawing.Image)
        Me.DrawRect.Location = New System.Drawing.Point(64, 0)
        Me.DrawRect.Name = "DrawRect"
        Me.DrawRect.Size = New System.Drawing.Size(32, 30)
        Me.DrawRect.TabIndex = 2
        '
        'DrawEllipse
        '
        Me.DrawEllipse.BackColor = System.Drawing.Color.Yellow
        Me.DrawEllipse.ForeColor = System.Drawing.Color.Green
        Me.DrawEllipse.Image = CType(resources.GetObject("DrawEllipse.Image"), System.Drawing.Image)
        Me.DrawEllipse.Location = New System.Drawing.Point(32, 0)
        Me.DrawEllipse.Name = "DrawEllipse"
        Me.DrawEllipse.Size = New System.Drawing.Size(32, 30)
        Me.DrawEllipse.TabIndex = 1
        '
        'DrawLine
        '
        Me.DrawLine.BackColor = System.Drawing.Color.Yellow
        Me.DrawLine.ForeColor = System.Drawing.Color.DarkGreen
        Me.DrawLine.Image = CType(resources.GetObject("DrawLine.Image"), System.Drawing.Image)
        Me.DrawLine.Location = New System.Drawing.Point(0, 0)
        Me.DrawLine.Name = "DrawLine"
        Me.DrawLine.Size = New System.Drawing.Size(32, 30)
        Me.DrawLine.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(192, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 16)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Pen Width"
        '
        'PenWidthCounter
        '
        Me.PenWidthCounter.Location = New System.Drawing.Point(256, 8)
        Me.PenWidthCounter.Maximum = New Decimal(New Integer() {10, 0, 0, 0})
        Me.PenWidthCounter.Name = "PenWidthCounter"
        Me.PenWidthCounter.Size = New System.Drawing.Size(40, 20)
        Me.PenWidthCounter.TabIndex = 8
        Me.PenWidthCounter.Value = New Decimal(New Integer() {3, 0, 0, 0})
        '
        'PenBtn
        '
        Me.PenBtn.BackColor = System.Drawing.Color.White
        Me.PenBtn.ForeColor = System.Drawing.Color.Green
        Me.PenBtn.Image = CType(resources.GetObject("PenBtn.Image"), System.Drawing.Image)
        Me.PenBtn.Location = New System.Drawing.Point(304, 1)
        Me.PenBtn.Name = "PenBtn"
        Me.PenBtn.Size = New System.Drawing.Size(32, 30)
        Me.PenBtn.TabIndex = 9
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(352, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 23)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Transparency:"
        '
        'TransCounter
        '
        Me.TransCounter.Location = New System.Drawing.Point(424, 8)
        Me.TransCounter.Maximum = New Decimal(New Integer() {255, 0, 0, 0})
        Me.TransCounter.Name = "TransCounter"
        Me.TransCounter.Size = New System.Drawing.Size(48, 20)
        Me.TransCounter.TabIndex = 11
        Me.TransCounter.Value = New Decimal(New Integer() {255, 0, 0, 0})
        '
        'BrushBtn
        '
        Me.BrushBtn.BackColor = System.Drawing.Color.White
        Me.BrushBtn.ForeColor = System.Drawing.Color.Green
        Me.BrushBtn.Image = CType(resources.GetObject("BrushBtn.Image"), System.Drawing.Image)
        Me.BrushBtn.Location = New System.Drawing.Point(472, 0)
        Me.BrushBtn.Name = "BrushBtn"
        Me.BrushBtn.Size = New System.Drawing.Size(32, 30)
        Me.BrushBtn.TabIndex = 12
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(640, 461)
        Me.Controls.Add(Me.Panel1)
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(64, Byte), CType(64, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "GDI+Painter"
        Me.Panel1.ResumeLayout(False)
        CType(Me.PenWidthCounter, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TransCounter, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Get the full size of the form
        fullSize = SystemInformation.PrimaryMonitorMaximizedWindowSize
        ' Create a bitmap using full size
        bitmap = New Bitmap(fullSize.Width, fullSize.Height)
        ' Create a Graphics object from Bitmap
        curGraphics = Graphics.FromImage(bitmap)
        ' Set background color as form's color
        curGraphics.Clear(Me.BackColor)
        ' Default pen and brush button colors
        PenBtn.BackColor = Color.Black
        BrushBtn.BackColor = Color.Black
        ' Create a new pen and brush as 
        ' default pen and brush
        curPen = New Pen(Color.Black)
        curBrush = New SolidBrush(Color.Black)
    End Sub

    Protected Overrides Sub OnMouseDown(ByVal e As MouseEventArgs)
        ' Store the starting point of 
        ' the rectangle and set the drag mode
        ' to true
        curX = e.X
        curY = e.Y
        dragMode = True
    End Sub
    Protected Overrides Sub OnMouseMove(ByVal e As MouseEventArgs)
        ' Find out the ending point of 
        ' the rectangle and calculate the 
        ' difference of starting and ending
        ' points to find out the height and width 
        ' of the rectangle
        x = e.X
        y = e.Y
        diffX = e.X - curX
        diffY = e.Y - curY
        ' If drag mode is true, call refresh
        ' that forces window to repaint
        If dragMode Then
            Me.Refresh()
        End If
    End Sub
    Protected Overrides Sub OnMouseUp(ByVal e As MouseEventArgs)
        ' Set the pen's color
        curPen.Color = Color.FromArgb(Convert.ToInt16(TransCounter.Value.ToString()), PenBtn.BackColor.R, PenBtn.BackColor.G, PenBtn.BackColor.B)
        ' Set the pen's width
        curPen.Width = CSng(PenWidthCounter.Value)
        ' Set the brush's color
        curBrush.Color = Color.FromArgb(Convert.ToInt16(TransCounter.Value.ToString()), BrushBtn.BackColor.R, BrushBtn.BackColor.G, BrushBtn.BackColor.B)

        diffX = x - curX
        diffY = y - curY
        Select Case drawIndex
            Case 1
                ' Draw a line
                curGraphics.DrawLine(curPen, curX, curY, x, y)
                'Exit 
            Case 2
                ' Draw an ellipse
                curGraphics.DrawEllipse(curPen, curX, curY, diffX, diffY)
                'Exit 
            Case 3
                ' Draw rectangle
                curGraphics.DrawRectangle(curPen, curX, curY, diffX, diffY)
                'Exit 
            Case 4
                ' Fill rectangle
                curGraphics.FillRectangle(curBrush, curX, curY, diffX, diffY)
                'Exit 
            Case 5
                ' Fill ellipse
                curGraphics.FillEllipse(curBrush, curX, curY, diffX, diffY)
                'Exit 
        End Select
        ' Refresh 
        RefreshFormBackground()
        ' Set drag mode to false
        dragMode = False

    End Sub


    Private Sub DrawLine_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DrawLine.Click
        drawIndex = 1
    End Sub

    Private Sub DrawEllipse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DrawEllipse.Click
        drawIndex = 2
    End Sub

    Private Sub DrawRect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DrawRect.Click
        drawIndex = 3
    End Sub

    Private Sub Filledrect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Filledrect.Click
        drawIndex = 4
    End Sub

    Private Sub FilledEllipse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FilledEllipse.Click
        drawIndex = 5
    End Sub

    Private Sub SaveBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        ' Save file dialog
        Dim saveFileDlg As New SaveFileDialog
        saveFileDlg.Filter = "Image files (*.bmp)|*.bmp|All files (*.*)|*.*"
        If saveFileDlg.ShowDialog() = DialogResult.OK Then
            ' Create bitmap and call Save method 
            ' to save it 
            Dim tmpBitmap As Bitmap = bitmap.Clone(New Rectangle(0, 0, Me.Width, Me.Height), bitmap.PixelFormat)
            tmpBitmap.Save(saveFileDlg.FileName, ImageFormat.Bmp)
        End If
    End Sub

    Private Sub Form1_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        RefreshFormBackground()
    End Sub 'Form1_SizeChanged


    Private Sub RefreshFormBackground()
        curBitmap = bitmap.Clone(New Rectangle(0, 0, Me.Width, Me.Height), bitmap.PixelFormat)
        Me.BackgroundImage = curBitmap
    End Sub 'RefreshFormBackground

    Private Sub Form1_Closed(ByVal e As Form1)
        ' Dispose all public objects
        curPen.Dispose()
        curBrush.Dispose()
        curGraphics.Dispose()
    End Sub 'Form1_Closed


    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs)
        ' Dispose all public objects
        curPen.Dispose()
        curBrush.Dispose()
        curGraphics.Dispose()
    End Sub 'Form1_Closed

    Private Sub Panel1_Paint(ByVal sender As System.Object, ByVal e As System.Windows.Forms.PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub PenBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PenBtn.Click
        Dim colorDlg As New ColorDialog
        colorDlg.ShowDialog()
        PenBtn.BackColor = colorDlg.Color

    End Sub

    Private Sub BrushBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BrushBtn.Click
        Dim colorDlg As New ColorDialog
        colorDlg.ShowDialog()
        BrushBtn.BackColor = colorDlg.Color
    End Sub
    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        ' Set current pens color
        curPen.Color = Color.FromArgb(Convert.ToInt16(TransCounter.Value.ToString()), PenBtn.BackColor.R, PenBtn.BackColor.G, PenBtn.BackColor.B)
        ' Set pen's width
        curPen.Width = CSng(PenWidthCounter.Value)
        ' Set current brush's color
        curBrush.Color = Color.FromArgb(Convert.ToInt16(TransCounter.Value.ToString()), BrushBtn.BackColor.R, BrushBtn.BackColor.G, BrushBtn.BackColor.B)

        Dim g As Graphics = e.Graphics
        ' If dragmode is true, draw selected
        ' graphics shape
        If dragMode Then
            Select Case drawIndex
                Case 1
                    g.DrawLine(curPen, curX, curY, x, y)
                    ' Exit 
                Case 2
                    g.DrawEllipse(curPen, curX, curY, diffX, diffY)
                    'Exit 
                Case 3
                    g.DrawRectangle(curPen, curX, curY, diffX, diffY)
                    'Exit 
                Case 4
                    g.FillRectangle(curBrush, curX, curY, diffX, diffY)
                    'Exit 
                Case 5
                    g.FillEllipse(curBrush, curX, curY, diffX, diffY)
                    'Exit 
            End Select
        End If
    End Sub
End Class

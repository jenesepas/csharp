Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D
Imports System.Drawing.Imaging

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents TextureBrush As System.Windows.Forms.MenuItem
    Friend WithEvents LinearGradiantBrush As System.Windows.Forms.MenuItem
    Friend WithEvents PathGradiantBrush As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.TextureBrush = New System.Windows.Forms.MenuItem
        Me.LinearGradiantBrush = New System.Windows.Forms.MenuItem
        Me.PathGradiantBrush = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.TextureBrush, Me.LinearGradiantBrush, Me.PathGradiantBrush})
        Me.MenuItem1.Text = "Brush Transformation"
        '
        'TextureBrush
        '
        Me.TextureBrush.Index = 0
        Me.TextureBrush.Text = "Texture Brush"
        '
        'LinearGradiantBrush
        '
        Me.LinearGradiantBrush.Index = 1
        Me.LinearGradiantBrush.Text = "LinearGradiantBrush"
        '
        'PathGradiantBrush
        '
        Me.PathGradiantBrush.Index = 2
        Me.PathGradiantBrush.Text = "PathGradiantBrush"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(536, 342)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub TextureBrush_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextureBrush.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a TextureBrush object
        Dim txtrBrush As New TextureBrush(New Bitmap("smallRoses.gif"))
        ' Create a transformation matrix.
        Dim M As New Matrix
        ' Rotate the texture image by 90 degrees.
        txtrBrush.RotateTransform(90, MatrixOrder.Prepend)
        ' Translate
        M.Translate(50, 0)
        ' Multiply the transformation matrix
        ' of tBrush by translateMatrix.
        txtrBrush.MultiplyTransform(M)
        ' Scale operation
        txtrBrush.ScaleTransform(2, 1, MatrixOrder.Prepend)
        ' Fill a rectangle with texture brush
        g.FillRectangle(txtrBrush, 240, 0, 200, 200)
        ' Reset transformation
        txtrBrush.ResetTransform()
        ' Fill rectangle after reseting transformation
        g.FillRectangle(txtrBrush, 0, 0, 200, 200)
        ' Dispose
        txtrBrush.Dispose()
        g.Dispose()
    End Sub

    Private Sub LinearGradiantBrush_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LinearGradiantBrush.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a LinearGradientBrush object
        Dim rect As New Rectangle(20, 20, 200, 100)
        Dim lgBrush As New LinearGradientBrush(rect, Color.Red, Color.Green, 0.0F, True)
        Dim ptsArray As Point() = {New Point(20, 50), New Point(200, 50), New Point(20, 100)}
        Dim M As New Matrix(rect, ptsArray)
        ' Multiply transform
        lgBrush.MultiplyTransform(M, MatrixOrder.Prepend)
        ' Rotate transform
        lgBrush.RotateTransform(45.0F, MatrixOrder.Prepend)
        ' Scale Transform
        lgBrush.ScaleTransform(2, 1, MatrixOrder.Prepend)
        ' Draw a rectangle after transformation
        g.FillRectangle(lgBrush, 0, 0, 200, 100)
        ' Reset transform.
        lgBrush.ResetTransform()
        ' Draw a rectangle after Reset transform
        g.FillRectangle(lgBrush, 220, 0, 200, 100)
        ' Dispose
        lgBrush.Dispose()
        g.Dispose()
    End Sub

    Private Sub PathGradiantBrush_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PathGradiantBrush.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a GraphicsPath object
        Dim path As New GraphicsPath
        ' Create a rectangle and add it to path
        Dim rect As New Rectangle(20, 20, 200, 200)
        path.AddRectangle(rect)
        ' Create a path gradient brush
        Dim pgBrush As New PathGradientBrush(path.PathPoints)
        ' Set its center and surrounding colors
        pgBrush.CenterColor = Color.Green
        pgBrush.SurroundColors = New Color() {Color.Blue}
        ' Create matrix
        Dim M As New Matrix
        ' Translate
        M.Translate(20.0F, 10.0F, MatrixOrder.Prepend)
        ' Rotate
        M.Rotate(10.0F, MatrixOrder.Prepend)
        ' Scale
        M.Scale(2, 1, MatrixOrder.Prepend)
        ' shear
        M.Shear(0.05F, 0.03F, MatrixOrder.Prepend)
        ' Apply matrix to the brush
        pgBrush.MultiplyTransform(M)
        ' Use brush after transformation
        ' to fill a rectangle
        g.FillRectangle(pgBrush, 20, 100, 400, 400)
        ' Dispose
        pgBrush.Dispose()
        g.Dispose()
    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D

Public Class Form1
    Inherits System.Windows.Forms.Form
    Private txtrBrush As Brush
    'Private components As System.ComponentModel.IContainer
    'Private menuItem7 As System.Windows.Forms.MenuItem
    'Private menuItem8 As System.Windows.Forms.MenuItem
    'Private timer1 As System.Windows.Forms.Timer
    Private brushType As Short = 0
    Private fireActive As Boolean = False
    ' Private button1 As System.Windows.Forms.Button
    Private fireBrush As LinearGradientBrush = Nothing


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem7 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem8 As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.Button1 = New System.Windows.Forms.Button
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.MenuItem3 = New System.Windows.Forms.MenuItem
        Me.MenuItem4 = New System.Windows.Forms.MenuItem
        Me.MenuItem5 = New System.Windows.Forms.MenuItem
        Me.MenuItem6 = New System.Windows.Forms.MenuItem
        Me.MenuItem7 = New System.Windows.Forms.MenuItem
        Me.MenuItem8 = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(272, 56)
        Me.Button1.Name = "Button1"
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "ON"
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem2})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem3, Me.MenuItem4, Me.MenuItem5, Me.MenuItem6, Me.MenuItem7, Me.MenuItem8})
        Me.MenuItem1.Text = "Brushes"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 0
        Me.MenuItem3.Text = "Solid Brush"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 1
        Me.MenuItem4.Text = "Hatch Brush"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 2
        Me.MenuItem5.Text = "Texture Brush"
        '
        'MenuItem6
        '
        Me.MenuItem6.Index = 3
        Me.MenuItem6.Text = "Gradiant Brush1"
        '
        'MenuItem7
        '
        Me.MenuItem7.Index = 4
        Me.MenuItem7.Text = "Gradiant Brush2"
        '
        'MenuItem8
        '
        Me.MenuItem8.Index = 5
        Me.MenuItem8.Text = "Fire Show"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.Text = "Pens"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(392, 326)
        Me.Controls.Add(Me.Button1)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If fireActive Then
            fireActive = False
            Button1.Text = "OFF"
        Else
            fireActive = True
            Button1.Text = "ON"
        End If
        Me.Invalidate(Me.ClientRectangle)
    End Sub

    Private Sub MenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem3.Click
        brushType = 1
        Me.Invalidate(Me.ClientRectangle)
    End Sub

    Private Sub MenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem4.Click
        brushType = 2
        Me.Invalidate(Me.ClientRectangle)
    End Sub

    Private Sub MenuItem5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem5.Click
        Dim img As Image = New Bitmap("C:\BookCover1.jpg")
        txtrBrush = New TextureBrush(img)
        brushType = 3
        Me.Invalidate(Me.ClientRectangle)
    End Sub

    Private Sub MenuItem6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem6.Click
        brushType = 4
        Me.Invalidate(Me.ClientRectangle)
    End Sub

    Private Sub MenuItem7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem7.Click
        brushType = 5
        Me.Invalidate(Me.ClientRectangle)
    End Sub

    Private Sub MenuItem8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem8.Click
        brushType = 6
			me.Invalidate(me.ClientRectangle)
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        brushType = 0
    End Sub
    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        Dim g As Graphics = e.Graphics '
        If brushType = 0 Then
            Return
        End If
        If brushType = 1 Then
            Dim redBrush As New SolidBrush(Color.Red)
            Dim greenBrush As New SolidBrush(Color.Green)
            Dim blueBrush As New SolidBrush(Color.Blue)

            g.FillEllipse(redBrush, 20, 40, 100, 120)
            Dim rect As New Rectangle(150, 80, 200, 140)
            g.FillPie(greenBrush, 40, 20, 200, 40, 0.0F, 60.0F)
            g.FillRectangle(blueBrush, rect)
        End If

        If brushType = 2 Then
            Dim hBrush1 As New HatchBrush(HatchStyle.DashedVertical, Color.Chocolate, Color.Red)
            Dim hBrush2 As New HatchBrush(HatchStyle.DarkDownwardDiagonal, Color.Green, Color.Black)
            Dim hBrush3 As New HatchBrush(HatchStyle.SmallCheckerBoard, Color.BlueViolet, Color.Blue)

            g.FillEllipse(hBrush1, 20, 40, 100, 120)
            Dim rect As New Rectangle(150, 80, 200, 140)
            g.FillPie(hBrush3, 40, 20, 200, 40, 0.0F, 60.0F)
            g.FillRectangle(hBrush2, rect)
        End If

        If brushType = 3 Then
            g.FillRectangle(txtrBrush, ClientRectangle)
        End If

        If brushType = 4 Then
            Dim rect1 As New Rectangle(20, 40, 100, 120)
            Dim rect2 As New Rectangle(150, 80, 200, 140)
            Dim rect3 As New Rectangle(0, 20, 200, 40)

            Dim lgBrush1 As New LinearGradientBrush(rect1, Color.Red, Color.Green, LinearGradientMode.BackwardDiagonal)

            Dim lgBrush2 As New LinearGradientBrush(rect2, Color.Black, Color.Yellow, LinearGradientMode.Horizontal)

            Dim lgBrush3 As New LinearGradientBrush(rect3, Color.Blue, Color.Gold, LinearGradientMode.Vertical)

            g.FillEllipse(lgBrush1, 20, 40, 100, 120)
            Dim rect As New Rectangle(150, 80, 200, 140)
            g.FillPie(lgBrush2, 40, 20, 200, 40, 0.0F, 60.0F)
            g.FillRectangle(lgBrush3, rect)
        End If

        If brushType = 5 Then
            Dim pt1 As New Point(40, 30)
            Dim pt2 As New Point(80, 100)

            Dim lnColors As Color() = {Color.Black, Color.Red}

            Dim lgBrush As New LinearGradientBrush(pt1, pt2, Color.Red, Color.Green)
            lgBrush.LinearColors = lnColors
            lgBrush.GammaCorrection = True

            g.FillRectangle(lgBrush, 20, 20, 200, 200)
        End If

        If brushType = 6 Then
            Dim rect3 As New Rectangle(0, 20, 100, 20)

            If Not fireActive Then
                fireBrush = New LinearGradientBrush(rect3, Color.Yellow, Color.Red, LinearGradientMode.Vertical)
            Else
                fireBrush = New LinearGradientBrush(rect3, Color.Gold, Color.Red, LinearGradientMode.Vertical)
            End If

            Dim pt1 As New Point(40, 30)
            Dim pt2 As New Point(80, 100)

            Dim lnColors As Color() = {Color.Black, Color.Red}

            Dim lgBrush As New LinearGradientBrush(pt1, pt2, Color.Red, Color.Green)
            lgBrush.LinearColors = lnColors
            lgBrush.GammaCorrection = True
            g.FillRectangle(lgBrush, Me.ClientRectangle)
            g.FillRectangle(fireBrush, 50, 50, 140, 100)
        End If
    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D

Public Class Form1
    Inherits System.Windows.Forms.Form
    Private style As New HatchStyle
    Private forClr As Color = Color.Blue
    Private backClr As Color = Color.Red
    Private lgBrush As LinearGradientBrush = Nothing
    Private mode As New LinearGradientMode
    Private startColor As Color = Color.Red
    Private endColor As Color = Color.Green

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents ForColorBtn As System.Windows.Forms.Button
    Friend WithEvents BackGroundBtn As System.Windows.Forms.Button
    Friend WithEvents ApplyBtn As System.Windows.Forms.Button
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents PrepertiesBtn As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.ComboBox1 = New System.Windows.Forms.ComboBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.ForColorBtn = New System.Windows.Forms.Button
        Me.BackGroundBtn = New System.Windows.Forms.Button
        Me.ApplyBtn = New System.Windows.Forms.Button
        Me.CheckBox1 = New System.Windows.Forms.CheckBox
        Me.CheckBox2 = New System.Windows.Forms.CheckBox
        Me.PrepertiesBtn = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Select Style:"
        '
        'ComboBox1
        '
        Me.ComboBox1.Location = New System.Drawing.Point(96, 8)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 1
        Me.ComboBox1.Text = "ComboBox1"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 23)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Forground Color:"
        '
        'TextBox1
        '
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.Location = New System.Drawing.Point(112, 40)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(32, 20)
        Me.TextBox1.TabIndex = 3
        Me.TextBox1.Text = ""
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(0, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(104, 23)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Background Color:"
        '
        'TextBox2
        '
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.Location = New System.Drawing.Point(112, 72)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.Size = New System.Drawing.Size(32, 20)
        Me.TextBox2.TabIndex = 5
        Me.TextBox2.Text = ""
        '
        'ForColorBtn
        '
        Me.ForColorBtn.Location = New System.Drawing.Point(152, 40)
        Me.ForColorBtn.Name = "ForColorBtn"
        Me.ForColorBtn.Size = New System.Drawing.Size(48, 23)
        Me.ForColorBtn.TabIndex = 6
        Me.ForColorBtn.Text = "Pick..."
        '
        'BackGroundBtn
        '
        Me.BackGroundBtn.Location = New System.Drawing.Point(152, 72)
        Me.BackGroundBtn.Name = "BackGroundBtn"
        Me.BackGroundBtn.Size = New System.Drawing.Size(48, 23)
        Me.BackGroundBtn.TabIndex = 7
        Me.BackGroundBtn.Text = "Pic..."
        '
        'ApplyBtn
        '
        Me.ApplyBtn.Location = New System.Drawing.Point(224, 64)
        Me.ApplyBtn.Name = "ApplyBtn"
        Me.ApplyBtn.Size = New System.Drawing.Size(96, 32)
        Me.ApplyBtn.TabIndex = 8
        Me.ApplyBtn.Text = "Apply  Settings"
        '
        'CheckBox1
        '
        Me.CheckBox1.Location = New System.Drawing.Point(240, 8)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(152, 24)
        Me.CheckBox1.TabIndex = 9
        Me.CheckBox1.Text = "Other Rectangle"
        '
        'CheckBox2
        '
        Me.CheckBox2.Location = New System.Drawing.Point(240, 40)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(152, 24)
        Me.CheckBox2.TabIndex = 10
        Me.CheckBox2.Text = "Gamma Correction"
        '
        'PrepertiesBtn
        '
        Me.PrepertiesBtn.Location = New System.Drawing.Point(336, 64)
        Me.PrepertiesBtn.Name = "PrepertiesBtn"
        Me.PrepertiesBtn.Size = New System.Drawing.Size(96, 32)
        Me.PrepertiesBtn.TabIndex = 11
        Me.PrepertiesBtn.Text = "Properties"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(464, 389)
        Me.Controls.Add(Me.PrepertiesBtn)
        Me.Controls.Add(Me.CheckBox2)
        Me.Controls.Add(Me.CheckBox1)
        Me.Controls.Add(Me.ApplyBtn)
        Me.Controls.Add(Me.BackGroundBtn)
        Me.Controls.Add(Me.ForColorBtn)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Hatch Brushes"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Fill combo box with hatch styles
        AddGradientMode()
        ' Set foreground and background color
        ' text boxes's backgrond color
        TextBox1.BackColor = startColor
        TextBox2.BackColor = endColor
    End Sub

    Private Sub ApplyBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ApplyBtn.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Read curretnt style from combo box
        Dim str As String = ComboBox1.Text
        ' Find out the mode and set it as the 
        ' current mode
        Select Case str
            Case "BackwardDiagonal"
                mode = LinearGradientMode.BackwardDiagonal
            Case "ForwardDiagonal"
                mode = LinearGradientMode.ForwardDiagonal
            Case "Horizontal"
                mode = LinearGradientMode.Horizontal
            Case "Vertical"
                mode = LinearGradientMode.Vertical
            Case Else
        End Select
        ' Create a rectangle
        Dim rect As New Rectangle(50, 140, 200, 220)

        ' Create linear gradient brush and set mode
        If CheckBox1.Checked Then
            Dim rect1 As New Rectangle(20, 20, 50, 50)
            lgBrush = New LinearGradientBrush(rect1, startColor, endColor, mode)
        Else
            lgBrush = New LinearGradientBrush(rect, startColor, endColor, mode)
        End If
        ' Gamma correction check box is checked
        If CheckBox1.Checked Then
            lgBrush.GammaCorrection = True
        End If

        ' Fill rectangle
        g.FillRectangle(lgBrush, rect)
        ' Dispose
        lgBrush.Dispose()
        g.Dispose()
    End Sub

    Private Sub AddGradientMode()
        ' Adds linear gradient mode styles to the 
        ' combo box
        ComboBox1.Items.Add(LinearGradientMode.BackwardDiagonal)
        ComboBox1.Items.Add(LinearGradientMode.ForwardDiagonal)
        ComboBox1.Items.Add(LinearGradientMode.Horizontal)
        ComboBox1.Items.Add(LinearGradientMode.Vertical)
        ComboBox1.Text = LinearGradientMode.BackwardDiagonal.ToString()
    End Sub 'AddGradientMode

    Private Sub ForColorBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ForColorBtn.Click
        ' Use Color dialog to select a color
        Dim clrDlg As New ColorDialog
        If clrDlg.ShowDialog() = DialogResult.OK Then
            ' Save color as foreground color
            ' fill text box as this color
            startColor = clrDlg.Color
            TextBox1.BackColor = startColor
        End If
    End Sub

    Private Sub BackGroundBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackGroundBtn.Click
        ' Use Color dialog to select a color
        Dim clrDlg As New ColorDialog
        If clrDlg.ShowDialog() = DialogResult.OK Then
            ' Save color as background color
            ' fill text box as this color
            endColor = clrDlg.Color
            TextBox2.BackColor = endColor
        End If

    End Sub

    Private Sub PrepertiesBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrepertiesBtn.Click
        Dim g As Graphics = Me.CreateGraphics()
        ' Create points
        Dim pt1 As New Point(40, 30)
        Dim pt2 As New Point(80, 100)
        Dim lnColors As Color() = {Color.Black, Color.Red}
        ' Create a linear gradient brush 
        Dim lgBrush As New LinearGradientBrush(pt1, pt2, Color.Red, Color.Green)
        ' Set linear colors and gamma correction
        lgBrush.LinearColors = lnColors
        lgBrush.GammaCorrection = True
        ' Draw rectangle
        g.FillRectangle(lgBrush, 50, 140, 200, 200)
        ' Dispose
        lgBrush.Dispose()
        g.Dispose()
    End Sub
End Class

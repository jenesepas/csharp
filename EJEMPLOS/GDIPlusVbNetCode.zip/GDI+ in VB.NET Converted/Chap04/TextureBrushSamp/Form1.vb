Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D

Public Class Form1
    Inherits System.Windows.Forms.Form
    Private txtrBrush As TextureBrush = Nothing

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents ContextMenu1 As System.Windows.Forms.ContextMenu
    Friend WithEvents Clamp As System.Windows.Forms.MenuItem
    Friend WithEvents Tile As System.Windows.Forms.MenuItem
    Friend WithEvents TileFlipX As System.Windows.Forms.MenuItem
    Friend WithEvents TileFlipY As System.Windows.Forms.MenuItem
    Friend WithEvents TileFlipXY As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.ContextMenu1 = New System.Windows.Forms.ContextMenu
        Me.Clamp = New System.Windows.Forms.MenuItem
        Me.Tile = New System.Windows.Forms.MenuItem
        Me.TileFlipX = New System.Windows.Forms.MenuItem
        Me.TileFlipY = New System.Windows.Forms.MenuItem
        Me.TileFlipXY = New System.Windows.Forms.MenuItem
        '
        'ContextMenu1
        '
        Me.ContextMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.Clamp, Me.Tile, Me.TileFlipX, Me.TileFlipY, Me.TileFlipXY})
        '
        'Clamp
        '
        Me.Clamp.Index = 0
        Me.Clamp.Text = "Clamp"
        '
        'Tile
        '
        Me.Tile.Index = 1
        Me.Tile.Text = "Tile"
        '
        'TileFlipX
        '
        Me.TileFlipX.Index = 2
        Me.TileFlipX.Text = "TileFlipX"
        '
        'TileFlipY
        '
        Me.TileFlipY.Index = 3
        Me.TileFlipY.Text = "TileFlipY"
        '
        'TileFlipXY
        '
        Me.TileFlipXY.Index = 4
        Me.TileFlipXY.Text = "TileFlipXY"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(488, 293)
        Me.Name = "Form1"
        Me.Text = "TextureBrushSamp"

    End Sub

#End Region

    Private Sub Clamp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Clamp.Click
        txtrBrush.WrapMode = WrapMode.Clamp
        Me.Invalidate()
    End Sub

    Private Sub Tile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Tile.Click
        txtrBrush.WrapMode = WrapMode.Tile
        Me.Invalidate()
    End Sub

    Private Sub TileFlipX_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TileFlipX.Click
        txtrBrush.WrapMode = WrapMode.TileFlipX
        Me.Invalidate()
    End Sub

    Private Sub TileFlipY_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TileFlipY.Click
        txtrBrush.WrapMode = WrapMode.TileFlipY
        Me.Invalidate()
    End Sub

    Private Sub TileFlipXY_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TileFlipXY.Click
        txtrBrush.WrapMode = WrapMode.TileFlipXY
        Me.Invalidate()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Create an Image from a file
        Dim img = New Bitmap("smallRoses.gif")
        ' Create a texture brush from an image
        txtrBrush = New TextureBrush(img)
        img.Dispose()
    End Sub
    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        Dim g As Graphics = e.Graphics
        ' Fill a rectangle with a texture brush
        g.FillRectangle(txtrBrush, ClientRectangle)
    End Sub

    Protected Overrides Sub OnMouseDown(ByVal e As MouseEventArgs)
        If e.Button = MouseButtons.Right Then '
            Me.ContextMenu = ContextMenu1
        End If
    End Sub
End Class

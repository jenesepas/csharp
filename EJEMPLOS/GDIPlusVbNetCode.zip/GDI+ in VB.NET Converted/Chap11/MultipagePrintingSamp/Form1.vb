Imports System
Imports System.Drawing
Imports System.Drawing.Text
Imports System.Drawing.Printing
Imports System.Collections
'imports System.ComponentModel
imports System.Windows.Forms
Public Class Form1

    Inherits System.Windows.Forms.Form
    Private fontcount As Integer
    Private fontposition As Integer = 1
    Private ypos As Single = 1
    Private previewDlg As PrintPreviewDialog = Nothing

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents printPreviewDialog1 As System.Windows.Forms.PrintPreviewDialog
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents DisplayFonts As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents richTextBox1 As System.Windows.Forms.RichTextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.printPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.DisplayFonts = New System.Windows.Forms.MenuItem
        Me.menuItem5 = New System.Windows.Forms.MenuItem
        Me.menuItem2 = New System.Windows.Forms.MenuItem
        Me.menuItem3 = New System.Windows.Forms.MenuItem
        Me.richTextBox1 = New System.Windows.Forms.RichTextBox
        Me.SuspendLayout()
        '
        'printPreviewDialog1
        '
        Me.printPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.printPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.printPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.printPreviewDialog1.Enabled = True
        Me.printPreviewDialog1.Icon = CType(resources.GetObject("printPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.printPreviewDialog1.Location = New System.Drawing.Point(44, 58)
        Me.printPreviewDialog1.MinimumSize = New System.Drawing.Size(375, 250)
        Me.printPreviewDialog1.Name = "printPreviewDialog1"
        Me.printPreviewDialog1.TransparencyKey = System.Drawing.Color.Empty
        Me.printPreviewDialog1.Visible = False
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.DisplayFonts, Me.menuItem5, Me.menuItem2, Me.menuItem3})
        Me.menuItem1.Text = "File"
        '
        'DisplayFonts
        '
        Me.DisplayFonts.Index = 0
        Me.DisplayFonts.Text = "Display Fonts"
        '
        'menuItem5
        '
        Me.menuItem5.Index = 1
        Me.menuItem5.Text = "-"
        '
        'menuItem2
        '
        Me.menuItem2.Index = 2
        Me.menuItem2.Text = "Print"
        '
        'menuItem3
        '
        Me.menuItem3.Index = 3
        Me.menuItem3.Text = "Print Preview"
        '
        'richTextBox1
        '
        Me.richTextBox1.Location = New System.Drawing.Point(8, 0)
        Me.richTextBox1.Name = "richTextBox1"
        Me.richTextBox1.Size = New System.Drawing.Size(424, 280)
        Me.richTextBox1.TabIndex = 1
        Me.richTextBox1.Text = "richTextBox1"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(440, 294)
        Me.Controls.Add(Me.richTextBox1)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Multiple Page Printing"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub DisplayFonts_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DisplayFonts.Click
        ' Create InstalledFontCollection object
        Dim ifc As New InstalledFontCollection
        ' Get font families
        Dim ffs As FontFamily() = ifc.Families
        Dim f As Font
        ' Make sure tich text box is empty
        richTextBox1.Clear()
        ' Read font families one by one and 
        ' set font to some text
        ' and add text to the text box
        Dim ff As FontFamily
        For Each ff In ffs
            If ff.IsStyleAvailable(FontStyle.Regular) Then
                f = New Font(ff.GetName(1), 12, FontStyle.Regular)
            Else
                If ff.IsStyleAvailable(FontStyle.Bold) Then
                    f = New Font(ff.GetName(1), 12, FontStyle.Bold)
                Else
                    If ff.IsStyleAvailable(FontStyle.Italic) Then
                        f = New Font(ff.GetName(1), 12, FontStyle.Italic)
                    Else
                        f = New Font(ff.GetName(1), 12, FontStyle.Underline)
                    End If
                End If
            End If
            richTextBox1.SelectionFont = f
            richTextBox1.AppendText((ff.GetName(1) + ControlChars.Cr + ControlChars.Lf))
            richTextBox1.SelectionFont = f
            richTextBox1.AppendText("abcdefghijklmnopqrstuvwxyz" + ControlChars.Cr + ControlChars.Lf)
            richTextBox1.SelectionFont = f
            richTextBox1.AppendText("ABCDEFGHIJKLMNOPQRSTUVWXYZ" + ControlChars.Cr + ControlChars.Lf)
            richTextBox1.AppendText("==============================" + ControlChars.Cr + ControlChars.Lf)
        Next ff

    End Sub

    Private Sub menuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuItem2.Click
        ' Create a PrintPreviewDialog
        previewDlg = New PrintPreviewDialog
        ' Create a PrintDocument
        Dim pd As New PrintDocument
        pd.DocumentName = "A Test Document"
        ' Add print page event hanlder
        AddHandler pd.PrintPage, AddressOf pd_PrintPage
        ' Print
        pd.Print()
    End Sub

    Private Sub menuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuItem3.Click
        ' Create a PrintPreviewDialog
        previewDlg = New PrintPreviewDialog
        ' Create a PrintDocument
        Dim pd As New PrintDocument
        ' Add print page event hanlder
        AddHandler pd.PrintPage, AddressOf pd_PrintPage
        ' Set Document property of PrintPreviewDlg
        previewDlg.Document = pd
        ' Display dialog
        previewDlg.Show()
    End Sub

    Public Sub pd_PrintPage(ByVal sender As Object, ByVal ev As PrintPageEventArgs)
        ypos = 1
        Dim pageheight As Single = ev.MarginBounds.Height
        ' Create a Graphics object
        Dim g As Graphics = ev.Graphics
        ' Get installed fonts
        Dim ifc As New InstalledFontCollection
        ' Get font families
        Dim ffs As FontFamily() = ifc.Families
        ' Draw string on the paper
        While ypos + 60 < pageheight And fontposition < ffs.GetLength(0)
            ' Get the font name
            Dim f As New Font(ffs(fontposition).GetName(0), 25)
            ' Draw string
            g.DrawString(ffs(fontposition).GetName(0), f, New SolidBrush(Color.Black), 1, ypos)
            fontposition = fontposition + 1
            ypos = ypos + 60
        End While
        If fontposition < ffs.GetLength(0) Then
            ' Has more pages??
            ev.HasMorePages = True
        End If
    End Sub 'pd_PrintPage
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Printing
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents Normal As System.Windows.Forms.MenuItem
    Friend WithEvents Margins As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.Normal = New System.Windows.Forms.MenuItem
        Me.Margins = New System.Windows.Forms.MenuItem
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.Normal, Me.Margins})
        Me.menuItem1.Text = "Printing"
        '
        'Normal
        '
        Me.Normal.Index = 0
        Me.Normal.Text = "Normal"
        '
        'Margins
        '
        Me.Margins.Index = 1
        Me.Margins.Text = "Margins"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(344, 306)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Printing Margins Sample"

    End Sub

#End Region

    Private Sub Normal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Normal.Click
        Dim pd As New PrintDocument
        AddHandler pd.PrintPage, AddressOf NormalPrinting
        pd.Print()
    End Sub

    Public Sub NormalPrinting(ByVal sender As Object, ByVal ev As PrintPageEventArgs)
        Dim ypos As Single = 1
        Dim leftMargin As Single = ev.MarginBounds.Left
        'Create a font
        Dim font As New Font("Arial", 16)
        Dim fontheight As Single = font.GetHeight(ev.Graphics)
        ev.Graphics.DrawString("Top Margin = " + ev.MarginBounds.Top.ToString(), font, Brushes.Black, leftMargin, ypos)
        ypos = ypos + fontheight
        ev.Graphics.DrawString("Bottom Margin = " + ev.MarginBounds.Bottom.ToString(), font, Brushes.Black, leftMargin, ypos)
        ypos = ypos + fontheight
        ev.Graphics.DrawString("Left Margin = " + ev.MarginBounds.Left.ToString(), font, Brushes.Black, leftMargin, ypos)
        ypos = ypos + fontheight
        ev.Graphics.DrawString("Right Margin = " + ev.MarginBounds.Right.ToString(), font, Brushes.Black, leftMargin, ypos)
        ypos = ypos + fontheight
        ev.Graphics.DrawRectangle(New Pen(Color.Black), ev.MarginBounds.X, ev.MarginBounds.Y, ev.MarginBounds.Width, ev.MarginBounds.Height)
    End Sub 'NormalPrinting


    Public Sub MarginPrinting(ByVal sender As Object, ByVal ev As PrintPageEventArgs)
        Dim ypos As Single = ev.MarginBounds.Top
        Dim leftMargin As Single = ev.MarginBounds.Left

        'Create a font
        Dim font As New Font("Arial", 16)

        Dim fontheight As Single = font.GetHeight(ev.Graphics)
        ev.Graphics.DrawString("Top Margin = " + ev.MarginBounds.Top.ToString(), font, Brushes.Black, leftMargin, ypos)
        ypos = ypos + fontheight
        ev.Graphics.DrawString("Bottom Margin = " + ev.MarginBounds.Bottom.ToString(), font, Brushes.Black, leftMargin, ypos)
        ypos = ypos + fontheight
        ev.Graphics.DrawString("Left Margin = " + ev.MarginBounds.Left.ToString(), font, Brushes.Black, leftMargin, ypos)
        ypos = ypos + fontheight
        ev.Graphics.DrawString("Right Margin = " + ev.MarginBounds.Right.ToString(), font, Brushes.Black, leftMargin, ypos)
        ypos = ypos + fontheight
        ev.Graphics.DrawRectangle(New Pen(Color.Black), ev.MarginBounds.X, ev.MarginBounds.Y, ev.MarginBounds.Width, ev.MarginBounds.Height)
    End Sub 'MarginPrinting

    Private Sub Margins_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Margins.Click
        Dim pd As New PrintDocument
        AddHandler pd.PrintPage, AddressOf MarginPrinting
        pd.Print()
    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Printing
Imports System.Drawing.Imaging
Imports System.Drawing.Drawing2D
Imports System.Drawing.Text
Public Class Form1
    Inherits System.Windows.Forms.Form
    Private curImage As Image = Nothing
    Private curFileName As String = Nothing
    Private previewDlg As PrintPreviewDialog = Nothing
    Private setupDlg As PageSetupDialog = Nothing
    Private printDoc As PrintDocument = Nothing
    Private printDlg As PrintDialog = Nothing
    Private printDialog1 As System.Windows.Forms.PrintDialog

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    ' Friend WithEvents printDialog1 As System.Windows.Forms.PrintDialog
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents OpenFile As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents PrintPreview As System.Windows.Forms.MenuItem
    Friend WithEvents PrintSetup As System.Windows.Forms.MenuItem
    Friend WithEvents PrintDialog As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.printDialog1 = New System.Windows.Forms.PrintDialog
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.OpenFile = New System.Windows.Forms.MenuItem
        Me.menuItem2 = New System.Windows.Forms.MenuItem
        Me.PrintPreview = New System.Windows.Forms.MenuItem
        Me.PrintSetup = New System.Windows.Forms.MenuItem
        Me.PrintDialog = New System.Windows.Forms.MenuItem
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.OpenFile, Me.menuItem2, Me.PrintPreview, Me.PrintSetup, Me.PrintDialog})
        Me.menuItem1.Text = "Print Dialog"
        '
        'OpenFile
        '
        Me.OpenFile.Index = 0
        Me.OpenFile.Text = "Open File"
        '
        'menuItem2
        '
        Me.menuItem2.Index = 1
        Me.menuItem2.Text = "-"
        '
        'PrintPreview
        '
        Me.PrintPreview.Index = 2
        Me.PrintPreview.Text = "Print Preview Dialog"
        '
        'PrintSetup
        '
        Me.PrintSetup.Index = 3
        Me.PrintSetup.Text = "Page Setup Dialog"
        '
        'PrintDialog
        '
        Me.PrintDialog.Index = 4
        Me.PrintDialog.Text = "Print Dialog"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(368, 353)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub OpenFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenFile.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim openDlg As New OpenFileDialog
        openDlg.Filter = "All Image files|*.bmp;*.gif;*.jpg;*.ico;" + "*.emf,*.wmf|Bitmap Files(*.bmp;*.gif;*.jpg;" + "*.ico)|*.bmp;*.gif;*.jpg;*.ico|" + "Meta Files(*.emf;*.wmf)|*.emf;*.wmf"
        Dim filter As String = openDlg.Filter
        openDlg.InitialDirectory = Environment.CurrentDirectory
        openDlg.Title = "Open Image File"
        openDlg.ShowHelp = True
        If openDlg.ShowDialog() = DialogResult.OK Then
            curFileName = openDlg.FileName
            curImage = Image.FromFile(curFileName)
        End If
        Invalidate()

    End Sub

    Private Sub PrintPreview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintPreview.Click
        previewDlg.UseAntiAlias = True
        previewDlg.WindowState = FormWindowState.Normal
        previewDlg.ShowDialog()
    End Sub

    Private Sub PrintSetup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintSetup.Click
        If (setupDlg.ShowDialog() = DialogResult.OK) Then
            printDoc.DefaultPageSettings = setupDlg.PageSettings()
            printDoc.PrinterSettings = setupDlg.PrinterSettings
        End If

    End Sub

    Private Sub PrintDialog_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintDialog.Click
        If (printDlg.ShowDialog() = DialogResult.OK) Then
            printDoc.Print()
        End If

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Create print preview dialog
        ' and other dialogs 
        previewDlg = New PrintPreviewDialog
        setupDlg = New PageSetupDialog
        printDlg = New PrintDialog
        printDoc = New PrintDocument
        ' Set document name
        printDoc.DocumentName = "Print Document"
        ' PrintPreviewDialog Settings
        previewDlg.Document = printDoc
        ' PageSetupDialog Settings
        setupDlg.Document = printDoc
        ' PrintDialog settings
        printDlg.Document = printDoc
        printDlg.AllowSelection = True
        printDlg.AllowSomePages = True
        ' Create a PringPage Event Handler
        AddHandler printDoc.PrintPage, AddressOf pd_Print
    End Sub
    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        DrawGraphicsItems(e.Graphics)
    End Sub

    Private Sub DrawGraphicsItems(ByVal gObj As Graphics) '
        ' Setting text and images quality
        gObj.SmoothingMode = SmoothingMode.AntiAlias
        gObj.TextRenderingHint = TextRenderingHint.AntiAlias
        If Not (curImage Is Nothing) Then
            ' Draw Image using the DrawImage method 
            gObj.DrawImage(curImage, AutoScrollPosition.X, AutoScrollPosition.Y, curImage.Width, curImage.Height)
        End If
        ' Draw a string     
        gObj.DrawString("Printing Dialogs Test", New Font("Verdana", 14), New SolidBrush(Color.Blue), 0, 0)
    End Sub 'DrawGraphicsItems

    Private Sub pd_Print(ByVal sender As Object, ByVal ppeArgs As PrintPageEventArgs)
        DrawGraphicsItems(ppeArgs.Graphics)
    End Sub 'pd_Print
End Class

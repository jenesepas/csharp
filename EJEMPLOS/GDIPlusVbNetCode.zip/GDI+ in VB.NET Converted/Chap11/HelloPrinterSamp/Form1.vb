Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Printing
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents printersList As System.Windows.Forms.ComboBox
    Friend WithEvents HelloPrinterBtn As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.label1 = New System.Windows.Forms.Label
        Me.printersList = New System.Windows.Forms.ComboBox
        Me.HelloPrinterBtn = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(108, 46)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(112, 24)
        Me.label1.TabIndex = 5
        Me.label1.Text = "Available Printers:"
        '
        'printersList
        '
        Me.printersList.Location = New System.Drawing.Point(228, 46)
        Me.printersList.Name = "printersList"
        Me.printersList.Size = New System.Drawing.Size(136, 21)
        Me.printersList.TabIndex = 4
        '
        'HelloPrinterBtn
        '
        Me.HelloPrinterBtn.Location = New System.Drawing.Point(204, 142)
        Me.HelloPrinterBtn.Name = "HelloPrinterBtn"
        Me.HelloPrinterBtn.Size = New System.Drawing.Size(112, 32)
        Me.HelloPrinterBtn.TabIndex = 3
        Me.HelloPrinterBtn.Text = "Hello Printer"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(472, 221)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.printersList)
        Me.Controls.Add(Me.HelloPrinterBtn)
        Me.Name = "Form1"
        Me.Text = "My First Printing Application"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' See if installed printers are 0
        If PrinterSettings.InstalledPrinters.Count <= 0 Then
            MessageBox.Show("Printer not found!")
            Return
        End If
        ' Get all the available printers and add to the 
        ' ComboBox
        Dim printer As [String]
        For Each printer In PrinterSettings.InstalledPrinters
            printersList.Items.Add(printer.ToString())
        Next printer
    End Sub

    Public Sub pd_PrintPage(ByVal sender As Object, ByVal ev As PrintPageEventArgs)
        ' Get the Graphics object 
        Dim g As Graphics = ev.Graphics
        'Create a font arial with size 16
        Dim font As New Font("Arial", 16)
        ' Create a solid brush with black color
        Dim brush As New SolidBrush(Color.Black)
        ' Draw Hello Printer! 
        g.DrawString("Hello Printer!", font, brush, New RectangleF(20, 20, 200, 100))
    End Sub 'pd_PrintPage

    Private Sub HelloPrinterBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HelloPrinterBtn.Click
        ' Create a PrintDocumet
        Dim pd As New PrintDocument
        ' Set PrinterName as the selected printer
        ' in the printers list
        pd.PrinterSettings.PrinterName = printersList.SelectedItem.ToString()
        ' Add PrintPage event handler
        AddHandler pd.PrintPage, AddressOf pd_PrintPage
        ' Print the document.
        pd.Print()
    End Sub
End Class

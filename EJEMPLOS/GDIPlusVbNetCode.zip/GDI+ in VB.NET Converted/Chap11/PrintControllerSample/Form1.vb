Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Printing
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents StandardPrintControllerMenu As System.Windows.Forms.MenuItem
    Friend WithEvents statusBar1 As System.Windows.Forms.StatusBar
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.StandardPrintControllerMenu = New System.Windows.Forms.MenuItem
        Me.statusBar1 = New System.Windows.Forms.StatusBar
        Me.SuspendLayout()
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.StandardPrintControllerMenu})
        Me.menuItem1.Text = "PrintController"
        '
        'StandardPrintControllerMenu
        '
        Me.StandardPrintControllerMenu.Index = 0
        Me.StandardPrintControllerMenu.Text = "Standard Print Controller"
        '
        'statusBar1
        '
        Me.statusBar1.Location = New System.Drawing.Point(0, 272)
        Me.statusBar1.Name = "statusBar1"
        Me.statusBar1.Size = New System.Drawing.Size(292, 22)
        Me.statusBar1.TabIndex = 1
        Me.statusBar1.Text = "statusBar1"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 294)
        Me.Controls.Add(Me.statusBar1)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub StandardPrintControllerMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StandardPrintControllerMenu.Click
        Dim printDoc As New PrintDocument
        printDoc.DocumentName = "PrintController Document"
        printDoc.PrintController = New MyPrintController(statusBar1)
        AddHandler printDoc.PrintPage, AddressOf PringPageHandler
        printDoc.Print()
    End Sub

    Sub PringPageHandler(ByVal obj As Object, ByVal ppeArgs As PrintPageEventArgs)
        Dim g As Graphics = ppeArgs.Graphics
        Dim brush As New SolidBrush(Color.Red)
        Dim verdana20Font As New Font("Verdana", 20)
        g.DrawString("Pring Controller Test", verdana20Font, brush, 20, 20)
    End Sub 'PringPageHandler

End Class

Class MyPrintController
    Inherits StandardPrintController
    Private statusBar As StatusBar
    Private str As String = String.Empty


    Public Sub New(ByVal sBar As StatusBar)
        statusBar = sBar
    End Sub 'New

    Public Overrides Sub OnStartPrint(ByVal printDoc As PrintDocument, ByVal peArgs As PrintEventArgs)
        statusBar.Text = "OnStartPrint Called"
        MessageBox.Show("Wait")
        MyBase.OnStartPrint(printDoc, peArgs)
    End Sub 'OnStartPrint

    Public Overrides Function OnStartPage(ByVal printDoc As PrintDocument, ByVal ppea As PrintPageEventArgs) As Graphics
        statusBar.Text = "OnStartPage Called"
        Return MyBase.OnStartPage(printDoc, ppea)
    End Function 'OnStartPage

    Public Overrides Sub OnEndPage(ByVal printDoc As PrintDocument, ByVal ppeArgs As PrintPageEventArgs)
        statusBar.Text = "OnEndPage Called"
        MyBase.OnEndPage(printDoc, ppeArgs)
    End Sub 'OnEndPage

    Public Overrides Sub OnEndPrint(ByVal printDoc As PrintDocument, ByVal peArgs As PrintEventArgs)
        statusBar.Text = "OnEndPrint Called"
        statusBar.Text = str
        MyBase.OnEndPrint(printDoc, peArgs)
    End Sub 'OnEndPrint
End Class 'MyPrintController


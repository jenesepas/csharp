Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Printing
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents groupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents PaperSourceCombo As System.Windows.Forms.ComboBox
    Friend WithEvents PaperSizeCombo As System.Windows.Forms.ComboBox
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents groupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents bottomMarginBox As System.Windows.Forms.TextBox
    Friend WithEvents topMarginBox As System.Windows.Forms.TextBox
    Friend WithEvents label5 As System.Windows.Forms.Label
    Friend WithEvents label6 As System.Windows.Forms.Label
    Friend WithEvents rightMarginBox As System.Windows.Forms.TextBox
    Friend WithEvents leftMarginBox As System.Windows.Forms.TextBox
    Friend WithEvents label4 As System.Windows.Forms.Label
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents printersList As System.Windows.Forms.ComboBox
    Friend WithEvents label8 As System.Windows.Forms.Label
    Friend WithEvents ColorPrintingBox As System.Windows.Forms.CheckBox
    Friend WithEvents boundsTextBox As System.Windows.Forms.TextBox
    Friend WithEvents label7 As System.Windows.Forms.Label
    Friend WithEvents CancelBtn As System.Windows.Forms.Button
    Friend WithEvents SetPropertiesBtn As System.Windows.Forms.Button
    Friend WithEvents groupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents landscapeButton As System.Windows.Forms.RadioButton
    Friend WithEvents portraitButton As System.Windows.Forms.RadioButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.groupBox1 = New System.Windows.Forms.GroupBox
        Me.PaperSourceCombo = New System.Windows.Forms.ComboBox
        Me.PaperSizeCombo = New System.Windows.Forms.ComboBox
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.groupBox3 = New System.Windows.Forms.GroupBox
        Me.bottomMarginBox = New System.Windows.Forms.TextBox
        Me.topMarginBox = New System.Windows.Forms.TextBox
        Me.label5 = New System.Windows.Forms.Label
        Me.label6 = New System.Windows.Forms.Label
        Me.rightMarginBox = New System.Windows.Forms.TextBox
        Me.leftMarginBox = New System.Windows.Forms.TextBox
        Me.label4 = New System.Windows.Forms.Label
        Me.label3 = New System.Windows.Forms.Label
        Me.printersList = New System.Windows.Forms.ComboBox
        Me.label8 = New System.Windows.Forms.Label
        Me.ColorPrintingBox = New System.Windows.Forms.CheckBox
        Me.boundsTextBox = New System.Windows.Forms.TextBox
        Me.label7 = New System.Windows.Forms.Label
        Me.CancelBtn = New System.Windows.Forms.Button
        Me.SetPropertiesBtn = New System.Windows.Forms.Button
        Me.groupBox2 = New System.Windows.Forms.GroupBox
        Me.landscapeButton = New System.Windows.Forms.RadioButton
        Me.portraitButton = New System.Windows.Forms.RadioButton
        Me.groupBox1.SuspendLayout()
        Me.groupBox3.SuspendLayout()
        Me.groupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'groupBox1
        '
        Me.groupBox1.BackColor = System.Drawing.SystemColors.Desktop
        Me.groupBox1.Controls.Add(Me.PaperSourceCombo)
        Me.groupBox1.Controls.Add(Me.PaperSizeCombo)
        Me.groupBox1.Controls.Add(Me.label2)
        Me.groupBox1.Controls.Add(Me.label1)
        Me.groupBox1.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold)
        Me.groupBox1.Location = New System.Drawing.Point(8, 51)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(416, 96)
        Me.groupBox1.TabIndex = 13
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "Paper Properties"
        '
        'PaperSourceCombo
        '
        Me.PaperSourceCombo.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.PaperSourceCombo.Location = New System.Drawing.Point(104, 56)
        Me.PaperSourceCombo.Name = "PaperSourceCombo"
        Me.PaperSourceCombo.Size = New System.Drawing.Size(272, 21)
        Me.PaperSourceCombo.TabIndex = 3
        '
        'PaperSizeCombo
        '
        Me.PaperSizeCombo.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.PaperSizeCombo.Location = New System.Drawing.Point(104, 24)
        Me.PaperSizeCombo.Name = "PaperSizeCombo"
        Me.PaperSizeCombo.Size = New System.Drawing.Size(272, 21)
        Me.PaperSizeCombo.TabIndex = 2
        '
        'label2
        '
        Me.label2.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.label2.Location = New System.Drawing.Point(16, 48)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(56, 23)
        Me.label2.TabIndex = 1
        Me.label2.Text = "Source:"
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.label1.Location = New System.Drawing.Point(16, 24)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(56, 16)
        Me.label1.TabIndex = 0
        Me.label1.Text = "Size:"
        '
        'groupBox3
        '
        Me.groupBox3.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(255, Byte), CType(192, Byte))
        Me.groupBox3.Controls.Add(Me.bottomMarginBox)
        Me.groupBox3.Controls.Add(Me.topMarginBox)
        Me.groupBox3.Controls.Add(Me.label5)
        Me.groupBox3.Controls.Add(Me.label6)
        Me.groupBox3.Controls.Add(Me.rightMarginBox)
        Me.groupBox3.Controls.Add(Me.leftMarginBox)
        Me.groupBox3.Controls.Add(Me.label4)
        Me.groupBox3.Controls.Add(Me.label3)
        Me.groupBox3.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold)
        Me.groupBox3.Location = New System.Drawing.Point(168, 163)
        Me.groupBox3.Name = "groupBox3"
        Me.groupBox3.Size = New System.Drawing.Size(256, 96)
        Me.groupBox3.TabIndex = 15
        Me.groupBox3.TabStop = False
        Me.groupBox3.Text = "Paper Margins (In Inches)"
        '
        'bottomMarginBox
        '
        Me.bottomMarginBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.bottomMarginBox.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.bottomMarginBox.Location = New System.Drawing.Point(192, 60)
        Me.bottomMarginBox.Name = "bottomMarginBox"
        Me.bottomMarginBox.Size = New System.Drawing.Size(56, 20)
        Me.bottomMarginBox.TabIndex = 7
        Me.bottomMarginBox.Text = ""
        '
        'topMarginBox
        '
        Me.topMarginBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.topMarginBox.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.topMarginBox.Location = New System.Drawing.Point(56, 60)
        Me.topMarginBox.Name = "topMarginBox"
        Me.topMarginBox.Size = New System.Drawing.Size(56, 20)
        Me.topMarginBox.TabIndex = 6
        Me.topMarginBox.Text = ""
        '
        'label5
        '
        Me.label5.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.label5.Location = New System.Drawing.Point(136, 60)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(48, 24)
        Me.label5.TabIndex = 5
        Me.label5.Text = "Bottom:"
        '
        'label6
        '
        Me.label6.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.label6.Location = New System.Drawing.Point(16, 60)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(40, 24)
        Me.label6.TabIndex = 4
        Me.label6.Text = "Top:"
        '
        'rightMarginBox
        '
        Me.rightMarginBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.rightMarginBox.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.rightMarginBox.Location = New System.Drawing.Point(192, 24)
        Me.rightMarginBox.Name = "rightMarginBox"
        Me.rightMarginBox.Size = New System.Drawing.Size(56, 20)
        Me.rightMarginBox.TabIndex = 3
        Me.rightMarginBox.Text = ""
        '
        'leftMarginBox
        '
        Me.leftMarginBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.leftMarginBox.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.leftMarginBox.Location = New System.Drawing.Point(56, 24)
        Me.leftMarginBox.Name = "leftMarginBox"
        Me.leftMarginBox.Size = New System.Drawing.Size(56, 20)
        Me.leftMarginBox.TabIndex = 2
        Me.leftMarginBox.Text = ""
        '
        'label4
        '
        Me.label4.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.label4.Location = New System.Drawing.Point(136, 24)
        Me.label4.Name = "label4"
        Me.label4.Size = New System.Drawing.Size(40, 24)
        Me.label4.TabIndex = 1
        Me.label4.Text = "Right:"
        '
        'label3
        '
        Me.label3.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.label3.Location = New System.Drawing.Point(16, 24)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(40, 24)
        Me.label3.TabIndex = 0
        Me.label3.Text = "Left:"
        '
        'printersList
        '
        Me.printersList.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.printersList.Location = New System.Drawing.Point(184, 11)
        Me.printersList.Name = "printersList"
        Me.printersList.Size = New System.Drawing.Size(232, 21)
        Me.printersList.TabIndex = 22
        '
        'label8
        '
        Me.label8.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(224, Byte), CType(192, Byte))
        Me.label8.Location = New System.Drawing.Point(8, 11)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(104, 24)
        Me.label8.TabIndex = 21
        Me.label8.Text = "Available Printers:"
        '
        'ColorPrintingBox
        '
        Me.ColorPrintingBox.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(192, Byte), CType(255, Byte))
        Me.ColorPrintingBox.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ColorPrintingBox.Location = New System.Drawing.Point(16, 315)
        Me.ColorPrintingBox.Name = "ColorPrintingBox"
        Me.ColorPrintingBox.TabIndex = 20
        Me.ColorPrintingBox.Text = "Color Printing"
        '
        'boundsTextBox
        '
        Me.boundsTextBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.boundsTextBox.Enabled = False
        Me.boundsTextBox.Location = New System.Drawing.Point(144, 283)
        Me.boundsTextBox.Name = "boundsTextBox"
        Me.boundsTextBox.Size = New System.Drawing.Size(184, 20)
        Me.boundsTextBox.TabIndex = 19
        Me.boundsTextBox.Text = ""
        '
        'label7
        '
        Me.label7.Location = New System.Drawing.Point(16, 283)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(104, 23)
        Me.label7.TabIndex = 18
        Me.label7.Text = "Bounds (Rectangle):"
        '
        'CancelBtn
        '
        Me.CancelBtn.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(255, Byte), CType(255, Byte))
        Me.CancelBtn.Location = New System.Drawing.Point(280, 323)
        Me.CancelBtn.Name = "CancelBtn"
        Me.CancelBtn.TabIndex = 17
        Me.CancelBtn.Text = "Cancel"
        '
        'SetPropertiesBtn
        '
        Me.SetPropertiesBtn.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(255, Byte), CType(255, Byte))
        Me.SetPropertiesBtn.Location = New System.Drawing.Point(160, 323)
        Me.SetPropertiesBtn.Name = "SetPropertiesBtn"
        Me.SetPropertiesBtn.Size = New System.Drawing.Size(96, 23)
        Me.SetPropertiesBtn.TabIndex = 16
        Me.SetPropertiesBtn.Text = "Set Properties"
        '
        'groupBox2
        '
        Me.groupBox2.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(192, Byte), CType(192, Byte))
        Me.groupBox2.Controls.Add(Me.landscapeButton)
        Me.groupBox2.Controls.Add(Me.portraitButton)
        Me.groupBox2.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold)
        Me.groupBox2.Location = New System.Drawing.Point(8, 163)
        Me.groupBox2.Name = "groupBox2"
        Me.groupBox2.Size = New System.Drawing.Size(144, 96)
        Me.groupBox2.TabIndex = 14
        Me.groupBox2.TabStop = False
        Me.groupBox2.Text = "Paper Orientation"
        '
        'landscapeButton
        '
        Me.landscapeButton.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.landscapeButton.Location = New System.Drawing.Point(16, 56)
        Me.landscapeButton.Name = "landscapeButton"
        Me.landscapeButton.TabIndex = 1
        Me.landscapeButton.Text = "Landscape"
        '
        'portraitButton
        '
        Me.portraitButton.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.portraitButton.Location = New System.Drawing.Point(16, 24)
        Me.portraitButton.Name = "portraitButton"
        Me.portraitButton.TabIndex = 0
        Me.portraitButton.Text = "Portrait"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(255, Byte), CType(192, Byte))
        Me.ClientSize = New System.Drawing.Size(432, 357)
        Me.Controls.Add(Me.groupBox1)
        Me.Controls.Add(Me.groupBox3)
        Me.Controls.Add(Me.printersList)
        Me.Controls.Add(Me.label8)
        Me.Controls.Add(Me.ColorPrintingBox)
        Me.Controls.Add(Me.boundsTextBox)
        Me.Controls.Add(Me.label7)
        Me.Controls.Add(Me.CancelBtn)
        Me.Controls.Add(Me.SetPropertiesBtn)
        Me.Controls.Add(Me.groupBox2)
        Me.Name = "Form1"
        Me.Text = "PageSetupDialog Sample"
        Me.groupBox1.ResumeLayout(False)
        Me.groupBox3.ResumeLayout(False)
        Me.groupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub SetPropertiesBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetPropertiesBtn.Click
        ' Set other default properties
        Dim settings As New PrinterSettings
        Dim pgSettings As PageSettings = settings.DefaultPageSettings
        ' Color printing
        If ColorPrintingBox.Checked Then
            pgSettings.Color = True
        Else
            pgSettings.Color = False
        End If
        ' Landscape or portrait
        If landscapeButton.Checked Then
            pgSettings.Landscape = True
        Else
            pgSettings.Landscape = False
        End If '

    End Sub

    Private Sub CancelBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelBtn.Click
        Me.Close()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Load all available printers
        LoadPrinters()
        ' Load Paper sizes
        LoadPaperSizes()
        ' Load Paper sources
        LoadPaperSources()
        ' Other Settings
        ReadOtherSettings()
    End Sub

    Private Sub LoadPaperSizes()
        PaperSizeCombo.DisplayMember = "PaperName"
        Dim settings As New PrinterSettings
        ' Get all Paper sizes and add to combo list			
        Dim size As PaperSize
        For Each size In settings.PaperSizes
            PaperSizeCombo.Items.Add(size.Kind.ToString())
        Next size ' You can even read paper name and all PaperSize
        ' Properperties by uncommenting these two lines
        'PaperSizeCombo.Items.Add
        '(size.PaperName.ToString());
        'PaperSizeCombo.Items.Add(size.ToString());
        ' Create a custom paper size and add to the list
        Dim customPaperSize As New PaperSize("Custom Size", 50, 100)
        ' You can also change properties
        customPaperSize.PaperName = "New Custom Size"
        customPaperSize.Height = 200
        customPaperSize.Width = 100
        ' Don't assign Kind prop. It's read only
        ' customPaperSize.Kind = PaperKind.A4;
        ' Add CustomSize			
        PaperSizeCombo.Items.Add(customPaperSize)
    End Sub 'LoadPaperSizes

    Private Sub LoadPaperSources()
        Dim settings As New PrinterSettings
        PaperSourceCombo.DisplayMember = "SourceName"
        ' Add all Paper sources to the combo
        Dim source As PaperSource
        For Each source In settings.PaperSources
            PaperSourceCombo.Items.Add([source].ToString())
        Next source ' You can even add Kind and SourceName 
    End Sub 'LoadPaperSources 'PaperSourceCombo.Items.Add
    '(source.Kind.ToString());
    'PaperSourceCombo.Items.Add
    '(source.SourceName.ToString());


    Private Sub LoadPrinters()
        ' Load all available printers
        Dim printer As [String]
        For Each printer In PrinterSettings.InstalledPrinters
            printersList.Items.Add(printer.ToString())
        Next printer
        printersList.Select(0, 1)
    End Sub 'LoadPrinters

    Private Sub ReadOtherSettings()
        ' Set other default properties
        Dim settings As New PrinterSettings
        Dim pgSettings As PageSettings = settings.DefaultPageSettings
        ' Color printing
        If pgSettings.Color Then
            ColorPrintingBox.Checked = True
        Else
            ColorPrintingBox.Checked = False
        End If ' Page Margins
        leftMarginBox.Text = pgSettings.Bounds.Left.ToString()
        rightMarginBox.Text = pgSettings.Bounds.Right.ToString()
        topMarginBox.Text = pgSettings.Bounds.Top.ToString()
        bottomMarginBox.Text = pgSettings.Bounds.Bottom.ToString()
        ' Landscape or portrait
        If pgSettings.Landscape Then
            landscapeButton.Checked = True
        Else
            portraitButton.Checked = True
        End If ' Bounds
        boundsTextBox.Text = pgSettings.Bounds.ToString()
    End Sub 'ReadOtherSettings
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Text
Imports System.Drawing.Printing
Imports System.IO
Public Class Form1
    Inherits System.Windows.Forms.Form
    Private textColor As Color
    Private textSize As Integer
    Private Shared noFilename As String = "Untitled"
    Private curFilename As String = Nothing
    Private dirty As Boolean = False
    Private fileOnDiskModified As Boolean = False
    Private storedPageSettings As PageSettings = Nothing

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents OpenFile As System.Windows.Forms.MenuItem
    Friend WithEvents SaveFileAs As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem7 As System.Windows.Forms.MenuItem
    Friend WithEvents PrintMenu As System.Windows.Forms.MenuItem
    Friend WithEvents PrintPreviewMenu As System.Windows.Forms.MenuItem
    Friend WithEvents PageSetupMenu As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem11 As System.Windows.Forms.MenuItem
    Friend WithEvents ExitMenu As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents UndoMenu As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem14 As System.Windows.Forms.MenuItem
    Friend WithEvents CutMenu As System.Windows.Forms.MenuItem
    Friend WithEvents CopyMenu As System.Windows.Forms.MenuItem
    Friend WithEvents PasteMenu As System.Windows.Forms.MenuItem
    Friend WithEvents DeleteMenu As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem19 As System.Windows.Forms.MenuItem
    Friend WithEvents GotoMenu As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem21 As System.Windows.Forms.MenuItem
    Friend WithEvents SelectAllMenu As System.Windows.Forms.MenuItem
    Friend WithEvents DeleteAllMenu As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents button2 As System.Windows.Forms.Button
    Friend WithEvents richTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents numericUpDown1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents comboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents FileSystemWatcher1 As System.IO.FileSystemWatcher
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.OpenFile = New System.Windows.Forms.MenuItem
        Me.SaveFileAs = New System.Windows.Forms.MenuItem
        Me.menuItem7 = New System.Windows.Forms.MenuItem
        Me.PrintMenu = New System.Windows.Forms.MenuItem
        Me.PrintPreviewMenu = New System.Windows.Forms.MenuItem
        Me.PageSetupMenu = New System.Windows.Forms.MenuItem
        Me.menuItem11 = New System.Windows.Forms.MenuItem
        Me.ExitMenu = New System.Windows.Forms.MenuItem
        Me.menuItem2 = New System.Windows.Forms.MenuItem
        Me.UndoMenu = New System.Windows.Forms.MenuItem
        Me.menuItem14 = New System.Windows.Forms.MenuItem
        Me.CutMenu = New System.Windows.Forms.MenuItem
        Me.CopyMenu = New System.Windows.Forms.MenuItem
        Me.PasteMenu = New System.Windows.Forms.MenuItem
        Me.DeleteMenu = New System.Windows.Forms.MenuItem
        Me.menuItem19 = New System.Windows.Forms.MenuItem
        Me.GotoMenu = New System.Windows.Forms.MenuItem
        Me.menuItem21 = New System.Windows.Forms.MenuItem
        Me.SelectAllMenu = New System.Windows.Forms.MenuItem
        Me.DeleteAllMenu = New System.Windows.Forms.MenuItem
        Me.menuItem3 = New System.Windows.Forms.MenuItem
        Me.button2 = New System.Windows.Forms.Button
        Me.richTextBox1 = New System.Windows.Forms.RichTextBox
        Me.button1 = New System.Windows.Forms.Button
        Me.label2 = New System.Windows.Forms.Label
        Me.numericUpDown1 = New System.Windows.Forms.NumericUpDown
        Me.label1 = New System.Windows.Forms.Label
        Me.comboBox1 = New System.Windows.Forms.ComboBox
        Me.FileSystemWatcher1 = New System.IO.FileSystemWatcher
        CType(Me.numericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FileSystemWatcher1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1, Me.menuItem2, Me.menuItem3})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.OpenFile, Me.SaveFileAs, Me.menuItem7, Me.PrintMenu, Me.PrintPreviewMenu, Me.PageSetupMenu, Me.menuItem11, Me.ExitMenu})
        Me.menuItem1.Text = "&File"
        '
        'OpenFile
        '
        Me.OpenFile.Index = 0
        Me.OpenFile.Text = "&Open File"
        '
        'SaveFileAs
        '
        Me.SaveFileAs.Index = 1
        Me.SaveFileAs.Text = "&Save File As"
        '
        'menuItem7
        '
        Me.menuItem7.Index = 2
        Me.menuItem7.Text = "-"
        '
        'PrintMenu
        '
        Me.PrintMenu.Index = 3
        Me.PrintMenu.Text = "&Print"
        '
        'PrintPreviewMenu
        '
        Me.PrintPreviewMenu.Index = 4
        Me.PrintPreviewMenu.Text = "Print Pre&view"
        '
        'PageSetupMenu
        '
        Me.PageSetupMenu.Index = 5
        Me.PageSetupMenu.Text = "Page Setup"
        '
        'menuItem11
        '
        Me.menuItem11.Index = 6
        Me.menuItem11.Text = "-"
        '
        'ExitMenu
        '
        Me.ExitMenu.Index = 7
        Me.ExitMenu.Text = "E&xit"
        '
        'menuItem2
        '
        Me.menuItem2.Index = 1
        Me.menuItem2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.UndoMenu, Me.menuItem14, Me.CutMenu, Me.CopyMenu, Me.PasteMenu, Me.DeleteMenu, Me.menuItem19, Me.GotoMenu, Me.menuItem21, Me.SelectAllMenu, Me.DeleteAllMenu})
        Me.menuItem2.Text = "&Edit"
        '
        'UndoMenu
        '
        Me.UndoMenu.Index = 0
        Me.UndoMenu.Text = "&Undo"
        '
        'menuItem14
        '
        Me.menuItem14.Index = 1
        Me.menuItem14.Text = "-"
        '
        'CutMenu
        '
        Me.CutMenu.Index = 2
        Me.CutMenu.Text = "Cu&t"
        '
        'CopyMenu
        '
        Me.CopyMenu.Index = 3
        Me.CopyMenu.Text = "&Copy"
        '
        'PasteMenu
        '
        Me.PasteMenu.Index = 4
        Me.PasteMenu.Text = "&Paste"
        '
        'DeleteMenu
        '
        Me.DeleteMenu.Index = 5
        Me.DeleteMenu.Text = "De&lete"
        '
        'menuItem19
        '
        Me.menuItem19.Index = 6
        Me.menuItem19.Text = "-"
        '
        'GotoMenu
        '
        Me.GotoMenu.Index = 7
        Me.GotoMenu.Text = "&Go To"
        '
        'menuItem21
        '
        Me.menuItem21.Index = 8
        Me.menuItem21.Text = "-"
        '
        'SelectAllMenu
        '
        Me.SelectAllMenu.Index = 9
        Me.SelectAllMenu.Text = "Select &All"
        '
        'DeleteAllMenu
        '
        Me.DeleteAllMenu.Index = 10
        Me.DeleteAllMenu.Text = "&Delete All"
        '
        'menuItem3
        '
        Me.menuItem3.Index = 2
        Me.menuItem3.Text = "F&ormat"
        '
        'button2
        '
        Me.button2.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold)
        Me.button2.Location = New System.Drawing.Point(408, 81)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(80, 32)
        Me.button2.TabIndex = 15
        Me.button2.Text = "Apply"
        '
        'richTextBox1
        '
        Me.richTextBox1.BackColor = System.Drawing.SystemColors.Info
        Me.richTextBox1.Location = New System.Drawing.Point(8, 113)
        Me.richTextBox1.Name = "richTextBox1"
        Me.richTextBox1.Size = New System.Drawing.Size(648, 248)
        Me.richTextBox1.TabIndex = 14
        Me.richTextBox1.Text = "richTextBox1"
        '
        'button1
        '
        Me.button1.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(128, Byte), CType(0, Byte))
        Me.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.button1.Location = New System.Drawing.Point(240, 81)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(80, 24)
        Me.button1.TabIndex = 13
        Me.button1.Text = "Color"
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(184, 57)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(56, 24)
        Me.label2.TabIndex = 12
        Me.label2.Text = "Size"
        '
        'numericUpDown1
        '
        Me.numericUpDown1.Location = New System.Drawing.Point(184, 81)
        Me.numericUpDown1.Name = "numericUpDown1"
        Me.numericUpDown1.Size = New System.Drawing.Size(48, 20)
        Me.numericUpDown1.TabIndex = 11
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(8, 57)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(104, 24)
        Me.label1.TabIndex = 10
        Me.label1.Text = "Available Fonts"
        '
        'comboBox1
        '
        Me.comboBox1.Location = New System.Drawing.Point(8, 81)
        Me.comboBox1.Name = "comboBox1"
        Me.comboBox1.Size = New System.Drawing.Size(152, 21)
        Me.comboBox1.TabIndex = 9
        '
        'FileSystemWatcher1
        '
        Me.FileSystemWatcher1.EnableRaisingEvents = True
        Me.FileSystemWatcher1.SynchronizingObject = Me
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.Teal
        Me.ClientSize = New System.Drawing.Size(664, 418)
        Me.Controls.Add(Me.button2)
        Me.Controls.Add(Me.richTextBox1)
        Me.Controls.Add(Me.button1)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.numericUpDown1)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.comboBox1)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "GDI+ Editor - A Simple Text Editor"
        CType(Me.numericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FileSystemWatcher1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        numericUpDown1.Value = 10

        ' Create InstalledFontCollection object
        Dim sysFontCollection As New InstalledFontCollection

        ' Get the array of FontFamily objects.
        Dim fontFamilies As FontFamily() = sysFontCollection.Families
        ' Read all font familes and add to the combo box
        Dim i As Integer

        While i < fontFamilies.Length
            comboBox1.Items.Add(fontFamilies(i).Name)
            i = i + 1
        End While
        comboBox1.Select(0, 20)

    End Sub

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        Dim colorDlg As New ColorDialog
        If colorDlg.ShowDialog() = DialogResult.OK Then
            textColor = colorDlg.Color
        End If
    End Sub

    Private Sub button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button2.Click
        textSize = CInt(numericUpDown1.Value)
        Dim selFont As String = comboBox1.SelectedText
        Dim textFont As New Font(selFont, textSize)
        richTextBox1.ForeColor = textColor
        richTextBox1.Font = textFont

    End Sub

    Private Sub OpenFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenFile.Click
        Dim openDlg As New OpenFileDialog   '

        If openDlg.ShowDialog() = DialogResult.OK Then
            curFilename = openDlg.FileName
            ReadTextFile()
        End If
    End Sub


    Private Sub ReadTextFile()
        AddHandler richTextBox1.TextChanged, AddressOf richTextBox1_TextChanged
        fileSystemWatcher1.EnableRaisingEvents = False
        Try
            ' Open the file as a stream
            Dim fs = New FileStream(curFilename, FileMode.Open)
            Dim filInfo As New FileInfo(curFilename)
            ' Get the file extension
            Dim extn As String = filInfo.Extension.ToUpper()
            ' See if file is rich text format, Load it with 
            ' RichText option. Otherwise PlainText
            If extn.Equals(".RTF") Then
                richTextBox1.LoadFile(fs, RichTextBoxStreamType.RichText)
            Else
                richTextBox1.LoadFile(fs, RichTextBoxStreamType.PlainText)
            End If ' Close stream
            fs.Close()
            fileSystemWatcher1.Path = filInfo.DirectoryName
            fileSystemWatcher1.Filter = filInfo.Name

        Catch exp As Exception
            MessageBox.Show(exp.Message.ToString())
        Finally
            AddHandler richTextBox1.TextChanged, AddressOf richTextBox1_TextChanged
            fileSystemWatcher1.EnableRaisingEvents = True
        End Try
    End Sub 'ReadTextFile

    Private Sub richTextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles richTextBox1.TextChanged

    End Sub
End Class

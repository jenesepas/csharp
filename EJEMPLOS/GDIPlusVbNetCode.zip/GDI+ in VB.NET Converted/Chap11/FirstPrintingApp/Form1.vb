Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Printing
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents GetProperties As System.Windows.Forms.Button
    Friend WithEvents groupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents textBox2 As System.Windows.Forms.TextBox
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents SuppColorsChkBox As System.Windows.Forms.CheckBox
    Friend WithEvents IsValidChkBox As System.Windows.Forms.CheckBox
    Friend WithEvents CollateChkBox As System.Windows.Forms.CheckBox
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents CanDuplexChkBox As System.Windows.Forms.CheckBox
    Friend WithEvents IsPlotterChkBox As System.Windows.Forms.CheckBox
    Friend WithEvents IsDefPrinterChkBox As System.Windows.Forms.CheckBox
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents PrintersList As System.Windows.Forms.ComboBox
    Friend WithEvents PaperSizesList As System.Windows.Forms.ListBox
    Friend WithEvents button3 As System.Windows.Forms.Button
    Friend WithEvents ResolutionsList As System.Windows.Forms.ListBox
    Friend WithEvents button2 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.GetProperties = New System.Windows.Forms.Button
        Me.groupBox1 = New System.Windows.Forms.GroupBox
        Me.textBox2 = New System.Windows.Forms.TextBox
        Me.label3 = New System.Windows.Forms.Label
        Me.SuppColorsChkBox = New System.Windows.Forms.CheckBox
        Me.IsValidChkBox = New System.Windows.Forms.CheckBox
        Me.CollateChkBox = New System.Windows.Forms.CheckBox
        Me.textBox1 = New System.Windows.Forms.TextBox
        Me.label2 = New System.Windows.Forms.Label
        Me.CanDuplexChkBox = New System.Windows.Forms.CheckBox
        Me.IsPlotterChkBox = New System.Windows.Forms.CheckBox
        Me.IsDefPrinterChkBox = New System.Windows.Forms.CheckBox
        Me.label1 = New System.Windows.Forms.Label
        Me.PrintersList = New System.Windows.Forms.ComboBox
        Me.PaperSizesList = New System.Windows.Forms.ListBox
        Me.button3 = New System.Windows.Forms.Button
        Me.ResolutionsList = New System.Windows.Forms.ListBox
        Me.button2 = New System.Windows.Forms.Button
        Me.groupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GetProperties
        '
        Me.GetProperties.Location = New System.Drawing.Point(4, 210)
        Me.GetProperties.Name = "GetProperties"
        Me.GetProperties.Size = New System.Drawing.Size(152, 32)
        Me.GetProperties.TabIndex = 17
        Me.GetProperties.Text = "Get Printer Properties"
        '
        'groupBox1
        '
        Me.groupBox1.Controls.Add(Me.textBox2)
        Me.groupBox1.Controls.Add(Me.label3)
        Me.groupBox1.Controls.Add(Me.SuppColorsChkBox)
        Me.groupBox1.Controls.Add(Me.IsValidChkBox)
        Me.groupBox1.Controls.Add(Me.CollateChkBox)
        Me.groupBox1.Controls.Add(Me.textBox1)
        Me.groupBox1.Controls.Add(Me.label2)
        Me.groupBox1.Controls.Add(Me.CanDuplexChkBox)
        Me.groupBox1.Controls.Add(Me.IsPlotterChkBox)
        Me.groupBox1.Controls.Add(Me.IsDefPrinterChkBox)
        Me.groupBox1.Location = New System.Drawing.Point(4, 250)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(496, 168)
        Me.groupBox1.TabIndex = 16
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "Printer Properties"
        '
        'textBox2
        '
        Me.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.textBox2.Location = New System.Drawing.Point(216, 56)
        Me.textBox2.Name = "textBox2"
        Me.textBox2.Size = New System.Drawing.Size(96, 20)
        Me.textBox2.TabIndex = 9
        Me.textBox2.Text = ""
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(152, 56)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(56, 16)
        Me.label3.TabIndex = 8
        Me.label3.Text = "Copies:"
        '
        'SuppColorsChkBox
        '
        Me.SuppColorsChkBox.Location = New System.Drawing.Point(152, 112)
        Me.SuppColorsChkBox.Name = "SuppColorsChkBox"
        Me.SuppColorsChkBox.Size = New System.Drawing.Size(152, 24)
        Me.SuppColorsChkBox.TabIndex = 7
        Me.SuppColorsChkBox.Text = "Supports Colors"
        '
        'IsValidChkBox
        '
        Me.IsValidChkBox.Location = New System.Drawing.Point(152, 88)
        Me.IsValidChkBox.Name = "IsValidChkBox"
        Me.IsValidChkBox.Size = New System.Drawing.Size(136, 16)
        Me.IsValidChkBox.TabIndex = 6
        Me.IsValidChkBox.Text = "IsValid"
        '
        'CollateChkBox
        '
        Me.CollateChkBox.Location = New System.Drawing.Point(16, 136)
        Me.CollateChkBox.Name = "CollateChkBox"
        Me.CollateChkBox.Size = New System.Drawing.Size(80, 24)
        Me.CollateChkBox.TabIndex = 5
        Me.CollateChkBox.Text = "Collate"
        '
        'textBox1
        '
        Me.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.textBox1.Location = New System.Drawing.Point(104, 16)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(280, 20)
        Me.textBox1.TabIndex = 4
        Me.textBox1.Text = ""
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(16, 16)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(72, 24)
        Me.label2.TabIndex = 3
        Me.label2.Text = "Printer Name:"
        '
        'CanDuplexChkBox
        '
        Me.CanDuplexChkBox.Location = New System.Drawing.Point(16, 104)
        Me.CanDuplexChkBox.Name = "CanDuplexChkBox"
        Me.CanDuplexChkBox.Size = New System.Drawing.Size(80, 32)
        Me.CanDuplexChkBox.TabIndex = 2
        Me.CanDuplexChkBox.Text = "CanDuplex"
        '
        'IsPlotterChkBox
        '
        Me.IsPlotterChkBox.Location = New System.Drawing.Point(16, 72)
        Me.IsPlotterChkBox.Name = "IsPlotterChkBox"
        Me.IsPlotterChkBox.Size = New System.Drawing.Size(80, 32)
        Me.IsPlotterChkBox.TabIndex = 1
        Me.IsPlotterChkBox.Text = "IsPlotter"
        '
        'IsDefPrinterChkBox
        '
        Me.IsDefPrinterChkBox.Location = New System.Drawing.Point(16, 40)
        Me.IsDefPrinterChkBox.Name = "IsDefPrinterChkBox"
        Me.IsDefPrinterChkBox.Size = New System.Drawing.Size(104, 32)
        Me.IsDefPrinterChkBox.TabIndex = 0
        Me.IsDefPrinterChkBox.Text = "IsDefaultPrinter"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(4, 10)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(96, 16)
        Me.label1.TabIndex = 15
        Me.label1.Text = "Available Printers"
        '
        'PrintersList
        '
        Me.PrintersList.Location = New System.Drawing.Point(4, 34)
        Me.PrintersList.Name = "PrintersList"
        Me.PrintersList.Size = New System.Drawing.Size(200, 21)
        Me.PrintersList.TabIndex = 14
        '
        'PaperSizesList
        '
        Me.PaperSizesList.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PaperSizesList.Location = New System.Drawing.Point(4, 106)
        Me.PaperSizesList.Name = "PaperSizesList"
        Me.PaperSizesList.Size = New System.Drawing.Size(288, 93)
        Me.PaperSizesList.TabIndex = 13
        '
        'button3
        '
        Me.button3.Location = New System.Drawing.Point(4, 66)
        Me.button3.Name = "button3"
        Me.button3.Size = New System.Drawing.Size(136, 32)
        Me.button3.TabIndex = 12
        Me.button3.Text = "Get Paper Size"
        '
        'ResolutionsList
        '
        Me.ResolutionsList.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ResolutionsList.Location = New System.Drawing.Point(300, 106)
        Me.ResolutionsList.Name = "ResolutionsList"
        Me.ResolutionsList.Size = New System.Drawing.Size(224, 93)
        Me.ResolutionsList.TabIndex = 11
        '
        'button2
        '
        Me.button2.Location = New System.Drawing.Point(332, 74)
        Me.button2.Name = "button2"
        Me.button2.Size = New System.Drawing.Size(144, 24)
        Me.button2.TabIndex = 10
        Me.button2.Text = "Get Printer Resolution"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(528, 429)
        Me.Controls.Add(Me.GetProperties)
        Me.Controls.Add(Me.groupBox1)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.PrintersList)
        Me.Controls.Add(Me.PaperSizesList)
        Me.Controls.Add(Me.button3)
        Me.Controls.Add(Me.ResolutionsList)
        Me.Controls.Add(Me.button2)
        Me.Name = "Form1"
        Me.Text = "Printing settings"
        Me.groupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub GetProperties_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetProperties.Click
        ' If there is no printer selected
        If PrintersList.Text = String.Empty Then
            MessageBox.Show("Select a printer from the list")
            Return
        End If

        Dim ps As New PrinterSettings
        Dim str As String = PrintersList.SelectedItem.ToString()
        ps.PrinterName = str
        ' Check if its a valid printer
        If Not ps.IsValid Then
            MessageBox.Show("Not a valid printer")
            Return
        End If
        ' Set printer name and copies
        textBox1.Text = ps.PrinterName.ToString()
        textBox2.Text = ps.Copies.ToString()

        ' If priter is the default printer
        If ps.IsDefaultPrinter = True Then
            IsDefPrinterChkBox.Checked = True
        Else
            IsDefPrinterChkBox.Checked = False
        End If ' If priter is a plotter
        If ps.IsPlotter Then
            IsPlotterChkBox.Checked = True
        Else
            IsPlotterChkBox.Checked = False
        End If ' Can Duplex?
        If ps.CanDuplex Then
            CanDuplexChkBox.Checked = True
        Else
            CanDuplexChkBox.Checked = False
        End If ' Collate?
        If ps.Collate Then
            CollateChkBox.Checked = True
        Else
            CollateChkBox.Checked = False
        End If ' Printer is valid or not
        If ps.IsValid Then
            IsValidChkBox.Checked = True
        Else
            IsValidChkBox.Checked = False
        End If ' Color printer or not?
        If ps.SupportsColor Then
            SuppColorsChkBox.Checked = True
        Else
            SuppColorsChkBox.Checked = False
        End If '

    End Sub
    Private Sub groupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles groupBox1.Enter

    End Sub
    Private Sub label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles label1.Click

    End Sub
    Private Sub PrintersList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintersList.SelectedIndexChanged

    End Sub
    Private Sub PaperSizesList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PaperSizesList.SelectedIndexChanged

    End Sub
    Private Sub button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button3.Click
        ' If there is no printer selected
        If PrintersList.Text = String.Empty Then
            MessageBox.Show("Select a printer from the list")
            Return
        End If
        ' Create Printer Settings
        Dim prs As New PrinterSettings
        ' Get the current selected printer from the 
        ' printers list
        Dim str As String = PrintersList.SelectedItem.ToString()
        prs.PrinterName = str
        ' Read paper sizes and add to the ListBox
        Dim ps As PaperSize
        For Each ps In prs.PaperSizes
            PaperSizesList.Items.Add(ps.ToString())
        Next ps

    End Sub
    Private Sub ResolutionsList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ResolutionsList.SelectedIndexChanged

    End Sub
    Private Sub button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button2.Click
        ' If there is no printer selected
        If PrintersList.Text = String.Empty Then
            MessageBox.Show("Select a printer from the list")
            Return
        End If
        ' Get the current selected printer from the 
        ' printers list
        Dim str As String = PrintersList.SelectedItem.ToString()
        ' Create a PrinterSetting object
        Dim ps As New PrinterSettings
        ' Set the current printer 
        ps.PrinterName = str
        ' Read all printer resolutions and add
        ' the the listBox
        Dim pr As PrinterResolution
        For Each pr In ps.PrinterResolutions
            ResolutionsList.Items.Add(pr.ToString())
        Next pr

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' See if installed printers are 0
        If PrinterSettings.InstalledPrinters.Count <= 0 Then
            MessageBox.Show("Printer not found!")
            Return
        End If
        ' Get all the available printers and add to the 
        ' ComboBox
        Dim printer As [String]
        For Each printer In PrinterSettings.InstalledPrinters
            PrintersList.Items.Add(printer.ToString())
        Next printer

    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
imports System.Data
Imports System.Drawing.Printing
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MarginalBtn As System.Windows.Forms.Button
    Friend WithEvents NormalBtn As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MarginalBtn = New System.Windows.Forms.Button
        Me.NormalBtn = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'MarginalBtn
        '
        Me.MarginalBtn.Location = New System.Drawing.Point(48, 80)
        Me.MarginalBtn.Name = "MarginalBtn"
        Me.MarginalBtn.Size = New System.Drawing.Size(104, 23)
        Me.MarginalBtn.TabIndex = 3
        Me.MarginalBtn.Text = "Marginal Printing"
        '
        'NormalBtn
        '
        Me.NormalBtn.Location = New System.Drawing.Point(48, 40)
        Me.NormalBtn.Name = "NormalBtn"
        Me.NormalBtn.Size = New System.Drawing.Size(104, 23)
        Me.NormalBtn.TabIndex = 2
        Me.NormalBtn.Text = "Normal Printing"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 273)
        Me.Controls.Add(Me.MarginalBtn)
        Me.Controls.Add(Me.NormalBtn)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub MarginalBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MarginalBtn.Click
        ' Create a PrintDocument
        Dim pd As New PrintDocument
        ' Add PrintPage event handler
        AddHandler pd.PrintPage, AddressOf MarginPrinting
        ' Print
        pd.Print()
    End Sub
    Private Sub NormalBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NormalBtn.Click
        ' Create a PrintDocument
        Dim pd As New PrintDocument
        ' Add PrintPage event handler
        AddHandler pd.PrintPage, AddressOf NormalPrinting
        ' Print
        pd.Print()
    End Sub

    Public Sub NormalPrinting(ByVal sender As Object, ByVal ev As PrintPageEventArgs) '
        ' Set the top position as 1
        Dim ypos As Single = 1
        ' Get the default left margin
        Dim leftMargin As Single = ev.MarginBounds.Left
        'Create a font
        Dim font As New Font("Arial", 16)
        ' Get font's height
        Dim fontheight As Single = font.GetHeight(ev.Graphics)
        ' Draw four strings
        ev.Graphics.DrawString("Top Margin = " + ev.MarginBounds.Top.ToString(), font, Brushes.Black, leftMargin, ypos)
        ypos = ypos + fontheight
        ev.Graphics.DrawString("Bottom Margin = " + ev.MarginBounds.Bottom.ToString(), font, Brushes.Black, leftMargin, ypos)
        ypos = ypos + fontheight
        ev.Graphics.DrawString("Left Margin = " + ev.MarginBounds.Left.ToString(), font, Brushes.Black, leftMargin, ypos)
        ypos = ypos + fontheight
        ev.Graphics.DrawString("Right Margin = " + ev.MarginBounds.Right.ToString(), font, Brushes.Black, leftMargin, ypos)
        ypos = ypos + fontheight
        ' Draw a rectangle with default margins
        ev.Graphics.DrawRectangle(New Pen(Color.Black), ev.MarginBounds.X, ev.MarginBounds.Y, ev.MarginBounds.Width, ev.MarginBounds.Height)
    End Sub 'NormalPrinting

    Public Sub MarginPrinting(ByVal sender As Object, ByVal ev As PrintPageEventArgs)
        ' Set the top position as the default margin
        Dim ypos As Single = ev.MarginBounds.Top
        ' Get the default left margin
        Dim leftMargin As Single = ev.MarginBounds.Left
        'Create a font
        Dim font As New Font("Arial", 16)
        ' Get font's height
        Dim fontheight As Single = font.GetHeight(ev.Graphics)
        ' Draw four strings
        ev.Graphics.DrawString("Top Margin = " + ev.MarginBounds.Top.ToString(), font, Brushes.Black, leftMargin, ypos)
        ypos = ypos + fontheight
        ev.Graphics.DrawString("Bottom Margin = " + ev.MarginBounds.Bottom.ToString(), font, Brushes.Black, leftMargin, ypos)
        ypos = ypos + fontheight
        ev.Graphics.DrawString("Left Margin = " + ev.MarginBounds.Left.ToString(), font, Brushes.Black, leftMargin, ypos)
        ypos = ypos + fontheight
        ev.Graphics.DrawString("Right Margin = " + ev.MarginBounds.Right.ToString(), font, Brushes.Black, leftMargin, ypos)
        ypos = ypos + fontheight
        ' Draw a rectangle with default margins
        ev.Graphics.DrawRectangle(New Pen(Color.Black), ev.MarginBounds.X, ev.MarginBounds.Y, ev.MarginBounds.Width, ev.MarginBounds.Height)
    End Sub 'MarginPrinting
End Class


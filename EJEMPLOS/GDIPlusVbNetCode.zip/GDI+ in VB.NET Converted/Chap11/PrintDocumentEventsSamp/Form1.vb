Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Printing
Public Class Form1
    Inherits System.Windows.Forms.Form
    Private redBrush As SolidBrush = Nothing
    Private bluePen As Pen = Nothing

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents printersList As System.Windows.Forms.ComboBox
    Friend WithEvents PrintEvents As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.printersList = New System.Windows.Forms.ComboBox
        Me.PrintEvents = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'printersList
        '
        Me.printersList.Location = New System.Drawing.Point(80, 30)
        Me.printersList.Name = "printersList"
        Me.printersList.Size = New System.Drawing.Size(121, 21)
        Me.printersList.TabIndex = 3
        Me.printersList.Text = "comboBox1"
        '
        'PrintEvents
        '
        Me.PrintEvents.Location = New System.Drawing.Point(144, 214)
        Me.PrintEvents.Name = "PrintEvents"
        Me.PrintEvents.Size = New System.Drawing.Size(136, 32)
        Me.PrintEvents.TabIndex = 2
        Me.PrintEvents.Text = "PrintEvents Start"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(360, 277)
        Me.Controls.Add(Me.printersList)
        Me.Controls.Add(Me.PrintEvents)
        Me.Name = "Form1"
        Me.Text = "PrintDocument Events Sample"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub printersList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printersList.SelectedIndexChanged

    End Sub
    Private Sub PrintEvents_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintEvents.Click
        ' Get the selected printer
        Dim printerName As String = printersList.SelectedItem.ToString()
        ' Create a PrintDocument and set the
        ' current printer
        Dim pd As New PrintDocument
        pd.PrinterSettings.PrinterName = printerName
        ' BegingPaint event
        AddHandler pd.BeginPrint, AddressOf BgnPrntEventHandler
        ' PrintPage event
        AddHandler pd.PrintPage, AddressOf PrntPgEventHandler
        ' EndPaint event
        AddHandler pd.EndPrint, AddressOf EndPrntEventHandler
        ' Print the document.
        pd.Print()

    End Sub

    Public Sub BgnPrntEventHandler(ByVal sender As Object, ByVal peaArgs As PrintEventArgs)
        ' Create a brush and a pen
        redBrush = New SolidBrush(Color.Red)
        bluePen = New Pen(Color.Blue, 3)
    End Sub 'BgnPrntEventHandler

    Public Sub EndPrntEventHandler(ByVal sender As Object, ByVal peaArgs As PrintEventArgs)
        ' Release brush and pen objects
        redBrush.Dispose()
        bluePen.Dispose()
    End Sub 'EndPrntEventHandler

    Public Sub PrntPgEventHandler(ByVal sender As Object, ByVal ppeArgs As PrintPageEventArgs)
        ' Create PrinterSettings
        Dim ps As New PrinterSettings
        ' Get the Graphics object
        Dim g As Graphics = ppeArgs.Graphics
        ' Create a PageSettings
        Dim pgSettings As New PageSettings(ps)
        ' Set page margins
        ppeArgs.PageSettings.Margins.Left = 50
        ppeArgs.PageSettings.Margins.Right = 100
        ppeArgs.PageSettings.Margins.Top = 50
        ppeArgs.PageSettings.Margins.Bottom = 100
        ' Create two rectangles
        Dim rect1 As New Rectangle(20, 20, 50, 50)
        Dim rect2 As New Rectangle(100, 100, 50, 100)
        ' Draw and fill rectangles
        g.DrawRectangle(bluePen, rect1)
        g.FillRectangle(redBrush, rect2)
    End Sub 'PrntPgEventHandler

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' See if installed printers are 0
        If PrinterSettings.InstalledPrinters.Count <= 0 Then
            MessageBox.Show("Printer not found!")
            Return
        End If
        ' Get all the available printers and add to the 
        ' ComboBox
        Dim printer As [String]
        For Each printer In PrinterSettings.InstalledPrinters
            printersList.Items.Add(printer.ToString())
        Next printer
    End Sub
End Class

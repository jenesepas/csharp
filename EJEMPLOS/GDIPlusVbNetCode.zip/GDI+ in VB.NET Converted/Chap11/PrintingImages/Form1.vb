Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Printing
Public Class Form1
    Inherits System.Windows.Forms.Form
    Private curImage As Image = Nothing
    Private curFileName As String = Nothing

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents DrawItems As System.Windows.Forms.MenuItem
    Friend WithEvents ViewImage As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents PrintImage As System.Windows.Forms.MenuItem
    Friend WithEvents PrintGraphicsItems As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.DrawItems = New System.Windows.Forms.MenuItem
        Me.ViewImage = New System.Windows.Forms.MenuItem
        Me.menuItem2 = New System.Windows.Forms.MenuItem
        Me.PrintImage = New System.Windows.Forms.MenuItem
        Me.PrintGraphicsItems = New System.Windows.Forms.MenuItem
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.DrawItems, Me.ViewImage, Me.menuItem2, Me.PrintImage, Me.PrintGraphicsItems})
        Me.menuItem1.Text = "Printing "
        '
        'DrawItems
        '
        Me.DrawItems.Index = 0
        Me.DrawItems.Text = "Draw Items"
        '
        'ViewImage
        '
        Me.ViewImage.Index = 1
        Me.ViewImage.Text = "View Image"
        '
        'menuItem2
        '
        Me.menuItem2.Index = 2
        Me.menuItem2.Text = "-"
        '
        'PrintImage
        '
        Me.PrintImage.Index = 3
        Me.PrintImage.Text = "Print Image"
        '
        'PrintGraphicsItems
        '
        Me.PrintGraphicsItems.Index = 4
        Me.PrintGraphicsItems.Text = "Print Graphics Items"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(384, 370)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub DrawItems_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DrawItems.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Draw graphics items
        g.DrawLine(Pens.Blue, 10, 10, 10, 100)
        g.DrawLine(Pens.Blue, 10, 10, 100, 10)
        g.DrawRectangle(Pens.Yellow, 20, 20, 200, 200)
        g.FillEllipse(Brushes.Gray, 40, 40, 100, 100)
        ' Dispose
        g.Dispose()
    End Sub

    Private Sub ViewImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewImage.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim openDlg As New OpenFileDialog
        openDlg.Filter = "All Image files|*.bmp;*.gif;*.jpg;*.ico;" + "*.emf,*.wmf|Bitmap Files(*.bmp;*.gif;*.jpg;" + "*.ico)|*.bmp;*.gif;*.jpg;*.ico|" + "Meta Files(*.emf;*.wmf)|*.emf;*.wmf"
        Dim filter As String = openDlg.Filter
        openDlg.InitialDirectory = Environment.CurrentDirectory
        openDlg.Title = "Open Image File"
        openDlg.ShowHelp = True
        If openDlg.ShowDialog() = DialogResult.OK Then
            curFileName = openDlg.FileName
            curImage = Image.FromFile(curFileName)
        End If
        If Not (curImage Is Nothing) Then
            ' Draw Image using the DrawImage method 
            g.DrawImage(curImage, AutoScrollPosition.X, AutoScrollPosition.Y, curImage.Width, curImage.Height)
        End If
        ' Dispose
        g.Dispose()

    End Sub

    Private Sub PrintImage_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintImage.Click
        Dim pd As New PrintDocument
        AddHandler pd.PrintPage, AddressOf PrintImageHandler
        pd.Print()
    End Sub

    Private Sub PrintImageHandler(ByVal sender As Object, ByVal ppeArgs As PrintPageEventArgs) '
        Dim g As Graphics = ppeArgs.Graphics
        If Not (curImage Is Nothing) Then
            ' Draw Image using the DrawImage method 
            g.DrawImage(curImage, 0, 0, curImage.Width, curImage.Height)
        End If
    End Sub 'PrintImageHandler

    Private Sub PrintGraphicsItems_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintGraphicsItems.Click
        Dim pd As New PrintDocument
        AddHandler pd.PrintPage, AddressOf PrintGraphicsItemsHandler
        pd.Print()
    End Sub

    Sub PrintGraphicsItemsHandler(ByVal sender As Object, ByVal ppeArgs As PrintPageEventArgs) '
        Dim g As Graphics = ppeArgs.Graphics
        ' Draw graphics items
        g.DrawLine(Pens.Blue, 10, 10, 10, 100)
        g.DrawLine(Pens.Blue, 10, 10, 100, 10)
        g.DrawRectangle(Pens.Yellow, 20, 20, 200, 200)
        g.FillEllipse(Brushes.Gray, 40, 40, 100, 100)
    End Sub 'PrintGraphicsItemsHandler
End Class

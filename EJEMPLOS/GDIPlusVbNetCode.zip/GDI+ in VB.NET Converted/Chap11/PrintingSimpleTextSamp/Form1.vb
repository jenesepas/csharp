Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
imports System.Drawing.Printing
Imports System.IO
Public Class Form1
    Inherits System.Windows.Forms.Form
    Private redBrush As SolidBrush
    Private greenBrush As SolidBrush
    Private blueBrush As SolidBrush
    Private bluePen As Pen
    'Private textBox1 As System.Windows.Forms.TextBox
    'Private BrowseBtn As System.Windows.Forms.Button
    'Private PrintTextFile As System.Windows.Forms.Button

    Private verdana10Font As Font
    Private reader As StreamReader

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents printersList As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents BrowseBtn As System.Windows.Forms.Button
    Friend WithEvents PrintingText As System.Windows.Forms.Button
    Friend WithEvents PrintEvents As System.Windows.Forms.Button
    Friend WithEvents PrintTextFile As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.printersList = New System.Windows.Forms.ComboBox
        Me.PrintingText = New System.Windows.Forms.Button
        Me.PrintEvents = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'printersList
        '
        Me.printersList.Location = New System.Drawing.Point(32, 16)
        Me.printersList.Name = "printersList"
        Me.printersList.Size = New System.Drawing.Size(121, 21)
        Me.printersList.TabIndex = 2
        Me.printersList.Text = "comboBox1"
        '
        'PrintingText
        '
        Me.PrintingText.Location = New System.Drawing.Point(32, 256)
        Me.PrintingText.Name = "PrintingText"
        Me.PrintingText.Size = New System.Drawing.Size(75, 32)
        Me.PrintingText.TabIndex = 5
        Me.PrintingText.Text = "Print Text"
        '
        'PrintEvents
        '
        Me.PrintEvents.Location = New System.Drawing.Point(160, 256)
        Me.PrintEvents.Name = "PrintEvents"
        Me.PrintEvents.Size = New System.Drawing.Size(75, 32)
        Me.PrintEvents.TabIndex = 6
        Me.PrintEvents.Text = "Print Events"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(384, 325)
        Me.Controls.Add(Me.PrintEvents)
        Me.Controls.Add(Me.PrintingText)
        Me.Controls.Add(Me.printersList)
        Me.Name = "Form1"
        Me.Text = "Printing Simple Text"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub BrowseBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BrowseBtn.Click
        Dim fdlg As New OpenFileDialog
        fdlg.Title = "C# Corner Open File Dialog"
        fdlg.InitialDirectory = "c:\"
        fdlg.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*" '
        fdlg.FilterIndex = 2
        fdlg.RestoreDirectory = True
        If fdlg.ShowDialog() = DialogResult.OK Then
            TextBox1.Text = fdlg.FileName
        End If
    End Sub

    Private Sub PrintingText_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintingText.Click
        Dim printerName As String = printersList.SelectedItem.ToString()
        Dim pd As New PrintDocument
        pd.PrinterSettings.PrinterName = printerName
        AddHandler pd.PrintPage, AddressOf pd_PrintPage
        ' Print the document.
        pd.Print()
    End Sub

    Public Sub pd_PrintPage(ByVal sender As Object, ByVal ev As PrintPageEventArgs)
        ' Get the Graphics object attached to 
        ' PrintPage event args
        Dim g As Graphics = ev.Graphics

        Dim ypos As Single = 1
        Dim leftMargin As Single = ev.MarginBounds.Left
        'Create a font
        Dim font As New Font("Arial", 16)
        Dim fontheight As Single = font.GetHeight(ev.Graphics)
        g.DrawString("Top Margin = " + ev.MarginBounds.Top.ToString(), font, Brushes.Black, leftMargin, ypos)
        ypos = ypos + fontheight
        g.DrawString("Bottom Margin = " + ev.MarginBounds.Bottom.ToString(), font, Brushes.Black, leftMargin, ypos)
        ypos = ypos + fontheight
        g.DrawString("Left Margin = " + ev.MarginBounds.Left.ToString(), font, Brushes.Black, leftMargin, ypos)
        ypos = ypos + fontheight
        g.DrawString("Right Margin = " + ev.MarginBounds.Right.ToString(), font, Brushes.Black, leftMargin, ypos)
        ypos = ypos + fontheight
        g.DrawRectangle(New Pen(Color.Black), ev.MarginBounds.X, ev.MarginBounds.Y, ev.MarginBounds.Width, ev.MarginBounds.Height)
    End Sub 'pd_PrintPage

    Private Sub PrintTextFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintTextFile.Click
        ' Get the file name
        Dim filename As String = textBox1.Text.ToString()
        ' Check if its not empty
        If filename.Equals(String.Empty) Then
            MessageBox.Show("Enter a valid file name")
            textBox1.Focus()
            Return
        End If
        ' Create a StreamReader
        reader = New StreamReader(filename)
        ' Create a verdana font with size 10
        verdana10Font = New Font("Verdana", 10)
        ' Create a PrintDocument
        Dim pd As New PrintDocument
        ' Add PrintPage event handler
        AddHandler pd.PrintPage, AddressOf PrintTextFileHandler
        ' Call Print method
        pd.Print()
        ' Close the reader
        If Not (reader Is Nothing) Then
            reader.Close()
        End If
    End Sub

    Private Sub PrintTextFileHandler(ByVal sender As Object, ByVal ppeArgs As PrintPageEventArgs)
        ' Get the Graphics object
        Dim g As Graphics = ppeArgs.Graphics
        Dim linesPerPage As Single = 0
        Dim yPos As Single = 0
        Dim count As Integer = 0
        ' Read margins from the PrintPageEventArgs
        Dim leftMargin As Single = ppeArgs.MarginBounds.Left
        Dim topMargin As Single = ppeArgs.MarginBounds.Top
        Dim line As String = Nothing
        ' Calculate the lines per page based on the 
        ' height of the page and the height of the 
        ' font
        linesPerPage = ppeArgs.MarginBounds.Height / verdana10Font.GetHeight(g)
        ' Now read lines one by one using StreamReader
        While count < linesPerPage And (Not ((line <= reader.ReadLine()) = True))
            ' Calculate the starting position
            yPos = topMargin + count * verdana10Font.GetHeight(g)
            ' Draw text
            g.DrawString(line, verdana10Font, Brushes.Black, leftMargin, yPos, New StringFormat)
            ' Move to next line
            count += 1
        End While
        ' If PrintPageEventArgs has more pages 
        ' to print
        If Not (line Is Nothing) Then
            ppeArgs.HasMorePages = True
        Else
            ppeArgs.HasMorePages = False
        End If
    End Sub 'PrintTextFileHandler

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim printer As [String]
        For Each printer In PrinterSettings.InstalledPrinters
            printersList.Items.Add(printer.ToString())
        Next printer
    End Sub
    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        Dim g As Graphics = e.Graphics
        Dim redBrush As New SolidBrush(Color.Red)
        Dim rect As New Rectangle(150, 80, 200, 140)
        g.FillPie(greenBrush, 40, 20, 200, 40, 0.0F, 60.0F)
        g.FillRectangle(blueBrush, rect)
    End Sub

    Private Sub PrintEvents_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintEvents.Click
        Try

            Dim printerName As String = printersList.SelectedItem.ToString()
            Dim pd As New PrintDocument
            pd.PrinterSettings.PrinterName = printerName
            AddHandler pd.BeginPrint, AddressOf BgnPrntEventHandler
            AddHandler pd.PrintPage, AddressOf PrntPgEventHandler
            AddHandler pd.EndPrint, AddressOf EndPrntEventHandler
            ' Print the document.
            pd.Print()
        Catch exp As Exception
            MessageBox.Show(exp.Message)
        Finally
        End Try ' Use later

    End Sub

    Public Sub BgnPrntEventHandler(ByVal sender As Object, ByVal peaArgs As PrintEventArgs)
        redBrush = New SolidBrush(Color.Red)
        bluePen = New Pen(Color.Blue, 3)
    End Sub 'BgnPrntEventHandler


    Public Sub EndPrntEventHandler(ByVal sender As Object, ByVal peaArgs As PrintEventArgs)
        redBrush.Dispose()
        bluePen.Dispose()
    End Sub 'EndPrntEventHandler


    Public Sub PrntPgEventHandler(ByVal sender As Object, ByVal ppeArgs As PrintPageEventArgs)
        Try
            Dim ps As New PrinterSettings
            Dim g As Graphics = ppeArgs.Graphics
            Dim pgSettings As New PageSettings(ps)
            ppeArgs.PageSettings.Margins.Left = 50
            ppeArgs.PageSettings.Margins.Right = 100
            ppeArgs.PageSettings.Margins.Top = 50
            ppeArgs.PageSettings.Margins.Bottom = 100
            Dim rect1 As Rectangle = ppeArgs.MarginBounds
            Dim rect2 As Rectangle = ppeArgs.PageBounds
            g.DrawRectangle(bluePen, rect1)
            g.FillRectangle(redBrush, rect2)
        Catch exp As Exception
            MessageBox.Show(exp.Message)
        Finally
        End Try ' Use later
    End Sub 'PrntPgEventHandler
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.MenuItem3 = New System.Windows.Forms.MenuItem
        Me.MenuItem4 = New System.Windows.Forms.MenuItem
        Me.MenuItem5 = New System.Windows.Forms.MenuItem
        Me.MenuItem6 = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem2, Me.MenuItem3, Me.MenuItem4, Me.MenuItem5, Me.MenuItem6})
        Me.MenuItem1.Text = "Other Methods"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 0
        Me.MenuItem2.Text = "ExcludeClip"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 1
        Me.MenuItem3.Text = "IntersectClip"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 2
        Me.MenuItem4.Text = "SetClip"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 3
        Me.MenuItem5.Text = "ResetClip"
        '
        'MenuItem6
        '
        Me.MenuItem6.Index = 4
        Me.MenuItem6.Text = "MeasureString"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(352, 314)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub MenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem2.Click
        Dim g As Graphics = Graphics.FromHwnd(Me.Handle)
        g.Clear(Me.BackColor)

        Dim redBrush As New SolidBrush(Color.Red)
        Dim exRect As New Rectangle(100, 100, 150, 100)
        g.ExcludeClip(exRect)
        g.FillRectangle(redBrush, 10, 10, 350, 300)
    End Sub

    Private Sub MenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem3.Click
        Dim g As Graphics = Graphics.FromHwnd(Me.Handle)
        g.Clear(Me.BackColor)

        Dim blackPen As New Pen(Color.Black, 2)
        Dim redPen As New Pen(Color.Red, 2)
        Dim greenPen As New Pen(Color.Green, 2)
        Dim yellowPen As New Pen(Color.Yellow, 2)
        Dim yelgreenPen As New Pen(Color.YellowGreen)

        Dim rect1 As New Rectangle(0, 0, 50, 50)
        Dim rect2 As New Rectangle(50, 50, 100, 100)
        Dim region1 As New [Region](rect1)
        Dim region2 As New [Region](rect2)
        g.SetClip(region1, System.Drawing.Drawing2D.CombineMode.Replace)
        Dim intRect1 As New Rectangle(25, 25, 75, 75)
        Dim intRect2 As New Rectangle(100, 100, 150, 150)

        Dim intReg1 As New [Region](intRect1)
        Dim intReg2 As New [Region](intRect2)
        g.IntersectClip(intReg1)
        'g.IntersectClip(intReg2);
        g.FillRectangle(New SolidBrush(Color.Blue), 0, 0, 125, 125)
        g.FillRectangle(New SolidBrush(Color.Blue), 50, 50, 175, 175)
        g.ResetClip()
        g.DrawRectangle(yellowPen, rect1)
        g.DrawRectangle(greenPen, intRect1)
        g.DrawRectangle(blackPen, rect2)
        g.DrawRectangle(redPen, intRect2)
    End Sub

    Private Sub MenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem4.Click

    End Sub

    Private Sub MenuItem5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem5.Click
        Dim g As Graphics = Graphics.FromHwnd(Me.Handle)
        g.Clear(Me.BackColor)

        ' Set clipping region.
        Dim clipRect As New Rectangle(0, 0, 200, 200)
        g.SetClip(clipRect)
        ' Update clipping region to intersecton of existing region with new rectangle.
        Dim intersectRectF As New RectangleF(100.0F, 100.0F, 200.0F, 200.0F)
        g.IntersectClip(intersectRectF)
        ' Fill rectangle to demonstrate effective clipping region.
        g.FillRectangle(New SolidBrush(Color.Blue), 0, 0, 500, 500)
        ' Reset clipping region to infinite.
        g.ResetClip()
        ' Draw clipRect and intersectRect to screen.
        g.DrawRectangle(New Pen(Color.Black), clipRect)
        g.DrawRectangle(New Pen(Color.Red), Rectangle.Round(intersectRectF))
    End Sub

    Private Sub MenuItem6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem6.Click
        Dim g As Graphics = Graphics.FromHwnd(Me.Handle)
        g.Clear(Me.BackColor)

        Dim testString As String = "This is a test string"
        Dim verdana14 As New Font("Verdana", 14)
        Dim tahoma18 As New Font("Tahoma", 18)
        Dim nChars As Integer
        Dim nLines As Integer

        ' Call MeasureString to measure a string
        Dim sz As SizeF = g.MeasureString(testString, verdana14)
        Dim stringDetails As String = "Height: " + sz.Height.ToString() + ", Width: " + sz.Width.ToString()
        MessageBox.Show(("First string details: " + stringDetails))
        ' 
        g.DrawString(testString, verdana14, Brushes.Green, New PointF(0, 100))
        g.DrawRectangle(New Pen(Color.Red, 2), 0.0F, 100.0F, sz.Width, sz.Height)

        sz = g.MeasureString("Ellipse", tahoma18, New SizeF(0.0F, 100.0F), New StringFormat, nChars, nLines)
        stringDetails = "Height: " + sz.Height.ToString() + ", Width: " + sz.Width.ToString() + ", Lines: " + nLines.ToString() + ", Chars: " + nChars.ToString()
        MessageBox.Show(("Second string details: " + stringDetails))

        g.DrawString("Ellipse", tahoma18, Brushes.Blue, New PointF(10, 10))
        g.DrawEllipse(New Pen(Color.Red, 3), 10, 10, sz.Width, sz.Height)
        g.Dispose()
    End Sub
End Class

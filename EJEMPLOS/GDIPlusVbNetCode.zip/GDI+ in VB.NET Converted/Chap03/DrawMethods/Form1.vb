Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D

Public Class Form1
    Inherits System.Windows.Forms.Form
    Private objType As Integer = 0

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem7 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem8 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem9 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem10 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem11 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem12 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem13 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem14 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem15 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem16 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem17 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem18 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem19 As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.MenuItem3 = New System.Windows.Forms.MenuItem
        Me.MenuItem4 = New System.Windows.Forms.MenuItem
        Me.MenuItem5 = New System.Windows.Forms.MenuItem
        Me.MenuItem6 = New System.Windows.Forms.MenuItem
        Me.MenuItem7 = New System.Windows.Forms.MenuItem
        Me.MenuItem8 = New System.Windows.Forms.MenuItem
        Me.MenuItem9 = New System.Windows.Forms.MenuItem
        Me.MenuItem10 = New System.Windows.Forms.MenuItem
        Me.MenuItem11 = New System.Windows.Forms.MenuItem
        Me.MenuItem12 = New System.Windows.Forms.MenuItem
        Me.MenuItem13 = New System.Windows.Forms.MenuItem
        Me.MenuItem14 = New System.Windows.Forms.MenuItem
        Me.MenuItem15 = New System.Windows.Forms.MenuItem
        Me.MenuItem16 = New System.Windows.Forms.MenuItem
        Me.MenuItem17 = New System.Windows.Forms.MenuItem
        Me.MenuItem18 = New System.Windows.Forms.MenuItem
        Me.MenuItem19 = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem16})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem2, Me.MenuItem3, Me.MenuItem4, Me.MenuItem5, Me.MenuItem6, Me.MenuItem7, Me.MenuItem8, Me.MenuItem9, Me.MenuItem10, Me.MenuItem11, Me.MenuItem12, Me.MenuItem13, Me.MenuItem14, Me.MenuItem15})
        Me.MenuItem1.Text = "Draw Method"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 0
        Me.MenuItem2.Text = "Rectangle"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 1
        Me.MenuItem3.Text = "Line "
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 2
        Me.MenuItem4.Text = "Circle"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 3
        Me.MenuItem5.Text = "Ellipse"
        '
        'MenuItem6
        '
        Me.MenuItem6.Index = 4
        Me.MenuItem6.Text = "Arc"
        '
        'MenuItem7
        '
        Me.MenuItem7.Index = 5
        Me.MenuItem7.Text = "Bezier"
        '
        'MenuItem8
        '
        Me.MenuItem8.Index = 6
        Me.MenuItem8.Text = "Curve"
        '
        'MenuItem9
        '
        Me.MenuItem9.Index = 7
        Me.MenuItem9.Text = "Icon"
        '
        'MenuItem10
        '
        Me.MenuItem10.Index = 8
        Me.MenuItem10.Text = "Image"
        '
        'MenuItem11
        '
        Me.MenuItem11.Index = 9
        Me.MenuItem11.Text = "Polygon"
        '
        'MenuItem12
        '
        Me.MenuItem12.Index = 10
        Me.MenuItem12.Text = "Text"
        '
        'MenuItem13
        '
        Me.MenuItem13.Index = 11
        Me.MenuItem13.Text = "Path"
        '
        'MenuItem14
        '
        Me.MenuItem14.Index = 12
        Me.MenuItem14.Text = "pie"
        '
        'MenuItem15
        '
        Me.MenuItem15.Index = 13
        Me.MenuItem15.Text = "Clear"
        '
        'MenuItem16
        '
        Me.MenuItem16.Index = 1
        Me.MenuItem16.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem17, Me.MenuItem18, Me.MenuItem19})
        Me.MenuItem16.Text = "Image"
        '
        'MenuItem17
        '
        Me.MenuItem17.Index = 0
        Me.MenuItem17.Text = "FromImage"
        '
        'MenuItem18
        '
        Me.MenuItem18.Index = 1
        Me.MenuItem18.Text = "FromHdc"
        '
        'MenuItem19
        '
        Me.MenuItem19.Index = 2
        Me.MenuItem19.Text = "FromHwnd"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(560, 422)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        If objType = 1 Then
            Dim g As Graphics = e.Graphics
            Dim blueBrush As New SolidBrush(Color.Green)
            Dim redBrush As New SolidBrush(Color.Green)
            Dim rect As New Rectangle(10, 20, 50, 50)

            Dim rectArray As RectangleF() = {New RectangleF(0.0F, 0.0F, 60.0F, 60.0F), New RectangleF(100.0F, 100.0F, 150.0F, 60.0F), New RectangleF(200.0F, 80.0F, 230.0F, 100.0F), New RectangleF(40.0F, 32.0F, 20.0F, 200.0F)}

            g.FillRectangle(New HatchBrush(HatchStyle.BackwardDiagonal, Color.Yellow, Color.Black), rect)
            e.Graphics.FillRectangle(blueBrush, rect)
            e.Graphics.FillRectangles(redBrush, rectArray)
        End If

        ' Drawing lines
        If objType = 2 Then
            Dim g As Graphics = e.Graphics
            Dim pn As New Pen(Color.Blue)
            ' Rectangle rect = new Rectangle(50, 50, 200, 100); 
            Dim pt1 As New Point(30, 30)
            Dim pt2 As New Point(110, 100)
            g.DrawLine(pn, pt1, pt2)


            ' Create a pen with red color and width 3
            Dim redPen As New Pen(Color.Red, 3)
            ' Create an array of points
            Dim ptsArray As PointF() = {New PointF(10.0F, 20.0F), New PointF(50.0F, 40.0F), New PointF(220.0F, 120.0F), New PointF(120.0F, 20.0F)}
            g.DrawLines(redPen, ptsArray)
        End If
        ' Drawing a Circle
        If objType = 3 Then
            Dim g As Graphics = e.Graphics
            Dim pn As New Pen(Color.Blue, 100)
            Dim rect As New Rectangle(50, 50, 100, 100)
            g.DrawEllipse(pn, rect)
        End If
        ' Drawing an Ellipse
        If objType = 4 Then
            Dim g As Graphics = e.Graphics
            Dim rect As New Rectangle(50, 50, 200, 100)
            Dim htchBrush As New HatchBrush(HatchStyle.Cross, Color.Blue, Color.Yellow)
            e.Graphics.FillEllipse(htchBrush, rect)
        End If
        ' Drawing an arc
        If objType = 5 Then
            Dim g As Graphics = e.Graphics
            Dim pn As New Pen(Color.Blue)
            Dim rect As New Rectangle(50, 50, 200, 100)
            g.DrawArc(pn, rect, 12, 84)
        End If

        ' Drawing Beziers
        If objType = 6 Then
            Dim g As Graphics = e.Graphics
            ' Create a green pen.
            Dim greenPen As New Pen(Color.Green, 2)
            ' Draw bezier
            e.Graphics.DrawBezier(greenPen, 20.0F, 30.0F, 100.0F, 200.0F, 40.0F, 400.0F, 100.0F, 200.0F)

            ' Create pen.
            Dim redPen As New Pen(Color.Red, 2)
            ' Create points for curve.
            Dim p1 As New PointF(40.0F, 50.0F)
            Dim p2 As New PointF(60.0F, 70.0F)
            Dim p3 As New PointF(80.0F, 34.0F)
            Dim p4 As New PointF(120.0F, 180.0F)
            Dim p5 As New PointF(200.0F, 150.0F)
            Dim p6 As New PointF(350.0F, 250.0F)
            Dim p7 As New PointF(200.0F, 200.0F)
            Dim ptsArray As PointF() = {p1, p2, p3, p4, p5, p6, p7}
            e.Graphics.DrawBeziers(redPen, ptsArray)
        End If

        ' Drawing an arc
        If objType = 7 Then
            Dim pt1 As New PointF(10.0F, 10.0F)
            Dim pt2 As New PointF(50.0F, 35.0F)
            Dim pt3 As New PointF(100.0F, 20.0F)
            Dim pt4 As New PointF(250.0F, 50.0F)
            Dim pt5 As New PointF(300.0F, 100.0F)
            Dim pt6 As New PointF(350.0F, 200.0F)
            Dim pt7 As New PointF(250.0F, 250.0F)
            Dim ptsArray As PointF() = {pt1, pt2, pt3, pt4, pt5, pt6, pt7}
            Dim tension As Single = 1.0F
            Dim flMode As FillMode = FillMode.Alternate
            Dim blueBrush As New SolidBrush(Color.Blue)
            e.Graphics.FillClosedCurve(blueBrush, ptsArray, flMode, tension)
        End If
        ' Drawing an Icon
        If objType = 8 Then
            Dim icon As New Icon("mouse.ico")
            Dim x As Integer = 50
            Dim y As Integer = 100
            e.Graphics.DrawIcon(icon, x, y)
            Dim rect As New Rectangle(50, 100, 400, 400)
            e.Graphics.DrawIconUnstretched(icon, rect)
        End If

        ' Drawing a polygon
        If objType = 10 Then
            Dim pt1 As New PointF(10.0F, 10.0F)
            Dim pt2 As New PointF(100.0F, 25.0F)
            Dim pt3 As New PointF(150.0F, 35.0F)
            Dim pt4 As New PointF(250.0F, 50.0F)
            Dim pt5 As New PointF(300.0F, 100.0F)
            Dim pt6 As New PointF(350.0F, 200.0F)
            Dim pt7 As New PointF(250.0F, 250.0F)
            Dim ptsArray As PointF() = {pt1, pt2, pt3, pt4, pt5, pt6, pt7}
            Dim htchBrush As New HatchBrush(HatchStyle.ForwardDiagonal, Color.Black, Color.Red)
            Dim flMode As FillMode = FillMode.Winding
            e.Graphics.FillPolygon(htchBrush, ptsArray, flMode)
        End If


        ' Drawing text
        If objType = 11 Then
            Dim fnt As New Font("Verdana", 16)
            Dim g As Graphics = e.Graphics
            g.DrawString("GDI+ World", fnt, New SolidBrush(Color.Red), 14, 10)
        End If
        ' Drawing a path
        If objType = 12 Then
            Dim g As Graphics = e.Graphics
            Dim graphPath As New GraphicsPath
            graphPath.AddEllipse(50, 50, 150, 200)
            Dim blackBrush As New SolidBrush(Color.Black)
            e.Graphics.FillPath(blackBrush, graphPath)
        End If
        ' Drawing a Pie
        If objType = 13 Then
            Dim g As Graphics = e.Graphics
            g.FillPie(New SolidBrush(Color.Red), 0.0F, 0.0F, 100, 60, 0.0F, 90.0F)
        End If

    End Sub

    Private Sub MenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem2.Click
        objType = 1
        Me.Invalidate(Me.Region, True)
    End Sub

    Private Sub MenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem3.Click
        objType = 2
        Me.Invalidate(Me.Region, True)
    End Sub

    Private Sub MenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem4.Click
        objType = 3
        Me.Invalidate(Me.Region, True)
    End Sub

    Private Sub MenuItem5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem5.Click
        objType = 4
        Me.Invalidate(Me.Region, True)
    End Sub

    Private Sub MenuItem6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem6.Click
        objType = 5
        Me.Invalidate(Me.Region, True)
    End Sub

    Private Sub MenuItem7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem7.Click
        objType = 6
        Me.Invalidate(Me.Region, True)
    End Sub

    Private Sub MenuItem8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem8.Click
        objType = 7
        Me.Invalidate(Me.Region, True)
    End Sub

    Private Sub MenuItem9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem9.Click
        objType = 8
        Me.Invalidate(Me.Region, True)
    End Sub

    Private Sub MenuItem10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem10.Click
        objType = 9
        Me.Invalidate(Me.Region, True)
    End Sub

    Private Sub MenuItem11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem11.Click
        objType = 10
        Me.Invalidate(Me.Region, True)
    End Sub

    Private Sub MenuItem12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem12.Click
        objType = 11
        Me.Invalidate(Me.Region, True)
    End Sub

    Private Sub MenuItem13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem13.Click
        objType = 12
        Me.Invalidate(Me.Region, True)
    End Sub

    Private Sub MenuItem14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem14.Click
        objType = 13
        Me.Invalidate(Me.Region, True)
    End Sub

    Private Sub MenuItem15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem15.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        g.Dispose()
    End Sub

    Private Sub MenuItem17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem17.Click
        Dim imageFile As Image = Image.FromFile("F:\Mahesh\Stuff\hotjb.jpg")
        Dim g As Graphics = Me.CreateGraphics() '
        Dim newGraphics As Graphics = Graphics.FromImage(imageFile)
        newGraphics.FillRectangle(New SolidBrush(Color.Black), 100, 50, 100, 100)
        g.DrawImage(imageFile, New PointF(0.0F, 0.0F))
        newGraphics.Dispose()
        g.Dispose()
    End Sub

    Private Sub MenuItem18_Click(ByVal sender As System.Object, ByVal e As PaintEventArgs)
        Dim hdc As IntPtr = e.Graphics.GetHdc()
        Dim newGraphics As Graphics = Graphics.FromHdc(hdc)
        newGraphics.DrawRectangle(New Pen(Color.Red, 3), 0, 0, 200, 100)
        e.Graphics.ReleaseHdc(hdc)
    End Sub

    Private Sub MenuItem19_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem19.Click

    End Sub
End Class

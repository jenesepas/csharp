Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents DrawBtn As System.Windows.Forms.Button
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton4 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton5 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton6 As System.Windows.Forms.RadioButton

    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.DrawBtn = New System.Windows.Forms.Button
        Me.RadioButton1 = New System.Windows.Forms.RadioButton
        Me.RadioButton2 = New System.Windows.Forms.RadioButton
        Me.RadioButton3 = New System.Windows.Forms.RadioButton
        Me.RadioButton4 = New System.Windows.Forms.RadioButton
        Me.RadioButton5 = New System.Windows.Forms.RadioButton
        Me.RadioButton6 = New System.Windows.Forms.RadioButton
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RadioButton6)
        Me.GroupBox1.Controls.Add(Me.RadioButton5)
        Me.GroupBox1.Controls.Add(Me.RadioButton4)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 16)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(100, 112)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Object"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.RadioButton3)
        Me.GroupBox2.Controls.Add(Me.RadioButton2)
        Me.GroupBox2.Controls.Add(Me.RadioButton1)
        Me.GroupBox2.Location = New System.Drawing.Point(8, 128)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(100, 96)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Color"
        '
        'DrawBtn
        '
        Me.DrawBtn.Location = New System.Drawing.Point(24, 272)
        Me.DrawBtn.Name = "DrawBtn"
        Me.DrawBtn.Size = New System.Drawing.Size(112, 32)
        Me.DrawBtn.TabIndex = 2
        Me.DrawBtn.Text = "Draw"
        '
        'RadioButton1
        '
        Me.RadioButton1.Location = New System.Drawing.Point(8, 16)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(80, 24)
        Me.RadioButton1.TabIndex = 0
        Me.RadioButton1.Text = "Red"
        '
        'RadioButton2
        '
        Me.RadioButton2.Location = New System.Drawing.Point(8, 40)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(80, 24)
        Me.RadioButton2.TabIndex = 1
        Me.RadioButton2.Text = "Green"
        '
        'RadioButton3
        '
        Me.RadioButton3.Location = New System.Drawing.Point(8, 64)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(80, 24)
        Me.RadioButton3.TabIndex = 2
        Me.RadioButton3.Text = "Blue"
        '
        'RadioButton4
        '
        Me.RadioButton4.Location = New System.Drawing.Point(8, 24)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(80, 24)
        Me.RadioButton4.TabIndex = 0
        Me.RadioButton4.Text = "Circle"
        '
        'RadioButton5
        '
        Me.RadioButton5.Location = New System.Drawing.Point(8, 48)
        Me.RadioButton5.Name = "RadioButton5"
        Me.RadioButton5.Size = New System.Drawing.Size(80, 24)
        Me.RadioButton5.TabIndex = 1
        Me.RadioButton5.Text = "Rectangle"
        '
        'RadioButton6
        '
        Me.RadioButton6.Location = New System.Drawing.Point(8, 72)
        Me.RadioButton6.Name = "RadioButton6"
        Me.RadioButton6.Size = New System.Drawing.Size(80, 24)
        Me.RadioButton6.TabIndex = 2
        Me.RadioButton6.Text = "String"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(408, 341)
        Me.Controls.Add(Me.DrawBtn)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Drawing with No OnPaint"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        RadioButton4.Checked = True
        RadioButton1.Checked = True
    End Sub

    Private Sub DrawBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DrawBtn.Click
        Dim g As Graphics = Graphics.FromHwnd(Me.Handle)
        Dim pn As New Pen(Color.Blue, 10)
        Dim br As New SolidBrush(Color.AliceBlue)
        Dim rc As New Rectangle(150, 50, 250, 250)

        If RadioButton1.Checked Then
            pn.Color = Color.Red
            br.Color = Color.Red
        End If
        If RadioButton2.Checked Then
            pn.Color = Color.Green
            br.Color = Color.Green
        End If
        If RadioButton3.Checked Then
            pn.Color = Color.Blue
            br.Color = Color.Blue
        End If
        If RadioButton4.Checked Then
            g.FillEllipse(br, rc)
            g.DrawEllipse(pn, rc)
        End If
        If RadioButton5.Checked Then
            g.DrawRectangle(pn, rc)
        End If
        If RadioButton6.Checked Then
            g.DrawString("Test String", New Font("Verdana", 14), New SolidBrush(Color.Black), rc.Location.X, rc.Location.Y)
        End If
        pn.Dispose()
        br.Dispose()
    End Sub
End Class

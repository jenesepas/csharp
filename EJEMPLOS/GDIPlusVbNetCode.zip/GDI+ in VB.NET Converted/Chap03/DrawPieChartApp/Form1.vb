Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Public Class Form1
    Inherits System.Windows.Forms.Form
    Private rect As New Rectangle(250, 150, 200, 200)
    Public sliceList As New ArrayList

    Structure sliceData
        Public share As Integer
        Public clr As Color
    End Structure 'sliceData
    Private curClr As Color = Color.Black
    Dim shareTotal As Integer = 0

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents ColorBtn As System.Windows.Forms.Button
    Friend WithEvents AddSliceBtn As System.Windows.Forms.Button
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents DrawChartBtn As System.Windows.Forms.Button
    Friend WithEvents FillChartBtn As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.ColorBtn = New System.Windows.Forms.Button
        Me.AddSliceBtn = New System.Windows.Forms.Button
        Me.ListBox1 = New System.Windows.Forms.ListBox
        Me.DrawChartBtn = New System.Windows.Forms.Button
        Me.FillChartBtn = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(8, 8)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(80, 20)
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = ""
        '
        'ColorBtn
        '
        Me.ColorBtn.BackColor = System.Drawing.Color.Blue
        Me.ColorBtn.ForeColor = System.Drawing.Color.White
        Me.ColorBtn.Location = New System.Drawing.Point(96, 8)
        Me.ColorBtn.Name = "ColorBtn"
        Me.ColorBtn.TabIndex = 1
        Me.ColorBtn.Text = "Select Color"
        '
        'AddSliceBtn
        '
        Me.AddSliceBtn.Location = New System.Drawing.Point(208, 16)
        Me.AddSliceBtn.Name = "AddSliceBtn"
        Me.AddSliceBtn.TabIndex = 2
        Me.AddSliceBtn.Text = "Add Slice"
        '
        'ListBox1
        '
        Me.ListBox1.Location = New System.Drawing.Point(16, 56)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(200, 199)
        Me.ListBox1.TabIndex = 3
        '
        'DrawChartBtn
        '
        Me.DrawChartBtn.Location = New System.Drawing.Point(16, 288)
        Me.DrawChartBtn.Name = "DrawChartBtn"
        Me.DrawChartBtn.TabIndex = 4
        Me.DrawChartBtn.Text = "Draw Chart"
        '
        'FillChartBtn
        '
        Me.FillChartBtn.Location = New System.Drawing.Point(112, 288)
        Me.FillChartBtn.Name = "FillChartBtn"
        Me.FillChartBtn.TabIndex = 5
        Me.FillChartBtn.Text = "Fill Chart"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(504, 381)
        Me.Controls.Add(Me.FillChartBtn)
        Me.Controls.Add(Me.DrawChartBtn)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.AddSliceBtn)
        Me.Controls.Add(Me.ColorBtn)
        Me.Controls.Add(Me.TextBox1)
        Me.Name = "Form1"
        Me.Text = "Pie Chart Application"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ColorBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ColorBtn.Click
        Dim clrDlg As ColorDialog = New ColorDialog
        If (clrDlg.ShowDialog() = DialogResult.OK) Then
            curClr = clrDlg.Color
        End If
    End Sub

    Private Sub AddSliceBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddSliceBtn.Click
        Dim slice As Integer = Convert.ToInt32(TextBox1.Text)
        shareTotal += slice
        Dim dt As sliceData
        dt.clr = curClr
        dt.share = slice
        sliceList.Add(dt)
        ListBox1.Items.Add(("Share:" + slice.ToString() + " ," + curClr.ToString()))
    End Sub

    Private Sub DrawChartBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DrawChartBtn.Click
        DrawPieChart(False)
    End Sub

    Private Sub FillChartBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FillChartBtn.Click
        DrawPieChart(True)
    End Sub
    Private Sub DrawPieChart(ByVal flMode As Boolean)
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim rect As New Rectangle(250, 150, 200, 200)
        Dim angle As Single = 0
        Dim sweep As Single = 0
        Dim dt As sliceData
        For Each dt In sliceList
            sweep = 360.0F * dt.share / shareTotal
            If flMode Then
                g.FillPie(New SolidBrush(dt.clr), rect, angle, sweep)
            Else
                g.DrawPie(New Pen(dt.clr), rect, angle, sweep)
            End If
            angle += sweep
        Next dt
        g.Dispose()
    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D

Public Class Form1
    Inherits System.Windows.Forms.Form
    Private tension As Single = 0.5F

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents ApplyBtn As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.ApplyBtn = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(256, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(80, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Enter Tension"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(336, 16)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(80, 20)
        Me.TextBox1.TabIndex = 1
        Me.TextBox1.Text = ""
        '
        'ApplyBtn
        '
        Me.ApplyBtn.Location = New System.Drawing.Point(320, 88)
        Me.ApplyBtn.Name = "ApplyBtn"
        Me.ApplyBtn.Size = New System.Drawing.Size(96, 32)
        Me.ApplyBtn.TabIndex = 2
        Me.ApplyBtn.Text = "Apply"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(440, 301)
        Me.Controls.Add(Me.ApplyBtn)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Draw Curve"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ApplyBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ApplyBtn.Click
        tension = CSng(Convert.ToDouble(TextBox1.Text))
        Invalidate()
    End Sub

    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        ' Create a pen
        Dim bluePen As New Pen(Color.Blue, 1)
        ' Create an array of points
        Dim pt1 As New PointF(40.0F, 50.0F)
        Dim pt2 As New PointF(50.0F, 75.0F)
        Dim pt3 As New PointF(100.0F, 115.0F)
        Dim pt4 As New PointF(200.0F, 180.0F)
        Dim pt5 As New PointF(200.0F, 90.0F)
        Dim ptsArray As PointF() = {pt1, pt2, pt3, pt4, pt5}
        ' Draw curve
        Dim offset As Integer = 1
        Dim segments As Integer = 3
        e.Graphics.DrawCurve(bluePen, ptsArray, offset, segments, tension)
        ' Dispose
        bluePen.Dispose()
    End Sub
End Class

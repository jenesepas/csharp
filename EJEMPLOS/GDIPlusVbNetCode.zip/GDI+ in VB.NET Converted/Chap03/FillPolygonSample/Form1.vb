Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(336, 273)
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        Dim g As Graphics = e.Graphics
        ' Create a solid brush
        Dim greenBrush As New SolidBrush(Color.Green)
        ' Create points for polygon.
        Dim p1 As New PointF(40.0F, 50.0F)
        Dim p2 As New PointF(60.0F, 70.0F)
        Dim p3 As New PointF(80.0F, 34.0F)
        Dim p4 As New PointF(120.0F, 180.0F)
        Dim p5 As New PointF(200.0F, 150.0F)
        Dim ptsArray As PointF() = {p1, p2, p3, p4, p5}
        ' Draw polygon
        e.Graphics.FillPolygon(greenBrush, ptsArray)
        ' Dispose
        greenBrush.Dispose()
    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        ' Creating four Pen objects with red,
        ' blue, green and black colors and 
        ' different width
        Dim redPen As New Pen(Color.Red, 1)
        Dim bluePen As New Pen(Color.Blue, 2)
        Dim greenPen As New Pen(Color.Green, 3)
        Dim blackPen As New Pen(Color.Black, 4)
        ' Draw line using float coordinates 
        Dim x1 As Single = 20.0F
        Dim y1 As Single = 20.0F
        Dim x2 As Single = 200.0F
        Dim y2 As Single = 20.0F
        e.Graphics.DrawLine(redPen, x1, y1, x2, y2)
        ' Draw line using Point structure
        Dim pt1 As New Point(20, 20)
        Dim pt2 As New Point(20, 200)
        e.Graphics.DrawLine(greenPen, pt1, pt2)
        ' Draw line using PointF structure
        Dim ptf1 As New PointF(20.0F, 20.0F)
        Dim ptf2 As New PointF(200.0F, 200.0F)
        e.Graphics.DrawLine(bluePen, ptf1, ptf2)
        ' Draw line using integer coordinates
        Dim X3 As Integer = 60
        Dim Y3 As Integer = 40
        Dim X4 As Integer = 250
        Dim Y4 As Integer = 100
        e.Graphics.DrawLine(blackPen, X3, Y3, X4, Y4)
        redPen.Dispose()
        bluePen.Dispose()
        greenPen.Dispose()
        blackPen.Dispose()
    End Sub
End Class

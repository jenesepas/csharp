Imports System
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Windows.Forms
Imports System.IO
Public Class Form1
    Inherits System.Windows.Forms.Form
    Private bitmap As Bitmap = Nothing
    Private curBitmap As Bitmap = Nothing
    Private dragMode As Boolean = False
    Private drawIndex As Integer = 1
    Private curX, curY, x, y As Integer
    Private diffX, diffY As Integer
    Private curGraphics As Graphics
    Public curPen As Pen
    Private curBrush As SolidBrush
    Private fullSize As Size
    Private penReader As TextReader = Nothing
    Private brushReader As TextReader = Nothing

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents DrawLine As System.Windows.Forms.Button
    Friend WithEvents FilledEllipse As System.Windows.Forms.Button
    Friend WithEvents Filledrect As System.Windows.Forms.Button
    Friend WithEvents DrawRect As System.Windows.Forms.Button
    Friend WithEvents DrawEllipse As System.Windows.Forms.Button
    Friend WithEvents SaveBtn As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.FilledEllipse = New System.Windows.Forms.Button
        Me.Filledrect = New System.Windows.Forms.Button
        Me.DrawRect = New System.Windows.Forms.Button
        Me.DrawEllipse = New System.Windows.Forms.Button
        Me.DrawLine = New System.Windows.Forms.Button
        Me.SaveBtn = New System.Windows.Forms.Button
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.SaveBtn)
        Me.Panel1.Controls.Add(Me.FilledEllipse)
        Me.Panel1.Controls.Add(Me.Filledrect)
        Me.Panel1.Controls.Add(Me.DrawRect)
        Me.Panel1.Controls.Add(Me.DrawEllipse)
        Me.Panel1.Controls.Add(Me.DrawLine)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(640, 32)
        Me.Panel1.TabIndex = 0
        '
        'FilledEllipse
        '
        Me.FilledEllipse.BackColor = System.Drawing.Color.Yellow
        Me.FilledEllipse.ForeColor = System.Drawing.Color.Green
        Me.FilledEllipse.Image = CType(resources.GetObject("FilledEllipse.Image"), System.Drawing.Image)
        Me.FilledEllipse.Location = New System.Drawing.Point(128, 0)
        Me.FilledEllipse.Name = "FilledEllipse"
        Me.FilledEllipse.Size = New System.Drawing.Size(32, 30)
        Me.FilledEllipse.TabIndex = 4
        '
        'Filledrect
        '
        Me.Filledrect.BackColor = System.Drawing.Color.Yellow
        Me.Filledrect.ForeColor = System.Drawing.Color.Green
        Me.Filledrect.Image = CType(resources.GetObject("Filledrect.Image"), System.Drawing.Image)
        Me.Filledrect.Location = New System.Drawing.Point(96, 0)
        Me.Filledrect.Name = "Filledrect"
        Me.Filledrect.Size = New System.Drawing.Size(32, 30)
        Me.Filledrect.TabIndex = 3
        '
        'DrawRect
        '
        Me.DrawRect.BackColor = System.Drawing.Color.Yellow
        Me.DrawRect.ForeColor = System.Drawing.Color.Green
        Me.DrawRect.Image = CType(resources.GetObject("DrawRect.Image"), System.Drawing.Image)
        Me.DrawRect.Location = New System.Drawing.Point(64, 0)
        Me.DrawRect.Name = "DrawRect"
        Me.DrawRect.Size = New System.Drawing.Size(32, 30)
        Me.DrawRect.TabIndex = 2
        '
        'DrawEllipse
        '
        Me.DrawEllipse.BackColor = System.Drawing.Color.Yellow
        Me.DrawEllipse.ForeColor = System.Drawing.Color.Green
        Me.DrawEllipse.Image = CType(resources.GetObject("DrawEllipse.Image"), System.Drawing.Image)
        Me.DrawEllipse.Location = New System.Drawing.Point(32, 0)
        Me.DrawEllipse.Name = "DrawEllipse"
        Me.DrawEllipse.Size = New System.Drawing.Size(32, 30)
        Me.DrawEllipse.TabIndex = 1
        '
        'DrawLine
        '
        Me.DrawLine.BackColor = System.Drawing.Color.Yellow
        Me.DrawLine.ForeColor = System.Drawing.Color.DarkGreen
        Me.DrawLine.Image = CType(resources.GetObject("DrawLine.Image"), System.Drawing.Image)
        Me.DrawLine.Location = New System.Drawing.Point(0, 0)
        Me.DrawLine.Name = "DrawLine"
        Me.DrawLine.Size = New System.Drawing.Size(32, 30)
        Me.DrawLine.TabIndex = 0
        '
        'SaveBtn
        '
        Me.SaveBtn.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(128, Byte), CType(0, Byte))
        Me.SaveBtn.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Bold)
        Me.SaveBtn.ForeColor = System.Drawing.Color.White
        Me.SaveBtn.Location = New System.Drawing.Point(536, 0)
        Me.SaveBtn.Name = "SaveBtn"
        Me.SaveBtn.Size = New System.Drawing.Size(104, 40)
        Me.SaveBtn.TabIndex = 5
        Me.SaveBtn.Text = "&SaveImage"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(640, 461)
        Me.Controls.Add(Me.Panel1)
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(64, Byte), CType(64, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "GDI+Painter"
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Get the full size of the form
        fullSize = SystemInformation.PrimaryMonitorMaximizedWindowSize
        ' Create a bitmap using full size
        bitmap = New Bitmap(fullSize.Width, fullSize.Height)
        ' Create a Graphics object from Bitmap
        curGraphics = Graphics.FromImage(bitmap)
        ' Set background color as form's color
        curGraphics.Clear(Me.BackColor)
        ' Create a new pen and brush as 
        ' default pen and brush
        curPen = New Pen(Color.Black)
        curBrush = New SolidBrush(Color.Black)
    End Sub

    Protected Overrides Sub OnMouseDown(ByVal e As MouseEventArgs)
        ' Store the starting point of 
        ' the rectangle and set the drag mode
        ' to true
        curX = e.X
        curY = e.Y
        dragMode = True
    End Sub
    Protected Overrides Sub OnMouseMove(ByVal e As MouseEventArgs)
        ' Find out the ending point of 
        ' the rectangle and calculate the 
        ' difference of starting and ending
        ' points to find out the height and width 
        ' of the rectangle
        x = e.X
        y = e.Y
        diffX = e.X - curX
        diffY = e.Y - curY
        ' If drag mode is true, call refresh
        ' that forces window to repaint
        If dragMode Then
            Me.Refresh()
        End If
    End Sub
    Protected Overrides Sub OnMouseUp(ByVal e As MouseEventArgs)
        diffX = x - curX
        diffY = y - curY
        Select Case drawIndex
            Case 1
                ' Draw a line
                curGraphics.DrawLine(curPen, curX, curY, x, y)
                'Exit 
            Case 2
                ' Draw an ellipse
                curGraphics.DrawEllipse(curPen, curX, curY, diffX, diffY)
                'Exit 
            Case 3
                ' Draw rectangle
                curGraphics.DrawRectangle(curPen, curX, curY, diffX, diffY)
                ' Exit 
            Case 4
                ' Fill rectangle
                curGraphics.FillRectangle(curBrush, curX, curY, diffX, diffY)
                'Exit 
            Case 5
                ' Fill ellipse
                curGraphics.FillEllipse(curBrush, curX, curY, diffX, diffY)
                ' Exit 
        End Select
        ' Refresh 
        RefreshFormBackground()
        ' Set drag mode to false
        dragMode = False

    End Sub

    Private Sub DrawLine_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DrawLine.Click
        drawIndex = 1
    End Sub

    Private Sub DrawEllipse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DrawEllipse.Click
        drawIndex = 2
    End Sub

    Private Sub DrawRect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DrawRect.Click
        drawIndex = 3
    End Sub

    Private Sub Filledrect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Filledrect.Click
        drawIndex = 4
    End Sub

    Private Sub FilledEllipse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FilledEllipse.Click
        drawIndex = 5
    End Sub

    Private Sub SaveBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveBtn.Click
        ' Save file dialog
        Dim saveFileDlg As New SaveFileDialog
        saveFileDlg.Filter = "Image files (*.bmp)|*.bmp|All files (*.*)|*.*"
        If saveFileDlg.ShowDialog() = DialogResult.OK Then
            ' Create bitmap and call Save method 
            ' to save it 
            Dim tmpBitmap As Bitmap = bitmap.Clone(New Rectangle(0, 0, Me.Width, Me.Height), bitmap.PixelFormat)
            tmpBitmap.Save(saveFileDlg.FileName, ImageFormat.Bmp)
        End If
    End Sub

    Private Sub Form1_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs)
        RefreshFormBackground()
    End Sub 'Form1_SizeChanged


    Private Sub RefreshFormBackground()
        curBitmap = bitmap.Clone(New Rectangle(0, 0, Me.Width, Me.Height), bitmap.PixelFormat)
        Me.BackgroundImage = curBitmap
    End Sub 'RefreshFormBackground

    Private Sub Form1_Closed(ByVal e As Form1)
        ' Dispose all public objects
        curPen.Dispose()
        curBrush.Dispose()
        curGraphics.Dispose()
    End Sub 'Form1_Closed


    Private Sub Form1_Closed(ByVal sender As Object, ByVal e As System.EventArgs)
        ' Dispose all public objects
        curPen.Dispose()
        curBrush.Dispose()
        curGraphics.Dispose()
    End Sub 'Form1_Closed
End Class

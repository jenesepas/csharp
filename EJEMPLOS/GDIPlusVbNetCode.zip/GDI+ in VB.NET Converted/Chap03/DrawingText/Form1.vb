Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(360, 325)
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        Dim blueBrush As New SolidBrush(Color.Blue)
        Dim redBrush As New SolidBrush(Color.Red)
        Dim greenBrush As New SolidBrush(Color.Green)
        ' Create a rectangle
        Dim rect As New Rectangle(20, 20, 200, 100)
        ' The text to be drawn
        Dim drawString As [String] = "Hello GDI+ World!"
        ' Create a Font
        Dim drawFont As New Font("Verdana", 14)
        Dim x As Single = 100.0F
        Dim y As Single = 100.0F
        ' String format
        Dim drawFormat As New StringFormat
        ' Set string format flag to direction vertical
        ' which draws text vertical
        drawFormat.FormatFlags = StringFormatFlags.DirectionVertical
        ' Draw string
        e.Graphics.DrawString("Drawing text", New Font("Tahoma", 14), greenBrush, rect.Location.X, rect.Location.Y)
        e.Graphics.DrawString(drawString, New Font("Arial", 12), redBrush, 120, 140)
        e.Graphics.DrawString(drawString, drawFont, blueBrush, x, y, drawFormat)
        ' Dispose
        blueBrush.Dispose()
        redBrush.Dispose()
        greenBrush.Dispose()
        drawFont.Dispose()
    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.MenuItem3 = New System.Windows.Forms.MenuItem
        Me.MenuItem4 = New System.Windows.Forms.MenuItem
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(152, 80)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(144, 40)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Button1"
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem2, Me.MenuItem3, Me.MenuItem4})
        Me.MenuItem1.Text = "Test"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 0
        Me.MenuItem2.Text = "Point Structure"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 1
        Me.MenuItem3.Text = "Size Structure"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 2
        Me.MenuItem4.Text = "Rectangle Structure"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(352, 266)
        Me.Controls.Add(Me.Button1)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub MenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem2.Click
        Dim pt1 As New PointF(30.6F, 30.8F)
        Dim pt2 As New PointF(50.3F, 60.7F)
        Dim pt3 As New PointF(110.3F, 80.5F)

        Dim pt4 As Point = Point.Ceiling(pt1)
        Dim pt5 As Point = Point.Round(pt2)
        Dim pt6 As Point = Point.Truncate(pt3)

        MessageBox.Show(pt4.ToString())
        MessageBox.Show(pt5.ToString())
        MessageBox.Show(pt6.ToString())

        Dim g As Graphics = Graphics.FromHwnd(Me.Handle)
        g.Clear(Me.BackColor)
        g.Dispose()
    End Sub

    Private Sub MenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem3.Click
        Dim pt1 As New PointF(30.6F, 30.8F)
        Dim pt2 As New PointF(50.3F, 60.7F)
        Dim pt3 As New PointF(110.3F, 80.5F)

        Dim sz1 As New SizeF(pt1)
        Dim sz2 As New SizeF(pt2)
        Dim sz3 As New SizeF(pt3)

        Dim sz4 As Size = Size.Ceiling(sz1)
        Dim sz5 As Size = Size.Round(sz2)
        Dim sz6 As Size = Size.Truncate(sz3)

        MessageBox.Show(sz4.ToString())
        MessageBox.Show(sz5.ToString())
        MessageBox.Show(sz6.ToString())
    End Sub
    Protected Overrides Sub OnMouseMove(ByVal e As MouseEventArgs)
        Dim rect As New Rectangle(Button1.Location, Button1.Size)

        If rect.Contains(New Rectangle(New Point(e.X, e.Y), Button1.Size)) Then
            Dim g As Graphics = Graphics.FromHwnd(Me.Handle)
            g.FillRectangle(SystemBrushes.ControlDark, 10, 20, 50, 100)
            MessageBox.Show("Rajkumar")
            g.Clear(Me.BackColor)
            g.Dispose()
        End If
    End Sub

    Private Sub MenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem4.Click

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        'Dim rect As New Rectangle(Button1.Location, Button1.Size)

        'If rect.Contains(New Rectangle(New Point(100, 100), Button1.Size)) Then
        '    Dim g As Graphics = Graphics.FromHwnd(Me.Handle)
        '    g.FillRectangle(SystemBrushes.ControlDarkDark, 10, 20, 50, 100)
        '    g.Clear(Me.BackColor)
        '    g.Dispose()
        'End If
    End Sub
End Class

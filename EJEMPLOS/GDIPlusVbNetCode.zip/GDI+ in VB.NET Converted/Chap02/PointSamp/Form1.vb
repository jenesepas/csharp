Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.MenuItem3 = New System.Windows.Forms.MenuItem
        Me.MenuItem4 = New System.Windows.Forms.MenuItem
        Me.MenuItem5 = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem2, Me.MenuItem3, Me.MenuItem4, Me.MenuItem5})
        Me.MenuItem1.Text = "Point"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 0
        Me.MenuItem2.Text = "Point Code"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 1
        Me.MenuItem3.Text = "PoinyF Code"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 2
        Me.MenuItem4.Text = "Point Methods"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 3
        Me.MenuItem5.Text = "Point Conversions"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(400, 330)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Point Structure Sample"

    End Sub

#End Region

    Private Sub MenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem2.Click
        Dim pt As New Point(50, 50)
        ' Create a new point using Point.Empty
        Dim newPoint As Point = Point.Empty
        ' Set X and Y properties of Point
        newPoint.X = 100
        newPoint.Y = 200
        ' Create a Graphics object from the 
        ' current form's handle
        Dim g As Graphics = Graphics.FromHwnd(Me.Handle)
        ' Create a new pen with blue color
        ' and with = 4
        Dim pn As New Pen(Color.Blue, 4)
        ' Draw a line from point pt to 
        ' new point
        g.DrawLine(pn, pt, newPoint)
        ' Dispose pen and graphics objects
        pn.Dispose()
        g.Dispose()
    End Sub

    Private Sub MenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem3.Click
        ' Create a new PointF
        Dim pt As New PointF(50.0F, 50.0F)
        ' Create a new point using PointF.Empty
        Dim newPoint As PointF = PointF.Empty
        ' Set X and Y properties of PointF
        newPoint.X = 100.0F
        newPoint.Y = 200.0F
        ' Create a Graphics object from the 
        ' current form's handle
        Dim g As Graphics = Graphics.FromHwnd(Me.Handle)
        ' Create a new pen with blue color
        ' and with = 4
        Dim pn As New Pen(Color.Blue, 4)
        ' Draw a line from point pt to 
        ' new point
        g.DrawLine(pn, pt, newPoint)
        ' Dispose pen and graphics objects
        pn.Dispose()
        g.Dispose()
    End Sub

    Private Sub MenuItem4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem4.Click
        ' Create three points
        Dim pt1 As New PointF(30.6F, 30.8F)
        Dim pt2 As New PointF(50.3F, 60.7F)
        Dim pt3 As New PointF(110.3F, 80.5F)
        ' Call Ceiling, Round, and Truncate methods
        ' and return new points
        Dim pt4 As Point = Point.Ceiling(pt1)
        Dim pt5 As Point = Point.Round(pt2)
        Dim pt6 As Point = Point.Truncate(pt3)
        ' Display results
        MessageBox.Show(("Value of pt4: " + pt4.ToString()))
        MessageBox.Show(("Value of pt5: " + pt5.ToString()))
        MessageBox.Show(("Value of pt6: " + pt6.ToString()))
    End Sub

    Private Sub MenuItem5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem5.Click
        ' Create a Size 
        Dim sz As New Size(12, 12)
        ' Create a Point
        Dim pt As New Point(20, 20)
        ' Add poitn and size and copy to point
        pt.X += sz.Width
        pt.Y += sz.Height
        MessageBox.Show(("Addition :" + pt.ToString()))
        ' Subtract point and size
        pt.X -= sz.Width
        pt.Y -= sz.Height
        MessageBox.Show(("Subtraction :" + pt.ToString()))
        ' Create a PointF from Point
        Dim ptf As PointF
        ptf.X = pt.X
        ptf.Y = pt.Y

        MessageBox.Show(("PointF :" + pt.ToString()))
        ' Concert Point to Size
        sz.Width = pt.X
        sz.Height = pt.Y
        MessageBox.Show(("Size :" + sz.Width.ToString() + "," + sz.Height.ToString()))
    End Sub
End Class

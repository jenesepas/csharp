Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents RectCreate As System.Windows.Forms.MenuItem
    Friend WithEvents RectProperties As System.Windows.Forms.MenuItem
    Friend WithEvents RectMethods As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents RectFCreate As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.RectCreate = New System.Windows.Forms.MenuItem
        Me.RectProperties = New System.Windows.Forms.MenuItem
        Me.RectMethods = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.RectFCreate = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem2})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.RectCreate, Me.RectProperties, Me.RectMethods})
        Me.MenuItem1.Text = "Rectangle"
        '
        'RectCreate
        '
        Me.RectCreate.Index = 0
        Me.RectCreate.Text = "Create"
        '
        'RectProperties
        '
        Me.RectProperties.Index = 1
        Me.RectProperties.Text = "Properties"
        '
        'RectMethods
        '
        Me.RectMethods.Index = 2
        Me.RectMethods.Text = "Methods"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.RectFCreate})
        Me.MenuItem2.Text = "RectangleF"
        '
        'RectFCreate
        '
        Me.RectFCreate.Index = 0
        Me.RectFCreate.Text = "Create"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub RectCreate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RectCreate.Click
        Dim g As Graphics = Me.CreateGraphics()
        Dim x As Integer = 40
        Dim y As Integer = 40
        Dim height As Integer = 120
        Dim width As Integer = 120
        ' Create a Point
        Dim pt As New Point(80, 80)
        ' Create a Size
        Dim sz As New Size(100, 100)
        ' Create a Rectangle from Point and Size
        Dim rect1 As New Rectangle(pt, sz)
        ' Create a Rectangel from integers
        Dim rect2 As New Rectangle(x, y, width, height)
        ' Create a Rectangle from direct integers
        Dim rect3 As New Rectangle(10, 10, 180, 180)
        ' Create pens and brushes
        Dim redPen As New Pen(Color.Red, 2)
        Dim greenBrush As New SolidBrush(Color.Blue)
        Dim blueBrush As New SolidBrush(Color.Green)
        ' Draw and fill rectangles
        g.DrawRectangle(redPen, rect3)
        g.FillRectangle(blueBrush, rect2)
        g.FillRectangle(greenBrush, rect1)
        ' Dispose
        redPen.Dispose()
        blueBrush.Dispose()
        greenBrush.Dispose()
        g.Dispose()
    End Sub

    Private Sub RectProperties_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RectProperties.Click
        ' Create Point, Size, and Rectangle
        Dim pt As New Point(10, 10)
        Dim sz As New Size(60, 40)
        Dim rect1 As Rectangle = Rectangle.Empty
        Dim rect2 As New Rectangle(20, 30, 30, 10)
        ' Set Rectangle properties
        If rect1.IsEmpty Then
            rect1.Location = pt
            rect1.Width = sz.Width
            rect1.Height = sz.Height
        End If
        ' Get Rectangle properties
        Dim str As String = "Location:" + rect1.Location.ToString()
        str += ", X:" + rect1.X.ToString()
        str += ", Y:" + rect1.Y.ToString()
        str += ", Left:" + rect1.Left.ToString()
        str += ", Right" + rect1.Right.ToString()
        str += ", Top:" + rect1.Top.ToString()
        str += ", Bottom:" + rect1.Bottom.ToString()
        MessageBox.Show(str)
    End Sub

    Private Sub RectMethods_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RectMethods.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        ' Create PointF, SizeF and RectangleF
        Dim pt As New PointF(30.8F, 20.7F)
        Dim sz As New SizeF(60.0F, 40.0F)
        Dim rect2 As New RectangleF(40.2F, 40.6F, 100.5F, 100.0F)
        Dim rect1 As New RectangleF(pt, sz)
        Dim rect3 As Rectangle = Rectangle.Ceiling(rect1)
        Dim rect4 As Rectangle = Rectangle.Truncate(rect1)
        Dim rect5 As Rectangle = Rectangle.Round(rect2)
        ' Draw rectangles
        g.DrawRectangle(Pens.Black, rect3)
        g.DrawRectangle(Pens.Red, rect5)
        ' Intersect rectangles
        Dim isectRect As Rectangle = Rectangle.Intersect(rect3, rect5)
        ' Fill new rectangle
        g.FillRectangle(New SolidBrush(Color.Blue), isectRect)
        ' Create a Size
        Dim inflateSize As New Size(0, 40)
        ' Inflate rectangle
        isectRect.Inflate(inflateSize)
        ' Draw new rectangle
        g.DrawRectangle(Pens.Blue, isectRect)
        ' Set Rectangle properties
        rect4 = Rectangle.Empty
        rect4.Location = New Point(50, 50)
        rect4.X = 30
        rect4.Y = 40
        ' Union two rectangles
        Dim unionRect As Rectangle = Rectangle.Union(rect4, rect5)
        ' Draw new rectangle
        g.DrawRectangle(Pens.Green, unionRect)
        ' Create a Graphics object
        g.Dispose()
    End Sub

    Private Sub RectFCreate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RectFCreate.Click
        Dim g As Graphics = Me.CreateGraphics()
        Dim x As Single = 40.0F
        Dim y As Single = 40.0F
        Dim height As Single = 120.0F
        Dim width As Single = 120.0F
        ' Create a Point
        Dim pt As New PointF(80.0F, 80.0F)
        ' Create a Size
        Dim sz As New SizeF(100.0F, 100.0F)
        ' Create a Rectangle from Point and Size
        Dim rect1 As New RectangleF(pt, sz)
        ' Create a Rectangel from integers
        Dim rect2 As New RectangleF(x, y, width, height)
        ' Create a Rectangle from direct integers
        Dim rect3 As New RectangleF(10.0F, 10.0F, 180.0F, 180.0F)
        ' Create pens and brushes
        Dim redPen As New Pen(Color.Red, 2)
        Dim greenBrush As New SolidBrush(Color.Blue)
        Dim blueBrush As New SolidBrush(Color.Green)
        ' Draw and fill rectangles
        g.DrawRectangle(redPen, rect3.X, rect3.Y, rect3.Width, rect3.Height)
        g.FillRectangle(blueBrush, rect2)
        g.FillRectangle(greenBrush, rect1)
        ' Dispose
        redPen.Dispose()
        blueBrush.Dispose()
        greenBrush.Dispose()
        g.Dispose()
    End Sub
End Class

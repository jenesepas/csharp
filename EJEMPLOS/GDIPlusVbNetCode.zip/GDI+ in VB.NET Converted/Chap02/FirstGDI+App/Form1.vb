Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(456, 293)
        Me.Name = "Form1"
        Me.Text = "My First GDI+ Application"

    End Sub

#End Region

    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        Dim g As Graphics = e.Graphics
        ' Set the composit quality and smooting mode
        ' of the surface
        g.CompositingQuality = CompositingQuality.HighQuality
        g.SmoothingMode = SmoothingMode.AntiAlias
        ' Create a rectangle from point (20, 20) to (100, 100)
        Dim rect As New Rectangle(20, 20, 100, 100)
        ' Create two Pen objects with Red and Green color
        Dim redPen As New Pen(Color.Red, 3)
        Dim blackPen As Pen = Pens.Black
        ' Create a SolidBrush objects 
        Dim greenBrush As New SolidBrush(Color.Green)
        ' Draw shapes and lines
        g.DrawRectangle(redPen, rect)
        g.FillEllipse(greenBrush, rect)
        g.DrawLine(blackPen, 0, 250, Me.Width, 250)
        g.FillEllipse(Brushes.Blue, 70, 220, 30, 30)
        g.FillEllipse(Brushes.SkyBlue, 100, 210, 40, 40)
        g.FillEllipse(Brushes.Green, 140, 200, 50, 50)
        g.FillEllipse(Brushes.Yellow, 190, 190, 60, 60)
        g.FillEllipse(Brushes.Violet, 250, 180, 70, 70)
        g.FillEllipse(Brushes.Red, 320, 170, 80, 80)
        ' Dispose objects
        greenBrush.Dispose()
        ' blackPen.Dispose();
        redPen.Dispose()
        g.Dispose()
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class

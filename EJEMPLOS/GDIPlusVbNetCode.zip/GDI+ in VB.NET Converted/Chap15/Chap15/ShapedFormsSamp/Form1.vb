Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents pictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents button1 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.pictureBox1 = New System.Windows.Forms.PictureBox
        Me.button1 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'pictureBox1
        '
        Me.pictureBox1.Location = New System.Drawing.Point(108, 98)
        Me.pictureBox1.Name = "pictureBox1"
        Me.pictureBox1.Size = New System.Drawing.Size(176, 160)
        Me.pictureBox1.TabIndex = 3
        Me.pictureBox1.TabStop = False
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(124, 42)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(112, 32)
        Me.button1.TabIndex = 2
        Me.button1.Text = "Exit"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(392, 301)
        Me.Controls.Add(Me.pictureBox1)
        Me.Controls.Add(Me.button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub pictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles pictureBox1.Click

    End Sub
    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        Me.Close()
    End Sub

    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        ' Create a rectangle
        Dim rect As New Rectangle(0, 0, 100, 100)
        ' Create a graphics path 
        Dim path As New GraphicsPath
        ' Add an ellipse to graphics path
        path.AddEllipse(rect)
        ' Set region property of PictureBox
        ' by creating a Region from path
        pictureBox1.Region = New [Region](path)
        rect.Height += 200
        rect.Width += 200
        path.Reset()
        path.AddEllipse(rect)
        Me.Region = New [Region](path)
        ' Create an Image from file and
        ' set PictureBox's Image property
        Dim bmp As Image = Bitmap.FromFile("Neel02.jpg")
        pictureBox1.Image = bmp
    End Sub
End Class

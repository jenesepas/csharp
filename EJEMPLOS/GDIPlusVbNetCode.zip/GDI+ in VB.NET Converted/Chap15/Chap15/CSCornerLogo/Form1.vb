Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D
Imports System.Drawing.Imaging
Imports System.Drawing.Text
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.HighlightText
        Me.ClientSize = New System.Drawing.Size(472, 357)
        Me.Name = "Form1"
        Me.Text = "C# Corner Information Center"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        ' Create a pen and font
        Dim g As Graphics = e.Graphics
        Dim blackPen As New Pen(Color.Black, 2)
        Dim verdanaFont As New Font("Verdana", 60, FontStyle.Bold)
        ' Create points that define polygon.
        Dim curvePoints1 As Point() = {New Point(200, 15), New Point(200, 200), New Point(375, 250)}
        Dim curvePoints2 As Point() = {New Point(0, 250), New Point(200, 200), New Point(375, 250)}
        Dim curvePoints3 As Point() = {New Point(200, 15), New Point(200, 200), New Point(0, 250)}
        ' Create linear gradient brushes
        Dim pt1 As New Point(10, 10)
        Dim pt2 As New Point(30, 30)
        Dim lgBrush1 As New LinearGradientBrush(pt1, pt2, Color.Red, Color.Blue)
        Dim lgBrush2 As New LinearGradientBrush(pt1, pt2, Color.Red, Color.Green)
        Dim lgBrush3 As New LinearGradientBrush(pt1, pt2, Color.Blue, Color.Green)
        ' If you want to draw three lines
        'e.Graphics.DrawLine(blackPen, 200, 55, 200, 200);
        'e.Graphics.DrawLine(blackPen, 50, 250, 200, 200);
        'e.Graphics.DrawLine(blackPen, 345, 260, 200, 200);			
        ' Set quality of text and shape
        g.TextRenderingHint = TextRenderingHint.AntiAlias
        g.SmoothingMode = SmoothingMode.AntiAlias
        ' Draw three polygons and string
        e.Graphics.FillPolygon(New SolidBrush(Color.FromArgb(80, 255, 0, 0)), curvePoints1)
        e.Graphics.FillPolygon(New SolidBrush(Color.FromArgb(80, 0, 255, 0)), curvePoints2)
        e.Graphics.FillPolygon(New SolidBrush(Color.FromArgb(80, 0, 0, 255)), curvePoints3)
        ' Draw C# using the DrawString method 
        ' Starting @ point 140, 150
        g.DrawString("C#", verdanaFont, lgBrush1, New PointF(140, 150))
        ' Dispose Graphocs
        g.Dispose()
    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents panel1 As System.Windows.Forms.Panel
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents btnBrowse As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.panel1 = New System.Windows.Forms.Panel
        Me.textBox1 = New System.Windows.Forms.TextBox
        Me.button1 = New System.Windows.Forms.Button
        Me.btnBrowse = New System.Windows.Forms.Button
        Me.btnClose = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'panel1
        '
        Me.panel1.Location = New System.Drawing.Point(228, 6)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(136, 112)
        Me.panel1.TabIndex = 9
        '
        'textBox1
        '
        Me.textBox1.Location = New System.Drawing.Point(12, 38)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(168, 20)
        Me.textBox1.TabIndex = 8
        Me.textBox1.Text = ""
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(12, 126)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(352, 232)
        Me.button1.TabIndex = 7
        '
        'btnBrowse
        '
        Me.btnBrowse.Location = New System.Drawing.Point(100, 6)
        Me.btnBrowse.Name = "btnBrowse"
        Me.btnBrowse.TabIndex = 6
        Me.btnBrowse.Text = "Browse"
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(12, 6)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.TabIndex = 5
        Me.btnClose.Text = "Close"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.Desktop
        Me.ClientSize = New System.Drawing.Size(376, 365)
        Me.Controls.Add(Me.panel1)
        Me.Controls.Add(Me.textBox1)
        Me.Controls.Add(Me.button1)
        Me.Controls.Add(Me.btnBrowse)
        Me.Controls.Add(Me.btnClose)
        Me.Name = "Form1"
        Me.Text = "ButtonViewer"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnBrowse_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBrowse.Click
        Dim fdlg As New OpenFileDialog
        fdlg.Title = "C# Corner Open File Dialog"
        fdlg.InitialDirectory = ""
        fdlg.Filter = "Image Files(*.BMP;*.JPG;*.GIF)|" + "*.BMP;*.JPG;*.GIF|All files (*.*)|*.*" '

        fdlg.FilterIndex = 2
        fdlg.RestoreDirectory = True
        If fdlg.ShowDialog() = DialogResult.OK Then
            button1.BackgroundImage = Image.FromFile(fdlg.FileName)
            textBox1.Text = fdlg.FileName
        End If
        Invalidate()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Button 1
        button1.ForeColor = Color.Yellow
        button1.BackColor = Color.Maroon
        button1.FlatStyle = FlatStyle.Flat
        button1.Font = New Font("Verdana", 10, FontStyle.Bold)
        ' Close and Browse buttons
        btnClose.ForeColor = Color.Yellow
        btnClose.BackColor = Color.Black
        btnClose.FlatStyle = FlatStyle.Flat
        btnClose.Font = New Font("Ariel", 10, FontStyle.Italic)
        btnBrowse.ForeColor = Color.White
        btnBrowse.BackColor = Color.Black
        btnBrowse.FlatStyle = FlatStyle.Flat
        btnBrowse.Font = New Font("Ariel", 10, FontStyle.Bold)
        ' Text Box 1
        textBox1.BorderStyle = BorderStyle.FixedSingle
        textBox1.BackColor = Color.Blue
        textBox1.ForeColor = Color.Yellow
        textBox1.Font = New Font("Tahoma", 10, FontStyle.Strikeout Or FontStyle.Bold Or FontStyle.Italic)
        ' Panel 1
        panel1.BorderStyle = BorderStyle.FixedSingle
        panel1.BackColor = Color.Red
        ' Code for transparent controls 
        Me.SetStyle(ControlStyles.SupportsTransparentBackColor, True)
        button1.BackColor = Color.Transparent
        btnBrowse.BackColor = Color.Transparent
        btnClose.BackColor = Color.Transparent
        panel1.BackColor = Color.FromArgb(70, 0, 0, 255)

    End Sub
End Class

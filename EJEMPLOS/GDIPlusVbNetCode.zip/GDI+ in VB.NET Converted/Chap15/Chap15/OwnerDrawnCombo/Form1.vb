Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Public Class Form1
    Inherits System.Windows.Forms.Form
    'Private comboBox1 As OwnerComboBox

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()


        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    'Friend WithEvents ComboBox1 As OwnerComboBox
    Friend WithEvents ComboBox1 As OwnerComboBox

    Private Sub InitializeComponent()

        Me.ComboBox1 = New OwnerComboBox
        Me.SuspendLayout()
        '
        'ComboBox1
        '
        Me.ComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ComboBox1.Location = New System.Drawing.Point(72, 112)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(121, 21)
        Me.ComboBox1.TabIndex = 0
        Me.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox1.ItemHeight = 20
        Me.ComboBox1.Items.AddRange(New Object() {System.Drawing.Color.Blue, System.Drawing.Color.Red, System.Drawing.Color.Green, System.Drawing.Color.Aqua, System.Drawing.Color.Pink, System.Drawing.Color.Lavender})
        Me.ComboBox1.Location = New System.Drawing.Point(80, 100)

        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 273)
        Me.Controls.Add(Me.ComboBox1)
        Me.Name = "Form1"
        Me.Text = "Owner Drawn ComboBox"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
Public Class OwnerComboBox
    Inherits System.Windows.Forms.ComboBox
    Private oldSelectedRect As Rectangle
    Private oldSelectedIndex As Integer = -1


    Public Sub OwnerComboBox()
        InitializeComponent()
    End Sub 'New

    Public Sub DrawComboItem(ByVal sender As Object, ByVal e As System.Windows.Forms.DrawItemEventArgs)
        '            If (oldSelectedRect.X <> e.Bounds.X Or oldSelectedRect.Y <> e.Bounds.Y Or oldSelectedRect.Width <> e.Bounds.Width Or oldSelectedRect.Height <> e.Bounds.Height) And oldSelectedIndex > -1 And oldSelectedIndex < Items.Count Then
        If (oldSelectedRect.X <> e.Bounds.X Or oldSelectedRect.Y <> e.Bounds.Y Or oldSelectedRect.Width <> e.Bounds.Width Or oldSelectedRect.Height <> e.Bounds.Height) And oldSelectedIndex > -1 And oldSelectedIndex < Items.Count Then
            If oldSelectedRect.Y <> 3 Then '!=3 is hack to handle a drawing anomally
                e.Graphics.DrawRectangle(New Pen(CType(Items(oldSelectedIndex), Color), 1), oldSelectedRect)
            End If
        End If
        If e.Index > -1 And e.Index < Items.Count Then
            e.Graphics.FillRectangle(New SolidBrush(CType(Items(e.Index), Color)), e.Bounds)
        End If
        If SelectedIndex = e.Index Then
            e.Graphics.DrawRectangle(New Pen(Color.Black, 1), e.Bounds)
            oldSelectedRect = e.Bounds
            oldSelectedIndex = e.Index
        End If
    End Sub 'DrawComboItem

    Public Sub ComboDropDown(ByVal sender As Object, ByVal e As System.EventArgs)
        oldSelectedIndex = -1
        oldSelectedRect.Width = 0
    End Sub 'ComboDropDown

    Private Sub InitializeComponent()
        oldSelectedRect.X = -1
        oldSelectedRect.Y = -1
        oldSelectedRect.Width = 0
        oldSelectedRect.Height = 0

        Me.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.DropDownStyle = ComboBoxStyle.DropDownList
        Me.ItemHeight = 20
        Items.AddRange(New Object() {Color.Blue, Color.Red, Color.Green, Color.Aqua, Color.Pink, Color.Lavender})

        Location = New System.Drawing.Point(80, 100)
        Name = "comboBox1"
        Size = New System.Drawing.Size(121, 21)
        TabIndex = 1
        Me.SelectedIndex = 2
        AddHandler Me.DrawItem, AddressOf DrawComboItem
    End Sub 'InitializeComponent




End Class

Imports System
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.Windows.Forms

Public Class Form1
    Inherits System.Windows.Forms.Form
    Dim origImage As Image

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents pictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents groupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents button1 As System.Windows.Forms.Button
    Friend WithEvents fileDlg As System.Windows.Forms.OpenFileDialog
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.menuItem2 = New System.Windows.Forms.MenuItem
        Me.pictureBox1 = New System.Windows.Forms.PictureBox
        Me.groupBox1 = New System.Windows.Forms.GroupBox
        Me.button1 = New System.Windows.Forms.Button
        Me.fileDlg = New System.Windows.Forms.OpenFileDialog
        Me.groupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem2})
        Me.menuItem1.Text = "File"
        '
        'menuItem2
        '
        Me.menuItem2.Index = 0
        Me.menuItem2.Text = "Open"
        '
        'pictureBox1
        '
        Me.pictureBox1.Location = New System.Drawing.Point(160, 47)
        Me.pictureBox1.Name = "pictureBox1"
        Me.pictureBox1.Size = New System.Drawing.Size(100, 100)
        Me.pictureBox1.TabIndex = 2
        Me.pictureBox1.TabStop = False
        '
        'groupBox1
        '
        Me.groupBox1.Controls.Add(Me.button1)
        Me.groupBox1.Location = New System.Drawing.Point(8, 31)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(264, 128)
        Me.groupBox1.TabIndex = 3
        Me.groupBox1.TabStop = False
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(8, 16)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(128, 32)
        Me.button1.TabIndex = 0
        Me.button1.Text = "Add Copyright"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(280, 190)
        Me.Controls.Add(Me.pictureBox1)
        Me.Controls.Add(Me.groupBox1)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Graphics Copyright"
        Me.groupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub menuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuItem2.Click
        Dim fileDlg As New OpenFileDialog   '
        fileDlg.InitialDirectory = "c:\"
        fileDlg.Filter = "All files (*.*)|*.*"
        fileDlg.FilterIndex = 2
        fileDlg.RestoreDirectory = True
        If fileDlg.ShowDialog() = DialogResult.OK Then
            ' Create image from file
            Dim fileName As String = fileDlg.FileName.ToString()
            origImage = Image.FromFile(fileName)
            ' Create a thumbnail image
            Dim thumbNail As Image = origImage.GetThumbnailImage(100, 100, Nothing, New IntPtr)
            'View in PictureBox
            pictureBox1.Image = thumbNail
        End If
    End Sub

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        If origImage Is Nothing Then
            MessageBox.Show("Open a file")
            Return
        End If
        Dim imgWidth As Integer
        Dim imgHeight As Integer
        Dim fntSize As Integer = 300
        Dim x, y As Integer
        Dim a, re, gr, bl, x1, y1, z1 As Integer
        Dim size As Integer
        Dim pattern As Bitmap
        Dim sizeofstring As SizeF
        Dim foundfont As Boolean
        imgWidth = origImage.Width
        imgHeight = origImage.Height
        size = imgWidth * imgHeight
        pattern = New Bitmap(imgWidth, imgHeight)
        Dim temp As New Bitmap(origImage)
        Dim g As Graphics = Graphics.FromImage(pattern)
        Dim tempg As Graphics = Graphics.FromImage(origImage)
        'find a font size that will fit in the bitmap
        foundfont = False
        g.Clear(Color.White)
        While foundfont = False
            Dim fc As New Font("Georgia", fntSize, System.Drawing.FontStyle.Bold)
            sizeofstring = New SizeF(imgWidth, imgHeight)
            sizeofstring = g.MeasureString("Add Copyright Info", fc)
            If sizeofstring.Width < pattern.Width Then
                If sizeofstring.Height < pattern.Height Then
                    foundfont = True
                    g.DrawString("Add Copyright Info", fc, New SolidBrush(Color.Black), 1, 15)
                End If
            Else
                fntSize = fntSize - 1
            End If
        End While
        MessageBox.Show("Creating new graphic", "GraphicsCopyright")
        For x = 1 To pattern.Width - 1
            For y = 1 To pattern.Height - 1 '
                If pattern.GetPixel(x, y).ToArgb() = Color.Black.ToArgb() Then
                    a = temp.GetPixel(x, y).A
                    re = temp.GetPixel(x, y).R
                    gr = temp.GetPixel(x, y).G
                    bl = temp.GetPixel(x, y).B

                    x1 = re
                    y1 = gr
                    z1 = bl

                    If bl + 25 < 255 Then
                        bl = bl + 25
                    End If
                    If gr + 25 < 255 Then
                        gr = gr + 25
                    End If
                    If re + 25 < 255 Then
                        re = re + 25
                    End If
                    If x1 - 25 > 0 Then
                        x1 = x1 - 25
                    End If
                    If y1 - 25 > 0 Then
                        y1 = y1 - 25
                    End If
                    If z1 - 25 > 0 Then
                        z1 = z1 - 25
                    End If
                    tempg.DrawEllipse(New Pen(New SolidBrush(Color.Black)), x, y + 1, 3, 3)
                    tempg.DrawEllipse(New Pen(New SolidBrush(Color.FromArgb(a, x1, y1, z1))), x, y, 1, 1)
                End If
            Next y
        Next x
        MessageBox.Show("Output file is output.jpeg", "GraphicsCopyright")
        tempg.Save()
        origImage.Save("output.jpeg", ImageFormat.Jpeg)

    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Public Class Form1
    Inherits System.Windows.Forms.Form
    Private imgArray(5) As Image
    Private textArray(5) As String

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()
        textArray = New String() {"Black Item", "Blue Item", "Red Item", "Green Item", "Yellow Item"}

        imgArray = New Image() {Image.FromFile("Img1.jpg"), Image.FromFile("Img2.jpg"), Image.FromFile("Img3.jpg"), Image.FromFile("Img4.jpg"), Image.FromFile("Img5.jpg")}

        ' Bind text array to ListBox
        listBox1.DataSource = textArray

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents listBox1 As System.Windows.Forms.ListBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.listBox1 = New System.Windows.Forms.ListBox
        Me.SuspendLayout()
        '
        'listBox1
        '
        Me.listBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable
        Me.listBox1.Location = New System.Drawing.Point(4, 6)
        Me.listBox1.Name = "listBox1"
        Me.listBox1.Size = New System.Drawing.Size(328, 440)
        Me.listBox1.TabIndex = 1
        AddHandler Me.listBox1.MeasureItem, AddressOf ListBoxMeasureItem
        AddHandler Me.listBox1.DrawItem, AddressOf ListBoxDrawItem
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(336, 453)
        Me.Controls.Add(Me.listBox1)
        Me.Name = "Form1"
        Me.Text = "Owner Draw Image ListBox"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub listBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles listBox1.SelectedIndexChanged

    End Sub

    Private Sub ListBoxDrawItem(ByVal sender As Object, ByVal e As DrawItemEventArgs)
        Dim curImgSize As SizeF = imgArray(e.Index).PhysicalDimension
        e.Graphics.DrawImage(imgArray(e.Index), e.Bounds.X + 5, (e.Bounds.Bottom + e.Bounds.Top) \ 2 - curImgSize.Height \ 2)
    End Sub 'ListBoxDrawItem


    Private Sub ListBoxMeasureItem(ByVal sender As Object, ByVal e As MeasureItemEventArgs)
        e.ItemHeight = 150
    End Sub 'ListBoxMeasureItem
End Class

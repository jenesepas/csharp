Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Public Class Form1
    Inherits System.Windows.Forms.Form
    Private rect As New Rectangle(250, 150, 200, 200)
    Public sliceList As New ArrayList

    Structure sliceData
        Public share As Integer
        Public clr As Color
    End Structure 'sliceData

    Private curClr As Color = Color.Black
    Dim shareTotal As Integer = 0
    ' Private label1 As System.Windows.Forms.Label


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents FillChart As System.Windows.Forms.Button
    Friend WithEvents listBox1 As System.Windows.Forms.ListBox
    Friend WithEvents ColorBtn As System.Windows.Forms.Button
    Friend WithEvents AddSliceBtn As System.Windows.Forms.Button
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    Friend WithEvents DraPie As System.Windows.Forms.Button
    Friend WithEvents ColorDialog1 As System.Windows.Forms.ColorDialog
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.FillChart = New System.Windows.Forms.Button
        Me.listBox1 = New System.Windows.Forms.ListBox
        Me.ColorBtn = New System.Windows.Forms.Button
        Me.AddSliceBtn = New System.Windows.Forms.Button
        Me.textBox1 = New System.Windows.Forms.TextBox
        Me.DraPie = New System.Windows.Forms.Button
        Me.ColorDialog1 = New System.Windows.Forms.ColorDialog
        Me.SuspendLayout()
        '
        'FillChart
        '
        Me.FillChart.Location = New System.Drawing.Point(136, 326)
        Me.FillChart.Name = "FillChart"
        Me.FillChart.Size = New System.Drawing.Size(88, 32)
        Me.FillChart.TabIndex = 13
        Me.FillChart.Text = "Fill Chart"
        '
        'listBox1
        '
        Me.listBox1.Location = New System.Drawing.Point(16, 78)
        Me.listBox1.Name = "listBox1"
        Me.listBox1.Size = New System.Drawing.Size(224, 225)
        Me.listBox1.TabIndex = 12
        '
        'ColorBtn
        '
        Me.ColorBtn.BackColor = System.Drawing.Color.Blue
        Me.ColorBtn.ForeColor = System.Drawing.Color.Yellow
        Me.ColorBtn.Location = New System.Drawing.Point(96, 30)
        Me.ColorBtn.Name = "ColorBtn"
        Me.ColorBtn.Size = New System.Drawing.Size(88, 24)
        Me.ColorBtn.TabIndex = 11
        Me.ColorBtn.Text = "Select Color"
        '
        'AddSliceBtn
        '
        Me.AddSliceBtn.Location = New System.Drawing.Point(264, 30)
        Me.AddSliceBtn.Name = "AddSliceBtn"
        Me.AddSliceBtn.Size = New System.Drawing.Size(88, 24)
        Me.AddSliceBtn.TabIndex = 10
        Me.AddSliceBtn.Text = "Add Slice"
        '
        'textBox1
        '
        Me.textBox1.AutoSize = False
        Me.textBox1.Location = New System.Drawing.Point(16, 30)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(72, 24)
        Me.textBox1.TabIndex = 9
        Me.textBox1.Text = ""
        '
        'DraPie
        '
        Me.DraPie.Location = New System.Drawing.Point(24, 326)
        Me.DraPie.Name = "DraPie"
        Me.DraPie.Size = New System.Drawing.Size(88, 32)
        Me.DraPie.TabIndex = 8
        Me.DraPie.Text = "Draw Chart"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(496, 373)
        Me.Controls.Add(Me.FillChart)
        Me.Controls.Add(Me.listBox1)
        Me.Controls.Add(Me.ColorBtn)
        Me.Controls.Add(Me.AddSliceBtn)
        Me.Controls.Add(Me.textBox1)
        Me.Controls.Add(Me.DraPie)
        Me.Name = "Form1"
        Me.Text = "Pie Chart Application"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub AddSliceBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddSliceBtn.Click
        Dim slice As Integer = Convert.ToInt32(textBox1.Text)
        shareTotal += slice
        Dim dt As sliceData
        dt.clr = curClr
        dt.share = slice
        sliceList.Add(dt)
        listBox1.Items.Add(("Share:" + slice.ToString() + " ," + curClr.ToString()))
    End Sub

    Private Sub DraPie_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DraPie.Click
        DrawPieChart(False)
    End Sub

    Private Sub FillChart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FillChart.Click
        DrawPieChart(True)
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ColorBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ColorBtn.Click
        Dim clrDlg As New ColorDialog
        If clrDlg.ShowDialog() = DialogResult.OK Then
            curClr = clrDlg.Color
        End If
    End Sub

    Private Sub DrawPieChart(ByVal flMode As Boolean)
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim rect As New Rectangle(250, 150, 200, 200)
        Dim angle As Single = 0
        Dim sweep As Single = 0
        Dim dt As sliceData
        For Each dt In sliceList
            sweep = 360.0F * dt.share / shareTotal
            If flMode Then
                g.FillPie(New SolidBrush(dt.clr), rect, angle, sweep)
            Else
                g.DrawPie(New Pen(dt.clr), rect, angle, sweep)
            End If
            angle += sweep
        Next dt
        g.Dispose()
    End Sub 'DrawPieChart
End Class

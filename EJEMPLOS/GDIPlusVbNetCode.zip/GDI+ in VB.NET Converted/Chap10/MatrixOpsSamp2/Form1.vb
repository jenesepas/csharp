Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents saveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents Rotate As System.Windows.Forms.MenuItem
    Friend WithEvents RotateAtMenu As System.Windows.Forms.MenuItem
    Friend WithEvents ScaleMenu As System.Windows.Forms.MenuItem
    Friend WithEvents Shear As System.Windows.Forms.MenuItem
    Friend WithEvents Translate As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents InvertMenu As System.Windows.Forms.MenuItem
    Friend WithEvents MultiplyMenu As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.saveFileDialog1 = New System.Windows.Forms.SaveFileDialog
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.Rotate = New System.Windows.Forms.MenuItem
        Me.RotateAtMenu = New System.Windows.Forms.MenuItem
        Me.ScaleMenu = New System.Windows.Forms.MenuItem
        Me.Shear = New System.Windows.Forms.MenuItem
        Me.Translate = New System.Windows.Forms.MenuItem
        Me.menuItem2 = New System.Windows.Forms.MenuItem
        Me.InvertMenu = New System.Windows.Forms.MenuItem
        Me.MultiplyMenu = New System.Windows.Forms.MenuItem
        '
        'saveFileDialog1
        '
        Me.saveFileDialog1.FileName = "doc1"
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1, Me.menuItem2})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.Rotate, Me.RotateAtMenu, Me.ScaleMenu, Me.Shear, Me.Translate})
        Me.menuItem1.Text = "Matrix Operations"
        '
        'Rotate
        '
        Me.Rotate.Index = 0
        Me.Rotate.Text = "Rotate"
        '
        'RotateAtMenu
        '
        Me.RotateAtMenu.Index = 1
        Me.RotateAtMenu.Text = "RotateAt"
        '
        'ScaleMenu
        '
        Me.ScaleMenu.Index = 2
        Me.ScaleMenu.Text = "Scale"
        '
        'Shear
        '
        Me.Shear.Index = 3
        Me.Shear.Text = "Shear"
        '
        'Translate
        '
        Me.Translate.Index = 4
        Me.Translate.Text = "Translate"
        '
        'menuItem2
        '
        Me.menuItem2.Index = 1
        Me.menuItem2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.InvertMenu, Me.MultiplyMenu})
        Me.menuItem2.Text = "Matrix Class"
        '
        'InvertMenu
        '
        Me.InvertMenu.Index = 0
        Me.InvertMenu.Text = "Invert"
        '
        'MultiplyMenu
        '
        Me.MultiplyMenu.Index = 1
        Me.MultiplyMenu.Text = "Multiply"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(496, 326)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub Rotate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Rotate.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a Matrix object
        Dim X As New Matrix
        ' Rotate by 45 degrees
        X.Rotate(45, MatrixOrder.Append)
        ' Apply Matrix on the Graphics object
        ' that means all the graphics items 
        ' drawn on the Graphics object
        g.Transform = X
        ' Draw a line
        g.DrawLine(New Pen(Color.Green, 3), New Point(120, 50), New Point(200, 50))
        ' Fill a rectangle
        g.FillRectangle(Brushes.Blue, 200, 100, 100, 60)
        ' Dispose */
        g.Dispose()

    End Sub

    Private Sub RotateAtMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RotateAtMenu.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a Matrix object
        Dim X As New Matrix
        ' a point
        Dim pt As New PointF(180.0F, 50.0F)
        ' Rotate by 45 degrees
        X.RotateAt(45, pt, MatrixOrder.Append)
        ' Reset the Matrix
        X.Reset()
        ' Apply Matrix on the Graphics object
        ' that means all the graphics items 
        ' drawn on the Graphics object
        g.Transform = X
        ' Draw a line
        g.DrawLine(New Pen(Color.Green, 3), New Point(120, 50), New Point(200, 50))
        ' Fill a rectangle
        g.FillRectangle(Brushes.Blue, 200, 100, 100, 60)
        ' Dispose */
        g.Dispose()

    End Sub

    Private Sub ScaleMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ScaleMenu.Click
        ' Create Graphics
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Draw a filled rectangle with 
        ' height width 20 and height 30
        g.FillRectangle(Brushes.Blue, 20, 20, 20, 30)
        ' Create a Matrix object
        Dim X As New Matrix
        ' Apply 3 times scaling 
        X.Scale(3, 4, MatrixOrder.Append)
        ' Apply transformation on the form
        g.Transform = X
        ' Draw a filled rectangle with 
        ' widht = 20 and height = 30
        g.FillRectangle(Brushes.Blue, 20, 20, 20, 30)
        ' Dispose
        g.Dispose()
        '

    End Sub

    Private Sub Shear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Shear.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a Brush
        Dim hBrush As New HatchBrush(HatchStyle.DarkVertical, Color.Green, Color.Yellow)
        ' Fill a rectangle
        g.FillRectangle(hBrush, 100, 50, 100, 60)
        ' Create a Matrix object
        Dim X As New Matrix
        ' Shear
        X.Shear(2, 1)
        ' Apply transoformation
        g.Transform = X
        ' Fill rectangle
        g.FillRectangle(hBrush, 10, 100, 100, 60)
        ' Dispose
        hBrush.Dispose()
        g.Dispose()
        '

    End Sub

    Private Sub Translate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Translate.Click
        ' Create a Graphics obhect
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Draw a filled rectangle
        g.FillRectangle(Brushes.Blue, 50, 50, 100, 60)
        ' Create a Matrix
        Dim X As New Matrix
        ' Translate 100 in x and 100 in 
        ' y direction
        X.Translate(100, 100)
        ' Apply transformation
        g.Transform = X
        ' Draw a filled rectangle after 
        ' translation
        g.FillRectangle(Brushes.Blue, 50, 50, 100, 60)
        ' Dispose
        g.Dispose()
        '

    End Sub

    Private Sub InvertMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InvertMenu.Click
        Dim str As String = "Original values: "
        ' Create a Matrix object
        Dim X As New Matrix(2, 1, 3, 1, 0, 4)
        ' Write its values
        Dim i As Integer
        For i = 0 To X.Elements.Length - 1
            str += X.Elements(i).ToString()
            str += ", "
        Next i
        str += ControlChars.Lf
        str += "Inverted values: "
        ' Invert Matrix
        X.Invert()
        Dim pts As Single() = X.Elements
        ' Read inverted Matrix
        Dim i1 As Integer
        For i = 0 To pts.Length - 1
            str += pts(i).ToString()
            str += ", "
        Next i
        ' Display result
        MessageBox.Show(str)

    End Sub

    Private Sub MultiplyMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MultiplyMenu.Click
        Dim str As String = Nothing
        ' Create two Matrix objects
        Dim X As New Matrix(2.0F, 1.0F, 3.0F, 1.0F, 0.0F, 4.0F)
        Dim Y As New Matrix(0.0F, 1.0F, -1.0F, 0.0F, 0.0F, 0.0F)
        ' Multiply two Matrices
        X.Multiply(Y, MatrixOrder.Append)
        ' Read the result Matrix
        Dim i As Integer
        For i = 0 To X.Elements.Length - 1
            str += X.Elements(i).ToString()
            str += ", "
        Next i
        ' Display result
        MessageBox.Show(str)

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class

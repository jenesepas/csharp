Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Imaging
Imports System.Drawing.Drawing2D

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents RotationMenu As System.Windows.Forms.MenuItem
    Friend WithEvents ScalingMenu As System.Windows.Forms.MenuItem
    Friend WithEvents TranslationMenu As System.Windows.Forms.MenuItem
    Friend WithEvents ReflectionMenu As System.Windows.Forms.MenuItem
    Friend WithEvents ShearMenu As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.RotationMenu = New System.Windows.Forms.MenuItem
        Me.ScalingMenu = New System.Windows.Forms.MenuItem
        Me.TranslationMenu = New System.Windows.Forms.MenuItem
        Me.ReflectionMenu = New System.Windows.Forms.MenuItem
        Me.ShearMenu = New System.Windows.Forms.MenuItem
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.RotationMenu, Me.ScalingMenu, Me.TranslationMenu, Me.ReflectionMenu, Me.ShearMenu})
        Me.menuItem1.Text = "Image Transformation"
        '
        'RotationMenu
        '
        Me.RotationMenu.Index = 0
        Me.RotationMenu.Text = "Rotation"
        '
        'ScalingMenu
        '
        Me.ScalingMenu.Index = 1
        Me.ScalingMenu.Text = "Scaling"
        '
        'TranslationMenu
        '
        Me.TranslationMenu.Index = 2
        Me.TranslationMenu.Text = "Translation"
        '
        'ReflectionMenu
        '
        Me.ReflectionMenu.Index = 3
        Me.ReflectionMenu.Text = "Reflection"
        '
        'ShearMenu
        '
        Me.ShearMenu.Index = 4
        Me.ShearMenu.Text = "Shear"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(352, 314)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub RotationMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RotationMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim curBitmap As New Bitmap("roses.jpg") '
        g.DrawImage(curBitmap, 0, 0, 200, 200)
        ' Create a Matrix, call its Rotate method
        ' and set it as Graphics.Transform
        Dim X As New Matrix
        X.Rotate(30)
        g.Transform = X
        ' Draw Image
        g.DrawImage(curBitmap, New Rectangle(205, 0, 200, 200), 0, 0, curBitmap.Width, curBitmap.Height, GraphicsUnit.Pixel)
        ' Dispose
        curBitmap.Dispose()
        g.Dispose()

    End Sub

    Private Sub ScalingMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ScalingMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim curBitmap As New Bitmap("roses.jpg") '
        Dim X As New Matrix
        X.Scale(2, 1, MatrixOrder.Append)
        g.Transform = X
        g.DrawImage(curBitmap, New Rectangle(0, 0, 200, 200), 0, 0, curBitmap.Width, curBitmap.Height, GraphicsUnit.Pixel)
        ' Dispose
        curBitmap.Dispose()
        g.Dispose()

    End Sub

    Private Sub TranslationMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TranslationMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim curBitmap As New Bitmap("roses.jpg") '
        Dim X As New Matrix
        X.Translate(100, 100)
        g.Transform = X
        g.DrawImage(curBitmap, New Rectangle(0, 0, 200, 200), 0, 0, curBitmap.Width, curBitmap.Height, GraphicsUnit.Pixel)
        ' Dispose
        curBitmap.Dispose()
        g.Dispose()


    End Sub

    Private Sub ReflectionMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReflectionMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim curBitmap As New Bitmap("roses.jpg") '
        Dim X As New Matrix
        X.Invert()
        g.Transform = X
        g.DrawImage(curBitmap, New Rectangle(0, 0, 200, 200), 0, 0, curBitmap.Width, curBitmap.Height, GraphicsUnit.Pixel)
        ' Dispose
        curBitmap.Dispose()
        g.Dispose()

    End Sub

    Private Sub ShearMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ShearMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim curBitmap As New Bitmap("roses.jpg") '
        Dim X As New Matrix
        X.Shear(2, 1)
        g.Transform = X
        g.DrawImage(curBitmap, New Rectangle(0, 0, 200, 200), 0, 0, curBitmap.Width, curBitmap.Height, GraphicsUnit.Pixel)
        ' Dispose
        curBitmap.Dispose()
        g.Dispose()

    End Sub
End Class

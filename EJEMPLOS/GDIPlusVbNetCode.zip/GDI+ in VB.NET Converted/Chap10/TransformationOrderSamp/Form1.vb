Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MatrixOrderMenu As System.Windows.Forms.MenuItem
    Friend WithEvents First As System.Windows.Forms.MenuItem
    Friend WithEvents Second As System.Windows.Forms.MenuItem
    Friend WithEvents Third As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.MatrixOrderMenu = New System.Windows.Forms.MenuItem
        Me.First = New System.Windows.Forms.MenuItem
        Me.Second = New System.Windows.Forms.MenuItem
        Me.Third = New System.Windows.Forms.MenuItem
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MatrixOrderMenu})
        '
        'MatrixOrderMenu
        '
        Me.MatrixOrderMenu.Index = 0
        Me.MatrixOrderMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.First, Me.Second, Me.Third})
        Me.MatrixOrderMenu.Text = "MatrixOrder"
        '
        'First
        '
        Me.First.Index = 0
        Me.First.Text = "First"
        '
        'Second
        '
        Me.Second.Index = 1
        Me.Second.Text = "Second"
        '
        'Third
        '
        Me.Third.Index = 2
        Me.Third.Text = "Third"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(448, 334)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub First_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles First.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a Rectangle
        Dim rect As New Rectangle(20, 20, 100, 100)
        ' Create a solid brush
        Dim brush As New SolidBrush(Color.Red)
        ' Fill rectangle
        g.FillRectangle(brush, rect)
        ' Scale
        g.ScaleTransform(1.75F, 0.5F)
        ' Rotate
        g.RotateTransform(45.0F, MatrixOrder.Append)
        ' Translate
        g.TranslateTransform(150.0F, 50.0F, MatrixOrder.Append)
        ' Fill rectangle again
        g.FillRectangle(brush, rect)
        ' Dispose
        brush.Dispose()
        g.Dispose()

    End Sub

    Private Sub Second_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Second.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a Rectangle
        Dim rect As New Rectangle(20, 20, 100, 100)
        ' Create a solid brush
        Dim brush As New SolidBrush(Color.Red)
        ' Fill rectangle
        g.FillRectangle(brush, rect)
        ' Translate
        g.TranslateTransform(100.0F, 50.0F, MatrixOrder.Append)
        ' Scale
        g.ScaleTransform(1.75F, 0.5F)
        ' Rotate
        g.RotateTransform(45.0F, MatrixOrder.Append)
        ' Fill rectangle again
        g.FillRectangle(brush, rect)
        ' Dispose
        brush.Dispose()
        g.Dispose()

    End Sub

    Private Sub Third_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Third.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a Rectangle
        Dim rect As New Rectangle(20, 20, 100, 100)
        ' Create a solid brush
        Dim brush As New SolidBrush(Color.Red)
        ' Fill rectangle
        g.FillRectangle(brush, rect)
        ' Translate
        g.TranslateTransform(100.0F, 50.0F, MatrixOrder.Prepend)
        ' Rotate
        g.RotateTransform(45.0F, MatrixOrder.Prepend)
        ' Scale
        g.ScaleTransform(1.75F, 0.5F)
        ' Fill rectangle again
        g.FillRectangle(brush, rect)
        ' Dispose
        brush.Dispose()
        g.Dispose()
    End Sub
End Class

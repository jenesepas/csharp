Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ClientSize = New System.Drawing.Size(304, 273)
        Me.Name = "Form1"
        Me.Text = "GDI+ Coordinate System"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        Dim g As Graphics = e.Graphics
        g.TranslateTransform(50, 40)

        Dim vertFont As New Font("Verdana", 10, FontStyle.Regular)
        Dim horzFont As New Font("Verdana", 10, FontStyle.Regular)
        Dim blackBrush As New SolidBrush(Color.Black)
        Dim blackPen As New Pen(Color.Black, 1)
        Dim bluePen As New Pen(Color.Blue, 1)


        ' Page Coordinate ***** 
        'X axis drawing
        g.DrawString("200", horzFont, blackBrush, 200, 5)
        g.DrawString("100", horzFont, blackBrush, 100, 5)
        g.DrawString("X", horzFont, blackBrush, 250, 0)
        ' Drawing vertical strings
        Dim vertStrFormat As New StringFormat
        vertStrFormat.FormatFlags = StringFormatFlags.DirectionVertical
        'Y axis drawing
        g.DrawString("100", vertFont, blackBrush, 0, 100)
        g.DrawString("200", vertFont, blackBrush, 0, 200)
        g.DrawString("Y", vertFont, blackBrush, 0, 250)
        ' Drawing a vertical and a horizontal line
        g.DrawLine(blackPen, 0, 0, 0, 250)
        g.DrawLine(blackPen, 0, 0, 250, 0)

        Dim A As New Point(0, 0)
        Dim B As New Point(120, 80)
        g.DrawLine(Pens.Black, A, B)
    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Imaging
Imports System.Drawing.Drawing2D
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents TranslationMenu As System.Windows.Forms.MenuItem
    Friend WithEvents RotationMenu As System.Windows.Forms.MenuItem
    Friend WithEvents ScalingMenu As System.Windows.Forms.MenuItem
    Friend WithEvents ShearingMenu As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.TranslationMenu = New System.Windows.Forms.MenuItem
        Me.RotationMenu = New System.Windows.Forms.MenuItem
        Me.ScalingMenu = New System.Windows.Forms.MenuItem
        Me.ShearingMenu = New System.Windows.Forms.MenuItem
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.TranslationMenu, Me.RotationMenu, Me.ScalingMenu, Me.ShearingMenu})
        Me.menuItem1.Text = "Recoloring"
        '
        'TranslationMenu
        '
        Me.TranslationMenu.Index = 0
        Me.TranslationMenu.Text = "Translation"
        '
        'RotationMenu
        '
        Me.RotationMenu.Index = 1
        Me.RotationMenu.Text = "Rotation"
        '
        'ScalingMenu
        '
        Me.ScalingMenu.Index = 2
        Me.ScalingMenu.Text = "Scaling"
        '
        'ShearingMenu
        '
        Me.ShearingMenu.Index = 3
        Me.ShearingMenu.Text = "Shearing"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(416, 342)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub TranslationMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TranslationMenu.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a Bitmap
        Dim curBitmap As New Bitmap("roses.jpg")
        ' ColorMatrix elements
        Dim ptsArray As Single()() = {New Single() {1, 0, 0, 0, 0}, New Single() {0, 1, 0, 0, 0}, New Single() {0, 0, 1, 0, 0}, New Single() {0, 0, 0, 1, 0}, New Single() {0.9F, 0.0F, 0.0F, 0.0F, 1}}
        ' Create a ColorMatrix
        Dim clrMatrix As New ColorMatrix(ptsArray)
        ' Create ImageAttributes
        Dim imgAttribs As New ImageAttributes
        ' Set color matrix
        imgAttribs.SetColorMatrix(clrMatrix, ColorMatrixFlag.Default, ColorAdjustType.Default)
        ' Draw image with no affects
        g.DrawImage(curBitmap, 0, 0, 200, 200)
        ' Draw image with ImageAttributes
        g.DrawImage(curBitmap, New Rectangle(205, 0, 200, 200), 0, 0, curBitmap.Width, curBitmap.Height, GraphicsUnit.Pixel, imgAttribs)
        ' Dispose
        curBitmap.Dispose()
        g.Dispose()
    End Sub

    Private Sub RotationMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RotationMenu.Click
        Dim degrees As Single = 45.0F
        Dim r As Double = degrees * System.Math.PI / 180

        ' Create a Graphics object	
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a Bitmap from a file
        Dim curBitmap As New Bitmap("roses.jpg")

        ' ColorMatrix elements
        Dim ptsArray As Single()() = {New Single() {CSng(System.Math.Cos(r)), CSng(System.Math.Sin(r)), 0, 0, 0}, New Single() {CSng(-System.Math.Sin(r)), CSng(-System.Math.Cos(r)), 0, 0, 0}, New Single() {0.5F, 0, 1, 0, 0}, New Single() {0, 0, 0, 1, 0}, New Single() {0, 0, 0, 0, 1}}
        ' Create a ColorMatrix
        Dim clrMatrix As New ColorMatrix(ptsArray)
        ' Create ImageAttributes
        Dim imgAttribs As New ImageAttributes
        ' Set ColorMatrix to ImageAttributes
        imgAttribs.SetColorMatrix(clrMatrix, ColorMatrixFlag.Default, ColorAdjustType.Default)
        ' Draw image with no affects
        g.DrawImage(curBitmap, 0, 0, 200, 200)
        ' Draw image with ImageAttributes
        g.DrawImage(curBitmap, New Rectangle(205, 0, 200, 200), 0, 0, curBitmap.Width, curBitmap.Height, GraphicsUnit.Pixel, imgAttribs)
        ' Dispose
        curBitmap.Dispose()
        g.Dispose()

    End Sub

    Private Sub ScalingMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ScalingMenu.Click
        ' Create a Graphics
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a Bitmap
        Dim curBitmap As New Bitmap("roses.jpg")
        ' ColorMatrix elements
        Dim ptsArray As Single()() = {New Single() {1, 0, 0, 0, 0}, New Single() {0, 0.8F, 0, 0, 0}, New Single() {0, 0, 0.5F, 0, 0}, New Single() {0, 0, 0, 0.5F, 0}, New Single() {0, 0, 0, 0, 1}}
        ' Create a ColorMatrix
        Dim clrMatrix As New ColorMatrix(ptsArray)
        ' Create ImageAttributes
        Dim imgAttribs As New ImageAttributes
        ' Set color matrix
        imgAttribs.SetColorMatrix(clrMatrix, ColorMatrixFlag.Default, ColorAdjustType.Default)
        ' Draw an image with no affects
        g.DrawImage(curBitmap, 0, 0, 200, 200)
        ' Draw Image with image attributes
        g.DrawImage(curBitmap, New Rectangle(205, 0, 200, 200), 0, 0, curBitmap.Width, curBitmap.Height, GraphicsUnit.Pixel, imgAttribs)
        ' Dispose
        curBitmap.Dispose()
        g.Dispose()

    End Sub

    Private Sub ShearingMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ShearingMenu.Click
        ' Create a Graphics
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a Bitmap
        Dim curBitmap As New Bitmap("roses.jpg")
        ' ColorMatrix elements
        Dim ptsArray As Single()() = {New Single() {1, 0, 0, 0, 0}, New Single() {0, 1, 0, 0, 0}, New Single() {0.5F, 0, 1, 0, 0}, New Single() {0, 0, 0, 1, 0}, New Single() {0, 0, 0, 0, 1}}
        ' Create ColorMatrix
        Dim clrMatrix As New ColorMatrix(ptsArray)
        ' Create ImageAttributes
        Dim imgAttribs As New ImageAttributes
        ' Set color matrix
        imgAttribs.SetColorMatrix(clrMatrix, ColorMatrixFlag.Default, ColorAdjustType.Default)
        ' Draw Image with no effects
        g.DrawImage(curBitmap, 0, 0, 200, 200)
        ' Draw Image with image attributes
        g.DrawImage(curBitmap, New Rectangle(205, 0, 200, 200), 0, 0, curBitmap.Width, curBitmap.Height, GraphicsUnit.Pixel, imgAttribs)
        ' Dispose
        curBitmap.Dispose()
        g.Dispose()

    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D
Imports System.Drawing.Imaging
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents GlobalTransformation As System.Windows.Forms.MenuItem
    Friend WithEvents LocalTransformation As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.GlobalTransformation = New System.Windows.Forms.MenuItem
        Me.LocalTransformation = New System.Windows.Forms.MenuItem
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.GlobalTransformation, Me.LocalTransformation})
        Me.menuItem1.Text = "Transformation Types"
        '
        'GlobalTransformation
        '
        Me.GlobalTransformation.Index = 0
        Me.GlobalTransformation.Text = "Global"
        '
        'LocalTransformation
        '
        Me.LocalTransformation.Index = 1
        Me.LocalTransformation.Text = "Local"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(440, 298)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub GlobalTransformation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GlobalTransformation.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a pen with blue color and width 2
        Dim bluePen As New Pen(Color.Blue, 2)
        Dim pt1 As New Point(10, 10)
        Dim pt2 As New Point(20, 20)
        Dim lnColors As Color() = {Color.Black, Color.Red}
        Dim rect1 As New Rectangle(10, 10, 15, 15)
        ' Create two linear gradient brushes
        Dim lgBrush1 As New LinearGradientBrush(rect1, Color.Blue, Color.Green, LinearGradientMode.BackwardDiagonal)
        Dim lgBrush As New LinearGradientBrush(pt1, pt2, Color.Red, Color.Green)
        ' Set linear colors
        lgBrush.LinearColors = lnColors
        ' Set gamma correction
        lgBrush.GammaCorrection = True
        ' Fill and draw rectangle and ellipses
        g.FillRectangle(lgBrush, 150, 0, 50, 100)
        g.DrawEllipse(bluePen, 0, 0, 100, 50)
        g.FillEllipse(lgBrush1, 300, 0, 100, 100)
        ' Scale transformation
        g.ScaleTransform(1, 0.5F)
        ' Translate transformation
        g.TranslateTransform(50, 0, MatrixOrder.Append)
        'Rotate
        g.RotateTransform(30.0F, MatrixOrder.Append)
        ' Fill ellipse
        g.FillEllipse(lgBrush1, 300, 0, 100, 100)
        ' Rotate again
        g.RotateTransform(15.0F, MatrixOrder.Append)
        ' Fill rectangle
        g.FillRectangle(lgBrush, 150, 0, 50, 100)
        ' Rotate again
        g.RotateTransform(15.0F, MatrixOrder.Append)
        ' Draw ellipse
        g.DrawEllipse(bluePen, 0, 0, 100, 50)
        ' Dispose
        lgBrush1.Dispose()
        lgBrush.Dispose()
        bluePen.Dispose()
        g.Dispose()
    End Sub

    Private Sub LocalTransformation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LocalTransformation.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a GraphicsPath 
        Dim path As New GraphicsPath
        ' Add an ellipse and a line to the 
        ' graphics path
        path.AddEllipse(50, 50, 100, 150)
        path.AddLine(20, 20, 200, 20)
        ' Create a pen with blue color and 
        ' width 2
        Dim bluePen As New Pen(Color.Blue, 2)
        ' Create a Matrix object
        Dim X As New Matrix
        ' Rotate with 30 degrees
        X.Rotate(30)
        ' Translate with 50 offset in x dir
        X.Translate(50.0F, 0)
        ' Apply transformation on the path
        path.Transform(X)
        ' Draw a rentalgle, line and the path
        g.DrawRectangle(Pens.Green, 200, 50, 100, 100)
        g.DrawLine(Pens.Green, 30, 20, 200, 20)
        g.DrawPath(bluePen, path)
        ' Dispose
        bluePen.Dispose()
        path.Dispose()
        g.Dispose()

    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data

Public Class Form1
    Inherits System.Windows.Forms.Form
    Private bmpImage As System.Drawing.Bitmap
    Private curZoom As Double = 1.0
    Private curRect As Rectangle
    Private originalSize As New Size(0, 0)
    Private mouseDownPt As New Point(0, 0)
    Private mouseUpPt As New Point(0, 0)
    Private zoomMode As Boolean = False

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents OpenFileMenu As System.Windows.Forms.MenuItem
    Friend WithEvents SaveFileMenu As System.Windows.Forms.MenuItem
    Friend WithEvents ExitMenu As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents FitWidthMenu As System.Windows.Forms.MenuItem
    Friend WithEvents FitHeightMenu As System.Windows.Forms.MenuItem
    Friend WithEvents FitOriginalMenu As System.Windows.Forms.MenuItem
    Friend WithEvents FitAllMenu As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents Rotate90Menu As System.Windows.Forms.MenuItem
    Friend WithEvents Rotate180Menu As System.Windows.Forms.MenuItem
    Friend WithEvents Rotate270Menu As System.Windows.Forms.MenuItem
    Friend WithEvents NoRotateMenu As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem7 As System.Windows.Forms.MenuItem
    Friend WithEvents FlipXMenu As System.Windows.Forms.MenuItem
    Friend WithEvents FlipYMenu As System.Windows.Forms.MenuItem
    Friend WithEvents FlipXY As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem8 As System.Windows.Forms.MenuItem
    Friend WithEvents Zoom25Menu As System.Windows.Forms.MenuItem
    Friend WithEvents Zoom50Menu As System.Windows.Forms.MenuItem
    Friend WithEvents Zoom100Menu As System.Windows.Forms.MenuItem
    Friend WithEvents Zoom200Menu As System.Windows.Forms.MenuItem
    Friend WithEvents Zoom500Menu As System.Windows.Forms.MenuItem
    Friend WithEvents BrightnessMenu As System.Windows.Forms.MenuItem
    Friend WithEvents ColorMenu As System.Windows.Forms.MenuItem
    Friend WithEvents ContrastMenu As System.Windows.Forms.MenuItem
    Friend WithEvents GammaMenu As System.Windows.Forms.MenuItem
    Friend WithEvents GreyMenu As System.Windows.Forms.MenuItem
    Friend WithEvents Invertmenu As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.OpenFileMenu = New System.Windows.Forms.MenuItem
        Me.SaveFileMenu = New System.Windows.Forms.MenuItem
        Me.ExitMenu = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.MenuItem5 = New System.Windows.Forms.MenuItem
        Me.FitWidthMenu = New System.Windows.Forms.MenuItem
        Me.FitHeightMenu = New System.Windows.Forms.MenuItem
        Me.FitOriginalMenu = New System.Windows.Forms.MenuItem
        Me.FitAllMenu = New System.Windows.Forms.MenuItem
        Me.MenuItem6 = New System.Windows.Forms.MenuItem
        Me.Rotate90Menu = New System.Windows.Forms.MenuItem
        Me.Rotate180Menu = New System.Windows.Forms.MenuItem
        Me.Rotate270Menu = New System.Windows.Forms.MenuItem
        Me.NoRotateMenu = New System.Windows.Forms.MenuItem
        Me.MenuItem7 = New System.Windows.Forms.MenuItem
        Me.FlipXMenu = New System.Windows.Forms.MenuItem
        Me.FlipYMenu = New System.Windows.Forms.MenuItem
        Me.FlipXY = New System.Windows.Forms.MenuItem
        Me.MenuItem8 = New System.Windows.Forms.MenuItem
        Me.Zoom25Menu = New System.Windows.Forms.MenuItem
        Me.Zoom50Menu = New System.Windows.Forms.MenuItem
        Me.Zoom100Menu = New System.Windows.Forms.MenuItem
        Me.Zoom200Menu = New System.Windows.Forms.MenuItem
        Me.Zoom500Menu = New System.Windows.Forms.MenuItem
        Me.MenuItem3 = New System.Windows.Forms.MenuItem
        Me.BrightnessMenu = New System.Windows.Forms.MenuItem
        Me.ColorMenu = New System.Windows.Forms.MenuItem
        Me.ContrastMenu = New System.Windows.Forms.MenuItem
        Me.GammaMenu = New System.Windows.Forms.MenuItem
        Me.GreyMenu = New System.Windows.Forms.MenuItem
        Me.Invertmenu = New System.Windows.Forms.MenuItem
        Me.MenuItem4 = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem2, Me.MenuItem3, Me.MenuItem4})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.OpenFileMenu, Me.SaveFileMenu, Me.ExitMenu})
        Me.MenuItem1.Text = "&File"
        '
        'OpenFileMenu
        '
        Me.OpenFileMenu.Index = 0
        Me.OpenFileMenu.Text = "&Open File"
        '
        'SaveFileMenu
        '
        Me.SaveFileMenu.Index = 1
        Me.SaveFileMenu.Text = "&Save File As"
        '
        'ExitMenu
        '
        Me.ExitMenu.Index = 2
        Me.ExitMenu.Text = "E&xit"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem5, Me.MenuItem6, Me.MenuItem7, Me.MenuItem8})
        Me.MenuItem2.Text = "&Options"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 0
        Me.MenuItem5.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FitWidthMenu, Me.FitHeightMenu, Me.FitOriginalMenu, Me.FitAllMenu})
        Me.MenuItem5.Text = "Fit"
        '
        'FitWidthMenu
        '
        Me.FitWidthMenu.Index = 0
        Me.FitWidthMenu.Text = "Fit Width"
        '
        'FitHeightMenu
        '
        Me.FitHeightMenu.Index = 1
        Me.FitHeightMenu.Text = "Fit Height"
        '
        'FitOriginalMenu
        '
        Me.FitOriginalMenu.Index = 2
        Me.FitOriginalMenu.Text = "Original"
        '
        'FitAllMenu
        '
        Me.FitAllMenu.Index = 3
        Me.FitAllMenu.Text = "Fit All"
        '
        'MenuItem6
        '
        Me.MenuItem6.Index = 1
        Me.MenuItem6.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.Rotate90Menu, Me.Rotate180Menu, Me.Rotate270Menu, Me.NoRotateMenu})
        Me.MenuItem6.Text = "Rotate"
        '
        'Rotate90Menu
        '
        Me.Rotate90Menu.Index = 0
        Me.Rotate90Menu.Text = "90"
        '
        'Rotate180Menu
        '
        Me.Rotate180Menu.Index = 1
        Me.Rotate180Menu.Text = "180"
        '
        'Rotate270Menu
        '
        Me.Rotate270Menu.Index = 2
        Me.Rotate270Menu.Text = "270"
        '
        'NoRotateMenu
        '
        Me.NoRotateMenu.Index = 3
        Me.NoRotateMenu.Text = "No Rotate"
        '
        'MenuItem7
        '
        Me.MenuItem7.Index = 2
        Me.MenuItem7.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FlipXMenu, Me.FlipYMenu, Me.FlipXY})
        Me.MenuItem7.Text = "Flip"
        '
        'FlipXMenu
        '
        Me.FlipXMenu.Index = 0
        Me.FlipXMenu.Text = "FlipX"
        '
        'FlipYMenu
        '
        Me.FlipYMenu.Index = 1
        Me.FlipYMenu.Text = "FlipY"
        '
        'FlipXY
        '
        Me.FlipXY.Index = 2
        Me.FlipXY.Text = "FlipXY"
        '
        'MenuItem8
        '
        Me.MenuItem8.Index = 3
        Me.MenuItem8.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.Zoom25Menu, Me.Zoom50Menu, Me.Zoom100Menu, Me.Zoom200Menu, Me.Zoom500Menu})
        Me.MenuItem8.Text = "Zoom"
        '
        'Zoom25Menu
        '
        Me.Zoom25Menu.Index = 0
        Me.Zoom25Menu.Text = "25%"
        '
        'Zoom50Menu
        '
        Me.Zoom50Menu.Index = 1
        Me.Zoom50Menu.Text = "50%"
        '
        'Zoom100Menu
        '
        Me.Zoom100Menu.Index = 2
        Me.Zoom100Menu.Text = "100%"
        '
        'Zoom200Menu
        '
        Me.Zoom200Menu.Index = 3
        Me.Zoom200Menu.Text = "200%"
        '
        'Zoom500Menu
        '
        Me.Zoom500Menu.Index = 4
        Me.Zoom500Menu.Text = "500%"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 2
        Me.MenuItem3.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.BrightnessMenu, Me.ColorMenu, Me.ContrastMenu, Me.GammaMenu, Me.GreyMenu, Me.Invertmenu})
        Me.MenuItem3.Text = "&Filters"
        '
        'BrightnessMenu
        '
        Me.BrightnessMenu.Index = 0
        Me.BrightnessMenu.Text = "Brightness"
        '
        'ColorMenu
        '
        Me.ColorMenu.Index = 1
        Me.ColorMenu.Text = "Color"
        '
        'ContrastMenu
        '
        Me.ContrastMenu.Index = 2
        Me.ContrastMenu.Text = "Contrast"
        '
        'GammaMenu
        '
        Me.GammaMenu.Index = 3
        Me.GammaMenu.Text = "Gamma"
        '
        'GreyMenu
        '
        Me.GreyMenu.Index = 4
        Me.GreyMenu.Text = "Grey"
        '
        'Invertmenu
        '
        Me.Invertmenu.Index = 5
        Me.Invertmenu.Text = "Invert"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 3
        Me.MenuItem4.Text = "&Windows"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.Desktop
        Me.ClientSize = New System.Drawing.Size(544, 402)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "GDI+ Image Viewer"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        If Not (bmpImage Is Nothing) Then '
            e.Graphics.DrawImage(bmpImage, New Rectangle(Me.AutoScrollPosition.X, Me.AutoScrollPosition.Y, CInt(curRect.Width * curZoom), CInt(curRect.Height * curZoom)))
        End If
    End Sub

    Private Sub OpenFileMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenFileMenu.Click
        Dim openFileDialog As New OpenFileDialog
        openFileDialog.Filter = "Image Files(*.BMP;*.JPG;*.GIF;*.WMF)" + "|*.BMP;*.JPG;*.GIF|All files (*.*)|*.*"
        openFileDialog.FilterIndex = 2
        '	openFileDialog.RestoreDirectory = true ;
        If DialogResult.OK = openFileDialog.ShowDialog() Then
            bmpImage = CType(Bitmap.FromFile(openFileDialog.FileName, False), Bitmap)
            Me.AutoScroll = True
            Me.AutoScrollMinSize = New Size(CInt(bmpImage.Width * curZoom), CInt(bmpImage.Height * curZoom))
            Me.Invalidate()
            zoomMode = True
        End If
        curRect = New Rectangle(0, 0, bmpImage.Width, bmpImage.Height)
        originalSize.Width = bmpImage.Width
        originalSize.Height = bmpImage.Height
    End Sub

    Private Sub FitWidthMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FitWidthMenu.Click
        curRect.Width = Me.Width
        Me.Invalidate()
    End Sub

    Private Sub FitHeightMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FitHeightMenu.Click
        curRect.Height = Me.Height
        Me.Invalidate()
    End Sub

    Private Sub FitOriginalMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FitOriginalMenu.Click
        curRect.Height = originalSize.Height
        curRect.Width = originalSize.Width
        Me.Invalidate()
    End Sub

    Private Sub FitAllMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FitAllMenu.Click
        curRect.Height = Me.Height
        curRect.Width = Me.Width
        Me.Invalidate()
    End Sub

    Private Sub SaveFileMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveFileMenu.Click
        Dim saveFileDialog As New SaveFileDialog

        saveFileDialog.InitialDirectory = "c:\"
        saveFileDialog.Filter = "Bitmap files (*.bmp)|*.bmp|Jpeg files (*.jpg)|*.jpg|" + "All valid files (*.bmp/*.jpg)|*.bmp/*.jpg"
        saveFileDialog.FilterIndex = 1
        saveFileDialog.RestoreDirectory = True

        If DialogResult.OK = saveFileDialog.ShowDialog() Then
            bmpImage.Save(saveFileDialog.FileName)
        End If
    End Sub

    Private Sub ExitMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitMenu.Click
        Me.Close()
    End Sub

    Private Sub Rotate90Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Rotate90Menu.Click
        bmpImage.RotateFlip(RotateFlipType.Rotate90FlipNone)
        Me.Invalidate()
    End Sub

    Private Sub Rotate180Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Rotate180Menu.Click
        bmpImage.RotateFlip(RotateFlipType.Rotate180FlipNone)
        Me.Invalidate()
    End Sub

    Private Sub Rotate270Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Rotate270Menu.Click
        bmpImage.RotateFlip(RotateFlipType.Rotate270FlipNone)
        Me.Invalidate()
    End Sub

    Private Sub NoRotateMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NoRotateMenu.Click
        bmpImage.RotateFlip(RotateFlipType.RotateNoneFlipNone)
        Me.Invalidate()
    End Sub

    Private Sub FlipXMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlipXMenu.Click
        bmpImage.RotateFlip(RotateFlipType.RotateNoneFlipX)
        Me.Invalidate()
    End Sub

    Private Sub FlipYMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlipYMenu.Click
        bmpImage.RotateFlip(RotateFlipType.RotateNoneFlipY)
        Me.Invalidate()
    End Sub

    Private Sub FlipXY_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlipXY.Click
        bmpImage.RotateFlip(RotateFlipType.RotateNoneFlipXY)
        Me.Invalidate()
    End Sub

    Private Sub Zoom25Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Zoom25Menu.Click
        curZoom = CDbl(25) / 100
        Me.Invalidate()
    End Sub

    Private Sub Zoom50Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Zoom50Menu.Click
        curZoom = CDbl(50) / 100
        Me.Invalidate()
    End Sub

    Private Sub Zoom100Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Zoom100Menu.Click
        curZoom = 100 / 100
        Me.Invalidate()
    End Sub

    Private Sub Zoom200Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Zoom200Menu.Click
        curZoom = 200 / 100
        Me.Invalidate()
    End Sub

    Private Sub Zoom500Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Zoom500Menu.Click
        curZoom = 500 / 100
        Me.Invalidate()
    End Sub
    Protected Overrides Sub OnMouseDown(ByVal e As MouseEventArgs)
        If Not zoomMode Then '
            Return
        End If
        If e.Button = MouseButtons.Left Then
            mouseDownPt.X = e.X
            mouseDownPt.Y = e.Y
        End If
    End Sub
    Protected Overrides Sub OnMouseUp(ByVal e As MouseEventArgs)
        If Not zoomMode Then
            Return
        End If
    End Sub

End Class

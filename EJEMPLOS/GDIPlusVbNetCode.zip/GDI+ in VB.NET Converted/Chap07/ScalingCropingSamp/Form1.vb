Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data

Public Class Form1
    Inherits System.Windows.Forms.Form
    Private curImage As Image
    Private imgHeight As Single
    Private imgWidth As Single
    Private menuItem12 As System.Windows.Forms.MenuItem
    Private curFileName As String

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents OpenFileMenu As System.Windows.Forms.MenuItem
    Friend WithEvents Zoom25Menu As System.Windows.Forms.MenuItem
    Friend WithEvents Zoom50Menu As System.Windows.Forms.MenuItem
    Friend WithEvents Zoom100Menu As System.Windows.Forms.MenuItem
    Friend WithEvents Zoom200Menu As System.Windows.Forms.MenuItem
    Friend WithEvents Zoom500Menu As System.Windows.Forms.MenuItem
    Friend WithEvents Skewing25Menu As System.Windows.Forms.MenuItem
    Friend WithEvents Skewing50Menu As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.MenuItem3 = New System.Windows.Forms.MenuItem
        Me.OpenFileMenu = New System.Windows.Forms.MenuItem
        Me.Zoom25Menu = New System.Windows.Forms.MenuItem
        Me.Zoom50Menu = New System.Windows.Forms.MenuItem
        Me.Zoom100Menu = New System.Windows.Forms.MenuItem
        Me.Zoom200Menu = New System.Windows.Forms.MenuItem
        Me.Zoom500Menu = New System.Windows.Forms.MenuItem
        Me.Skewing25Menu = New System.Windows.Forms.MenuItem
        Me.Skewing50Menu = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem2, Me.MenuItem3})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.OpenFileMenu})
        Me.MenuItem1.Text = "File"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.Zoom25Menu, Me.Zoom50Menu, Me.Zoom100Menu, Me.Zoom200Menu, Me.Zoom500Menu})
        Me.MenuItem2.Text = "Zoom"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 2
        Me.MenuItem3.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.Skewing25Menu, Me.Skewing50Menu})
        Me.MenuItem3.Text = "Skewing"
        '
        'OpenFileMenu
        '
        Me.OpenFileMenu.Index = 0
        Me.OpenFileMenu.Text = "Open File"
        '
        'Zoom25Menu
        '
        Me.Zoom25Menu.Index = 0
        Me.Zoom25Menu.Text = "25%"
        '
        'Zoom50Menu
        '
        Me.Zoom50Menu.Index = 1
        Me.Zoom50Menu.Text = "50%"
        '
        'Zoom100Menu
        '
        Me.Zoom100Menu.Index = 2
        Me.Zoom100Menu.Text = "100%"
        '
        'Zoom200Menu
        '
        Me.Zoom200Menu.Index = 3
        Me.Zoom200Menu.Text = "200%"
        '
        'Zoom500Menu
        '
        Me.Zoom500Menu.Index = 4
        Me.Zoom500Menu.Text = "500%"
        '
        'Skewing25Menu
        '
        Me.Skewing25Menu.Index = 0
        Me.Skewing25Menu.Text = "25%"
        '
        'Skewing50Menu
        '
        Me.Skewing50Menu.Index = 1
        Me.Skewing50Menu.Text = "50%"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(496, 378)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Scaling"

    End Sub

#End Region

    Private Sub OpenFileMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenFileMenu.Click
        Dim openDlg As New OpenFileDialog
        openDlg.Filter = "All Bitmap files|*.bmp;*.gif;*.jpg;"
        Dim filter As String = openDlg.Filter
        openDlg.InitialDirectory = Environment.CurrentDirectory
        openDlg.Title = "Open Bitmap File"
        openDlg.ShowHelp = True
        If openDlg.ShowDialog() = DialogResult.OK Then
            curFileName = openDlg.FileName
            curImage = Image.FromFile(curFileName)
            imgHeight = curImage.Height
            imgWidth = curImage.Width
        End If
        Invalidate()
    End Sub

    Private Sub Zoom25Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Zoom25Menu.Click
        imgHeight = imgHeight * 25 / 100
        imgWidth = imgWidth * 25 / 100
        Invalidate()
    End Sub

    Private Sub Zoom50Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Zoom50Menu.Click
        imgHeight = imgHeight * 50 / 100
        imgWidth = imgWidth * 50 / 100
        Invalidate()
    End Sub

    Private Sub Zoom100Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Zoom100Menu.Click
        imgHeight = imgHeight
        imgWidth = imgWidth
        Invalidate()
    End Sub

    Private Sub Zoom200Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Zoom200Menu.Click
        imgHeight = imgHeight * 200 / 100
        imgWidth = imgWidth * 200 / 100
        Invalidate()
    End Sub

    Private Sub Zoom500Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Zoom500Menu.Click
        imgHeight = imgHeight * 500 / 100
        imgWidth = imgWidth * 500 / 100
        Invalidate()
    End Sub

    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        If Not (curImage Is Nothing) Then
            e.Graphics.DrawImage(curImage, AutoScrollPosition.X, AutoScrollPosition.Y, imgWidth, imgHeight)
        End If

    End Sub

    Private Sub Skewing25Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Skewing25Menu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim pts As Point() = {New Point(150, 20), New Point(20, 50), New Point(150, 300)}

        g.DrawImage(curImage, pts)
        g.Dispose()
    End Sub
End Class

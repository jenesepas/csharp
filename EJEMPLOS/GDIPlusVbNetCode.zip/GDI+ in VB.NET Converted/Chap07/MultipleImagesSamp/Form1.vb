Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Imaging

Public Class Form1
    Inherits System.Windows.Forms.Form
    Dim tpVal As Single = 1.0F
    Private curImage As Image

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents SaveImgBtn As System.Windows.Forms.Button
    Friend WithEvents textBox2 As System.Windows.Forms.TextBox
    Friend WithEvents label3 As System.Windows.Forms.Label
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents trackBar1 As System.Windows.Forms.TrackBar
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.SaveImgBtn = New System.Windows.Forms.Button
        Me.textBox2 = New System.Windows.Forms.TextBox
        Me.label3 = New System.Windows.Forms.Label
        Me.textBox1 = New System.Windows.Forms.TextBox
        Me.label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.trackBar1 = New System.Windows.Forms.TrackBar
        CType(Me.trackBar1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SaveImgBtn
        '
        Me.SaveImgBtn.Location = New System.Drawing.Point(392, 248)
        Me.SaveImgBtn.Name = "SaveImgBtn"
        Me.SaveImgBtn.Size = New System.Drawing.Size(120, 32)
        Me.SaveImgBtn.TabIndex = 13
        Me.SaveImgBtn.Text = "Save Image"
        '
        'textBox2
        '
        Me.textBox2.Location = New System.Drawing.Point(456, 200)
        Me.textBox2.Name = "textBox2"
        Me.textBox2.Size = New System.Drawing.Size(64, 20)
        Me.textBox2.TabIndex = 12
        Me.textBox2.Text = ""
        '
        'label3
        '
        Me.label3.Location = New System.Drawing.Point(360, 200)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(88, 24)
        Me.label3.TabIndex = 11
        Me.label3.Text = "New Height:"
        '
        'textBox1
        '
        Me.textBox1.Location = New System.Drawing.Point(456, 168)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(64, 20)
        Me.textBox1.TabIndex = 10
        Me.textBox1.Text = ""
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(360, 168)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(88, 24)
        Me.label2.TabIndex = 9
        Me.label2.Text = "New Width:"
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(360, 48)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(96, 24)
        Me.label1.TabIndex = 8
        Me.label1.Text = "Transparency"
        '
        'trackBar1
        '
        Me.trackBar1.LargeChange = 1
        Me.trackBar1.Location = New System.Drawing.Point(352, 88)
        Me.trackBar1.Name = "trackBar1"
        Me.trackBar1.Size = New System.Drawing.Size(104, 45)
        Me.trackBar1.TabIndex = 7
        Me.trackBar1.Value = 1
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(520, 341)
        Me.Controls.Add(Me.SaveImgBtn)
        Me.Controls.Add(Me.textBox2)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.textBox1)
        Me.Controls.Add(Me.label2)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.trackBar1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.trackBar1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub SaveImgBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveImgBtn.Click
        If curImage Is Nothing Then
            Return
        End If
        Dim height As Integer = Convert.ToInt16(textBox1.Text)
        Dim width As Integer = Convert.ToInt16(textBox2.Text)
        Dim saveDlg As New SaveFileDialog
        saveDlg.Title = "Save Image As"
        saveDlg.OverwritePrompt = True
        saveDlg.CheckPathExists = True
        saveDlg.Filter = "Bitmap File(*.bmp)|*.bmp|Gif File(*.gif)|*.gif| " + "JPEG File(*.jpg)|*.jpg"
        saveDlg.ShowHelp = True
        If saveDlg.ShowDialog() = DialogResult.OK Then
            Dim fileName As String = saveDlg.FileName
            Dim newImage As New Bitmap(curImage, New Size(width, height))
            newImage.Save(fileName, ImageFormat.Bmp)
        End If
    End Sub
    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        ' Create an Image (first image) from a file
        curImage = Image.FromFile("roses.jpg")
        ' Draw first image
        e.Graphics.DrawImage(curImage, AutoScrollPosition.X, AutoScrollPosition.Y, curImage.Width, curImage.Height)
        ' Create an array of ColorMatrix points
        Dim ptsArray As Single()() = {New Single() {1, 0, 0, 0, 0}, New Single() {0, 1, 0, 0, 0}, New Single() {0, 0, 1, 0, 0}, New Single() {0, 0, 0, tpVal, 0}, New Single() {0, 0, 0, 0, 1}}
        ' Create a ColorMatrix object
        Dim clrMatrix As New ColorMatrix(ptsArray)
        ' Create ImageAttributes
        Dim imgAttributes As New ImageAttributes
        ' Set ColorMatrix 
        imgAttributes.SetColorMatrix(clrMatrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap)
        ' Create second Image object from a file
        Dim smallImage As Image = Image.FromFile("smallRoses.gif")
        ' Draw second image with image attributes
        e.Graphics.DrawImage(smallImage, New Rectangle(100, 100, 100, 100), 0, 0, smallImage.Width, smallImage.Height, GraphicsUnit.Pixel, imgAttributes)
    End Sub

    Private Sub trackBar1_Scroll(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles trackBar1.Scroll
        tpVal = CSng(trackBar1.Value) / 10
        Me.Invalidate()
    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Imaging

Public Class Form1
    Inherits System.Windows.Forms.Form
    Private curImage As Image
    Private curFileName As String
    Private imgHeight As Single
    'Private panel1 As System.Windows.Forms.Panel
    Private imgWidth As Single

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents panel1 As System.Windows.Forms.Panel
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents textBox2 As System.Windows.Forms.TextBox
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    Friend WithEvents SaveImageBtn As System.Windows.Forms.Button
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents OpenFileMenu As System.Windows.Forms.MenuItem
    Friend WithEvents ExitMenu As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.panel1 = New System.Windows.Forms.Panel
        Me.label1 = New System.Windows.Forms.Label
        Me.textBox2 = New System.Windows.Forms.TextBox
        Me.label2 = New System.Windows.Forms.Label
        Me.textBox1 = New System.Windows.Forms.TextBox
        Me.SaveImageBtn = New System.Windows.Forms.Button
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.OpenFileMenu = New System.Windows.Forms.MenuItem
        Me.ExitMenu = New System.Windows.Forms.MenuItem
        Me.panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'panel1
        '
        Me.panel1.Controls.Add(Me.label1)
        Me.panel1.Controls.Add(Me.textBox2)
        Me.panel1.Controls.Add(Me.label2)
        Me.panel1.Controls.Add(Me.textBox1)
        Me.panel1.Controls.Add(Me.SaveImageBtn)
        Me.panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.panel1.Location = New System.Drawing.Point(0, 318)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(384, 48)
        Me.panel1.TabIndex = 6
        '
        'label1
        '
        Me.label1.Location = New System.Drawing.Point(8, 8)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(64, 16)
        Me.label1.TabIndex = 3
        Me.label1.Text = "New Width"
        '
        'textBox2
        '
        Me.textBox2.Location = New System.Drawing.Point(88, 24)
        Me.textBox2.Name = "textBox2"
        Me.textBox2.Size = New System.Drawing.Size(64, 20)
        Me.textBox2.TabIndex = 2
        Me.textBox2.Text = ""
        '
        'label2
        '
        Me.label2.Location = New System.Drawing.Point(88, 8)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(88, 16)
        Me.label2.TabIndex = 4
        Me.label2.Text = "New Height"
        '
        'textBox1
        '
        Me.textBox1.Location = New System.Drawing.Point(8, 24)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(72, 20)
        Me.textBox1.TabIndex = 1
        Me.textBox1.Text = ""
        '
        'SaveImageBtn
        '
        Me.SaveImageBtn.Location = New System.Drawing.Point(200, 8)
        Me.SaveImageBtn.Name = "SaveImageBtn"
        Me.SaveImageBtn.Size = New System.Drawing.Size(104, 32)
        Me.SaveImageBtn.TabIndex = 0
        Me.SaveImageBtn.Text = "Save Image "
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.OpenFileMenu, Me.ExitMenu})
        Me.MenuItem1.Text = "File"
        '
        'OpenFileMenu
        '
        Me.OpenFileMenu.Index = 0
        Me.OpenFileMenu.Text = "Open a File"
        '
        'ExitMenu
        '
        Me.ExitMenu.Index = 1
        Me.ExitMenu.Text = "Exit"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(384, 366)
        Me.Controls.Add(Me.panel1)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Resizing Images Sample"
        Me.panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub OpenFileMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenFileMenu.Click
        Dim openDlg As New OpenFileDialog
        openDlg.Filter = "All Image files|*.bmp;*.gif;*.jpg;*.ico;" + "*.emf,*.wmf|Bitmap Files(*.bmp;*.gif;*.jpg;" + "*.ico)|*.bmp;*.gif;*.jpg;*.ico|" + "Meta Files(*.emf;*.wmf)|*.emf;*.wmf"
        Dim filter As String = openDlg.Filter
        openDlg.InitialDirectory = Environment.CurrentDirectory
        openDlg.Title = "Open Image File"
        openDlg.ShowHelp = True
        If openDlg.ShowDialog() = DialogResult.OK Then
            curFileName = openDlg.FileName
            curImage = Image.FromFile(curFileName)
            imgHeight = curImage.Height
            imgWidth = curImage.Width
        End If
        Invalidate()
    End Sub

    Private Sub SaveImageBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveImageBtn.Click
        If curImage Is Nothing Then
            Return
        End If
        Dim height As Integer = Convert.ToInt16(textBox1.Text)
        Dim width As Integer = Convert.ToInt16(textBox2.Text)

        Dim saveDlg As New SaveFileDialog
        saveDlg.Title = "Save Image As"
        saveDlg.OverwritePrompt = True
        saveDlg.CheckPathExists = True
        saveDlg.Filter = "Bitmap File(*.bmp)|*.bmp|Gif File(*.gif)|*.gif| " + "JPEG File(*.jpg)|*.jpg"
        saveDlg.ShowHelp = True
        If saveDlg.ShowDialog() = DialogResult.OK Then
            Dim fileName As String = saveDlg.FileName
            Dim extn As String = fileName.Substring(fileName.Length - 3, 3)
            Dim newImage As New Bitmap(curImage, New Size(width, height))
            If extn.Equals("bmp") Then
                newImage.Save(fileName, ImageFormat.Bmp)
            Else
                If extn.Equals("gif") Then
                    newImage.Save(fileName, ImageFormat.Gif)
                Else
                    If extn.Equals("jpg") Then
                        newImage.Save(fileName, ImageFormat.Jpeg)
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub ExitMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitMenu.Click
        Me.Close()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        curImage = Image.FromFile("roses.jpg")
    End Sub
    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        e.Graphics.DrawImage(curImage, AutoScrollPosition.X, AutoScrollPosition.Y, curImage.Width, curImage.Height)
    End Sub
End Class

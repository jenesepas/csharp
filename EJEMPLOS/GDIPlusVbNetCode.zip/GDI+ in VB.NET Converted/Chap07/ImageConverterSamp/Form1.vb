Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Imaging

Public Class Form1
    Inherits System.Windows.Forms.Form
    Private curImage As Image

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents SaveFormatCombo As System.Windows.Forms.ComboBox
    Friend WithEvents ConvertToBtn As System.Windows.Forms.Button
    Friend WithEvents ViewImgBtn As System.Windows.Forms.Button
    Friend WithEvents pictureBox1 As System.Windows.Forms.PictureBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.SaveFormatCombo = New System.Windows.Forms.ComboBox
        Me.ConvertToBtn = New System.Windows.Forms.Button
        Me.ViewImgBtn = New System.Windows.Forms.Button
        Me.pictureBox1 = New System.Windows.Forms.PictureBox
        Me.SuspendLayout()
        '
        'SaveFormatCombo
        '
        Me.SaveFormatCombo.Items.AddRange(New Object() {"bmp", "jpg", "wmf", "gif", "emf"})
        Me.SaveFormatCombo.Location = New System.Drawing.Point(404, 214)
        Me.SaveFormatCombo.Name = "SaveFormatCombo"
        Me.SaveFormatCombo.Size = New System.Drawing.Size(96, 21)
        Me.SaveFormatCombo.TabIndex = 7
        Me.SaveFormatCombo.Text = "bmp"
        '
        'ConvertToBtn
        '
        Me.ConvertToBtn.BackColor = System.Drawing.SystemColors.Desktop
        Me.ConvertToBtn.Location = New System.Drawing.Point(404, 182)
        Me.ConvertToBtn.Name = "ConvertToBtn"
        Me.ConvertToBtn.Size = New System.Drawing.Size(96, 24)
        Me.ConvertToBtn.TabIndex = 6
        Me.ConvertToBtn.Text = "Convert Now"
        '
        'ViewImgBtn
        '
        Me.ViewImgBtn.BackColor = System.Drawing.SystemColors.Desktop
        Me.ViewImgBtn.Location = New System.Drawing.Point(404, 38)
        Me.ViewImgBtn.Name = "ViewImgBtn"
        Me.ViewImgBtn.Size = New System.Drawing.Size(88, 24)
        Me.ViewImgBtn.TabIndex = 5
        Me.ViewImgBtn.Text = "View Image"
        '
        'pictureBox1
        '
        Me.pictureBox1.Location = New System.Drawing.Point(4, 30)
        Me.pictureBox1.Name = "pictureBox1"
        Me.pictureBox1.Size = New System.Drawing.Size(368, 328)
        Me.pictureBox1.TabIndex = 4
        Me.pictureBox1.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ClientSize = New System.Drawing.Size(504, 389)
        Me.Controls.Add(Me.SaveFormatCombo)
        Me.Controls.Add(Me.ConvertToBtn)
        Me.Controls.Add(Me.ViewImgBtn)
        Me.Controls.Add(Me.pictureBox1)
        Me.Name = "Form1"
        Me.Text = "GDI+ Image Convertor"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ViewImgBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewImgBtn.Click
        Dim openDlg As New OpenFileDialog   '
        openDlg.Filter = "All Image files|*.bmp;*.gif;*.jpg;*.ico;*.emf,*.wmf|Bitmap Files(*.bmp;*.gif;*.jpg;*.ico)|*.bmp;*.gif;*.jpg;*.ico|Meta Files(*.emf;*.wmf)|*.emf;*.wmf"
        Dim filter As String = openDlg.Filter
        openDlg.InitialDirectory = Environment.CurrentDirectory
        openDlg.Title = "Open Image File"
        openDlg.ShowHelp = True
        If openDlg.ShowDialog() = DialogResult.OK Then
            curImage = Image.FromFile(openDlg.FileName)
            pictureBox1.Width = curImage.Width
            pictureBox1.Height = curImage.Height
            pictureBox1.Image = curImage
            pictureBox1.Visible = True
        End If
    End Sub

    Private Sub ConvertToBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ConvertToBtn.Click
        Dim imgStream As New System.IO.MemoryStream
        Dim imgConverter As New ImageConverter
    End Sub
End Class

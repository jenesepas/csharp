Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data

Public Class Form1
    Inherits System.Windows.Forms.Form
    Private curImage As Image = Nothing
    Private curFileName As String = Nothing

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents StopAnimationBtn As System.Windows.Forms.Button
    Friend WithEvents StartAnimationBtn As System.Windows.Forms.Button
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents OpenFilemenu As System.Windows.Forms.MenuItem
    Friend WithEvents ExitMenu As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.StopAnimationBtn = New System.Windows.Forms.Button
        Me.StartAnimationBtn = New System.Windows.Forms.Button
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.OpenFilemenu = New System.Windows.Forms.MenuItem
        Me.ExitMenu = New System.Windows.Forms.MenuItem
        Me.SuspendLayout()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1})
        '
        'StopAnimationBtn
        '
        Me.StopAnimationBtn.Location = New System.Drawing.Point(232, 280)
        Me.StopAnimationBtn.Name = "StopAnimationBtn"
        Me.StopAnimationBtn.Size = New System.Drawing.Size(104, 24)
        Me.StopAnimationBtn.TabIndex = 3
        Me.StopAnimationBtn.Text = "Stop Animation"
        '
        'StartAnimationBtn
        '
        Me.StartAnimationBtn.Location = New System.Drawing.Point(104, 280)
        Me.StartAnimationBtn.Name = "StartAnimationBtn"
        Me.StartAnimationBtn.Size = New System.Drawing.Size(104, 24)
        Me.StartAnimationBtn.TabIndex = 2
        Me.StartAnimationBtn.Text = "Start Animation"
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.OpenFilemenu, Me.ExitMenu})
        Me.MenuItem1.Text = "File"
        '
        'OpenFilemenu
        '
        Me.OpenFilemenu.Index = 0
        Me.OpenFilemenu.Text = "Open File"
        '
        'ExitMenu
        '
        Me.ExitMenu.Index = 1
        Me.ExitMenu.Text = "Exit"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(512, 322)
        Me.Controls.Add(Me.StopAnimationBtn)
        Me.Controls.Add(Me.StartAnimationBtn)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "ImageAnimationSample"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub StartAnimationBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartAnimationBtn.Click
        curImage = Image.FromFile(curFileName)
        If ImageAnimator.CanAnimate(curImage) Then
            ImageAnimator.Animate(curImage, New EventHandler(AddressOf OnFrameChanged))
        Else
            MessageBox.Show("Image doesn't have frames")
        End If
    End Sub

    Private Sub StopAnimationBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StopAnimationBtn.Click
        If Not (curImage Is Nothing) Then
            ImageAnimator.StopAnimate(curImage, New EventHandler(AddressOf OnFrameChanged))
        End If
    End Sub

    Private Sub OpenFilemenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenFilemenu.Click
        ' Create OpenFileDialog
        Dim opnDlg As New OpenFileDialog
        opnDlg.Filter = "Animated Gifs|*.gif;"
        ' If OK selected
        If opnDlg.ShowDialog() = DialogResult.OK Then
            ' Read current selected file name
            curFileName = opnDlg.FileName
        End If
    End Sub

    Private Sub OnFrameChanged(ByVal o As Object, ByVal e As EventArgs)
        Me.Invalidate()
    End Sub 'OnFrameChanged

    Private Sub ExitMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitMenu.Click
        Me.Close()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        If Not (curImage Is Nothing) Then
            ImageAnimator.UpdateFrames()
            e.Graphics.DrawImage(curImage, New Point(0, 0))
        End If
    End Sub


End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Imaging

Public Class Form1
    Inherits System.Windows.Forms.Form
    Private curImage As Image
    Private curFileName As String
    Private imgHeight As Single
    Private imgWidth As Single
    Private FlipXMenu As System.Windows.Forms.MenuItem
    Private FlipYMenu As System.Windows.Forms.MenuItem
    Private FlipXYMenu As System.Windows.Forms.MenuItem

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents ViewImageMenu As System.Windows.Forms.MenuItem
    Friend WithEvents SaveFileMenu As System.Windows.Forms.MenuItem
    Friend WithEvents SaveAddMenu As System.Windows.Forms.MenuItem
    Friend WithEvents ExitMenu As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents Rotate90Menu As System.Windows.Forms.MenuItem
    Friend WithEvents Rotate180Menu As System.Windows.Forms.MenuItem
    Friend WithEvents Rotate270Menu As System.Windows.Forms.MenuItem
    Friend WithEvents RotateNoneMenu As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    ' Friend WithEvents FlipXmenu As System.Windows.Forms.MenuItem
    ' Friend WithEvents FlipYMenu As System.Windows.Forms.MenuItem
    'Friend WithEvents FlipXYMenu As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents FitHeightMenu As System.Windows.Forms.MenuItem
    Friend WithEvents FitWidthMenu As System.Windows.Forms.MenuItem
    Friend WithEvents FitOriginalMenu As System.Windows.Forms.MenuItem
    Friend WithEvents ThumbnailMenu As System.Windows.Forms.MenuItem
    Friend WithEvents FlipX As System.Windows.Forms.MenuItem
    Friend WithEvents FlipY As System.Windows.Forms.MenuItem
    Friend WithEvents FlipXY As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.ViewImageMenu = New System.Windows.Forms.MenuItem
        Me.SaveFileMenu = New System.Windows.Forms.MenuItem
        Me.SaveAddMenu = New System.Windows.Forms.MenuItem
        Me.ExitMenu = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.MenuItem4 = New System.Windows.Forms.MenuItem
        Me.Rotate90Menu = New System.Windows.Forms.MenuItem
        Me.Rotate180Menu = New System.Windows.Forms.MenuItem
        Me.Rotate270Menu = New System.Windows.Forms.MenuItem
        Me.RotateNoneMenu = New System.Windows.Forms.MenuItem
        Me.MenuItem5 = New System.Windows.Forms.MenuItem
        Me.MenuItem6 = New System.Windows.Forms.MenuItem
        Me.FitHeightMenu = New System.Windows.Forms.MenuItem
        Me.FitWidthMenu = New System.Windows.Forms.MenuItem
        Me.FitOriginalMenu = New System.Windows.Forms.MenuItem
        Me.MenuItem3 = New System.Windows.Forms.MenuItem
        Me.ThumbnailMenu = New System.Windows.Forms.MenuItem
        Me.FlipX = New System.Windows.Forms.MenuItem
        Me.FlipY = New System.Windows.Forms.MenuItem
        Me.FlipXY = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem2, Me.MenuItem3})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.ViewImageMenu, Me.SaveFileMenu, Me.SaveAddMenu, Me.ExitMenu})
        Me.MenuItem1.Text = "File"
        '
        'ViewImageMenu
        '
        Me.ViewImageMenu.Index = 0
        Me.ViewImageMenu.Text = "View Image"
        '
        'SaveFileMenu
        '
        Me.SaveFileMenu.Index = 1
        Me.SaveFileMenu.Text = "Save As"
        '
        'SaveAddMenu
        '
        Me.SaveAddMenu.Index = 2
        Me.SaveAddMenu.Text = "Save Add"
        '
        'ExitMenu
        '
        Me.ExitMenu.Index = 3
        Me.ExitMenu.Text = "Exit"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem4, Me.MenuItem5, Me.MenuItem6})
        Me.MenuItem2.Text = "Options"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 0
        Me.MenuItem4.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.Rotate90Menu, Me.Rotate180Menu, Me.Rotate270Menu, Me.RotateNoneMenu})
        Me.MenuItem4.Text = "Rotate"
        '
        'Rotate90Menu
        '
        Me.Rotate90Menu.Index = 0
        Me.Rotate90Menu.Text = "Rotate 90"
        '
        'Rotate180Menu
        '
        Me.Rotate180Menu.Index = 1
        Me.Rotate180Menu.Text = "Rotate 180"
        '
        'Rotate270Menu
        '
        Me.Rotate270Menu.Index = 2
        Me.Rotate270Menu.Text = "Rotate 270"
        '
        'RotateNoneMenu
        '
        Me.RotateNoneMenu.Index = 3
        Me.RotateNoneMenu.Text = "Rotate None"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 1
        Me.MenuItem5.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FlipX, Me.FlipY, Me.FlipXY})
        Me.MenuItem5.Text = "Flip"
        '
        'MenuItem6
        '
        Me.MenuItem6.Index = 2
        Me.MenuItem6.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FitHeightMenu, Me.FitWidthMenu, Me.FitOriginalMenu})
        Me.MenuItem6.Text = "Fit"
        '
        'FitHeightMenu
        '
        Me.FitHeightMenu.Index = 0
        Me.FitHeightMenu.Text = "Fit Height"
        '
        'FitWidthMenu
        '
        Me.FitWidthMenu.Index = 1
        Me.FitWidthMenu.Text = "Fit Width"
        '
        'FitOriginalMenu
        '
        Me.FitOriginalMenu.Index = 2
        Me.FitOriginalMenu.Text = "Fit All"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 2
        Me.MenuItem3.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.ThumbnailMenu})
        Me.MenuItem3.Text = "Others"
        '
        'ThumbnailMenu
        '
        Me.ThumbnailMenu.Index = 0
        Me.ThumbnailMenu.Text = "Show Thumbnail"
        '
        'FlipX
        '
        Me.FlipX.Index = 0
        Me.FlipX.Text = "X"
        '
        'FlipY
        '
        Me.FlipY.Index = 1
        Me.FlipY.Text = "Y"
        '
        'FlipXY
        '
        Me.FlipXY.Index = 2
        Me.FlipXY.Text = "XY"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.ClientSize = New System.Drawing.Size(488, 438)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Image Class Functionality"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ViewImageMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewImageMenu.Click
        Dim openDlg As New OpenFileDialog   '
        openDlg.Filter = "All Image files|*.bmp;*.gif;*.jpg;*.ico;" + "*.emf,*.wmf|Bitmap Files(*.bmp;*.gif;*.jpg;" + "*.ico)|*.bmp;*.gif;*.jpg;*.ico|" + "Meta Files(*.emf;*.wmf)|*.emf;*.wmf"
        Dim filter As String = openDlg.Filter
        openDlg.InitialDirectory = Environment.CurrentDirectory
        openDlg.Title = "Open Image File"
        openDlg.ShowHelp = True
        If openDlg.ShowDialog() = DialogResult.OK Then
            curFileName = openDlg.FileName
            curImage = Image.FromFile(curFileName)
        End If
        If Not (curImage Is Nothing) Then
            ' Construct a Graphics object and clear
            ' the background
            Dim g As Graphics = Me.CreateGraphics()
            g.Clear(Me.BackColor)
            ' Draw Image using the DrawImage method 
            g.DrawImage(curImage, AutoScrollPosition.X, AutoScrollPosition.Y, curImage.Width, curImage.Height)
            ' g.DrawImage(curImage, this.ClientRectangle);	
            imgHeight = curImage.Height
            imgWidth = curImage.Width

            ' Viewing Image properties
            Dim imageProperties As String = "Size:" + curImage.Size.ToString()
            imageProperties += "," + ControlChars.Lf + " RawFormat:" + curImage.RawFormat.ToString()
            imageProperties += "," + ControlChars.Lf + " Vertical Resolution:" + curImage.VerticalResolution.ToString()
            imageProperties += "," + ControlChars.Lf + " Horizontal Resolution:" + curImage.HorizontalResolution.ToString()
            imageProperties += "," + ControlChars.Lf + " PixelFormat:" + curImage.PixelFormat.ToString()
            imageProperties += "," + ControlChars.Lf + " Flags:" + curImage.Flags.ToString()
            MessageBox.Show(imageProperties)
            'Dispose
            g.Dispose()
        End If
    End Sub

    Private Sub SaveFileMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveFileMenu.Click
        If curImage Is Nothing Then '
            Return
        End If
        Dim saveDlg As New SaveFileDialog
        saveDlg.Title = "Save Image As"
        saveDlg.OverwritePrompt = True
        saveDlg.CheckPathExists = True
        saveDlg.Filter = "Bitmap File(*.bmp)|*.bmp|Gif File(*.gif)|*.gif|JPEG File(*.jpg)|*.jpg"
        saveDlg.ShowHelp = True
        If saveDlg.ShowDialog() = DialogResult.OK Then
            Dim fileName As String = saveDlg.FileName
            Dim strFilExtn As String = fileName.Remove(0, fileName.Length - 3)

            Select Case strFilExtn
                Case "bmp"
                    curImage.Save(fileName, ImageFormat.Bmp)

                Case "jpg"
                    curImage.Save(fileName, ImageFormat.Jpeg)

                Case "gif"
                    curImage.Save(fileName, ImageFormat.Gif)

                Case "tif"
                    curImage.Save(fileName, ImageFormat.Tiff)
            End Select
        End If
    End Sub

    Private Sub ExitMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitMenu.Click
        Me.Close()
    End Sub

    Private Sub SaveAddMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveAddMenu.Click

    End Sub

    Private Sub Rotate90Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Rotate90Menu.Click
        curImage.RotateFlip(RotateFlipType.Rotate90FlipNone)
        Invalidate()
    End Sub

    Private Sub Rotate180Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Rotate180Menu.Click
        curImage.RotateFlip(RotateFlipType.Rotate180FlipNone)
        Invalidate()
    End Sub

    Private Sub Rotate270Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Rotate270Menu.Click
        curImage.RotateFlip(RotateFlipType.Rotate270FlipNone)
        Invalidate()
    End Sub

    Private Sub RotateNoneMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RotateNoneMenu.Click
        curImage.RotateFlip(RotateFlipType.RotateNoneFlipNone)
        Invalidate()
    End Sub

    Private Sub ThumbnailMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ThumbnailMenu.Click
        Dim openDlg As New OpenFileDialog
        openDlg.Filter = "All Image files|*.bmp;*.gif;*.jpg;*.ico;" + "*.emf,*.wmf|Bitmap Files(*.bmp;*.gif;*.jpg;" + "*.ico)|*.bmp;*.gif;*.jpg;*.ico|" + "Meta Files(*.emf;*.wmf)|*.emf;*.wmf"
        Dim filter As String = openDlg.Filter
        openDlg.InitialDirectory = Environment.CurrentDirectory
        openDlg.Title = "Open Image File"
        openDlg.ShowHelp = True
        If openDlg.ShowDialog() = DialogResult.OK Then
            curFileName = openDlg.FileName
            curImage = Image.FromFile(curFileName)
        End If

        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Draw Image using the DrawImage method 
        Dim tnCallback As Image.GetThumbnailImageAbort = New Image.GetThumbnailImageAbort(AddressOf tnCallbackMethod)
        Dim thumbNailImage As Image = curImage.GetThumbnailImage(100, 100, tnCallback, IntPtr.Zero)
        g.DrawImage(thumbNailImage, 40, 20)
        g.Dispose()
    End Sub

    Private Function tnCallbackMethod() As Boolean
        Return False
    End Function 'tnCallbackMethod

    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        If Not (curImage Is Nothing) Then
            e.Graphics.DrawImage(curImage, AutoScrollPosition.X, AutoScrollPosition.Y, imgWidth, imgHeight)
        End If
    End Sub

    Private Sub FitHeightMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FitHeightMenu.Click
        imgHeight = Me.Height
        Invalidate()
    End Sub

    Private Sub FitWidthMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FitWidthMenu.Click
        imgWidth = Me.Width
        Invalidate()
    End Sub

    Private Sub FitOriginalMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FitOriginalMenu.Click
        imgWidth = Me.Width
        imgHeight = Me.Height
        Invalidate()
    End Sub

    Private Sub FlipX_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlipX.Click
        curImage.RotateFlip(RotateFlipType.RotateNoneFlipX)
        Invalidate()
    End Sub

    Private Sub FlipY_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlipY.Click
        curImage.RotateFlip(RotateFlipType.RotateNoneFlipY)
        Invalidate()
    End Sub

    Private Sub FlipXY_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlipXY.Click
        curImage.RotateFlip(RotateFlipType.RotateNoneFlipXY)
        Invalidate()
    End Sub
End Class

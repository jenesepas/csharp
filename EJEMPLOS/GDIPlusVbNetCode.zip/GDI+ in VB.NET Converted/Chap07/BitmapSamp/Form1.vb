Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Imaging

Public Class Form1
    Inherits System.Windows.Forms.Form
    Private curBitmap As Bitmap
    Private imgHeight As Single
    Private imgWidth As Single
    Private curFileName As String

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents groupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents ApplyBtn As System.Windows.Forms.Button
    Friend WithEvents checkBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents textBox2 As System.Windows.Forms.TextBox
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents textBox1 As System.Windows.Forms.TextBox
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents OpenBmpMenu As System.Windows.Forms.MenuItem
    Friend WithEvents ExitMenu As System.Windows.Forms.MenuItem
    Friend WithEvents PropertiesMenu As System.Windows.Forms.MenuItem
    Friend WithEvents GrayScaleMenu As System.Windows.Forms.MenuItem
    Friend WithEvents GrayScaleUsingLockBitsMenu As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.groupBox1 = New System.Windows.Forms.GroupBox
        Me.ApplyBtn = New System.Windows.Forms.Button
        Me.checkBox1 = New System.Windows.Forms.CheckBox
        Me.textBox2 = New System.Windows.Forms.TextBox
        Me.label2 = New System.Windows.Forms.Label
        Me.textBox1 = New System.Windows.Forms.TextBox
        Me.label1 = New System.Windows.Forms.Label
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.OpenBmpMenu = New System.Windows.Forms.MenuItem
        Me.ExitMenu = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.PropertiesMenu = New System.Windows.Forms.MenuItem
        Me.GrayScaleMenu = New System.Windows.Forms.MenuItem
        Me.GrayScaleUsingLockBitsMenu = New System.Windows.Forms.MenuItem
        Me.groupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'groupBox1
        '
        Me.groupBox1.BackColor = System.Drawing.SystemColors.Desktop
        Me.groupBox1.Controls.Add(Me.ApplyBtn)
        Me.groupBox1.Controls.Add(Me.checkBox1)
        Me.groupBox1.Controls.Add(Me.textBox2)
        Me.groupBox1.Controls.Add(Me.label2)
        Me.groupBox1.Controls.Add(Me.textBox1)
        Me.groupBox1.Controls.Add(Me.label1)
        Me.groupBox1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.groupBox1.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(192, Byte))
        Me.groupBox1.Location = New System.Drawing.Point(360, 24)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(184, 360)
        Me.groupBox1.TabIndex = 1
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "Bitmap Properties"
        Me.groupBox1.Visible = False
        '
        'ApplyBtn
        '
        Me.ApplyBtn.Location = New System.Drawing.Point(40, 256)
        Me.ApplyBtn.Name = "ApplyBtn"
        Me.ApplyBtn.Size = New System.Drawing.Size(128, 32)
        Me.ApplyBtn.TabIndex = 5
        Me.ApplyBtn.Text = "Apply Settings"
        '
        'checkBox1
        '
        Me.checkBox1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.checkBox1.Location = New System.Drawing.Point(16, 152)
        Me.checkBox1.Name = "checkBox1"
        Me.checkBox1.Size = New System.Drawing.Size(144, 24)
        Me.checkBox1.TabIndex = 4
        Me.checkBox1.Text = "Transparent"
        '
        'textBox2
        '
        Me.textBox2.AutoSize = False
        Me.textBox2.BackColor = System.Drawing.SystemColors.Info
        Me.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.textBox2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.textBox2.Location = New System.Drawing.Point(16, 104)
        Me.textBox2.Name = "textBox2"
        Me.textBox2.Size = New System.Drawing.Size(120, 24)
        Me.textBox2.TabIndex = 3
        Me.textBox2.Text = ""
        '
        'label2
        '
        Me.label2.BackColor = System.Drawing.SystemColors.Desktop
        Me.label2.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.label2.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(192, Byte))
        Me.label2.Location = New System.Drawing.Point(16, 80)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(136, 16)
        Me.label2.TabIndex = 2
        Me.label2.Text = "Vert Resolution (DPI)"
        '
        'textBox1
        '
        Me.textBox1.AutoSize = False
        Me.textBox1.BackColor = System.Drawing.SystemColors.Info
        Me.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.textBox1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.textBox1.Location = New System.Drawing.Point(16, 48)
        Me.textBox1.Name = "textBox1"
        Me.textBox1.Size = New System.Drawing.Size(120, 24)
        Me.textBox1.TabIndex = 1
        Me.textBox1.Text = ""
        '
        'label1
        '
        Me.label1.Font = New System.Drawing.Font("Tahoma", 9.0!)
        Me.label1.Location = New System.Drawing.Point(16, 24)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(144, 16)
        Me.label1.TabIndex = 0
        Me.label1.Text = "Horz Resolution (DPI)"
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem2})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.OpenBmpMenu, Me.ExitMenu})
        Me.MenuItem1.Text = "Bitmap"
        '
        'OpenBmpMenu
        '
        Me.OpenBmpMenu.Index = 0
        Me.OpenBmpMenu.Text = "Open Bitmap"
        '
        'ExitMenu
        '
        Me.ExitMenu.Index = 1
        Me.ExitMenu.Text = "Exit"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.PropertiesMenu, Me.GrayScaleMenu, Me.GrayScaleUsingLockBitsMenu})
        Me.MenuItem2.Text = "Methods"
        '
        'PropertiesMenu
        '
        Me.PropertiesMenu.Index = 0
        Me.PropertiesMenu.Text = "Bitmap Preperties"
        '
        'GrayScaleMenu
        '
        Me.GrayScaleMenu.Index = 1
        Me.GrayScaleMenu.Text = "Gray Scale"
        '
        'GrayScaleUsingLockBitsMenu
        '
        Me.GrayScaleUsingLockBitsMenu.Index = 2
        Me.GrayScaleUsingLockBitsMenu.Text = "GrayScaleUsingLockBits"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(568, 402)
        Me.Controls.Add(Me.groupBox1)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.groupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub OpenBmpMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenBmpMenu.Click
        Dim openDlg As New OpenFileDialog
        openDlg.Filter = "All Bitmap files|*.bmp;*.gif;*.jpg;"
        Dim filter As String = openDlg.Filter
        openDlg.Title = "Open Bitmap File"
        openDlg.ShowHelp = True
        If openDlg.ShowDialog() = DialogResult.OK Then
            curFileName = openDlg.FileName
            curBitmap = New Bitmap(curFileName)
            imgHeight = curBitmap.Height
            imgWidth = curBitmap.Width
        End If
        Invalidate()
    End Sub

    Private Sub ExitMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitMenu.Click
        Me.Close()
    End Sub

    Private Sub PropertiesMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PropertiesMenu.Click
        groupBox1.Visible = True
    End Sub
    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        Dim g As Graphics = e.Graphics
        If Not (curBitmap Is Nothing) Then
            g.DrawImage(curBitmap, AutoScrollPosition.X, AutoScrollPosition.Y, imgWidth, imgHeight)
        End If
        g.Dispose()
    End Sub

    Private Sub ApplyBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ApplyBtn.Click
        If curBitmap Is Nothing Then
            Return
        End If
        Dim hDpi As Single = 90
        Dim vDpi As Single = 90
        If textBox1.Text.ToString() <> "" Then
            hDpi = Convert.ToInt32(textBox1.Text)
        End If
        If textBox1.Text.ToString() <> "" Then
            vDpi = Convert.ToInt32(textBox2.Text)
        End If
        curBitmap.SetResolution(hDpi, vDpi)

        If checkBox1.Checked Then
            Dim curColor As Color = curBitmap.GetPixel(10, 10)
            curBitmap.MakeTransparent()
        End If

        Dim i As Integer
        For i = 50 To 59
            Dim j As Integer
            For j = 50 To 59
                curBitmap.SetPixel(i, j, Color.Red)
            Next j
        Next i
        Invalidate()
    End Sub

    Private Sub GrayScaleMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GrayScaleMenu.Click
        ' Create a Graphics object from a button
        ' or menu click event handler
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a Bitmap object 
        Dim curBitmap As New Bitmap("")
        ' Draw bitmap in its original color 
        g.DrawImage(curBitmap, 0, 0, curBitmap.Width, curBitmap.Height) '
        ' Set each pixel to gray scale using GetPixel
        ' and SetPixel
        Dim i As Integer
        For i = 0 To curBitmap.Width - 1
            Dim j As Integer
            For j = 0 To curBitmap.Height - 1
                Dim curColor As Color = curBitmap.GetPixel(i, j)
                Dim ret As Integer = (curColor.R + curColor.G + curColor.B) / 3
                curBitmap.SetPixel(i, j, Color.FromArgb(ret, ret, ret))
            Next j
        Next i
        ' Draw bitmap again with gray settings
        g.DrawImage(curBitmap, 0, 0, curBitmap.Width, curBitmap.Height)
        'Dispose
        g.Dispose()
    End Sub

    Private Sub GrayScaleUsingLockBitsMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GrayScaleUsingLockBitsMenu.Click

    End Sub
End Class

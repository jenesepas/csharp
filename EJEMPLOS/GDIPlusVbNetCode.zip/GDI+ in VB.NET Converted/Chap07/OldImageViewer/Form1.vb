Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Imaging
Public Class Form1
    Inherits System.Windows.Forms.Form
    Private curImage As Image = Nothing
    Private curRect As Rectangle
    Private curZoom As Double = 1.0
    Private originalSize As Size = New Size(0, 0)
    Private curFileName As String = Nothing

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents OpenFileMenu As System.Windows.Forms.MenuItem
    Friend WithEvents SaveFileMenu As System.Windows.Forms.MenuItem
    Friend WithEvents ExitMenu As System.Windows.Forms.MenuItem
    Friend WithEvents PropertiesMenu As System.Windows.Forms.MenuItem
    Friend WithEvents ThumbnailMenu As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents Rotate90menu As System.Windows.Forms.MenuItem
    Friend WithEvents Rotate180Menu As System.Windows.Forms.MenuItem
    Friend WithEvents Rotate270Menu As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents FlipX As System.Windows.Forms.MenuItem
    Friend WithEvents FlipY As System.Windows.Forms.MenuItem
    Friend WithEvents FlipXY As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents FitHeightMenu As System.Windows.Forms.MenuItem
    Friend WithEvents FitWidthMenu As System.Windows.Forms.MenuItem
    Friend WithEvents FitOriginalMenu As System.Windows.Forms.MenuItem
    Friend WithEvents FitAllMenu As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents Zoom25Menu As System.Windows.Forms.MenuItem
    Friend WithEvents Zoom50Menu As System.Windows.Forms.MenuItem
    Friend WithEvents Zoom100Menu As System.Windows.Forms.MenuItem
    Friend WithEvents Zoom200Menu As System.Windows.Forms.MenuItem
    Friend WithEvents Zoom500Menu As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.OpenFileMenu = New System.Windows.Forms.MenuItem
        Me.SaveFileMenu = New System.Windows.Forms.MenuItem
        Me.ExitMenu = New System.Windows.Forms.MenuItem
        Me.PropertiesMenu = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.ThumbnailMenu = New System.Windows.Forms.MenuItem
        Me.MenuItem3 = New System.Windows.Forms.MenuItem
        Me.Rotate90menu = New System.Windows.Forms.MenuItem
        Me.Rotate180Menu = New System.Windows.Forms.MenuItem
        Me.Rotate270Menu = New System.Windows.Forms.MenuItem
        Me.MenuItem4 = New System.Windows.Forms.MenuItem
        Me.FlipX = New System.Windows.Forms.MenuItem
        Me.FlipY = New System.Windows.Forms.MenuItem
        Me.FlipXY = New System.Windows.Forms.MenuItem
        Me.MenuItem5 = New System.Windows.Forms.MenuItem
        Me.FitHeightMenu = New System.Windows.Forms.MenuItem
        Me.FitWidthMenu = New System.Windows.Forms.MenuItem
        Me.FitOriginalMenu = New System.Windows.Forms.MenuItem
        Me.FitAllMenu = New System.Windows.Forms.MenuItem
        Me.MenuItem6 = New System.Windows.Forms.MenuItem
        Me.Zoom25Menu = New System.Windows.Forms.MenuItem
        Me.Zoom50Menu = New System.Windows.Forms.MenuItem
        Me.Zoom100Menu = New System.Windows.Forms.MenuItem
        Me.Zoom200Menu = New System.Windows.Forms.MenuItem
        Me.Zoom500Menu = New System.Windows.Forms.MenuItem
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem2})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.OpenFileMenu, Me.SaveFileMenu, Me.ExitMenu, Me.PropertiesMenu})
        Me.MenuItem1.Text = "File"
        '
        'OpenFileMenu
        '
        Me.OpenFileMenu.Index = 0
        Me.OpenFileMenu.Text = "Open File"
        '
        'SaveFileMenu
        '
        Me.SaveFileMenu.Index = 1
        Me.SaveFileMenu.Text = "Save File"
        '
        'ExitMenu
        '
        Me.ExitMenu.Index = 2
        Me.ExitMenu.Text = "Exit"
        '
        'PropertiesMenu
        '
        Me.PropertiesMenu.Index = 3
        Me.PropertiesMenu.Text = "Properties"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.ThumbnailMenu, Me.MenuItem3, Me.MenuItem4, Me.MenuItem5, Me.MenuItem6})
        Me.MenuItem2.Text = "Options"
        '
        'ThumbnailMenu
        '
        Me.ThumbnailMenu.Index = 0
        Me.ThumbnailMenu.Text = "Create Thumbnail"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 1
        Me.MenuItem3.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.Rotate90menu, Me.Rotate180Menu, Me.Rotate270Menu})
        Me.MenuItem3.Text = "Rotate"
        '
        'Rotate90menu
        '
        Me.Rotate90menu.Index = 0
        Me.Rotate90menu.Text = "90"
        '
        'Rotate180Menu
        '
        Me.Rotate180Menu.Index = 1
        Me.Rotate180Menu.Text = "180"
        '
        'Rotate270Menu
        '
        Me.Rotate270Menu.Index = 2
        Me.Rotate270Menu.Text = "270"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 2
        Me.MenuItem4.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FlipX, Me.FlipY, Me.FlipXY})
        Me.MenuItem4.Text = "Flip"
        '
        'FlipX
        '
        Me.FlipX.Index = 0
        Me.FlipX.Text = "X"
        '
        'FlipY
        '
        Me.FlipY.Index = 1
        Me.FlipY.Text = "Y"
        '
        'FlipXY
        '
        Me.FlipXY.Index = 2
        Me.FlipXY.Text = "XY"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 3
        Me.MenuItem5.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FitHeightMenu, Me.FitWidthMenu, Me.FitOriginalMenu, Me.FitAllMenu})
        Me.MenuItem5.Text = "Fit"
        '
        'FitHeightMenu
        '
        Me.FitHeightMenu.Index = 0
        Me.FitHeightMenu.Text = "Fit Height"
        '
        'FitWidthMenu
        '
        Me.FitWidthMenu.Index = 1
        Me.FitWidthMenu.Text = "Fit Width"
        '
        'FitOriginalMenu
        '
        Me.FitOriginalMenu.Index = 2
        Me.FitOriginalMenu.Text = "Fit Original"
        '
        'FitAllMenu
        '
        Me.FitAllMenu.Index = 3
        Me.FitAllMenu.Text = "Fit All"
        '
        'MenuItem6
        '
        Me.MenuItem6.Index = 4
        Me.MenuItem6.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.Zoom25Menu, Me.Zoom50Menu, Me.Zoom100Menu, Me.Zoom200Menu, Me.Zoom500Menu})
        Me.MenuItem6.Text = "Zoom"
        '
        'Zoom25Menu
        '
        Me.Zoom25Menu.Index = 0
        Me.Zoom25Menu.Text = "Zoom25"
        '
        'Zoom50Menu
        '
        Me.Zoom50Menu.Index = 1
        Me.Zoom50Menu.Text = "Zoom50"
        '
        'Zoom100Menu
        '
        Me.Zoom100Menu.Index = 2
        Me.Zoom100Menu.Text = "Zoom100"
        '
        'Zoom200Menu
        '
        Me.Zoom200Menu.Index = 3
        Me.Zoom200Menu.Text = "Zoom200"
        '
        'Zoom500Menu
        '
        Me.Zoom500Menu.Index = 4
        Me.Zoom500Menu.Text = "Zoom500"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(560, 409)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Image Viewer"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub OpenFileMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenFileMenu.Click
        ' Create OpenFileDialog
        Dim opnDlg As New OpenFileDialog
        ' Set a filter for images
        opnDlg.Filter = "All Image files|*.bmp;*.gif;*.jpg;*.ico;" + "*.emf;,*.wmf|Bitmap Files(*.bmp;*.gif;*.jpg;" + "*.ico)|*.bmp;*.gif;*.jpg;*.ico|" + "Meta Files(*.emf;*.wmf;*.png)|*.emf;*.wmf;*.png"
        opnDlg.Title = "ImageViewer: Open Image File"
        opnDlg.ShowHelp = True
        ' If OK selected
        If opnDlg.ShowDialog() = DialogResult.OK Then
            ' Read current selected file name
            curFileName = opnDlg.FileName
            ' Create the Image object using 
            ' Image.FromFile
            Try
                curImage = Image.FromFile(curFileName)
            Catch exp As Exception
                MessageBox.Show(exp.Message)
            End Try
            ' Activate scrolling
            Me.AutoScroll = True
            Me.AutoScrollMinSize = New Size(CInt(curImage.Width), CInt(curImage.Height))
            ' Repaint the form, which forces the Paint
            ' event hanlder
            Me.Invalidate()
        End If
        ' Create current rectangle
        curRect = New Rectangle(0, 0, curImage.Width, curImage.Height)
        ' Save origianl size of the image
        originalSize.Width = curImage.Width
        originalSize.Height = curImage.Height
    End Sub

    Private Sub ExitMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitMenu.Click
        Me.Close()

    End Sub

    Private Sub SaveFileMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveFileMenu.Click
        ' If Image is created
        If curImage Is Nothing Then
            Return
        End If ' SaveFileDialog
        Dim saveDlg As New SaveFileDialog
        saveDlg.Title = "Save Image As"
        saveDlg.OverwritePrompt = True
        saveDlg.CheckPathExists = True
        saveDlg.Filter = "Bitmap File(*.bmp)|*.bmp|" + "Gif File(*.gif)|*.gif|" + "JPEG File(*.jpg)|*.jpg|" + "PNG File(*.png)|*.png"
        saveDlg.ShowHelp = True
        ' If selected Save
        If saveDlg.ShowDialog() = DialogResult.OK Then
            ' Get the user selected file name
            Dim fileName As String = saveDlg.FileName
            ' Get the extension
            Dim strFilExtn As String = fileName.Remove(0, fileName.Length - 3)
            ' Save file
            Select Case strFilExtn
                Case "bmp"
                    curImage.Save(fileName, ImageFormat.Bmp)
                Case "jpg"
                    curImage.Save(fileName, ImageFormat.Jpeg)
                Case "gif"
                    curImage.Save(fileName, ImageFormat.Gif)
                Case "tif"
                    curImage.Save(fileName, ImageFormat.Tiff)
                Case "png"
                    curImage.Save(fileName, ImageFormat.Png)
                Case Else
            End Select
        End If
    End Sub
    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        Dim g As Graphics = e.Graphics '
        If Not (curImage Is Nothing) Then
            ' Draw Image using the DrawImage method 
            g.DrawImage(curImage, New Rectangle(Me.AutoScrollPosition.X, Me.AutoScrollPosition.Y, CInt(curRect.Width * curZoom), CInt(curRect.Height * curZoom)))
        End If

    End Sub

    Private Sub PropertiesMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PropertiesMenu.Click
        If Not (curImage Is Nothing) Then '
            ' Viewing Image properties
            Dim imageProperties As String = "Size:" + curImage.Size.ToString()
            imageProperties += "," + ControlChars.Lf + " RawFormat:" + curImage.RawFormat.ToString()
            imageProperties += "," + ControlChars.Lf + " Vertical Resolution:" + curImage.VerticalResolution.ToString()
            imageProperties += "," + ControlChars.Lf + " Horizontal Resolution:" + curImage.HorizontalResolution.ToString()
            imageProperties += "," + ControlChars.Lf + " PixelFormat:" + curImage.PixelFormat.ToString()
            MessageBox.Show(imageProperties)
        End If
    End Sub

    Private Sub ThumbnailMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ThumbnailMenu.Click
        If Not (curImage Is Nothing) Then '
            ' Callback
            Dim tnCallBack As New Image.GetThumbnailImageAbort(AddressOf tnCallbackMethod)
            ' Get the thumbnail image
            Dim thumbNailImage As Image = curImage.GetThumbnailImage(curImage.Width / 4, curImage.Height / 4, tnCallBack, IntPtr.Zero)
            ' Create a Graphics object
            Dim tmpg As Graphics = Me.CreateGraphics()
            tmpg.Clear(Me.BackColor)
            ' Draw thumbnail image
            tmpg.DrawImage(thumbNailImage, 100, 50)
            ' Dispose Graphics
            tmpg.Dispose()
        End If
    End Sub

    Public Function tnCallbackMethod() As Boolean
        Return False
    End Function 'tnCallbackMethod

    Private Sub Rotate90menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Rotate90menu.Click
        If Not (curImage Is Nothing) Then '
            curImage.RotateFlip(RotateFlipType.Rotate90FlipNone)
            Invalidate()
        End If
    End Sub

    Private Sub Rotate180Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Rotate180Menu.Click
        If Not (curImage Is Nothing) Then '
            curImage.RotateFlip(RotateFlipType.Rotate180FlipNone)
            Invalidate()
        End If
    End Sub

    Private Sub Rotate270Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Rotate270Menu.Click
        If Not (curImage Is Nothing) Then
            curImage.RotateFlip(RotateFlipType.Rotate270FlipNone)
            Invalidate()
        End If
    End Sub

    Private Sub FlipX_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlipX.Click
        If Not (curImage Is Nothing) Then
            curImage.RotateFlip(RotateFlipType.RotateNoneFlipX)
            Invalidate()
        End If
    End Sub

    Private Sub FlipY_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlipY.Click
        If Not (curImage Is Nothing) Then
            curImage.RotateFlip(RotateFlipType.RotateNoneFlipY)
            Invalidate()
        End If
    End Sub

    Private Sub FlipXY_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FlipXY.Click
        If Not (curImage Is Nothing) Then
            curImage.RotateFlip(RotateFlipType.Rotate270FlipXY)
            Invalidate()
        End If
    End Sub

    Private Sub FitHeightMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FitHeightMenu.Click
        Dim wAspectRatio As Double = CDbl(Me.Width) / curImage.Width
        If Not (curImage Is Nothing) Then
            curRect.Height = Me.Height
            Invalidate()
        End If
    End Sub

    Private Sub FitWidthMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FitWidthMenu.Click
        Dim hAspectRatio As Double = CDbl(Me.Height) / curImage.Height
        If Not (curImage Is Nothing) Then
            curRect.Width = Me.Width
            Invalidate()
        End If
    End Sub

    Private Sub FitOriginalMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FitOriginalMenu.Click
        If Not (curImage Is Nothing) Then
            curRect.Height = originalSize.Height
            curRect.Width = originalSize.Width
            Invalidate()
        End If
    End Sub

    Private Sub FitAllMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FitAllMenu.Click
        If Not (curImage Is Nothing) Then
            Dim hAspectRatio As Double = CDbl(Me.Height) / curImage.Height
            Dim wAspectRatio As Double = CDbl(Me.Width) / curImage.Width
            If hAspectRatio <= wAspectRatio Then
                curRect.Height = Me.Height
            End If
            Invalidate()
        End If
    End Sub

    Private Sub Zoom25Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Zoom25Menu.Click
        If Not (curImage Is Nothing) Then
            curZoom = CDbl(25) / 100
            Invalidate()
        End If
    End Sub

    Private Sub Zoom50Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Zoom50Menu.Click
        If Not (curImage Is Nothing) Then
            curZoom = CDbl(100) / 100
            Invalidate()
        End If
    End Sub

    Private Sub Zoom100Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Zoom100Menu.Click
        If Not (curImage Is Nothing) Then
            curZoom = CDbl(100) / 100
            Invalidate()
        End If
    End Sub

    Private Sub Zoom200Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Zoom200Menu.Click
        If Not (curImage Is Nothing) Then
            curZoom = CDbl(200) / 100
            Invalidate()
        End If
    End Sub

    Private Sub Zoom500Menu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Zoom500Menu.Click
        If Not (curImage Is Nothing) Then
            curZoom = CDbl(500) / 100
            Invalidate()
        End If
    End Sub
End Class

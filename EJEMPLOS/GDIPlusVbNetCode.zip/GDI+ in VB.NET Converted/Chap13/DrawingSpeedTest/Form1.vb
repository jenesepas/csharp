imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D
Public Class Form1
    Inherits System.Windows.Forms.Form
    Private drawing As Boolean = False

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents GraphicsDraw As System.Windows.Forms.Button
    Friend WithEvents RectBtn As System.Windows.Forms.Button
    Friend WithEvents DoubleBuff As System.Windows.Forms.Button
    Friend WithEvents BitmapDraw As System.Windows.Forms.Button
    Friend WithEvents button1 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.GraphicsDraw = New System.Windows.Forms.Button
        Me.RectBtn = New System.Windows.Forms.Button
        Me.DoubleBuff = New System.Windows.Forms.Button
        Me.BitmapDraw = New System.Windows.Forms.Button
        Me.button1 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'GraphicsDraw
        '
        Me.GraphicsDraw.Location = New System.Drawing.Point(368, 184)
        Me.GraphicsDraw.Name = "GraphicsDraw"
        Me.GraphicsDraw.Size = New System.Drawing.Size(96, 32)
        Me.GraphicsDraw.TabIndex = 9
        Me.GraphicsDraw.Text = "Graphics Draw"
        '
        'RectBtn
        '
        Me.RectBtn.Location = New System.Drawing.Point(368, 224)
        Me.RectBtn.Name = "RectBtn"
        Me.RectBtn.Size = New System.Drawing.Size(96, 32)
        Me.RectBtn.TabIndex = 8
        Me.RectBtn.Text = "Rectangle Speed"
        '
        'DoubleBuff
        '
        Me.DoubleBuff.Location = New System.Drawing.Point(368, 88)
        Me.DoubleBuff.Name = "DoubleBuff"
        Me.DoubleBuff.Size = New System.Drawing.Size(96, 24)
        Me.DoubleBuff.TabIndex = 7
        Me.DoubleBuff.Text = "Anti Alias"
        '
        'BitmapDraw
        '
        Me.BitmapDraw.Location = New System.Drawing.Point(368, 56)
        Me.BitmapDraw.Name = "BitmapDraw"
        Me.BitmapDraw.Size = New System.Drawing.Size(96, 24)
        Me.BitmapDraw.TabIndex = 6
        Me.BitmapDraw.Text = "Bitmap Draw"
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(368, 24)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(96, 24)
        Me.button1.TabIndex = 5
        Me.button1.Text = "Simple Draw"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(480, 357)
        Me.Controls.Add(Me.GraphicsDraw)
        Me.Controls.Add(Me.RectBtn)
        Me.Controls.Add(Me.DoubleBuff)
        Me.Controls.Add(Me.BitmapDraw)
        Me.Controls.Add(Me.button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub DrawLines(ByVal g As Graphics)
        Dim width As Single = ClientRectangle.Width
        Dim height As Single = ClientRectangle.Height
        Dim partX As Single = width / 1000
        Dim partY As Single = height / 1000
        Dim i As Integer
        For i = 0 To 999

            g.DrawLine(Pens.Blue, 0, height - partY * i, partX * i, 0)
            g.DrawLine(Pens.Green, 0, height - partY * i, width - partX * i, 0)
            g.DrawLine(Pens.Red, 0, partY * i, width - partX * i, 0)
        Next i
    End Sub 'DrawLines

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        ' Create a Graphics object for "this"
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Draw lines
        DrawLines(g)
        ' Garbage Disposal
        g.Dispose()
    End Sub

    Private Sub BitmapDraw_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BitmapDraw.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a Bitmap object with the size of Form
        Dim curBitmap As New Bitmap(ClientRectangle.Width, ClientRectangle.Height)
        ' Create a temp Graphics object from the bitmap
        Dim g1 As Graphics = Graphics.FromImage(curBitmap)
        ' Draw lines on temp Graphics
        DrawLines(g1)
        ' Call DrawImage of Graphics and draw bitmap
        g.DrawImage(curBitmap, 0, 0)
        ' Garbage Disposal
        g1.Dispose()
        curBitmap.Dispose()
        g.Dispose()

    End Sub

    Private Sub DoubleBuff_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DoubleBuff.Click
        ' Activates double buffering
        Me.SetStyle(ControlStyles.UserPaint, True)
        Me.SetStyle(ControlStyles.AllPaintingInWmPaint, True)
        Me.SetStyle(ControlStyles.DoubleBuffer, True)

        'SetStyle(ControlStyles.ResizeRedraw | ControlStyles.Opaque, true);
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a Bitmap object with the size of Form
        Dim curBitmap As New Bitmap(ClientRectangle.Width, ClientRectangle.Height)
        ' Create a temp Graphics object from the bitmap
        Dim g1 As Graphics = Graphics.FromImage(curBitmap)
        ' Set smoothing mode to AntiAlias
        g1.SmoothingMode = SmoothingMode.AntiAlias
        ' Draw lines on temp Graphics
        DrawLines(g1)
        ' Call DrawImage of Graphics and draw bitmap
        g.DrawImage(curBitmap, 0, 0)
        ' Garbage Disposal
        g1.Dispose()
        curBitmap.Dispose()
        g.Dispose()

    End Sub


    Private Sub ResizeRedraw_Click(ByVal sender As Object, ByVal e As System.EventArgs)
        Me.SetStyle(ControlStyles.ResizeRedraw Or ControlStyles.Opaque, True)
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a Bitmap object with the size of Form
        Dim curBitmap As New Bitmap(ClientRectangle.Width, ClientRectangle.Height)
        ' Create a temp Graphics object from the bitmap
        Dim g1 As Graphics = Graphics.FromImage(curBitmap)
        ' Set smoothing mode to AntiAlias
        g1.SmoothingMode = SmoothingMode.AntiAlias
        ' Draw lines on temp Graphics
        DrawLines(g1)
        ' Call DrawImage of Graphics and draw bitmap
        g.DrawImage(curBitmap, 0, 0)
        ' Garbage Disposal
        g1.Dispose()
        curBitmap.Dispose()
        g.Dispose()
    End Sub 'ResizeRedraw_Click

    Private Sub GraphicsDraw_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GraphicsDraw.Click
        ' Create a Graphics object for "this"
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Draw lines
        DrawLines(g)
        ' Garbage Disposal
        g.Dispose()
    End Sub

    Private Sub RectBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RectBtn.Click
        ' Activates double buffering
        Me.SetStyle(ControlStyles.UserPaint, True)
        Me.SetStyle(ControlStyles.AllPaintingInWmPaint, True)
        Me.SetStyle(ControlStyles.DoubleBuffer, True)

        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim bluePen As New Pen(Color.Blue)
        Dim k As Integer = 0
        Dim ch As Integer = 250
        Dim cw As Integer = 250
        Dim i As Integer
        For i = 0 To 10000
            cw = cw - 2
            ch = ch - 2
            k = k + 4
            g.DrawRectangle(bluePen, New Rectangle(cw, ch, k, k))
            Me.Text = i.ToString()
        Next i

        bluePen.Dispose()
        g.Dispose()

    End Sub
End Class

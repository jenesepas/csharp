Imports System
imports System.Drawing
imports System.Collections
imports System.ComponentModel
imports System.Windows.Forms
imports System.Data
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents dataGrid1 As System.Windows.Forms.DataGrid
    Friend WithEvents button1 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.dataGrid1 = New System.Windows.Forms.DataGrid
        Me.button1 = New System.Windows.Forms.Button
        CType(Me.dataGrid1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dataGrid1
        '
        Me.dataGrid1.DataMember = ""
        Me.dataGrid1.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dataGrid1.Location = New System.Drawing.Point(32, 128)
        Me.dataGrid1.Name = "dataGrid1"
        Me.dataGrid1.Size = New System.Drawing.Size(280, 144)
        Me.dataGrid1.TabIndex = 3
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(32, 0)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(280, 128)
        Me.button1.TabIndex = 2
        Me.button1.Text = "button1"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(344, 273)
        Me.Controls.Add(Me.dataGrid1)
        Me.Controls.Add(Me.button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.dataGrid1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Protected Overrides Sub OnPaint(ByVal args As PaintEventArgs)
        ' Add your drawing code here
        Dim g As Graphics = args.Graphics
        g.DrawRectangle(New Pen(Color.Blue, 3), New Rectangle(10, 10, 50, 50))
        g.FillEllipse(Brushes.Red, New Rectangle(60, 60, 100, 100))
        g.DrawString("Text", New Font("Verdana", 14), New SolidBrush(Color.Green), 200, 200)
    End Sub 'OnPaint
End Class

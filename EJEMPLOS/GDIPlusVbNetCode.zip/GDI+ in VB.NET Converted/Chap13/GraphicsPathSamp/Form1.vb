Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
imports System.Drawing.Drawing2D
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents GraphicsPathBtn As System.Windows.Forms.Button
    Friend WithEvents NormalBtn As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.GraphicsPathBtn = New System.Windows.Forms.Button
        Me.NormalBtn = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'GraphicsPathBtn
        '
        Me.GraphicsPathBtn.Location = New System.Drawing.Point(208, 8)
        Me.GraphicsPathBtn.Name = "GraphicsPathBtn"
        Me.GraphicsPathBtn.Size = New System.Drawing.Size(160, 32)
        Me.GraphicsPathBtn.TabIndex = 3
        Me.GraphicsPathBtn.Text = "Draw Using Graphics Path"
        '
        'NormalBtn
        '
        Me.NormalBtn.Location = New System.Drawing.Point(32, 8)
        Me.NormalBtn.Name = "NormalBtn"
        Me.NormalBtn.Size = New System.Drawing.Size(120, 32)
        Me.NormalBtn.TabIndex = 2
        Me.NormalBtn.Text = "Normal Drawing"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(448, 357)
        Me.Controls.Add(Me.GraphicsPathBtn)
        Me.Controls.Add(Me.NormalBtn)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub NormalBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NormalBtn.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Creating a black pen
        Dim blackPen As New Pen(Color.Black, 2)
        ' Draw objects
        g.DrawLine(blackPen, 50, 50, 200, 50)
        g.DrawLine(blackPen, 50, 50, 50, 200)
        g.DrawRectangle(blackPen, 60, 60, 150, 150)
        g.DrawRectangle(blackPen, 70, 70, 100, 100)
        g.DrawEllipse(blackPen, 90, 90, 50, 50)
        ' Dispose
        blackPen.Dispose()
        g.Dispose()
    End Sub

    Private Sub GraphicsPathBtn_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GraphicsPathBtn.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Creating a black pen
        Dim blackPen As New Pen(Color.Black, 2)
        ' Create a graphics path
        Dim path As New GraphicsPath
        path.AddLine(50, 50, 200, 50)
        path.AddLine(50, 50, 50, 200)
        path.AddRectangle(New Rectangle(60, 60, 150, 150))
        path.AddRectangle(New Rectangle(70, 70, 100, 100))
        path.AddEllipse(90, 90, 50, 50)
        g.DrawPath(blackPen, path)
        ' Dispose
        blackPen.Dispose()
        g.Dispose()

    End Sub
End Class

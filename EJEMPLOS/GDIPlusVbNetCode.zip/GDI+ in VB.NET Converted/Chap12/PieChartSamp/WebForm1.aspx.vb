Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Web
Imports System.Web.SessionState
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls
Imports System.Drawing.Imaging
Imports System.Drawing.Drawing2D
Public Class WebForm1
    Inherits System.Web.UI.Page
    Public curBitmap As Bitmap
    Private rect As New Rectangle(250, 150, 200, 200)
    Public sliceList As New ArrayList
    Private curClr As Color = Color.Black
    Dim valArray As Integer() = {50, 25, 75, 100, 50}
    Dim clrArray As Color() = {Color.Red, Color.Green, Color.Yellow, Color.Pink, Color.Aqua}
    Dim total As Integer = 0

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents DrawChart As System.Web.UI.WebControls.Button
    Protected WithEvents FillChart As System.Web.UI.WebControls.Button

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub DrawChart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DrawChart.Click
        DrawPieChart(False)
    End Sub

    Private Sub DrawPieChart(ByVal flMode As Boolean)
        ' Create Bitmap and Graphics objects
        Dim curBitmap As New Bitmap(500, 300)
        Dim g As Graphics = Graphics.FromImage(curBitmap)
        g.SmoothingMode = SmoothingMode.AntiAlias
        Dim angle As Single = 0
        Dim sweep As Single = 0
        ' Total
        Dim i As Integer
        For i = 0 To valArray.Length - 1
            total += valArray(i)
        Next i
        ' Read color and value from array
        ' and caulate sweep
        ' Dim i As Integer
        For i = 0 To valArray.Length - 1
            Dim val As Integer = valArray(i)
            Dim clr As Color = clrArray(i)
            sweep = 360.0F * val / total
            ' If fill mode, fill pie
            If flMode Then
                Dim brush As New SolidBrush(clr)
                g.FillPie(brush, 20.0F, 20.0F, 200, 200, angle, sweep)
                ' If draw mode, dra pie
            Else
                Dim pn As New Pen(clr, 2)
                g.DrawPie(pn, 20.0F, 20.0F, 200, 200, angle, sweep)
            End If
            angle += sweep
        Next i
        ' Send output to the browser
        curBitmap.Save(Me.Response.OutputStream, ImageFormat.Jpeg)
        ' Dispose
        curBitmap.Dispose()
        g.Dispose()
    End Sub 'DrawPieChart

    Private Sub FillChart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FillChart.Click
        DrawPieChart(True)
    End Sub
End Class

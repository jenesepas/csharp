Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Web
Imports System.Web.SessionState
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls
Imports System.Drawing.Imaging
Imports System.Drawing.Drawing2D
Public Class WebForm1
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox3 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox4 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox5 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox6 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox7 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox8 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox9 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox10 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox11 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox12 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox13 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox14 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox15 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents TextBox16 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox17 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox18 As System.Web.UI.WebControls.TextBox

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ' Get the Chart background color
        Dim clr As Color = Color.FromName(TextBox3.Text)
        ' Create a ChartComp object
        Dim chart As New ChartComp(1, clr, 400, 300, Me.Page)
        chart.X0 = 0
        chart.Y0 = 0
        chart.chartX = Convert.ToInt16(TextBox1.Text)
        chart.chartY = Convert.ToInt16(TextBox2.Text)
        ' Add points to the chart
        chart.InsertPoint(Convert.ToInt16(TextBox4.Text), Convert.ToInt16(TextBox5.Text), Color.FromName(TextBox6.Text))
        chart.InsertPoint(Convert.ToInt16(TextBox7.Text), Convert.ToInt16(TextBox8.Text), Color.FromName(TextBox9.Text))
        chart.InsertPoint(Convert.ToInt16(TextBox10.Text), Convert.ToInt16(TextBox11.Text), Color.FromName(TextBox12.Text))
        chart.InsertPoint(Convert.ToInt16(TextBox13.Text), Convert.ToInt16(TextBox14.Text), Color.FromName(TextBox15.Text))
        chart.InsertPoint(Convert.ToInt16(TextBox16.Text), Convert.ToInt16(TextBox17.Text), Color.FromName(TextBox18.Text))
        ' Draw chart
        chart.DrawChart()
    End Sub

    Class ChartComp '
        Public curBitmap As Bitmap
        Public ptsArrayList As New ArrayList
        Public X0 As Single = 0
        Public Y0 As Single = 0
        Public chartX, chartY As Single
        Public chartColor As Color = Color.Gray
        ' ChartType: 1=Line, 2=Pie, 3=Bar. 
        ' For future use only
        Public chartType As Integer = 1
        Private Width, Height As Integer
        Private g As Graphics
        Private curPage As Page

        Structure ptStructure
            Public x As Single
            Public y As Single
            Public clr As Color
        End Structure 'ptStructure

        'ChartComp Constructor
        Public Sub New(ByVal [cType] As Integer, ByVal cColor As Color, ByVal cWidth As Integer, ByVal cHeight As Integer, ByVal cPage As Page)
            Width = cWidth
            Height = cHeight
            chartX = cWidth
            chartY = cHeight
            curPage = cPage
            chartType = [cType]
            chartColor = cColor
            curBitmap = New Bitmap(Width, Height)
            g = Graphics.FromImage(curBitmap)
        End Sub 'New

        ' Descructor. Dispose objects
        'Overloads Overrides Sub Finalize()
        '    curBitmap.Dispose()
        '    g.Dispose()
        '    MyBase.Finalize()
        'End Sub 'Finalize

        ' InsertPoint methods. Adds a point 
        ' to the array
        Public Overloads Sub InsertPoint(ByVal xPos As Integer, ByVal yPos As Integer, ByVal clr As Color)
            Dim pt As ptStructure
            pt.x = xPos
            pt.y = yPos
            pt.clr = clr
            ' Add the point to the array
            ptsArrayList.Add(pt)
        End Sub 'InsertPoint

        Public Overloads Sub InsertPoint(ByVal position As Integer, ByVal xPos As Integer, ByVal yPos As Integer, ByVal clr As Color)
            Dim pt As ptStructure
            pt.x = xPos
            pt.y = yPos
            pt.clr = clr
            ' Add the point to the array
            ptsArrayList.Insert(position, pt)
        End Sub 'InsertPoint

        ' Draw methods
        Public Sub DrawChart()
            Dim i As Integer
            Dim x, y, x0, y0 As Single
            curPage.Response.ContentType = "image/jpeg"
            g.SmoothingMode = SmoothingMode.HighQuality
            g.FillRectangle(New SolidBrush(chartColor), 0, 0, Width, Height)
            Dim chWidth As Integer = Width - 80
            Dim chHeight As Integer = Height - 80
            g.DrawRectangle(Pens.Black, 40, 40, chWidth, chHeight)
            g.DrawString("GDI+ Chart", New Font("arial", 14), Brushes.Black, Width / 3, 10)
            'Draw X and Y axis line, points, positions
            For i = 0 To 5
                x = 40 + i * chWidth / 5
                y = chHeight + 40
                Dim str As String = (X0 + chartX * i / 5).ToString()
                g.DrawString(str, New Font("Verdana", 10), Brushes.Blue, x - 4, y + 10)
                g.DrawLine(Pens.Black, x, y + 2, x, y - 2)
            Next i
            For i = 0 To 5
                x = 40
                y = chHeight + 40 - i * chHeight / 5
                Dim str As String = (Y0 + chartY * i / 5).ToString()
                g.DrawString(str, New Font("Verdana", 10), Brushes.Blue, 5, y - 6)
                g.DrawLine(Pens.Black, x + 2, y, x - 2, y)
            Next i
            'Transform coordinates so (0,0) point starts from
            ' the lower left corner. 
            g.RotateTransform(180)
            g.TranslateTransform(-40, 40)
            g.ScaleTransform(-1, 1)
            g.TranslateTransform(0, -Height)
            ' Draw all points from the array
            Dim prevPoint As New ptStructure
            Dim pt As ptStructure
            For Each pt In ptsArrayList
                x0 = chWidth * (prevPoint.x - X0) / chartX
                y0 = chHeight * (prevPoint.y - Y0) / chartY
                x = chWidth * (pt.x - X0) / chartX
                y = chHeight * (pt.y - Y0) / chartY
                g.DrawLine(Pens.Black, x0, y0, x, y)
                g.FillEllipse(New SolidBrush(pt.clr), x0 - 5, y0 - 5, 10, 10)
                g.FillEllipse(New SolidBrush(pt.clr), x - 5, y - 5, 10, 10)
                prevPoint = pt
            Next pt
            curBitmap.Save(curPage.Response.OutputStream, ImageFormat.Jpeg)
        End Sub 'DrawChart
    End Class 'ChartComp
End Class

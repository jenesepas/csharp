Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Web
Imports System.Web.SessionState
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls
Imports System.Drawing.Imaging
Imports System.Drawing.Drawing2D

Public Class WebForm1
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        'Put user code to initialize the page here
        ' Create a Bitmap and Graphics 
        Dim curBitmap As New Bitmap("d:\flowers.jpg")
        Dim g As Graphics = Graphics.FromImage(curBitmap)
        g.SmoothingMode = SmoothingMode.AntiAlias
        ' Create brushes and pens with alpha values
        Dim redColor As Color = Color.FromArgb(120, 0, 0, 255)
        Dim alphaPen As New Pen(redColor, 5)
        Dim alphaBrush As New SolidBrush(Color.FromArgb(90, 0, 255, 0))
        ' Draw a rectanle, ellipse, and text
        g.DrawRectangle(alphaPen, 10, 20, 180, 20)
        g.FillEllipse(alphaBrush, 50, 50, 100, 100)
        g.DrawString("Aplha String", New Font("Tahoma", 18), New SolidBrush(Color.FromArgb(150, 160, 0, 0)), New PointF(20, 20))
        curBitmap.Save(Me.Response.OutputStream, ImageFormat.Jpeg)
        g.Dispose()
    End Sub

End Class

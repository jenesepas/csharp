Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Web
Imports System.Web.SessionState
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls
imports System.Drawing.Drawing2D
imports System.Drawing.Imaging
Public Class WebForm1
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        ' Create a linear gradeient brush
        Dim lgBrush As New LinearGradientBrush(New Rectangle(0, 0, 10, 10), Color.Yellow, Color.Blue, LinearGradientMode.ForwardDiagonal)
        ' Create a path 
        Dim path As New GraphicsPath
        path.AddEllipse(50, 50, 150, 150)
        path.AddEllipse(10, 10, 50, 50)
        ' Create a path gradient brush
        Dim pgBrush As New PathGradientBrush(path)
        pgBrush.CenterColor = Color.Red
        ' Create Bitmap and Graphics objects
        Dim curBitmap As New Bitmap(500, 300)
        Dim g As Graphics = Graphics.FromImage(curBitmap)
        g.SmoothingMode = SmoothingMode.AntiAlias
        g.FillPath(pgBrush, path)
        g.FillRectangle(lgBrush, 250, 20, 100, 100)
        curBitmap.Save(Me.Response.OutputStream, ImageFormat.Jpeg)
        g.Dispose()
    End Sub

End Class

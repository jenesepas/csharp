Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Web
Imports System.Web.SessionState
Imports System.Web.UI
imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls
Imports System.Drawing.Drawing2D
Imports System.Drawing.Imaging
Imports System.Drawing.Text
Public Class WebForm1
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents Button2 As System.Web.UI.WebControls.Button

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        ' Construct brush and pens
        Dim redPen As New Pen(Color.Red, 3)
        Dim brush As New HatchBrush(HatchStyle.Cross, Color.Yellow, Color.Green)
        Dim hatchPen As New Pen(brush, 2)
        Dim bluePen As New Pen(Color.Blue, 3)
        Dim curBitmap As New Bitmap(300, 200)
        Dim g As Graphics = Graphics.FromImage(curBitmap)
        g.SmoothingMode = SmoothingMode.AntiAlias
        Dim testString As String = "Hello GDI+ On the Web"
        Dim verdana14 As New Font("Verdana", 14)
        Dim tahoma18 As New Font("Tahoma", 18)
        Dim nChars As Integer
        Dim nLines As Integer
        ' Call MeasureString to measure a string
        Dim sz As SizeF = g.MeasureString(testString, verdana14)
        Dim stringDetails As String = "Height: " + sz.Height.ToString() + ", Width: " + sz.Width.ToString()
        g.DrawString(testString, verdana14, Brushes.Wheat, New PointF(40, 70))
        g.DrawRectangle(New Pen(Color.Red, 2), 40.0F, 70.0F, sz.Width, sz.Height)
        sz = g.MeasureString("Ellipse", tahoma18, New SizeF(0.0F, 100.0F), New StringFormat, nChars, nLines)
        stringDetails = "Height: " + sz.Height.ToString() + ", Width: " + sz.Width.ToString() + ", Lines: " + nLines.ToString() + ", Chars: " + nChars.ToString()
        ' Draw Lines
        g.DrawLine(Pens.WhiteSmoke, 10, 20, 180, 20)
        g.DrawLine(Pens.White, 20, 10, 20, 180)
        ' Fill Ellipse
        g.FillEllipse(brush, 120, 100, 100, 100)
        ' Draw String
        g.DrawString("Ellipse", tahoma18, Brushes.Beige, New PointF(40, 20))
        ' Draw Ellipse
        g.DrawEllipse(New Pen(Color.Yellow, 3), 40, 20, sz.Width, sz.Height)
        ' Send output to the Browser and
        ' dispose objects
        curBitmap.Save(Me.Response.OutputStream, ImageFormat.Jpeg)
        g.Dispose()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        ' Create a Bitmap object from a file
        Dim curBitmap As New Bitmap("d:\white_salvia.jpg")
        ' Create a Graphics from Bitmap
        Dim g As Graphics = Graphics.FromImage(curBitmap)
        ' Set modes
        g.SmoothingMode = SmoothingMode.AntiAlias
        ' Send output to the browser
        curBitmap.Save(Me.Response.OutputStream, ImageFormat.Jpeg)
        ' Dispose
        g.Dispose()
    End Sub
End Class

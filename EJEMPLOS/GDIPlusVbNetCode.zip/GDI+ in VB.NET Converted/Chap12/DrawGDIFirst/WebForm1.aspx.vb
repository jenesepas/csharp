Imports System
Imports System.Collections
Imports System.ComponentModel
Imports System.Data
Imports System.Drawing
Imports System.Web
Imports System.Web.SessionState
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.HtmlControls
Imports System.Drawing.Drawing2D
Imports System.Drawing.Imaging
Public Class WebForm1
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        ' Create pens and bruses
        Dim redPen As New Pen(Color.Red, 3)
        Dim brush As New HatchBrush(HatchStyle.Cross, Color.Red, Color.Yellow)
        ' Create a Bitmap
        Dim curBitmap As New Bitmap(200, 200)
        ' Create a Graphics object from Bitmap
        Dim g As Graphics = Graphics.FromImage(curBitmap)
        ' Dra and fill rectangles
        g.FillRectangle(brush, 50, 50, 100, 100)
        g.DrawLine(Pens.WhiteSmoke, 10, 10, 180, 10)
        g.DrawLine(Pens.White, 10, 10, 10, 180)
        ' Save the Bitmap and send response to the 
        ' browser
        curBitmap.Save(Response.OutputStream, ImageFormat.Jpeg)
        ' Dispose Graphics and Bitmap
        curBitmap.Dispose()
        g.Dispose()
    End Sub

End Class

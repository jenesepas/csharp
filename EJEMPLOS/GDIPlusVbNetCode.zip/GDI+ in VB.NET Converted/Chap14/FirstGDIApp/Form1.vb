Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MoveMenu As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents BitBltMenu As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.MoveMenu = New System.Windows.Forms.MenuItem
        Me.menuItem2 = New System.Windows.Forms.MenuItem
        Me.BitBltMenu = New System.Windows.Forms.MenuItem
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1, Me.menuItem2})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MoveMenu})
        Me.menuItem1.Text = "Win32 "
        '
        'MoveMenu
        '
        Me.MoveMenu.Index = 0
        Me.MoveMenu.Text = "Move Function"
        '
        'menuItem2
        '
        Me.menuItem2.Index = 1
        Me.menuItem2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.BitBltMenu})
        Me.menuItem2.Text = "GDI Functionality"
        '
        'BitBltMenu
        '
        Me.BitBltMenu.Index = 0
        Me.BitBltMenu.Text = "BitBlt Function"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(456, 346)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region


    Private Sub MoveMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MoveMenu.Click
        MoveFile("c:\flowers1.jpeg", "d:\flowers.jpeg")
    End Sub
    '<System.Runtime.InteropServices.DllImportAttribute("KERNEL32.dll")>
    Public Shared Function MoveFile(ByVal src As [String], ByVal dst As [String]) As Boolean

    End Function
    '<System.Runtime.InteropServices.DllImport("Gdi32.dll")>

    Public Shared Function BitBlt(ByVal hdcDest As IntPtr, ByVal nXDest As Integer, ByVal nYDest As Integer, ByVal nWidth As Integer, ByVal nHeight As Integer, ByVal hdcSrc As IntPtr, ByVal nXSrc As Integer, ByVal nYSrc As Integer, ByVal dwRop As System.Int32) As Boolean

    End Function
    '<System.Runtime.InteropServices.DllImport("Gdi32.dll")>
    Public Shared Function LineTo(ByVal hdc As IntPtr, ByVal nXEnd As Integer, ByVal nYEnd As Integer) As Boolean

    End Function
    '<System.Runtime.InteropServices.DllImportAttribute("Gdi32.dll")>
    Public Shared Function MoveTo(ByVal hdc As IntPtr, ByVal nXEnd As Integer, ByVal nYEnd As Integer) As Boolean

    End Function
    Private Sub BitBltMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BitBltMenu.Click
        Dim g1 As Graphics = Me.CreateGraphics()
        Dim g2 As Graphics = Nothing
        Try
            g1.SmoothingMode = SmoothingMode.AntiAlias
            g1.DrawLine(New Pen(Color.Black, 2), 10, 10, 150, 10)
            g1.DrawLine(New Pen(Color.Black, 2), 10, 10, 10, 150)
            g1.FillRectangle(Brushes.Blue, 30, 30, 70, 70)
            g1.FillEllipse(New HatchBrush(HatchStyle.DashedDownwardDiagonal, Color.Red, Color.Green), 110, 110, 100, 100)
            Dim curBitmap As New Bitmap(Me.ClientRectangle.Width, Me.ClientRectangle.Height, g1)
            g2 = Graphics.FromImage(curBitmap)
            Dim hdc1 As IntPtr = g1.GetHdc()
            Dim hdc2 As IntPtr = g2.GetHdc()
            BitBlt(hdc2, 0, 0, Me.ClientRectangle.Width, Me.ClientRectangle.Height, hdc1, 0, 0, 13369376)
            g1.ReleaseHdc(hdc1)
            g2.ReleaseHdc(hdc2)
            curBitmap.Save("e:\flowers3.jpg", System.Drawing.Imaging.ImageFormat.Jpeg)
        Catch exp As Exception
            MessageBox.Show(exp.Message.ToString())
        Finally

            g2.Dispose()
            g1.Dispose()
        End Try
        MessageBox.Show("Image Saved")
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D
Imports System.Drawing.Imaging
Public Class Form1
    Inherits System.Windows.Forms.Form
    Public Shared Function BitBlt(ByVal hdcDest As IntPtr, ByVal nXDest As Integer, ByVal nYDest As Integer, ByVal nWidth As Integer, ByVal nHeight As Integer, ByVal hdcSrc As IntPtr, ByVal nXSrc As Integer, ByVal nYSrc As Integer, ByVal dwRop As System.Int32) As Boolean

    End Function


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(328, 273)
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    'Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
    Protected Overrides Sub OnPaint(ByVal e As PaintEventArgs)
        Dim g1 As Graphics = Me.CreateGraphics() '

        Dim g2 As Graphics = Nothing
        Try
            g1.SmoothingMode = SmoothingMode.AntiAlias
            g1.DrawLine(New Pen(Color.Black, 2), 10, 10, 150, 10)
            g1.DrawLine(New Pen(Color.Black, 2), 10, 10, 10, 150)
            g1.FillRectangle(Brushes.Blue, 30, 30, 70, 70)
            g1.FillEllipse(New HatchBrush(HatchStyle.DashedDownwardDiagonal, Color.Red, Color.Green), 110, 110, 100, 100)
            Dim curBitmap As New Bitmap(Me.ClientRectangle.Width, Me.ClientRectangle.Height, g1)
            g2 = Graphics.FromImage(curBitmap)
            Dim hdc1 As IntPtr = g1.GetHdc()
            Dim hdc2 As IntPtr = g2.GetHdc()
            BitBlt(hdc2, 0, 0, Me.ClientRectangle.Width, Me.ClientRectangle.Height, hdc1, 0, 0, 13369376)
            g1.ReleaseHdc(hdc1)
            g2.ReleaseHdc(hdc2)
            curBitmap.Save("d:\flowers.jpg", ImageFormat.Jpeg)
        Catch exp As Exception
            MessageBox.Show(exp.Message.ToString())
        Finally
            g2.Dispose()
            g1.Dispose()
        End Try
    End Sub
End Class

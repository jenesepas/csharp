Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Imaging
Imports System.Drawing.Drawing2D
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents SetColorKey As System.Windows.Forms.MenuItem
    Friend WithEvents ClearColorKey As System.Windows.Forms.MenuItem
    Friend WithEvents SetWrapMode As System.Windows.Forms.MenuItem
    Friend WithEvents SetColorMatrix As System.Windows.Forms.MenuItem
    Friend WithEvents SetNoOp As System.Windows.Forms.MenuItem
    Friend WithEvents SetGamma As System.Windows.Forms.MenuItem
    Friend WithEvents SetThreashold As System.Windows.Forms.MenuItem
    Friend WithEvents SetRemapTable As System.Windows.Forms.MenuItem
    Friend WithEvents SetBrushRemapTable As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.SetColorKey = New System.Windows.Forms.MenuItem
        Me.ClearColorKey = New System.Windows.Forms.MenuItem
        Me.SetWrapMode = New System.Windows.Forms.MenuItem
        Me.SetColorMatrix = New System.Windows.Forms.MenuItem
        Me.SetNoOp = New System.Windows.Forms.MenuItem
        Me.SetGamma = New System.Windows.Forms.MenuItem
        Me.SetThreashold = New System.Windows.Forms.MenuItem
        Me.SetRemapTable = New System.Windows.Forms.MenuItem
        Me.SetBrushRemapTable = New System.Windows.Forms.MenuItem
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.SetColorKey, Me.ClearColorKey, Me.SetWrapMode, Me.SetColorMatrix, Me.SetNoOp, Me.SetGamma, Me.SetThreashold, Me.SetRemapTable, Me.SetBrushRemapTable})
        Me.menuItem1.Text = "ImageAttributes"
        '
        'SetColorKey
        '
        Me.SetColorKey.Index = 0
        Me.SetColorKey.Text = "SetColorKey"
        '
        'ClearColorKey
        '
        Me.ClearColorKey.Index = 1
        Me.ClearColorKey.Text = "ClearColorKey"
        '
        'SetWrapMode
        '
        Me.SetWrapMode.Index = 2
        Me.SetWrapMode.Text = "SetWrapMode"
        '
        'SetColorMatrix
        '
        Me.SetColorMatrix.Index = 3
        Me.SetColorMatrix.Text = "SetColorMatrix"
        '
        'SetNoOp
        '
        Me.SetNoOp.Index = 4
        Me.SetNoOp.Text = "SetNoOp"
        '
        'SetGamma
        '
        Me.SetGamma.Index = 5
        Me.SetGamma.Text = "SetGamma"
        '
        'SetThreashold
        '
        Me.SetThreashold.Index = 6
        Me.SetThreashold.Text = "SetThreashold"
        '
        'SetRemapTable
        '
        Me.SetRemapTable.Index = 7
        Me.SetRemapTable.Text = "SetRemapTable"
        '
        'SetBrushRemapTable
        '
        Me.SetBrushRemapTable.Index = 8
        Me.SetBrushRemapTable.Text = "SetBrushRemapTable"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(384, 346)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub SetColorKey_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetColorKey.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim lClr As Color = Color.FromArgb(245, 0, 0)
        Dim uClr As Color = Color.FromArgb(255, 0, 0)
        Dim ImgAttr As New ImageAttributes
        ImgAttr.SetColorKey(lClr, uClr, ColorAdjustType.Default)

        ' Open an Image file and draw it to the screen.
        Dim curImage As Image = Image.FromFile("f:\dnWatcher.gif")
        g.DrawImage(curImage, 0, 0) '
        ' Draw the image with the color key set.
        Dim rect As New Rectangle(0, 0, 400, 400)
        g.DrawImage(curImage, rect, 0, 0, 400, 400, GraphicsUnit.Pixel, ImgAttr)

        ' Dispose
        g.Dispose()

    End Sub

    Private Sub ClearColorKey_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClearColorKey.Click
        Dim ImgAttr As New ImageAttributes
        ImgAttr.ClearColorKey(ColorAdjustType.Default)
    End Sub

    Private Sub SetWrapMode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetWrapMode.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim lClr As Color = Color.FromArgb(245, 0, 0)
        Dim uClr As Color = Color.FromArgb(255, 0, 0)
        Dim ImgAttr As New ImageAttributes
        ImgAttr.SetWrapMode(WrapMode.Tile, Color.Blue, True)
        Dim curImage As Image = Image.FromFile("f:\dnWatcher.gif")
        g.DrawImage(curImage, 0, 0) '
        Dim rect As New Rectangle(0, 0, 400, 400)
        g.DrawImage(curImage, rect, 0, 0, 400, 400, GraphicsUnit.Pixel, ImgAttr)

        ' Dispose
        g.Dispose()
    End Sub

    Private Sub SetColorMatrix_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetColorMatrix.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim rect As New Rectangle(20, 20, 200, 100)
        Dim bitmap As New Bitmap("")
        Dim ptsArray As Single()() = {New Single() {1, 0, 0, 0, 0}, New Single() {0, 1, 0, 0, 0}, New Single() {0, 0, 1, 0, 0}, New Single() {0, 0, 0, 0.5F, 0}, New Single() {0, 0, 0, 0, 1}}  '
        Dim clrMatrix As New ColorMatrix(ptsArray)
        If clrMatrix.Matrix34 <= 0.5 Then
            clrMatrix.Matrix34 = 0.8F
            clrMatrix.Matrix11 = 0.3F
        End If
        Dim imgAttributes As New ImageAttributes
        imgAttributes.SetColorMatrix(clrMatrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap)
        g.FillRectangle(Brushes.Red, rect)
        rect.Y += 120
        g.FillEllipse(Brushes.Black, rect)
        g.DrawImage(bitmap, New Rectangle(0, 0, bitmap.Width, bitmap.Height), 0, 0, bitmap.Width, bitmap.Height, GraphicsUnit.Pixel, imgAttributes)

        ' Dispose
        g.Dispose()
    End Sub

    Private Sub SetNoOp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetNoOp.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim lClr As Color = Color.FromArgb(245, 0, 0)
        Dim uClr As Color = Color.FromArgb(255, 0, 0)
        Dim ImgAttr As New ImageAttributes
        ImgAttr.SetColorKey(lClr, uClr, ColorAdjustType.Default)
        ImgAttr.SetGamma(2.0F, ColorAdjustType.Default)
        ImgAttr.SetNoOp(ColorAdjustType.Default)
        Dim curImage As Image = Image.FromFile("f:\dnWatcher.gif")
        g.DrawImage(curImage, 0, 0) '
        Dim rect As New Rectangle(0, 0, 400, 400)
        g.DrawImage(curImage, rect, 0, 0, 400, 400, GraphicsUnit.Pixel, ImgAttr)

        ' Dispose
        g.Dispose()
    End Sub

    Private Sub SetGamma_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetGamma.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim lClr As Color = Color.FromArgb(245, 0, 0)
        Dim uClr As Color = Color.FromArgb(255, 0, 0)
        Dim ImgAttr As New ImageAttributes
        ImgAttr.SetGamma(2.0F, ColorAdjustType.Default)
        Dim curImage As Image = Image.FromFile("f:\dnWatcher.gif")
        g.DrawImage(curImage, 0, 0) '
        Dim rect As New Rectangle(0, 0, 400, 400)
        g.DrawImage(curImage, rect, 0, 0, 400, 400, GraphicsUnit.Pixel, ImgAttr)
        ' Dispose
        g.Dispose()
    End Sub

    Private Sub SetThreashold_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetThreashold.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim lClr As Color = Color.FromArgb(245, 0, 0)
        Dim uClr As Color = Color.FromArgb(255, 0, 0)
        Dim ImgAttr As New ImageAttributes
        ImgAttr.SetThreshold(0.7F, ColorAdjustType.Default)
        Dim curImage As Image = Image.FromFile("f:\dnWatcher.gif")
        g.DrawImage(curImage, 0, 0) '
        Dim rect As New Rectangle(0, 0, 400, 400)
        g.DrawImage(curImage, rect, 0, 0, 400, 400, GraphicsUnit.Pixel, ImgAttr)
        ' Dispose
        g.Dispose()
    End Sub

    Private Sub SetRemapTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetRemapTable.Click

    End Sub

    Private Sub SetBrushRemapTable_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetBrushRemapTable.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim lClr As Color = Color.FromArgb(245, 0, 0)
        Dim uClr As Color = Color.FromArgb(255, 0, 0)
        Dim clrMapTable(1) As ColorMap
        clrMapTable(0) = New ColorMap
        clrMapTable(0).OldColor = lClr
        clrMapTable(0).NewColor = uClr
        Dim ImgAttr As New ImageAttributes
        ImgAttr.SetBrushRemapTable(clrMapTable)

        Dim curImage As Image = Image.FromFile("f:\dnWatcher.gif")
        g.DrawImage(curImage, 0, 0) '
        Dim rect As New Rectangle(0, 0, 400, 400)
        g.DrawImage(curImage, rect, 0, 0, 400, 400, GraphicsUnit.Pixel, ImgAttr)

        ' Dispose
        g.Dispose()
    End Sub
End Class

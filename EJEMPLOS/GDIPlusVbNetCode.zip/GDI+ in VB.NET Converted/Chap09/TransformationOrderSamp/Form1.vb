Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents DefMenu As System.Windows.Forms.MenuItem
    Friend WithEvents FirstMenu As System.Windows.Forms.MenuItem
    Friend WithEvents SecMenu As System.Windows.Forms.MenuItem
    Friend WithEvents ThirdMenu As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.DefMenu = New System.Windows.Forms.MenuItem
        Me.FirstMenu = New System.Windows.Forms.MenuItem
        Me.SecMenu = New System.Windows.Forms.MenuItem
        Me.ThirdMenu = New System.Windows.Forms.MenuItem
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.DefMenu, Me.FirstMenu, Me.SecMenu, Me.ThirdMenu})
        Me.menuItem1.Text = "Transformation Order"
        '
        'DefMenu
        '
        Me.DefMenu.Index = 0
        Me.DefMenu.Text = "Default"
        '
        'FirstMenu
        '
        Me.FirstMenu.Index = 1
        Me.FirstMenu.Text = "First Change"
        '
        'SecMenu
        '
        Me.SecMenu.Index = 2
        Me.SecMenu.Text = "Second Change"
        '
        'ThirdMenu
        '
        Me.ThirdMenu.Index = 3
        Me.ThirdMenu.Text = "Third Change"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(448, 386)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub DefMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DefMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim rect As New Rectangle(20, 20, 100, 100)
        Dim brush As New SolidBrush(Color.Red)
        g.FillRectangle(brush, rect)
        g.ScaleTransform(1.75F, 0.5F)
        g.RotateTransform(45.0F, MatrixOrder.Append)
        g.TranslateTransform(150.0F, 50.0F, MatrixOrder.Append)
        g.FillRectangle(brush, rect)

        g.Dispose()

    End Sub

    Private Sub FirstMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FirstMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim rect As New Rectangle(20, 20, 100, 100)
        Dim brush As New SolidBrush(Color.Red)
        g.FillRectangle(brush, rect)
        g.TranslateTransform(100.0F, 50.0F, MatrixOrder.Append)
        g.RotateTransform(45.0F, MatrixOrder.Append)
        g.ScaleTransform(1.75F, 0.5F)
        g.FillRectangle(brush, rect)

        g.Dispose()
    End Sub

    Private Sub SecMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SecMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim rect As New Rectangle(20, 20, 100, 100)
        Dim brush As New SolidBrush(Color.Red)
        g.FillRectangle(brush, rect)
        g.TranslateTransform(100.0F, 50.0F, MatrixOrder.Prepend)
        g.RotateTransform(45.0F, MatrixOrder.Prepend)
        g.ScaleTransform(1.75F, 0.5F)
        g.FillRectangle(brush, rect)

        g.Dispose()
    End Sub

    Private Sub ThirdMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ThirdMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)


        g.Dispose()
    End Sub
End Class

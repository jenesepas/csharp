Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D
Imports System.Drawing.Text

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents TransformUnits As System.Windows.Forms.MenuItem
    Friend WithEvents SaveRestoreMenu As System.Windows.Forms.MenuItem
    Friend WithEvents DrawTextMenu As System.Windows.Forms.MenuItem
    Friend WithEvents DrawShapesMenu As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.TransformUnits = New System.Windows.Forms.MenuItem
        Me.SaveRestoreMenu = New System.Windows.Forms.MenuItem
        Me.DrawTextMenu = New System.Windows.Forms.MenuItem
        Me.DrawShapesMenu = New System.Windows.Forms.MenuItem
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.TransformUnits, Me.SaveRestoreMenu, Me.DrawTextMenu, Me.DrawShapesMenu})
        Me.menuItem1.Text = "Graphics Containers"
        '
        'TransformUnits
        '
        Me.TransformUnits.Index = 0
        Me.TransformUnits.Text = "Transformation - Units"
        '
        'SaveRestoreMenu
        '
        Me.SaveRestoreMenu.Index = 1
        Me.SaveRestoreMenu.Text = "Save Restore Graphics States"
        '
        'DrawTextMenu
        '
        Me.DrawTextMenu.Index = 2
        Me.DrawTextMenu.Text = "Draw Text"
        '
        'DrawShapesMenu
        '
        Me.DrawShapesMenu.Index = 3
        Me.DrawShapesMenu.Text = "Draw Shapes"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(440, 378)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub SaveRestoreMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveRestoreMenu.Click
        ' Create a Graphics object and set its 
        ' background as form's background
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Page transformation
        g.PageUnit = GraphicsUnit.Pixel
        ' World transformation
        g.RotateTransform(45, MatrixOrder.Append)
        ' Save first graphics state
        Dim gs1 As GraphicsState = g.Save()
        ' one more tranfromation
        g.TranslateTransform(0, 110)
        ' Save graphics state again
        Dim gs2 As GraphicsState = g.Save()
        ' Dismiss all transformation affects by resetting it
        g.ResetTransform()
        ' Draw a simple ellipse with no transformation
        g.DrawEllipse(Pens.Red, 100, 0, 100, 50)
        ' Restore first graphics state, which means 
        ' new item should rotate 45 degrees
        g.Restore(gs1)
        g.FillRectangle(Brushes.Blue, 100, 0, 100, 50)
        ' Restore second graphics state which means
        g.Restore(gs2)
        g.DrawEllipse(Pens.Green, 100, 50, 100, 50)
        'Dispose Graphics object
        g.Dispose()
    End Sub

    Private Sub DrawTextMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DrawTextMenu.Click
        ' Create a Graphics object and set its 
        ' background as form's background
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create font and brushes
        Dim tnrFont As New Font("Times New Roman", 40, FontStyle.Bold, GraphicsUnit.Pixel)
        Dim blueBrush As New SolidBrush(Color.Blue)
        g.TextRenderingHint = TextRenderingHint.SystemDefault
        ' First Container boundary starts here
        Dim gContrainer1 As GraphicsContainer = g.BeginContainer()
        ' Gamma correction value 0 - 12. Default is 4.
        g.TextContrast = 4
        g.TextRenderingHint = TextRenderingHint.AntiAlias
        g.DrawString("Text String", tnrFont, blueBrush, New PointF(10, 20))
        ' Second Container boundary starts here
        Dim gContrainer2 As GraphicsContainer = g.BeginContainer()
        g.TextContrast = 12
        g.TextRenderingHint = TextRenderingHint.AntiAliasGridFit
        g.DrawString("Text String", tnrFont, blueBrush, New PointF(10, 50))
        ' Second container boundary finishes here
        g.EndContainer(gContrainer2)
        ' First container boundary finishes here
        g.EndContainer(gContrainer1)
        ' Draw string outside of the container
        g.DrawString("Text String", tnrFont, blueBrush, New PointF(10, 80))
        ' Dispose Graphics object
        blueBrush.Dispose()
        g.Dispose()
    End Sub

    Private Sub DrawShapesMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DrawShapesMenu.Click
        ' Create a Graphics object and set its 
        ' background as form's background
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create pens
        Dim redPen As New Pen(Color.Red, 20)
        Dim bluePen As New Pen(Color.Blue, 10)
        ' Create first Graphics container
        Dim gContainer1 As GraphicsContainer = g.BeginContainer()
        ' Set its properties
        g.SmoothingMode = SmoothingMode.AntiAlias
        g.CompositingQuality = CompositingQuality.GammaCorrected
        ' Draw graphics objects
        g.DrawEllipse(redPen, 10, 10, 100, 50)
        g.DrawRectangle(bluePen, 210, 0, 100, 100)
        ' Create second Graphics container
        Dim gContainer2 As GraphicsContainer = g.BeginContainer()
        ' Set its properties
        g.SmoothingMode = SmoothingMode.HighSpeed
        g.CompositingQuality = CompositingQuality.HighSpeed
        ' Draw graphics objects
        g.DrawEllipse(redPen, 10, 150, 100, 50)
        g.DrawRectangle(bluePen, 210, 150, 100, 100)
        ' Destroy containers
        g.EndContainer(gContainer2)
        g.EndContainer(gContainer1)
        'Dispose
        redPen.Dispose()
        bluePen.Dispose()
        g.Dispose()
    End Sub

    Private Sub TransformUnits_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TransformUnits.Click
        ' Create a Graphics object and set its 
        ' background as form's background
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Draw an ellipse with default units
        g.DrawEllipse(Pens.Red, 0, 0, 100, 50)
        ' Draw an ellipse with page unit as pixel
        g.PageUnit = GraphicsUnit.Pixel
        g.DrawEllipse(Pens.Red, 0, 0, 100, 50)
        ' Draw an ellipse with page unit as millimeter
        g.PageUnit = GraphicsUnit.Millimeter
        g.DrawEllipse(Pens.Blue, 0, 0, 100, 50)
        ' Draw an ellipse with page unit as point
        g.PageUnit = GraphicsUnit.Point
        g.DrawEllipse(Pens.Green, 0, 0, 100, 50)
        'Dispose
        g.Dispose()
    End Sub
End Class

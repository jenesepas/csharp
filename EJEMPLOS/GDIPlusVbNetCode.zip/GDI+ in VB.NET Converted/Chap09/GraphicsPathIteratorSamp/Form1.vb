Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(304, 273)
        Me.Name = "Form1"
        Me.Text = "GraphicsPathIterator Sample"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Protected Overrides Sub Onpaint(ByVal e As PaintEventArgs)
        '
        'ToDo: Error processing original source shown below
        'System.Char[]
        '^--- Syntax error: '}' expected
        ' Get the Graphics object
        Dim g As Graphics = e.Graphics
        ' Create a Rectangle
        Dim rect As New Rectangle(50, 50, 100, 50)
        ' Create a Graphics path
        Dim path As New GraphicsPath
        Dim ptsArray As PointF() = {New PointF(20, 20), New PointF(60, 12), New PointF(100, 20)}
        ' Add a curve, rectangle, ellipse, and a line
        path.AddCurve(ptsArray)
        path.AddRectangle(rect)
        rect.Y += 60
        path.AddEllipse(rect)
        path.AddLine(120, 50, 220, 100)
        ' Draw path
        g.DrawPath(Pens.Blue, path)
        ' Create a Graphics path iterator
        Dim pathIterator As New GraphicsPathIterator(path)
        ' Display total points and sub paths
        Dim str As String = "Total points = " + pathIterator.Count.ToString()
        str += ", Sub paths = " + pathIterator.SubpathCount.ToString()
        MessageBox.Show(str)
        ' rewind
        pathIterator.Rewind()
        ' Read all subpaths and their properties
        Dim i As Integer
        For i = 0 To pathIterator.SubpathCount - 1
            Dim strtIdx, endIdx As Integer
            Dim bClosedCurve As Boolean
            pathIterator.NextSubpath(strtIdx, endIdx, bClosedCurve)
            str = "Start Index = " + strtIdx.ToString() + ", End Index = " + endIdx.ToString() + ", IsClosed = " + bClosedCurve.ToString()
            MessageBox.Show(str)
        Next i
    End Sub
End Class

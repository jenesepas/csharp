Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents ShapedForm As System.Windows.Forms.MenuItem
    Friend WithEvents FilledText As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.ShapedForm = New System.Windows.Forms.MenuItem
        Me.FilledText = New System.Windows.Forms.MenuItem
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.ShapedForm, Me.FilledText})
        Me.menuItem1.Text = "Text Shapes"
        '
        'ShapedForm
        '
        Me.ShapedForm.Index = 0
        Me.ShapedForm.Text = "Shaped Form"
        '
        'FilledText
        '
        Me.FilledText.Index = 1
        Me.FilledText.Text = "Filled Text"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(624, 394)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"

    End Sub

#End Region

    Private Sub ShapedForm_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ShapedForm.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim path As New GraphicsPath(FillMode.Alternate)
        path.AddString("Close? Right Click!", New FontFamily("Verdana"), CInt(FontStyle.Bold), 50, New Point(0, 0), StringFormat.GenericDefault) '
        path.AddRectangle(New Rectangle(20, 70, 100, 100))

        path.AddEllipse(New Rectangle(140, 70, 100, 100))
        path.AddEllipse(New Rectangle(260, 70, 100, 100))
        path.AddRectangle(New Rectangle(380, 70, 100, 100))
        Dim rgn As New [Region](path)
        Me.Region = rgn
        Me.BackColor = Color.Red
        g.Dispose() '

    End Sub

    Protected Overrides Sub OnmouseDown(ByVal e As MouseEventArgs)
        If (e.Button = MouseButtons.Right) Then
            Me.Close()
        End If

    End Sub

    Private Sub FilledText_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FilledText.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim path As New GraphicsPath(FillMode.Alternate)
        path.AddString("Hello", New FontFamily("Verdana"), CInt(FontStyle.Bold), 200, New Point(0, 0), StringFormat.GenericDefault)
        g.FillPath(New SolidBrush(Color.Green), path)
        Dim rgn As New [Region](path)
        g.SetClip(path)

        Dim h As Integer = Me.Height
        Dim clr As Integer = 255 / (Me.Height / 3)

        Dim i As Integer
        For i = 0 To h - 3 Step 3
            If clr > 255 Then
                clr = clr Mod 255
            End If
            g.DrawLine(New Pen(Color.FromArgb(255, clr, 0, 0), 2), 0, i, Me.Width, i)
            clr += i
        Next i
        g.Dispose()
    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents GeneralMenu As System.Windows.Forms.MenuItem
    Friend WithEvents AntiAliasMenu As System.Windows.Forms.MenuItem
    Friend WithEvents PixelOffsetModeMenu As System.Windows.Forms.MenuItem
    Friend WithEvents groupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents radioButton6 As System.Windows.Forms.RadioButton
    Friend WithEvents radioButton5 As System.Windows.Forms.RadioButton
    Friend WithEvents radioButton4 As System.Windows.Forms.RadioButton
    Friend WithEvents radioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents radioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents radioButton1 As System.Windows.Forms.RadioButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.GeneralMenu = New System.Windows.Forms.MenuItem
        Me.AntiAliasMenu = New System.Windows.Forms.MenuItem
        Me.PixelOffsetModeMenu = New System.Windows.Forms.MenuItem
        Me.groupBox1 = New System.Windows.Forms.GroupBox
        Me.radioButton6 = New System.Windows.Forms.RadioButton
        Me.radioButton5 = New System.Windows.Forms.RadioButton
        Me.radioButton4 = New System.Windows.Forms.RadioButton
        Me.radioButton3 = New System.Windows.Forms.RadioButton
        Me.radioButton2 = New System.Windows.Forms.RadioButton
        Me.radioButton1 = New System.Windows.Forms.RadioButton
        Me.groupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.GeneralMenu, Me.AntiAliasMenu, Me.PixelOffsetModeMenu})
        Me.menuItem1.Text = "Drawing Quality"
        '
        'GeneralMenu
        '
        Me.GeneralMenu.Index = 0
        Me.GeneralMenu.Text = "General"
        '
        'AntiAliasMenu
        '
        Me.AntiAliasMenu.Index = 1
        Me.AntiAliasMenu.Text = "Anti Aliasing"
        '
        'PixelOffsetModeMenu
        '
        Me.PixelOffsetModeMenu.Index = 2
        Me.PixelOffsetModeMenu.Text = "PixelOffsetMode"
        '
        'groupBox1
        '
        Me.groupBox1.Controls.Add(Me.radioButton6)
        Me.groupBox1.Controls.Add(Me.radioButton5)
        Me.groupBox1.Controls.Add(Me.radioButton4)
        Me.groupBox1.Controls.Add(Me.radioButton3)
        Me.groupBox1.Controls.Add(Me.radioButton2)
        Me.groupBox1.Controls.Add(Me.radioButton1)
        Me.groupBox1.Location = New System.Drawing.Point(264, 16)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(120, 176)
        Me.groupBox1.TabIndex = 1
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "PixelOffsetMode"
        '
        'radioButton6
        '
        Me.radioButton6.Location = New System.Drawing.Point(24, 144)
        Me.radioButton6.Name = "radioButton6"
        Me.radioButton6.Size = New System.Drawing.Size(72, 16)
        Me.radioButton6.TabIndex = 5
        Me.radioButton6.Text = "None"
        '
        'radioButton5
        '
        Me.radioButton5.Location = New System.Drawing.Point(24, 120)
        Me.radioButton5.Name = "radioButton5"
        Me.radioButton5.Size = New System.Drawing.Size(72, 16)
        Me.radioButton5.TabIndex = 4
        Me.radioButton5.Text = "Invalid"
        '
        'radioButton4
        '
        Me.radioButton4.Location = New System.Drawing.Point(24, 96)
        Me.radioButton4.Name = "radioButton4"
        Me.radioButton4.Size = New System.Drawing.Size(80, 16)
        Me.radioButton4.TabIndex = 3
        Me.radioButton4.Text = "HighSpeed"
        '
        'radioButton3
        '
        Me.radioButton3.Location = New System.Drawing.Point(24, 72)
        Me.radioButton3.Name = "radioButton3"
        Me.radioButton3.Size = New System.Drawing.Size(80, 16)
        Me.radioButton3.TabIndex = 2
        Me.radioButton3.Text = "HighQuality"
        '
        'radioButton2
        '
        Me.radioButton2.Location = New System.Drawing.Point(24, 48)
        Me.radioButton2.Name = "radioButton2"
        Me.radioButton2.Size = New System.Drawing.Size(72, 16)
        Me.radioButton2.TabIndex = 1
        Me.radioButton2.Text = "Half"
        '
        'radioButton1
        '
        Me.radioButton1.Checked = True
        Me.radioButton1.Location = New System.Drawing.Point(24, 24)
        Me.radioButton1.Name = "radioButton1"
        Me.radioButton1.Size = New System.Drawing.Size(80, 16)
        Me.radioButton1.TabIndex = 0
        Me.radioButton1.TabStop = True
        Me.radioButton1.Text = "Default"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(400, 334)
        Me.Controls.Add(Me.groupBox1)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.groupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub GeneralMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GeneralMenu.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create three pens
        Dim redPen As New Pen(Color.Red, 6)
        Dim bluePen As New Pen(Color.Blue, 10)
        Dim blackPen As New Pen(Color.Black, 5)
        ' Set smoothing mode
        'g.SmoothingMode = SmoothingMode.AntiAlias;
        ' Draw a rectanlge, an ellipse, and a line
        g.DrawRectangle(bluePen, 10, 20, 100, 50)
        g.DrawEllipse(redPen, 10, 150, 100, 50)
        g.DrawLine(blackPen, 150, 100, 250, 220)
        ' Dispose
        redPen.Dispose()
        bluePen.Dispose()
        blackPen.Dispose()
        g.Dispose()
    End Sub

    Private Sub AntiAliasMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AntiAliasMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim redPen As New Pen(Color.Red, 6)
        Dim bluePen As New Pen(Color.Blue, 10)
        Dim blackPen As New Pen(Color.Black, 5)
        g.SmoothingMode = SmoothingMode.AntiAlias
        g.DrawRectangle(bluePen, 10, 20, 100, 50)
        g.DrawEllipse(redPen, 10, 150, 100, 50)
        g.DrawLine(blackPen, 150, 100, 250, 220)
        g.Dispose()
    End Sub

    Private Sub PixelOffsetModeMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PixelOffsetModeMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        Dim redPen As New Pen(Color.Red, 6)
        Dim bluePen As New Pen(Color.Blue, 10)
        Dim blackPen As New Pen(Color.Black, 5)
        g.PixelOffsetMode = PixelOffsetMode.Half
        g.DrawRectangle(bluePen, 10, 20, 100, 50)
        g.DrawEllipse(redPen, 10, 150, 100, 50)
        g.DrawLine(blackPen, 150, 100, 250, 220)
        g.Dispose()

    End Sub
End Class

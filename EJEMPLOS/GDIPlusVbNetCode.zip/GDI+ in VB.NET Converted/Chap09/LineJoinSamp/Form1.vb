Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents groupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents MiterClippedRadBtn As System.Windows.Forms.RadioButton
    Friend WithEvents RoundRadBtn As System.Windows.Forms.RadioButton
    Friend WithEvents MiterRadBtn As System.Windows.Forms.RadioButton
    Friend WithEvents BevelRadBtn As System.Windows.Forms.RadioButton
    Friend WithEvents ApplyJoin As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.groupBox1 = New System.Windows.Forms.GroupBox
        Me.MiterClippedRadBtn = New System.Windows.Forms.RadioButton
        Me.RoundRadBtn = New System.Windows.Forms.RadioButton
        Me.MiterRadBtn = New System.Windows.Forms.RadioButton
        Me.BevelRadBtn = New System.Windows.Forms.RadioButton
        Me.ApplyJoin = New System.Windows.Forms.Button
        Me.groupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'groupBox1
        '
        Me.groupBox1.Controls.Add(Me.MiterClippedRadBtn)
        Me.groupBox1.Controls.Add(Me.RoundRadBtn)
        Me.groupBox1.Controls.Add(Me.MiterRadBtn)
        Me.groupBox1.Controls.Add(Me.BevelRadBtn)
        Me.groupBox1.Location = New System.Drawing.Point(320, 18)
        Me.groupBox1.Name = "groupBox1"
        Me.groupBox1.Size = New System.Drawing.Size(152, 152)
        Me.groupBox1.TabIndex = 3
        Me.groupBox1.TabStop = False
        Me.groupBox1.Text = "Line Join"
        '
        'MiterClippedRadBtn
        '
        Me.MiterClippedRadBtn.Location = New System.Drawing.Point(16, 88)
        Me.MiterClippedRadBtn.Name = "MiterClippedRadBtn"
        Me.MiterClippedRadBtn.Size = New System.Drawing.Size(120, 24)
        Me.MiterClippedRadBtn.TabIndex = 3
        Me.MiterClippedRadBtn.Text = "Miter Clipped"
        '
        'RoundRadBtn
        '
        Me.RoundRadBtn.Location = New System.Drawing.Point(16, 120)
        Me.RoundRadBtn.Name = "RoundRadBtn"
        Me.RoundRadBtn.Size = New System.Drawing.Size(112, 24)
        Me.RoundRadBtn.TabIndex = 2
        Me.RoundRadBtn.Text = "Round"
        '
        'MiterRadBtn
        '
        Me.MiterRadBtn.Location = New System.Drawing.Point(16, 56)
        Me.MiterRadBtn.Name = "MiterRadBtn"
        Me.MiterRadBtn.Size = New System.Drawing.Size(120, 24)
        Me.MiterRadBtn.TabIndex = 1
        Me.MiterRadBtn.Text = "Miter"
        '
        'BevelRadBtn
        '
        Me.BevelRadBtn.Checked = True
        Me.BevelRadBtn.Location = New System.Drawing.Point(16, 24)
        Me.BevelRadBtn.Name = "BevelRadBtn"
        Me.BevelRadBtn.Size = New System.Drawing.Size(112, 24)
        Me.BevelRadBtn.TabIndex = 0
        Me.BevelRadBtn.TabStop = True
        Me.BevelRadBtn.Text = "Bevel"
        '
        'ApplyJoin
        '
        Me.ApplyJoin.Location = New System.Drawing.Point(344, 194)
        Me.ApplyJoin.Name = "ApplyJoin"
        Me.ApplyJoin.Size = New System.Drawing.Size(112, 32)
        Me.ApplyJoin.TabIndex = 2
        Me.ApplyJoin.Text = "Apply LineJoin"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(488, 245)
        Me.Controls.Add(Me.groupBox1)
        Me.Controls.Add(Me.ApplyJoin)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.groupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ApplyJoin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ApplyJoin.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Line join type
        If BevelRadBtn.Checked Then
            DrawJoinedLines(g, LineJoin.Bevel)
        End If
        If MiterRadBtn.Checked Then
            DrawJoinedLines(g, LineJoin.Miter)
        End If
        If MiterClippedRadBtn.Checked Then
            DrawJoinedLines(g, LineJoin.MiterClipped)
        End If
        If RoundRadBtn.Checked Then
            DrawJoinedLines(g, LineJoin.Round)
        End If
        ' Dispose
        g.Dispose()

    End Sub


    Private Sub DrawJoinedLines(ByVal g As Graphics, ByVal joinType As LineJoin)
        ' Set smoothing mode
        g.SmoothingMode = SmoothingMode.AntiAlias
        ' Create a pen with widht 20
        Dim redPen As New Pen(Color.Red, 20)
        ' Set line join
        redPen.LineJoin = joinType
        ' Create an array of points
        Dim pts As Point() = {New Point(150, 20), New Point(50, 20), New Point(80, 60), New Point(50, 150), New Point(150, 150)}
        ' Create a rectangle using lines
        Dim pts1 As Point() = {New Point(200, 20), New Point(300, 20), New Point(300, 120), New Point(200, 120), New Point(200, 20)}

        ' Draw lines
        g.DrawLines(redPen, pts)
        g.DrawLines(redPen, pts1)
        ' Dispose
        redPen.Dispose()
    End Sub 'DrawJoinedLines
End Class

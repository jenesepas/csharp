Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents GpSample As System.Windows.Forms.MenuItem
    Friend WithEvents CreateMenu As System.Windows.Forms.MenuItem
    Friend WithEvents Properties As System.Windows.Forms.MenuItem
    Friend WithEvents DrawPathMenu As System.Windows.Forms.MenuItem
    Friend WithEvents SubPathMenu As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.GpSample = New System.Windows.Forms.MenuItem
        Me.CreateMenu = New System.Windows.Forms.MenuItem
        Me.Properties = New System.Windows.Forms.MenuItem
        Me.DrawPathMenu = New System.Windows.Forms.MenuItem
        Me.SubPathMenu = New System.Windows.Forms.MenuItem
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.GpSample, Me.CreateMenu, Me.Properties, Me.DrawPathMenu, Me.SubPathMenu})
        Me.menuItem1.Text = "Graphics Path"
        '
        'GpSample
        '
        Me.GpSample.Index = 0
        Me.GpSample.Text = "GraphicsPath Sample"
        '
        'CreateMenu
        '
        Me.CreateMenu.Index = 1
        Me.CreateMenu.Text = "Create"
        '
        'Properties
        '
        Me.Properties.Index = 2
        Me.Properties.Text = "Properties"
        '
        'DrawPathMenu
        '
        Me.DrawPathMenu.Index = 3
        Me.DrawPathMenu.Text = "Draw GraphicsPath"
        '
        'SubPathMenu
        '
        Me.SubPathMenu.Index = 4
        Me.SubPathMenu.Text = "Sub Paths"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(448, 386)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Graphics Path Sample"

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub CreateMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CreateMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim greenPen As New Pen(Brushes.Green, 3)
        Dim path As New GraphicsPath
        Dim rect As New Rectangle(20, 20, 200, 100)
        path.AddLine(20, 30, 150, 70)
        path.AddArc(10, 10, 100, 50, 0, 180)
        path.AddRectangle(rect)
        g.DrawPath(greenPen, path)
        ' Getting GraphicsPath properties
        Dim fMode As FillMode = path.FillMode
        Dim data As PathData = path.PathData
        Dim pts As PointF() = path.PathPoints
        Dim ptsTypes As Byte() = path.PathTypes
        Dim count As Integer = path.PointCount

        ' Dispose
        g.Dispose()

    End Sub

    Private Sub GpSample_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GpSample.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        g.SmoothingMode = SmoothingMode.AntiAlias
        ' Create a Graphics path
        Dim path As New GraphicsPath
        ' Add two lines, a rectangle, and 
        ' an ellipse
        path.AddLine(20, 20, 200, 20)
        path.AddLine(20, 20, 20, 200)
        path.AddRectangle(New Rectangle(30, 30, 100, 100))
        path.AddEllipse(New Rectangle(50, 50, 60, 60))
        ' Draw path
        Dim redPen As New Pen(Color.Red, 2)
        g.DrawPath(redPen, path)
        g.FillPath(New SolidBrush(Color.Black), path)
        ' Dispose
        redPen.Dispose()
        g.Dispose()
    End Sub

    Private Sub DrawPathMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DrawPathMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim redPen As New Pen(Brushes.Red, 3)
        Dim rect As New Rectangle(70, 15, 50, 50)
        Dim path As New GraphicsPath
        path.AddArc(20, 150, 200, 100, 0, 180)
        path.AddLine(20, 40, 220, 190)
        path.AddLine(20, 220, 320, 20)
        path.AddRectangle(rect)
        path.AddEllipse(250, 200, 50, 50)
        g.DrawPath(redPen, path)

        ' Dispose
        g.Dispose()
    End Sub

    Private Sub Properties_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Properties.Click

    End Sub

    Private Sub SubPathMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SubPathMenu.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a GraphicsPath
        Dim path As New GraphicsPath
        ' Create an array of points 
        Dim pts As Point() = {New Point(40, 80), New Point(50, 70), New Point(70, 90), New Point(100, 120), New Point(80, 120)}
        ' Start first figure and add an 
        ' arc and a line
        path.StartFigure()
        path.AddArc(250, 80, 100, 50, 30, -180)
        path.AddLine(180, 220, 320, 80)
        ' Close first figure
        path.CloseFigure()
        ' Start second figure and two lines 
        ' and a curve and close all figures
        path.StartFigure()
        path.AddLine(50, 20, 5, 90)
        path.AddLine(50, 150, 150, 180)
        path.AddCurve(pts, 5)
        path.CloseAllFigures()
        ' Create third graphics and don't close
        ' it
        path.StartFigure()
        path.AddLine(200, 230, 250, 200)
        path.AddLine(200, 230, 250, 270)
        ' Draw path
        g.DrawPath(New Pen(Color.FromArgb(255, 255, 0, 0), 2), path)
        'path.Reverse();
        'path.Reset();
        ' Dispose
        g.Dispose()
    End Sub
End Class

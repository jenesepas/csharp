Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Imaging
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents JpegCompression As System.Windows.Forms.MenuItem
    Friend WithEvents ConvertToPNG As System.Windows.Forms.MenuItem
    Friend WithEvents button1 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.JpegCompression = New System.Windows.Forms.MenuItem
        Me.ConvertToPNG = New System.Windows.Forms.MenuItem
        Me.button1 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.JpegCompression, Me.ConvertToPNG})
        Me.menuItem1.Text = "Encoder/Decoder"
        '
        'JpegCompression
        '
        Me.JpegCompression.Index = 0
        Me.JpegCompression.Text = "JPEG Compression"
        '
        'ConvertToPNG
        '
        Me.ConvertToPNG.Index = 1
        Me.ConvertToPNG.Text = "Convert to PNG"
        '
        'button1
        '
        Me.button1.Location = New System.Drawing.Point(64, 216)
        Me.button1.Name = "button1"
        Me.button1.Size = New System.Drawing.Size(96, 32)
        Me.button1.TabIndex = 1
        Me.button1.Text = "Save Image"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(384, 294)
        Me.Controls.Add(Me.button1)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub JpegCompression_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles JpegCompression.Click
        Dim curBitmap As Bitmap
        Dim imgCodecInfo As ImageCodecInfo = Nothing
        Dim encoder As Encoder
        Dim encoderParam As EncoderParameter
        Dim encoderParams As New EncoderParameters(1)
        ' Create a Bitmap object based on a BMP file.
        curBitmap = New Bitmap("f:\Shapes.bmp")

        Dim j As Integer
        Dim mimeType As String = "image/jpeg"
        Dim encoders() As ImageCodecInfo
        encoders = ImageCodecInfo.GetImageEncoders()

        j = 0
        While j < encoders.Length
            If encoders(j).MimeType = mimeType Then
                imgCodecInfo = encoders(j)
            End If
        End While ' Jpeg Compression 
        encoder = encoder.Compression
        encoderParam = New EncoderParameter(encoder, 1, CInt(EncoderParameterValueType.ValueTypeLong), 0)
        encoderParams.Param(0) = encoderParam '
        curBitmap.Save("f:\Shape0.jpg", imgCodecInfo, encoderParams)
    End Sub

    Private Sub ConvertToPNG_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ConvertToPNG.Click
        Dim curBitmap As Bitmap
        Dim imgCodecInfo As ImageCodecInfo = Nothing
        ' Create a Bitmap object based on a BMP file.
        curBitmap = New Bitmap("f:\Shapes.bmp")
        Dim j As Integer
        Dim mimeType As String = "image/png"
        Dim encoders() As ImageCodecInfo
        encoders = ImageCodecInfo.GetImageEncoders()

        j = 0
        While j < encoders.Length
            If encoders(j).MimeType = mimeType Then
                imgCodecInfo = encoders(j)
            End If
        End While ' Save as png
        curBitmap.Save("f:\Shape0.png", imgCodecInfo, Nothing)
    End Sub

    Private Sub button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button1.Click
        Dim curBitmap As Bitmap
        Dim imgCodecInfo As ImageCodecInfo = Nothing
        Dim encoder As Encoder
        Dim encoderParam As EncoderParameter
        Dim encoderParams As New EncoderParameters(3)
        ' Create a Bitmap object based on a BMP file.
        curBitmap = New Bitmap("f:\hotpp.jpg")

        Dim j As Integer
        Dim mimeType As String = "image/tiff"
        Dim encoders() As ImageCodecInfo
        encoders = ImageCodecInfo.GetImageEncoders()

        j = 0
        While j < encoders.Length
            If encoders(j).MimeType = mimeType Then
                imgCodecInfo = encoders(j)
            End If
        End While ' Set color depth to 24 pixels
        encoder = encoder.ColorDepth
        encoderParam = New EncoderParameter(encoder, CLng(24))
        encoderParams.Param(0) = encoderParam '
        ' Compression mode LZW
        encoder = encoder.Compression
        encoderParam = New EncoderParameter(encoder, CLng(EncoderValue.CompressionLZW))
        encoderParams.Param(1) = encoderParam '
        ' Set transformation 180 degrees
        encoder = encoder.Transformation
        encoderParam = New EncoderParameter(encoder, CLng(EncoderValue.TransformRotate180))
        encoderParams.Param(2) = encoderParam '
        curBitmap.Save("f:\hotpp24.tif", imgCodecInfo, encoderParams)
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class

Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents GetCapStyles As System.Windows.Forms.MenuItem
    Friend WithEvents LineDashStyle As System.Windows.Forms.MenuItem
    Friend WithEvents LineDashCap As System.Windows.Forms.MenuItem
    Friend WithEvents OtherObjects As System.Windows.Forms.MenuItem
    Friend WithEvents DashedMenu As System.Windows.Forms.MenuItem
    Friend WithEvents CustomLineCap As System.Windows.Forms.MenuItem
    Friend WithEvents SetStrokeCapsMenu As System.Windows.Forms.MenuItem
    Friend WithEvents AdjustableRowCapMenu As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem2 As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.GetCapStyles = New System.Windows.Forms.MenuItem
        Me.LineDashStyle = New System.Windows.Forms.MenuItem
        Me.LineDashCap = New System.Windows.Forms.MenuItem
        Me.OtherObjects = New System.Windows.Forms.MenuItem
        Me.DashedMenu = New System.Windows.Forms.MenuItem
        Me.CustomLineCap = New System.Windows.Forms.MenuItem
        Me.SetStrokeCapsMenu = New System.Windows.Forms.MenuItem
        Me.AdjustableRowCapMenu = New System.Windows.Forms.MenuItem
        Me.menuItem2 = New System.Windows.Forms.MenuItem
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1, Me.menuItem2})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.GetCapStyles, Me.LineDashStyle, Me.LineDashCap, Me.OtherObjects, Me.DashedMenu, Me.CustomLineCap, Me.SetStrokeCapsMenu, Me.AdjustableRowCapMenu})
        Me.menuItem1.Text = "Lines and Curves"
        '
        'GetCapStyles
        '
        Me.GetCapStyles.Index = 0
        Me.GetCapStyles.Text = "Get LineCap Styles"
        '
        'LineDashStyle
        '
        Me.LineDashStyle.Index = 1
        Me.LineDashStyle.Text = "Get LineDash Styles"
        '
        'LineDashCap
        '
        Me.LineDashCap.Index = 2
        Me.LineDashCap.Text = "Get Line DahsCap "
        '
        'OtherObjects
        '
        Me.OtherObjects.Index = 3
        Me.OtherObjects.Text = "Other Objects"
        '
        'DashedMenu
        '
        Me.DashedMenu.Index = 4
        Me.DashedMenu.Text = "Dashed "
        '
        'CustomLineCap
        '
        Me.CustomLineCap.Index = 5
        Me.CustomLineCap.Text = "CustomLineCap"
        '
        'SetStrokeCapsMenu
        '
        Me.SetStrokeCapsMenu.Index = 6
        Me.SetStrokeCapsMenu.Text = "SetStrokeCaps"
        '
        'AdjustableRowCapMenu
        '
        Me.AdjustableRowCapMenu.Index = 7
        Me.AdjustableRowCapMenu.Text = "AdjustableRowCap"
        '
        'menuItem2
        '
        Me.menuItem2.Index = 1
        Me.menuItem2.Text = ""
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(536, 406)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Drawing Lines and Curves with Styles"

    End Sub

#End Region

    Private Sub GetCapStyles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GetCapStyles.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a pen
        Dim blackPen As New Pen(Color.Black, 10)
        ' Setting line styles 		
        blackPen.StartCap = LineCap.Triangle
        blackPen.EndCap = LineCap.Triangle
        g.DrawLine(blackPen, 20, 10, 200, 10)
        blackPen.StartCap = LineCap.Square
        blackPen.EndCap = LineCap.Square
        g.DrawLine(blackPen, 20, 30, 200, 30)
        blackPen.StartCap = LineCap.ArrowAnchor
        blackPen.EndCap = LineCap.ArrowAnchor
        g.DrawLine(blackPen, 20, 50, 200, 50)
        blackPen.StartCap = LineCap.DiamondAnchor
        blackPen.EndCap = LineCap.DiamondAnchor
        g.DrawLine(blackPen, 20, 70, 200, 70)
        blackPen.StartCap = LineCap.Flat
        blackPen.EndCap = LineCap.Flat
        g.DrawLine(blackPen, 20, 90, 200, 90)
        blackPen.StartCap = LineCap.Round
        blackPen.EndCap = LineCap.Round
        g.DrawLine(blackPen, 20, 110, 200, 110)
        blackPen.StartCap = LineCap.RoundAnchor
        blackPen.EndCap = LineCap.RoundAnchor
        g.DrawLine(blackPen, 20, 130, 200, 130)
        blackPen.StartCap = LineCap.Square
        blackPen.EndCap = LineCap.Square
        g.DrawLine(blackPen, 20, 150, 200, 150)
        blackPen.StartCap = LineCap.SquareAnchor
        blackPen.EndCap = LineCap.SquareAnchor
        g.DrawLine(blackPen, 20, 170, 200, 170)
        blackPen.StartCap = LineCap.Flat
        blackPen.EndCap = LineCap.Flat
        g.DrawLine(blackPen, 20, 190, 200, 190)
        ' Dispose
        blackPen.Dispose()
        g.Dispose()

    End Sub

    Private Sub LineDashStyle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LineDashStyle.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a pen
        Dim blackPen As New Pen(Color.Black, 6)
        ' Setting line styles 		
        blackPen.DashStyle = DashStyle.Dash
        blackPen.DashOffset = 40
        blackPen.DashCap = DashCap.Triangle
        g.DrawLine(blackPen, 20, 10, 500, 10)
        blackPen.DashStyle = DashStyle.DashDot
        g.DrawLine(blackPen, 20, 30, 500, 30)
        blackPen.DashStyle = DashStyle.DashDotDot
        g.DrawLine(blackPen, 20, 50, 500, 50)
        blackPen.DashStyle = DashStyle.Dot
        g.DrawLine(blackPen, 20, 70, 500, 70)
        blackPen.DashStyle = DashStyle.Solid
        g.DrawLine(blackPen, 20, 70, 500, 70)
        ' Dispose
        blackPen.Dispose()
        g.Dispose()

    End Sub

    Private Sub LineDashCap_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LineDashCap.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a pen
        Dim blackPen As New Pen(Color.Black, 10)
        ' Setting DashCap styles 		
        blackPen.DashStyle = DashStyle.DashDotDot
        blackPen.DashPattern = New Single() {10}
        blackPen.DashCap = DashCap.Triangle
        g.DrawLine(blackPen, 20, 10, 500, 10)
        blackPen.DashCap = DashCap.Flat
        g.DrawLine(blackPen, 20, 30, 500, 30)
        blackPen.DashCap = DashCap.Round
        g.DrawLine(blackPen, 20, 50, 500, 50)
        ' Dispose
        blackPen.Dispose()
        g.Dispose()
        '

    End Sub

    Private Sub OtherObjects_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OtherObjects.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        g.SmoothingMode = SmoothingMode.AntiAlias
        ' Create pen objects
        Dim blackPen As New Pen(Color.Black, 5)
        Dim bluePen As New Pen(Color.Blue, 8)
        Dim redPen As New Pen(Color.Red, 4)
        ' Setting DashCap styles 	
        blackPen.StartCap = LineCap.DiamondAnchor
        blackPen.EndCap = LineCap.SquareAnchor
        blackPen.DashStyle = DashStyle.DashDotDot
        blackPen.DashPattern = New Single() {10}
        blackPen.DashCap = DashCap.Triangle
        ' Set blue pen dash style and dash cap
        bluePen.DashStyle = DashStyle.DashDotDot
        bluePen.DashCap = DashCap.Round
        ' Set red pen line cap and line dash styles
        redPen.StartCap = LineCap.Round
        redPen.EndCap = LineCap.DiamondAnchor
        redPen.DashCap = DashCap.Triangle
        redPen.DashStyle = DashStyle.DashDot
        redPen.DashOffset = 3.4F
        ' Draw a rectangle
        g.DrawRectangle(blackPen, 20, 20, 200, 100)
        ' Draw an ellipse
        g.DrawEllipse(bluePen, 20, 150, 200, 100)
        ' Draw a curve
        Dim pt1 As New PointF(90.0F, 40.0F)
        Dim pt2 As New PointF(130.0F, 80.0F)
        Dim pt3 As New PointF(200.0F, 100.0F)
        Dim pt4 As New PointF(220.0F, 120.0F)
        Dim pt5 As New PointF(250.0F, 250.0F)
        Dim ptsArray As PointF() = {pt1, pt2, pt3, pt4, pt5}
        g.DrawCurve(redPen, ptsArray)
        ' Dispose
        blackPen.Dispose()
        g.Dispose()
    End Sub

    Private Sub DashedMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DashedMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create three pens
        Dim redPen As New Pen(Color.Red, 10)
        Dim bluePen As New Pen(Color.Blue, 8)
        Dim greenPen As New Pen(Color.Green, 8)
        ' Setting line styles 		
        redPen.DashStyle = DashStyle.Dash
        redPen.SetLineCap(LineCap.DiamondAnchor, LineCap.ArrowAnchor, DashCap.Flat)
        greenPen.DashStyle = DashStyle.DashDotDot
        greenPen.StartCap = LineCap.Triangle
        greenPen.EndCap = LineCap.Square
        greenPen.DashCap = DashCap.Triangle
        greenPen.DashOffset = 3.4F
        greenPen.EndCap = LineCap.DiamondAnchor
        bluePen.DashStyle = DashStyle.Dot
        bluePen.DashCap = DashCap.Triangle
        bluePen.DashStyle = DashStyle.DashDot
        bluePen.EndCap = LineCap.ArrowAnchor
        bluePen.StartCap = LineCap.SquareAnchor
        bluePen.DashPattern = New Single() {1.0F}
        ' Drawing Lines and curves
        Dim pt1 As New PointF(90.0F, 40.0F)
        Dim pt2 As New PointF(130.0F, 80.0F)
        Dim pt3 As New PointF(200.0F, 100.0F)
        Dim pt4 As New PointF(220.0F, 120.0F)
        Dim pt5 As New PointF(250.0F, 250.0F)
        Dim ptsArray As PointF() = {pt1, pt2, pt3, pt4, pt5}
        g.DrawLine(redPen, New Point(20, 20), New Point(300, 20))
        g.DrawLine(greenPen, New Point(20, 80), New Point(300, 80))
        g.DrawCurve(bluePen, ptsArray)
        ' Dispose
        redPen.Dispose()
        greenPen.Dispose()
        greenPen.Dispose()
        g.Dispose()
    End Sub

    Private Sub CustomLineCap_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CustomLineCap.Click
        ' Create a graphic 
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        g.SmoothingMode = SmoothingMode.AntiAlias
        Dim redPen As New Pen(Color.Red, 20)
        redPen.LineJoin = LineJoin.Bevel
        redPen.LineJoin = LineJoin.Miter
        redPen.LineJoin = LineJoin.MiterClipped
        redPen.LineJoin = LineJoin.Round
        Dim pts As Point() = {New Point(150, 20), New Point(50, 20), New Point(80, 60), New Point(50, 150), New Point(150, 150)}
        g.DrawLines(redPen, pts)
        Dim pts1 As Point() = {New Point(200, 20), New Point(300, 20), New Point(300, 120), New Point(200, 120), New Point(200, 20)}

        g.DrawLines(redPen, pts1)
        ' Dispose
        redPen.Dispose()
        g.Dispose()

    End Sub

    Private Sub SetStrokeCapsMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetStrokeCapsMenu.Click
        ' Create a graphic 
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a path for custom line cap. This 
        ' path will have two lines from points 
        ' -3, -3 to 0, 0 and 0, 0 to 3, -3
        Dim points As Point() = {New Point(-3, -3), New Point(0, 0), New Point(3, -3)}
        Dim path As New GraphicsPath
        path.AddLines(points)
        ' Create a Custom line cap from the path
        Dim cap As New CustomLineCap(Nothing, path)
        ' Set the start and end caps of the Custom cap
        cap.SetStrokeCaps(LineCap.Round, LineCap.Triangle)
        ' Create a Pen object and set its start and end
        ' caps
        Dim redPen As New Pen(Color.Red, 15)
        redPen.CustomStartCap = cap
        redPen.CustomEndCap = cap
        redPen.DashStyle = DashStyle.DashDotDot
        ' Draw the line 
        g.DrawLine(redPen, New Point(100, 100), New Point(400, 100))
        ' Dispose
        g.Dispose()

    End Sub

    Private Sub AdjustableRowCapMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AdjustableRowCapMenu.Click
        ' Create a Graphics object
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create two AdjustableArrowCap objects
        Dim cap1 As New AdjustableArrowCap(1, 1, False)
        Dim cap2 As New AdjustableArrowCap(2, 1)
        ' Set cap properties
        cap1.BaseCap = LineCap.Round
        cap1.BaseInset = 5
        cap1.StrokeJoin = LineJoin.Bevel
        cap2.WidthScale = 3
        cap2.BaseCap = LineCap.Square
        cap2.Height = 1
        ' Create a pen 
        Dim blackPen As New Pen(Color.Black, 15)
        ' Set CustomStartCap and CustomEndCap properties
        blackPen.CustomStartCap = cap1
        blackPen.CustomEndCap = cap2
        ' Draw line
        g.DrawLine(blackPen, 20, 50, 200, 50)
        ' Dispose
        blackPen.Dispose()
        g.Dispose()

    End Sub
End Class

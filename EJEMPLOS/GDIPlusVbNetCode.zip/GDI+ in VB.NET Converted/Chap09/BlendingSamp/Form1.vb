Imports System
Imports System.Drawing
Imports System.Collections
Imports System.ComponentModel
Imports System.Windows.Forms
Imports System.Data
Imports System.Drawing.Drawing2D
Imports System.Drawing.Imaging

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents mainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents menuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents ColorBlending As System.Windows.Forms.MenuItem
    Friend WithEvents AlphaBlending As System.Windows.Forms.MenuItem
    Friend WithEvents MixedBlendingMenu As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents EllipseMenu As System.Windows.Forms.MenuItem
    Friend WithEvents RectangleMenu As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents SetBlendTriangularShapeMenu As System.Windows.Forms.MenuItem
    Friend WithEvents SetSigmaBellShapeMenu As System.Windows.Forms.MenuItem
    Friend WithEvents BlendPropMenu As System.Windows.Forms.MenuItem
    Friend WithEvents InterpolationColorsMenu As System.Windows.Forms.MenuItem
    Friend WithEvents GammaCorrectionMenu As System.Windows.Forms.MenuItem
    Friend WithEvents CompBlendTSigmaBell As System.Windows.Forms.MenuItem
    Friend WithEvents CompBlendTSigmaBellMEnu As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents PathGradientProsMenu As System.Windows.Forms.MenuItem
    Friend WithEvents PathGBBlend As System.Windows.Forms.MenuItem
    Friend WithEvents PathGBInterPol As System.Windows.Forms.MenuItem
    Friend WithEvents menuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents AlphaBPensBrushes As System.Windows.Forms.MenuItem
    Friend WithEvents AlphaBImages As System.Windows.Forms.MenuItem
    Friend WithEvents AlphaBCompGammaCorr As System.Windows.Forms.MenuItem
    Friend WithEvents AlphaBMatrix As System.Windows.Forms.MenuItem
    Friend WithEvents MixedBlending As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.mainMenu1 = New System.Windows.Forms.MainMenu
        Me.menuItem1 = New System.Windows.Forms.MenuItem
        Me.ColorBlending = New System.Windows.Forms.MenuItem
        Me.AlphaBlending = New System.Windows.Forms.MenuItem
        Me.MixedBlendingMenu = New System.Windows.Forms.MenuItem
        Me.menuItem6 = New System.Windows.Forms.MenuItem
        Me.menuItem2 = New System.Windows.Forms.MenuItem
        Me.EllipseMenu = New System.Windows.Forms.MenuItem
        Me.RectangleMenu = New System.Windows.Forms.MenuItem
        Me.menuItem3 = New System.Windows.Forms.MenuItem
        Me.SetBlendTriangularShapeMenu = New System.Windows.Forms.MenuItem
        Me.SetSigmaBellShapeMenu = New System.Windows.Forms.MenuItem
        Me.BlendPropMenu = New System.Windows.Forms.MenuItem
        Me.InterpolationColorsMenu = New System.Windows.Forms.MenuItem
        Me.GammaCorrectionMenu = New System.Windows.Forms.MenuItem
        Me.CompBlendTSigmaBell = New System.Windows.Forms.MenuItem
        Me.CompBlendTSigmaBellMEnu = New System.Windows.Forms.MenuItem
        Me.menuItem5 = New System.Windows.Forms.MenuItem
        Me.PathGradientProsMenu = New System.Windows.Forms.MenuItem
        Me.PathGBBlend = New System.Windows.Forms.MenuItem
        Me.PathGBInterPol = New System.Windows.Forms.MenuItem
        Me.menuItem4 = New System.Windows.Forms.MenuItem
        Me.AlphaBPensBrushes = New System.Windows.Forms.MenuItem
        Me.AlphaBImages = New System.Windows.Forms.MenuItem
        Me.AlphaBCompGammaCorr = New System.Windows.Forms.MenuItem
        Me.AlphaBMatrix = New System.Windows.Forms.MenuItem
        Me.MixedBlending = New System.Windows.Forms.MenuItem
        '
        'mainMenu1
        '
        Me.mainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.menuItem1, Me.menuItem2, Me.menuItem4})
        '
        'menuItem1
        '
        Me.menuItem1.Index = 0
        Me.menuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.ColorBlending, Me.AlphaBlending, Me.MixedBlendingMenu, Me.menuItem6})
        Me.menuItem1.Text = "Blending"
        '
        'ColorBlending
        '
        Me.ColorBlending.Index = 0
        Me.ColorBlending.Text = "Color Blending"
        '
        'AlphaBlending
        '
        Me.AlphaBlending.Index = 1
        Me.AlphaBlending.Text = "Alpha Blending"
        '
        'MixedBlendingMenu
        '
        Me.MixedBlendingMenu.Index = 2
        Me.MixedBlendingMenu.Text = "Mixed Blending"
        '
        'menuItem6
        '
        Me.menuItem6.Index = 3
        Me.menuItem6.Text = "CompBlendTSigmaBell"
        '
        'menuItem2
        '
        Me.menuItem2.Index = 1
        Me.menuItem2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.EllipseMenu, Me.RectangleMenu, Me.menuItem3, Me.menuItem5})
        Me.menuItem2.Text = "Color Blending"
        '
        'EllipseMenu
        '
        Me.EllipseMenu.Index = 0
        Me.EllipseMenu.Text = "Ellipse"
        '
        'RectangleMenu
        '
        Me.RectangleMenu.Index = 1
        Me.RectangleMenu.Text = "Rectangle"
        '
        'menuItem3
        '
        Me.menuItem3.Index = 2
        Me.menuItem3.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.SetBlendTriangularShapeMenu, Me.SetSigmaBellShapeMenu, Me.BlendPropMenu, Me.InterpolationColorsMenu, Me.GammaCorrectionMenu, Me.CompBlendTSigmaBell, Me.CompBlendTSigmaBellMEnu})
        Me.menuItem3.Text = "LinearGradientBrush"
        '
        'SetBlendTriangularShapeMenu
        '
        Me.SetBlendTriangularShapeMenu.Index = 0
        Me.SetBlendTriangularShapeMenu.Text = "SetBlendTriangularShape"
        '
        'SetSigmaBellShapeMenu
        '
        Me.SetSigmaBellShapeMenu.Index = 1
        Me.SetSigmaBellShapeMenu.Text = "SetSigmaBellShape"
        '
        'BlendPropMenu
        '
        Me.BlendPropMenu.Index = 2
        Me.BlendPropMenu.Text = "Blend"
        '
        'InterpolationColorsMenu
        '
        Me.InterpolationColorsMenu.Index = 3
        Me.InterpolationColorsMenu.Text = "InterpolationColors"
        '
        'GammaCorrectionMenu
        '
        Me.GammaCorrectionMenu.Index = 4
        Me.GammaCorrectionMenu.Text = "GammaCorrection"
        '
        'CompBlendTSigmaBell
        '
        Me.CompBlendTSigmaBell.Index = 5
        Me.CompBlendTSigmaBell.Text = "Compare BlendTriangular and SigmaBell Shapes"
        '
        'CompBlendTSigmaBellMEnu
        '
        Me.CompBlendTSigmaBellMEnu.Index = 6
        Me.CompBlendTSigmaBellMEnu.Text = "CompBlendTSigmaBell"
        '
        'menuItem5
        '
        Me.menuItem5.Index = 3
        Me.menuItem5.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.PathGradientProsMenu, Me.PathGBBlend, Me.PathGBInterPol})
        Me.menuItem5.Text = "PathGradientBrush"
        '
        'PathGradientProsMenu
        '
        Me.PathGradientProsMenu.Index = 0
        Me.PathGradientProsMenu.Text = "Properties"
        '
        'PathGBBlend
        '
        Me.PathGBBlend.Index = 1
        Me.PathGBBlend.Text = "Blend"
        '
        'PathGBInterPol
        '
        Me.PathGBInterPol.Index = 2
        Me.PathGBInterPol.Text = "InterpolationColors"
        '
        'menuItem4
        '
        Me.menuItem4.Index = 2
        Me.menuItem4.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.AlphaBPensBrushes, Me.AlphaBImages, Me.AlphaBCompGammaCorr, Me.AlphaBMatrix, Me.MixedBlending})
        Me.menuItem4.Text = "Alpha Blending"
        '
        'AlphaBPensBrushes
        '
        Me.AlphaBPensBrushes.Index = 0
        Me.AlphaBPensBrushes.Text = "Pens and Brushes"
        '
        'AlphaBImages
        '
        Me.AlphaBImages.Index = 1
        Me.AlphaBImages.Text = "Images and Alpha Blending"
        '
        'AlphaBCompGammaCorr
        '
        Me.AlphaBCompGammaCorr.Index = 2
        Me.AlphaBCompGammaCorr.Text = "CompositeMode and GammaCorrection"
        '
        'AlphaBMatrix
        '
        Me.AlphaBMatrix.Index = 3
        Me.AlphaBMatrix.Text = "Matrix In Alpha Blending"
        '
        'MixedBlending
        '
        Me.MixedBlending.Index = 4
        Me.MixedBlending.Text = "Mixed Blending"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(424, 338)
        Me.Menu = Me.mainMenu1
        Me.Name = "Form1"
        Me.Text = "Blending Sample"

    End Sub

#End Region

    Private Sub ColorBlending_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ColorBlending.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create three linear gradient brushes
        Dim rgBrush As New LinearGradientBrush(New RectangleF(20, 20, 100, 100), Color.Red, Color.Green, LinearGradientMode.Horizontal)
        Dim yrBrush As New LinearGradientBrush(New RectangleF(140, 20, 150, 300), Color.Yellow, Color.Red, LinearGradientMode.ForwardDiagonal)
        Dim rbBrush As New LinearGradientBrush(New RectangleF(10, 10, 50, 50), Color.Red, Color.Blue, LinearGradientMode.ForwardDiagonal)
        ' Use different brush to draw different graphics
        ' object
        g.FillRectangle(rgBrush, 20, 20, 100, 100)
        g.FillEllipse(yrBrush, 140, 20, 200, 200)
        g.DrawString("Color Blending", New Font("Tahoma", 30), rbBrush, New RectangleF(100, 240, 300, 300))
        ' Dispose
        g.Dispose()
    End Sub

    Private Sub AlphaBlending_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AlphaBlending.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create Image from a file
        Dim curImage As Image = Image.FromFile("Neel3.jpg")
        g.DrawImage(curImage, 0, 0, curImage.Width, curImage.Height)
        ' Create opaque, semi transparent, and full 
        ' transparent pens
        Dim opqPen As New Pen(Color.FromArgb(255, 0, 255, 0), 10)
        Dim transPen As New Pen(Color.FromArgb(128, 0, 255, 0), 10)
        Dim totTransPen As New Pen(Color.FromArgb(40, 0, 255, 0), 10)
        ' Use different pen to draw different graphics
        ' object
        g.DrawLine(opqPen, 10, 10, 200, 10)
        g.DrawLine(transPen, 10, 30, 200, 30)
        g.DrawLine(totTransPen, 10, 50, 200, 50)
        Dim semiTransBrush As New SolidBrush(Color.FromArgb(90, 255, 255, 0))
        g.DrawString("Atlanta Photo " + ControlChars.Lf + "Date: 04/09/2001", New Font("Verdana", 14), semiTransBrush, New RectangleF(20, 100, 300, 100))
        ' Dispose
        g.Dispose()
    End Sub

    Private Sub EllipseMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EllipseMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Set smmoothing mode and compositing quality
        g.SmoothingMode = SmoothingMode.AntiAlias
        g.CompositingQuality = CompositingQuality.HighQuality
        ' Create a graphics path and
        ' add an ellipse to it
        Dim path As New GraphicsPath
        path.AddEllipse(20, 20, 200, 200)
        ' Create a path gradient brush with the path
        Dim pthGrBrush As New PathGradientBrush(path)
        ' Create a semi transparent color
        Dim transBlackColor As Color = color.FromArgb(90, 255, 255, 255)
        ' Set SurroundColors and CenterColor 
        ' of the brush
        Dim color1() As Color = {Color.Black}
        pthGrBrush.SurroundColors = color1
        pthGrBrush.CenterColor = color.Red
        ' Use bush to fill a path
        g.FillPath(pthGrBrush, path)
        ' Dispose
        g.Dispose()
    End Sub

    Private Sub RectangleMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RectangleMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)

        Dim rgBrush As New LinearGradientBrush(New RectangleF(0, 0, 200, 200), Color.Red, Color.Green, LinearGradientMode.Horizontal)
        '50
        '50 
        g.FillRectangle(rgBrush, 0, 0, 200, 50)

        ' Dispose
        g.Dispose()
    End Sub

    Private Sub MixedBlendingMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MixedBlendingMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a Image from a file
        Dim curImage As Image = Image.FromFile("Neel3.jpg")
        ' Draw Image
        g.DrawImage(curImage, 0, 0, curImage.Width, curImage.Height)
        ' Create a graphics path and add a rectangle
        Dim path As New GraphicsPath
        path.AddRectangle(New Rectangle(0, 0, 182, 300))
        ' Create a path gradient brush
        Dim grBrush As New PathGradientBrush(path)
        Dim transBlackColor As Color = color.FromArgb(60, 0, 255, 0)
        ' Create a array of colors
        Dim color2() As Color = {transBlackColor}
        ' Set surround and center colros
        grBrush.SurroundColors = color2
        grBrush.CenterColor = color.Yellow
        ' Fill path
        g.FillPath(grBrush, path)

        ' Dispose
        g.Dispose()
    End Sub

    Private Sub SetBlendTriangularShapeMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetBlendTriangularShapeMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a rectangle
        Dim rect As New Rectangle(20, 20, 100, 50)
        ' Create a linear gradient brush
        Dim rgBrush As New LinearGradientBrush(rect, Color.Red, Color.Green, 0.0F, True)
        ' Fill rectangle
        g.FillRectangle(rgBrush, rect)
        rect.Y = 90
        ' set blend triangular shape
        rgBrush.SetBlendTriangularShape(0.5F, 1.0F)
        ' Fill rectangle again
        g.FillRectangle(rgBrush, rect)
        ' Dispose
        g.Dispose()
        '
    End Sub

    Private Sub SetSigmaBellShapeMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SetSigmaBellShapeMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a rectangle
        Dim rect As New Rectangle(20, 20, 100, 50)
        ' Create a linear gradient brush
        Dim rgBrush As New LinearGradientBrush(rect, Color.Red, Color.Green, 0.0F, True)
        ' Fill rectangle
        g.FillRectangle(rgBrush, rect)
        rect.Y = 90
        ' set signma bell shape
        rgBrush.SetSigmaBellShape(0.5F, 1.0F)
        ' Fill rectangle again
        g.FillRectangle(rgBrush, rect)
        ' Dispose
        g.Dispose()
        '

    End Sub

    Private Sub BlendPropMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BlendPropMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a linear gradient brush
        Dim brBrush As New LinearGradientBrush(New Point(0, 0), New Point(50, 20), Color.Blue, Color.Red)
        ' Create a Blend object
        Dim blend As New Blend
        Dim factArray As Single() = {0.0F, 0.3F, 0.5F, 1.0F}
        Dim posArray As Single() = {0.0F, 0.2F, 0.6F, 1.0F}
        ' Set Blend's factors and positions
        blend.Factors = factArray
        blend.Positions = posArray
        ' Set Blend property of the brush
        brBrush.Blend = blend
        ' Fill a rectangel and ellipse
        g.FillRectangle(brBrush, 10, 20, 200, 100)
        g.FillEllipse(brBrush, 10, 150, 120, 120)
        ' Dispose
        g.Dispose()
        '
        
    End Sub

    Private Sub InterpolationColorsMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InterpolationColorsMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a LinearGradientBrush
        Dim brBrush As New LinearGradientBrush(New Point(0, 0), New Point(50, 20), Color.Blue, Color.Red)
        Dim rect As New Rectangle(20, 20, 200, 100)
        ' Create color and points array
        Dim clrArray As Color() = {Color.Red, Color.Blue, Color.Green, Color.Pink, Color.Yellow, Color.DarkTurquoise}
        Dim posArray As Single() = {0.0F, 0.2F, 0.4F, 0.6F, 0.8F, 1.0F}
        ' Create a ColorBlend object and 
        ' set its Colors and positions
        Dim colorBlend As New ColorBlend
        colorBlend.Colors = clrArray
        colorBlend.Positions = posArray
        ' Set InterpolationColors property
        brBrush.InterpolationColors = colorBlend
        ' Draw shapes		
        g.FillRectangle(brBrush, rect)
        rect.Y = 150
        rect.Width = 100
        rect.Height = 100
        g.FillEllipse(brBrush, rect)
        ' Dispose
        g.Dispose()
    End Sub

    Private Sub GammaCorrectionMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GammaCorrectionMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a rectangle
        Dim rect As New Rectangle(20, 20, 100, 50)
        ' Create a linear gradient brush
        Dim rgBrush As New LinearGradientBrush(rect, Color.Red, Color.Green, 0.0F, True)
        ' Fill rectangle
        g.FillRectangle(rgBrush, rect)
        rect.Y = 90
        ' Set gamma collection of the brush
        rgBrush.GammaCorrection = True
        ' Fill rectangle
        g.FillRectangle(rgBrush, rect)
        ' Dispose
        g.Dispose()
    End Sub

    Private Sub PathGradientProsMenu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PathGradientProsMenu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Set smoothing mode as anti alias
        g.SmoothingMode = SmoothingMode.AntiAlias
        ' Create a graphics path and add a rectangle
        Dim path As New GraphicsPath
        Dim rect As New Rectangle(10, 20, 200, 200)
        path.AddRectangle(rect)
        ' Create path gradient brush 
        Dim rgBrush As New PathGradientBrush(path)
        ' Set brush's center and focusscale colors
        rgBrush.CenterColor = Color.Red
        rgBrush.FocusScales = New PointF(0.6F, 0.2F)
        Dim colors As Color() = {Color.Green, Color.Blue, Color.Red, Color.Yellow}
        ' Set surrounded colors
        rgBrush.SurroundColors = colors
        ' Fill ellipse
        g.FillEllipse(rgBrush, rect)
        ' Dispose
        g.Dispose()
    End Sub

    Private Sub PathGBBlend_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PathGBBlend.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Creat Blend object
        Dim blend As New Blend
        ' Create point and position arrays
        Dim factArray As Single() = {0.0F, 0.3F, 0.5F, 1.0F}
        Dim posArray As Single() = {0.0F, 0.2F, 0.6F, 1.0F}
        ' Set factors and positions of Blend
        blend.Factors = factArray
        blend.Positions = posArray
        ' Set smoothing mode of Graphics
        g.SmoothingMode = SmoothingMode.AntiAlias
        ' Create path and add a rectangle
        Dim path As New GraphicsPath
        Dim rect As New Rectangle(10, 20, 200, 200)
        path.AddRectangle(rect)
        ' Create path gradient brush
        Dim rgBrush As New PathGradientBrush(path)
        ' set Blend and FocusScales properties
        rgBrush.Blend = blend
        rgBrush.FocusScales = New PointF(0.6F, 0.2F)
        Dim colors As Color() = {Color.Green, Color.Blue, Color.Red, Color.Yellow}

        ' Set CenterColor and SurroundColors 
        rgBrush.CenterColor = Color.Red
        rgBrush.SurroundColors = colors
        g.FillEllipse(rgBrush, rect)
        ' Dispose
        g.Dispose()
    End Sub

    Private Sub PathGBInterPol_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PathGBInterPol.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create color and points array
        Dim clrArray As Color() = {Color.Red, Color.Blue, Color.Green, Color.Pink, Color.Yellow, Color.DarkTurquoise}
        Dim posArray As Single() = {0.0F, 0.2F, 0.4F, 0.6F, 0.8F, 1.0F}
        ' Create a ColorBlend object and set its Colors and 
        ' positions
        Dim colorBlend As New ColorBlend
        colorBlend.Colors = clrArray
        colorBlend.Positions = posArray
        ' Set smoothing mode of Graphics
        g.SmoothingMode = SmoothingMode.AntiAlias
        ' Create a Graphics path and add a rectangle
        Dim path As New GraphicsPath
        Dim rect As New Rectangle(10, 20, 200, 200)
        path.AddRectangle(rect)
        ' Create a path gradiant brush
        Dim rgBrush As New PathGradientBrush(path)
        ' Set interpolation colors and focus scales
        rgBrush.InterpolationColors = colorBlend
        rgBrush.FocusScales = New PointF(0.6F, 0.2F)
        Dim colors() As Color = {Color.Green}
        ' Set ceneter and surrounded colors
        rgBrush.CenterColor = Color.Red
        rgBrush.SurroundColors = colors
        ' Draw ellipse
        g.FillEllipse(rgBrush, rect)
        ' Dispose
        g.Dispose()
    End Sub

    Private Sub AlphaBPensBrushes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AlphaBPensBrushes.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create pens with semi transparent colors
        Dim rect As New Rectangle(220, 30, 100, 50)
        Dim transPen As New Pen(Color.FromArgb(128, 255, 255, 255), 10)
        Dim totTransPen As New Pen(Color.FromArgb(40, 0, 255, 0), 10)
        ' Draw line, rectangle, ellipse, string using
        ' semi transparent colored pens
        g.DrawLine(transPen, 10, 30, 200, 30)
        g.DrawLine(totTransPen, 10, 50, 200, 50)
        g.FillRectangle(New SolidBrush(Color.FromArgb(40, 0, 0, 255)), rect)
        rect.Y += 60
        g.FillEllipse(New SolidBrush(Color.FromArgb(20, 255, 255, 0)), rect)
        Dim semiTransBrush As New SolidBrush(Color.FromArgb(90, 0, 50, 255))
        g.DrawString("Some Photo " + ControlChars.Lf + "Date: 04/09/2001", New Font("Verdana", 14), semiTransBrush, New RectangleF(20, 100, 300, 100))
        ' Dispose
        g.Dispose()

    End Sub

    Private Sub AlphaBImages_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AlphaBImages.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Draw an image 
        Dim curImage As Image = Image.FromFile("Neel3.jpg")
        g.DrawImage(curImage, 0, 0, curImage.Width, curImage.Height)
        ' Create pens and a rectangle
        Dim rect As New Rectangle(220, 30, 100, 50)
        Dim opqPen As New Pen(Color.FromArgb(255, 0, 255, 0), 10)
        Dim transPen As New Pen(Color.FromArgb(128, 255, 255, 255), 10)
        Dim totTransPen As New Pen(Color.FromArgb(40, 0, 255, 0), 10)
        ' Draw lines, rectangle, ellipse and string
        g.DrawLine(opqPen, 10, 10, 200, 10)
        g.DrawLine(transPen, 10, 30, 200, 30)
        g.DrawLine(totTransPen, 10, 50, 200, 50)
        g.FillRectangle(New SolidBrush(Color.FromArgb(140, 0, 0, 255)), rect)
        rect.Y += 60
        g.FillEllipse(New SolidBrush(Color.FromArgb(150, 255, 255, 255)), rect)
        Dim semiTransBrush As New SolidBrush(Color.FromArgb(90, 255, 255, 50))
        g.DrawString("Some Photo " + ControlChars.Lf + "Date: 04/09/2001", New Font("Verdana", 14), semiTransBrush, New RectangleF(20, 100, 300, 100))
        ' Dispose
        g.Dispose()
    End Sub

    Private Sub AlphaBCompGammaCorr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AlphaBCompGammaCorr.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create two rectangles
        Dim rect1 As New Rectangle(20, 20, 100, 100)
        Dim rect2 As New Rectangle(200, 20, 100, 100)
        ' Create two SolidBrush objects
        Dim redBrush As New SolidBrush(Color.FromArgb(150, 255, 0, 0))
        Dim greenBrush As New SolidBrush(Color.FromArgb(180, 0, 255, 0))
        ' Create a Bitmap
        Dim tempBmp As New Bitmap(200, 150)
        ' Create a Graphics objects
        Dim tempGraphics As Graphics = Graphics.FromImage(tempBmp)
        ' Set Compositing mode and compositing
        ' quality of Graphics object
        tempGraphics.CompositingMode = CompositingMode.SourceOver
        tempGraphics.CompositingQuality = CompositingQuality.GammaCorrected
        'tempGraphics.CompositingMode = 
        'CompositingMode.SourceCopy;
        ' Fill recntagle
        tempGraphics.FillRectangle(redBrush, rect1)
        rect1.X += 30
        rect1.Y += 30
        ' Fill ellipse
        tempGraphics.FillEllipse(greenBrush, rect1)
        g.CompositingQuality = CompositingQuality.GammaCorrected
        ' Draw image
        g.DrawImage(tempBmp, 0, 0)
        ' Fill rectangle			
        g.FillRectangle(Brushes.Red, rect2)
        rect2.X += 30
        rect2.Y += 30
        ' Fill ellipse
        g.FillEllipse(Brushes.Green, rect2)
        ' Dispose
        greenBrush.Dispose()
        redBrush.Dispose()
        tempBmp.Dispose()
        g.Dispose()
    End Sub

    Private Sub AlphaBMatrix_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AlphaBMatrix.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a rectangle 
        Dim rect As New Rectangle(20, 20, 200, 100)
        ' Create a Bitmap object from a file
        Dim bitmap As New Bitmap("MyPhoto.jpg")
        ' Create a points array
        Dim ptsArray As Single()() = {New Single() {1, 0, 0, 0, 0}, New Single() {0, 1, 0, 0, 0}, New Single() {0, 0, 1, 0, 0}, New Single() {0, 0, 0, 0.5F, 0}, New Single() {0, 0, 0, 0, 1}}
        ' Create a ColorMatrix using pts array
        Dim clrMatrix As New ColorMatrix(ptsArray)
        ' Create an ImageAttributes object
        Dim imgAttributes As New ImageAttributes
        ' Set ColorMatrix of ImageAttributes
        imgAttributes.SetColorMatrix(clrMatrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap)
        ' Fill rectangle
        g.FillRectangle(Brushes.Red, rect)
        rect.Y += 120
        ' Fill ellipse
        g.FillEllipse(Brushes.Black, rect)
        ' Draw image using ImageAttributes
        g.DrawImage(bitmap, New Rectangle(0, 0, bitmap.Width, bitmap.Height), 0, 0, bitmap.Width, bitmap.Height, GraphicsUnit.Pixel, imgAttributes)
        ' Dispose
        g.Dispose() '

    End Sub

    Private Sub MixedBlending_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MixedBlending.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a LinearGradientBrush
        Dim brBrush As New LinearGradientBrush(New Point(0, 0), New Point(50, 20), Color.Blue, Color.Red)
        Dim rect As New Rectangle(20, 20, 200, 100)
        ' Create color and points array
        Dim clrArray As Color() = {Color.Red, Color.Blue, Color.Green, Color.Pink, Color.Yellow, Color.DarkTurquoise}
        Dim posArray As Single() = {0.0F, 0.2F, 0.4F, 0.6F, 0.8F, 1.0F}
        ' Create a ColorBlend object and 
        ' set its Colors and positions
        Dim colorBlend As New ColorBlend
        colorBlend.Colors = clrArray
        colorBlend.Positions = posArray
        ' Set InterpolationColors property
        brBrush.InterpolationColors = colorBlend

        ' Create a Bitmap object from a file
        Dim bitmap As New Bitmap("Neel3.jpg")
        ' Create a points array
        Dim ptsArray As Single()() = {New Single() {1, 0, 0, 0, 0}, New Single() {0, 1, 0, 0, 0}, New Single() {0, 0, 1, 0, 0}, New Single() {0, 0, 0, 0.5F, 0}, New Single() {0, 0, 0, 0, 1}}
        ' Create a ColorMatrix using pts array
        Dim clrMatrix As New ColorMatrix(ptsArray)
        ' Create an ImageAttributes object
        Dim imgAttributes As New ImageAttributes
        ' Set ColorMatrix of ImageAttributes
        imgAttributes.SetColorMatrix(clrMatrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap)
        ' Fill rectangle
        g.FillRectangle(brBrush, rect)
        rect.Y += 120
        ' Fill ellipse
        g.FillEllipse(brBrush, rect)
        ' Draw image using ImageAttributes
        g.DrawImage(bitmap, New Rectangle(0, 0, bitmap.Width, bitmap.Height), 0, 0, bitmap.Width, bitmap.Height, GraphicsUnit.Pixel, imgAttributes)

        ' Dispose
        brBrush.Dispose()
        bitmap.Dispose()
        g.Dispose()

    End Sub

    Private Sub CompBlendTSigmaBell_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CompBlendTSigmaBell.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a rectangle
        Dim rect As New Rectangle(0, 0, 40, 20)
        ' Create a linear gradient brush
        Dim rgBrush As New LinearGradientBrush(rect, Color.Black, Color.Blue, 0.0F, True)
        ' Fill rectangle
        g.FillRectangle(rgBrush, New Rectangle(10, 10, 300, 100))
        ' set signma bell shape
        rgBrush.SetSigmaBellShape(0.8F, 1.0F)
        ' Fill rectangle again
        g.FillRectangle(rgBrush, New Rectangle(10, 120, 300, 100))
        ' set blend triangular shape
        rgBrush.SetBlendTriangularShape(0.2F, 1.0F)
        ' Fill rectangle again
        g.FillRectangle(rgBrush, New Rectangle(10, 240, 300, 100))
        ' Dispose
        g.Dispose()
    End Sub

    Private Sub CompBlendTSigmaBellMEnu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CompBlendTSigmaBellMEnu.Click
        Dim g As Graphics = Me.CreateGraphics()
        g.Clear(Me.BackColor)
        ' Create a rectangle
        Dim rect As New Rectangle(0, 0, 40, 20)
        ' Create a linear gradient brush
        Dim rgBrush As New LinearGradientBrush(rect, Color.Black, Color.Blue, 0.0F, True)
        ' Fill rectangle
        g.FillRectangle(rgBrush, New Rectangle(10, 10, 300, 100))
        ' set signma bell shape
        rgBrush.SetSigmaBellShape(0.5F, 1.0F)
        ' Fill rectangle again
        g.FillRectangle(rgBrush, New Rectangle(10, 120, 300, 100))
        ' set blend triangular shape
        rgBrush.SetBlendTriangularShape(0.5F, 1.0F)
        ' Fill rectangle again
        g.FillRectangle(rgBrush, New Rectangle(10, 240, 300, 100))
        ' Dispose
        g.Dispose()
    End Sub

    Private Sub menuItem6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles menuItem6.Click

    End Sub
End Class

Graphics Programming with GDI+ by Mahesh Chand @ 2003
=====================================================

GUIDELINES: HOW TO USE SOURCE CODE

Winzip extracts source code for each chapter in a seperate folder. All source code sampels are written using Visual Studio 2003. You can simple open a solution or project in Visual Studio 2003.

If you are using Visual Studio .NET, you can either use the backup project file (.bak) file in a project folder or simply create a new project and copy and paste code from cs file to your project.

Visit web site for source code updates.
using System;
using System.IO;

namespace ListingA1andA2
{
	class Class1
	{
		static void Main(string[] args)
		{
			string filename = @"C:\abc.txt";
			int counter = 10;
			StreamReader reader = new StreamReader();

			try
			{
				StreamReader reader = File.Open(filename); 
			}
			catch( when counter > 5
			{
				reader.
				Console.WriteLine(exp.Message);
			}
		}
	}
}




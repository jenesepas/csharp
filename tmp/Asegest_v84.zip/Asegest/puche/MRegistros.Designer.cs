﻿namespace Asegest
{
    partial class MRegistros
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MRegistros));
            this.p_reg = new System.Windows.Forms.Panel();
            this.tb_bate_ant = new System.Windows.Forms.TextBox();
            this.tb_d_col = new System.Windows.Forms.TextBox();
            this.cb_estado = new System.Windows.Forms.ComboBox();
            this.gb_fra = new System.Windows.Forms.GroupBox();
            this.gb_est_fra = new System.Windows.Forms.GroupBox();
            this.cb_est_fra = new System.Windows.Forms.ComboBox();
            this.gb_fac_a = new System.Windows.Forms.GroupBox();
            this.cb_cte_fra = new System.Windows.Forms.ComboBox();
            this.tb_itasa4 = new System.Windows.Forms.TextBox();
            this.tb_tipo4 = new System.Windows.Forms.TextBox();
            this.tb_itasa3 = new System.Windows.Forms.TextBox();
            this.tb_itasa2 = new System.Windows.Forms.TextBox();
            this.tb_itasa = new System.Windows.Forms.TextBox();
            this.lb_tipo4 = new System.Windows.Forms.Label();
            this.tb_tasa4 = new System.Windows.Forms.TextBox();
            this.lb_tasa4 = new System.Windows.Forms.Label();
            this.tb_tipo3 = new System.Windows.Forms.TextBox();
            this.lb_tipo3 = new System.Windows.Forms.Label();
            this.tb_tasa3 = new System.Windows.Forms.TextBox();
            this.lb_tasa3 = new System.Windows.Forms.Label();
            this.tb_tipo2 = new System.Windows.Forms.TextBox();
            this.lb_tipo2 = new System.Windows.Forms.Label();
            this.tb_tasa2 = new System.Windows.Forms.TextBox();
            this.lb_tasa2 = new System.Windows.Forms.Label();
            this.lb_t_fra = new System.Windows.Forms.Label();
            this.lb_tasa_fra = new System.Windows.Forms.Label();
            this.tb_p_iva = new System.Windows.Forms.TextBox();
            this.tb_tasa_fra = new System.Windows.Forms.TextBox();
            this.lb_p_iva = new System.Windows.Forms.Label();
            this.tb_hono = new System.Windows.Forms.TextBox();
            this.lb_hono = new System.Windows.Forms.Label();
            this.tb_descrip = new System.Windows.Forms.TextBox();
            this.lb_descrip = new System.Windows.Forms.Label();
            this.btt_facturar = new System.Windows.Forms.Button();
            this.tb_tipo = new System.Windows.Forms.TextBox();
            this.dtp_fec_fra = new System.Windows.Forms.DateTimePicker();
            this.lb_f_fra = new System.Windows.Forms.Label();
            this.tb_fra = new System.Windows.Forms.TextBox();
            this.tb_tasa = new System.Windows.Forms.TextBox();
            this.lb_tasa = new System.Windows.Forms.Label();
            this.lb_fra = new System.Windows.Forms.Label();
            this.lb_tipo = new System.Windows.Forms.Label();
            this.gb_t_fra = new System.Windows.Forms.GroupBox();
            this.tb_base_imp = new System.Windows.Forms.TextBox();
            this.tb_t_fra = new System.Windows.Forms.TextBox();
            this.lb_d_col = new System.Windows.Forms.Label();
            this.lb_base = new System.Windows.Forms.Label();
            this.btt_ac_tl = new System.Windows.Forms.Button();
            this.tb_nif = new System.Windows.Forms.TextBox();
            this.lb_nif = new System.Windows.Forms.Label();
            this.lb_bate_ant = new System.Windows.Forms.Label();
            this.tb_c_serv = new System.Windows.Forms.TextBox();
            this.lb_c_serv = new System.Windows.Forms.Label();
            this.dtp_fec_pre = new System.Windows.Forms.DateTimePicker();
            this.lb_f_pre = new System.Windows.Forms.Label();
            this.tb_exp = new System.Windows.Forms.TextBox();
            this.cb_sec_int = new System.Windows.Forms.ComboBox();
            this.lb_sec_int = new System.Windows.Forms.Label();
            this.tb_matri = new System.Windows.Forms.TextBox();
            this.lb_matri = new System.Windows.Forms.Label();
            this.cb_tram = new System.Windows.Forms.ComboBox();
            this.lb_tram = new System.Windows.Forms.Label();
            this.btt_ir_tit = new System.Windows.Forms.Button();
            this.btt_ir_cte = new System.Windows.Forms.Button();
            this.cb_sec = new System.Windows.Forms.ComboBox();
            this.lb_sec = new System.Windows.Forms.Label();
            this.btt_tit_buscar = new System.Windows.Forms.Button();
            this.btt_cte_buscar = new System.Windows.Forms.Button();
            this.tb_n_tit_rg = new System.Windows.Forms.TextBox();
            this.tb_tit_rg = new System.Windows.Forms.TextBox();
            this.lb_tit_reg = new System.Windows.Forms.Label();
            this.tb_n_cte_rg = new System.Windows.Forms.TextBox();
            this.tb_cte_rg = new System.Windows.Forms.TextBox();
            this.lb_cte_rg = new System.Windows.Forms.Label();
            this.lb_fec_ent = new System.Windows.Forms.Label();
            this.dtp_fec_rg = new System.Windows.Forms.DateTimePicker();
            this.tb_n_reg = new System.Windows.Forms.TextBox();
            this.lb_n_reg = new System.Windows.Forms.Label();
            this.gb_del = new System.Windows.Forms.GroupBox();
            this.cb_deleg = new System.Windows.Forms.ComboBox();
            this.gb_estado = new System.Windows.Forms.GroupBox();
            this.gb_reg = new System.Windows.Forms.GroupBox();
            this.gb_usu = new System.Windows.Forms.GroupBox();
            this.btt_ir_hrg = new System.Windows.Forms.Button();
            this.tb_usu = new System.Windows.Forms.TextBox();
            this.tb_n_col_rg = new System.Windows.Forms.TextBox();
            this.lb_col_rg = new System.Windows.Forms.Label();
            this.lb_vehic = new System.Windows.Forms.Label();
            this.lb_titulo_rg = new System.Windows.Forms.Label();
            this.btt_last_rg = new System.Windows.Forms.Button();
            this.btt_next_rg = new System.Windows.Forms.Button();
            this.btt_back_rg = new System.Windows.Forms.Button();
            this.btt_first_rg = new System.Windows.Forms.Button();
            this.btt_consultar_rg = new System.Windows.Forms.Button();
            this.btt_buscar_rg = new System.Windows.Forms.Button();
            this.btt_cancelar_rg = new System.Windows.Forms.Button();
            this.btt_borrar_rg = new System.Windows.Forms.Button();
            this.btt_modificar_rg = new System.Windows.Forms.Button();
            this.btt_guardar_rg = new System.Windows.Forms.Button();
            this.btt_nuevo_rg = new System.Windows.Forms.Button();
            this.btt_imprimir_rg = new System.Windows.Forms.Button();
            this.btt_imprimir_fra = new System.Windows.Forms.Button();
            this.lb_num_rg_rg = new System.Windows.Forms.Label();
            this.tab_reg = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.gn_f_anul = new System.Windows.Forms.GroupBox();
            this.tb_f_anul = new System.Windows.Forms.TextBox();
            this.gb_enviado = new System.Windows.Forms.GroupBox();
            this.tb_enviado = new System.Windows.Forms.TextBox();
            this.btt_ir_col = new System.Windows.Forms.Button();
            this.btt_col_buscar = new System.Windows.Forms.Button();
            this.tb_vehic = new System.Windows.Forms.TextBox();
            this.lb_exp = new System.Windows.Forms.Label();
            this.tb_observ = new System.Windows.Forms.TextBox();
            this.tb_col_rg = new System.Windows.Forms.TextBox();
            this.btt_ver = new System.Windows.Forms.Button();
            this.btt_explorar = new System.Windows.Forms.Button();
            this.tb_pdf = new System.Windows.Forms.TextBox();
            this.gb_tel = new System.Windows.Forms.GroupBox();
            this.gb_pdf = new System.Windows.Forms.GroupBox();
            this.gb_obs = new System.Windows.Forms.GroupBox();
            this.gp_exp_ntl = new System.Windows.Forms.GroupBox();
            this.tb_exp_ntl = new System.Windows.Forms.TextBox();
            this.tab_fra = new System.Windows.Forms.TabPage();
            this.tab_lin = new System.Windows.Forms.TabPage();
            this.gb_det = new System.Windows.Forms.GroupBox();
            this.btt_det_cancel = new System.Windows.Forms.Button();
            this.gb_det3 = new System.Windows.Forms.GroupBox();
            this.tb_det_cta = new System.Windows.Forms.TextBox();
            this.lb_det_cta = new System.Windows.Forms.Label();
            this.cb_det_iva = new System.Windows.Forms.ComboBox();
            this.tb_det_fra = new System.Windows.Forms.TextBox();
            this.tb_det_descrip = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lb_det_descrip = new System.Windows.Forms.Label();
            this.lb_det_iva = new System.Windows.Forms.Label();
            this.tb_det_impor = new System.Windows.Forms.TextBox();
            this.tb_det_lin = new System.Windows.Forms.TextBox();
            this.lb_det_impor = new System.Windows.Forms.Label();
            this.lb_det_lin = new System.Windows.Forms.Label();
            this.btt_det_del = new System.Windows.Forms.Button();
            this.btt_det_save = new System.Windows.Forms.Button();
            this.btt_det_new = new System.Windows.Forms.Button();
            this.dgv_linfac = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.gb_escri = new System.Windows.Forms.GroupBox();
            this.tb_entidad = new System.Windows.Forms.TextBox();
            this.lb_ent_bc = new System.Windows.Forms.Label();
            this.tb_n_operacion = new System.Windows.Forms.TextBox();
            this.lb_n_opera = new System.Windows.Forms.Label();
            this.tb_notario = new System.Windows.Forms.TextBox();
            this.lb_notario = new System.Windows.Forms.Label();
            this.tb_impor_liq = new System.Windows.Forms.TextBox();
            this.lb_impor_liq = new System.Windows.Forms.Label();
            this.tb_firmado_por = new System.Windows.Forms.TextBox();
            this.lb_firmado_por = new System.Windows.Forms.Label();
            this.gb_fra.SuspendLayout();
            this.gb_est_fra.SuspendLayout();
            this.gb_fac_a.SuspendLayout();
            this.gb_t_fra.SuspendLayout();
            this.gb_del.SuspendLayout();
            this.gb_estado.SuspendLayout();
            this.gb_reg.SuspendLayout();
            this.gb_usu.SuspendLayout();
            this.tab_reg.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.gn_f_anul.SuspendLayout();
            this.gb_enviado.SuspendLayout();
            this.gp_exp_ntl.SuspendLayout();
            this.tab_fra.SuspendLayout();
            this.tab_lin.SuspendLayout();
            this.gb_det.SuspendLayout();
            this.gb_det3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_linfac)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.gb_escri.SuspendLayout();
            this.SuspendLayout();
            // 
            // p_reg
            // 
            this.p_reg.BackColor = System.Drawing.Color.LightSteelBlue;
            this.p_reg.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.p_reg.Location = new System.Drawing.Point(12, 48);
            this.p_reg.Name = "p_reg";
            this.p_reg.Size = new System.Drawing.Size(667, 462);
            this.p_reg.TabIndex = 0;
            // 
            // tb_bate_ant
            // 
            this.tb_bate_ant.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_bate_ant.Location = new System.Drawing.Point(120, 320);
            this.tb_bate_ant.Name = "tb_bate_ant";
            this.tb_bate_ant.Size = new System.Drawing.Size(95, 24);
            this.tb_bate_ant.TabIndex = 34;
            this.tb_bate_ant.Validating += new System.ComponentModel.CancelEventHandler(this.tb_bate_ant_Validating);
            // 
            // tb_d_col
            // 
            this.tb_d_col.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_d_col.Location = new System.Drawing.Point(364, 305);
            this.tb_d_col.Name = "tb_d_col";
            this.tb_d_col.Size = new System.Drawing.Size(100, 24);
            this.tb_d_col.TabIndex = 86;
            this.tb_d_col.Validating += new System.ComponentModel.CancelEventHandler(this.tb_d_col_Validating);
            this.tb_d_col.Validated += new System.EventHandler(this.tb_d_col_Validated);
            // 
            // cb_estado
            // 
            this.cb_estado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_estado.FormattingEnabled = true;
            this.cb_estado.Items.AddRange(new object[] {
            "PTE. CLIENTE",
            "PTE. GESTORÍA",
            "EN TRÁMITE",
            "TERMINADO",
            "ANULADO",
            "LIQUIDADO"});
            this.cb_estado.Location = new System.Drawing.Point(6, 21);
            this.cb_estado.Name = "cb_estado";
            this.cb_estado.Size = new System.Drawing.Size(124, 24);
            this.cb_estado.TabIndex = 48;
            this.cb_estado.SelectedIndexChanged += new System.EventHandler(this.cb_estado_SelectedIndexChanged);
            // 
            // gb_fra
            // 
            this.gb_fra.Controls.Add(this.gb_est_fra);
            this.gb_fra.Controls.Add(this.gb_fac_a);
            this.gb_fra.Controls.Add(this.tb_itasa4);
            this.gb_fra.Controls.Add(this.tb_tipo4);
            this.gb_fra.Controls.Add(this.tb_itasa3);
            this.gb_fra.Controls.Add(this.tb_itasa2);
            this.gb_fra.Controls.Add(this.tb_itasa);
            this.gb_fra.Controls.Add(this.lb_tipo4);
            this.gb_fra.Controls.Add(this.tb_tasa4);
            this.gb_fra.Controls.Add(this.lb_tasa4);
            this.gb_fra.Controls.Add(this.tb_tipo3);
            this.gb_fra.Controls.Add(this.lb_tipo3);
            this.gb_fra.Controls.Add(this.tb_tasa3);
            this.gb_fra.Controls.Add(this.lb_tasa3);
            this.gb_fra.Controls.Add(this.tb_tipo2);
            this.gb_fra.Controls.Add(this.lb_tipo2);
            this.gb_fra.Controls.Add(this.tb_tasa2);
            this.gb_fra.Controls.Add(this.lb_tasa2);
            this.gb_fra.Controls.Add(this.tb_d_col);
            this.gb_fra.Controls.Add(this.lb_t_fra);
            this.gb_fra.Controls.Add(this.lb_tasa_fra);
            this.gb_fra.Controls.Add(this.tb_p_iva);
            this.gb_fra.Controls.Add(this.tb_tasa_fra);
            this.gb_fra.Controls.Add(this.lb_p_iva);
            this.gb_fra.Controls.Add(this.tb_hono);
            this.gb_fra.Controls.Add(this.lb_hono);
            this.gb_fra.Controls.Add(this.tb_descrip);
            this.gb_fra.Controls.Add(this.lb_descrip);
            this.gb_fra.Controls.Add(this.btt_facturar);
            this.gb_fra.Controls.Add(this.tb_tipo);
            this.gb_fra.Controls.Add(this.dtp_fec_fra);
            this.gb_fra.Controls.Add(this.lb_f_fra);
            this.gb_fra.Controls.Add(this.tb_fra);
            this.gb_fra.Controls.Add(this.tb_tasa);
            this.gb_fra.Controls.Add(this.lb_tasa);
            this.gb_fra.Controls.Add(this.lb_fra);
            this.gb_fra.Controls.Add(this.lb_tipo);
            this.gb_fra.Controls.Add(this.gb_t_fra);
            this.gb_fra.Location = new System.Drawing.Point(6, 6);
            this.gb_fra.Name = "gb_fra";
            this.gb_fra.Size = new System.Drawing.Size(649, 391);
            this.gb_fra.TabIndex = 30;
            this.gb_fra.TabStop = false;
            // 
            // gb_est_fra
            // 
            this.gb_est_fra.BackColor = System.Drawing.Color.LightBlue;
            this.gb_est_fra.Controls.Add(this.cb_est_fra);
            this.gb_est_fra.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_est_fra.Location = new System.Drawing.Point(471, 193);
            this.gb_est_fra.Name = "gb_est_fra";
            this.gb_est_fra.Size = new System.Drawing.Size(159, 52);
            this.gb_est_fra.TabIndex = 92;
            this.gb_est_fra.TabStop = false;
            this.gb_est_fra.Text = "Estado Fra.";
            // 
            // cb_est_fra
            // 
            this.cb_est_fra.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_est_fra.FormattingEnabled = true;
            this.cb_est_fra.Items.AddRange(new object[] {
            "",
            "LISTADA",
            "ENLAZADA"});
            this.cb_est_fra.Location = new System.Drawing.Point(13, 22);
            this.cb_est_fra.Name = "cb_est_fra";
            this.cb_est_fra.Size = new System.Drawing.Size(140, 24);
            this.cb_est_fra.TabIndex = 91;
            // 
            // gb_fac_a
            // 
            this.gb_fac_a.BackColor = System.Drawing.Color.LightBlue;
            this.gb_fac_a.Controls.Add(this.cb_cte_fra);
            this.gb_fac_a.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_fac_a.Location = new System.Drawing.Point(471, 122);
            this.gb_fac_a.Name = "gb_fac_a";
            this.gb_fac_a.Size = new System.Drawing.Size(159, 52);
            this.gb_fac_a.TabIndex = 91;
            this.gb_fac_a.TabStop = false;
            this.gb_fac_a.Text = "Fact. a:";
            // 
            // cb_cte_fra
            // 
            this.cb_cte_fra.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_cte_fra.FormattingEnabled = true;
            this.cb_cte_fra.Items.AddRange(new object[] {
            "CLIENTE",
            "TITULAR",
            "COLABORADOR"});
            this.cb_cte_fra.Location = new System.Drawing.Point(13, 22);
            this.cb_cte_fra.Name = "cb_cte_fra";
            this.cb_cte_fra.Size = new System.Drawing.Size(140, 24);
            this.cb_cte_fra.TabIndex = 91;
            // 
            // tb_itasa4
            // 
            this.tb_itasa4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_itasa4.BackColor = System.Drawing.Color.LightBlue;
            this.tb_itasa4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_itasa4.Enabled = false;
            this.tb_itasa4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_itasa4.ForeColor = System.Drawing.Color.Black;
            this.tb_itasa4.Location = new System.Drawing.Point(364, 221);
            this.tb_itasa4.Name = "tb_itasa4";
            this.tb_itasa4.Size = new System.Drawing.Size(100, 22);
            this.tb_itasa4.TabIndex = 103;
            this.tb_itasa4.TabStop = false;
            this.tb_itasa4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_tipo4
            // 
            this.tb_tipo4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_tipo4.Location = new System.Drawing.Point(307, 221);
            this.tb_tipo4.MaxLength = 5;
            this.tb_tipo4.Name = "tb_tipo4";
            this.tb_tipo4.Size = new System.Drawing.Size(51, 24);
            this.tb_tipo4.TabIndex = 70;
            this.tb_tipo4.Validating += new System.ComponentModel.CancelEventHandler(this.tb_tipo4_Validating);
            this.tb_tipo4.Validated += new System.EventHandler(this.tb_tipo4_Validated);
            // 
            // tb_itasa3
            // 
            this.tb_itasa3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_itasa3.BackColor = System.Drawing.Color.LightBlue;
            this.tb_itasa3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_itasa3.Enabled = false;
            this.tb_itasa3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_itasa3.ForeColor = System.Drawing.Color.Black;
            this.tb_itasa3.Location = new System.Drawing.Point(364, 189);
            this.tb_itasa3.Name = "tb_itasa3";
            this.tb_itasa3.Size = new System.Drawing.Size(100, 22);
            this.tb_itasa3.TabIndex = 98;
            this.tb_itasa3.TabStop = false;
            this.tb_itasa3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_itasa2
            // 
            this.tb_itasa2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_itasa2.BackColor = System.Drawing.Color.LightBlue;
            this.tb_itasa2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_itasa2.Enabled = false;
            this.tb_itasa2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_itasa2.ForeColor = System.Drawing.Color.Black;
            this.tb_itasa2.Location = new System.Drawing.Point(365, 157);
            this.tb_itasa2.Name = "tb_itasa2";
            this.tb_itasa2.Size = new System.Drawing.Size(100, 22);
            this.tb_itasa2.TabIndex = 93;
            this.tb_itasa2.TabStop = false;
            this.tb_itasa2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_itasa
            // 
            this.tb_itasa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_itasa.BackColor = System.Drawing.Color.LightBlue;
            this.tb_itasa.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_itasa.Enabled = false;
            this.tb_itasa.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_itasa.ForeColor = System.Drawing.Color.Black;
            this.tb_itasa.Location = new System.Drawing.Point(364, 123);
            this.tb_itasa.Name = "tb_itasa";
            this.tb_itasa.Size = new System.Drawing.Size(100, 22);
            this.tb_itasa.TabIndex = 88;
            this.tb_itasa.TabStop = false;
            this.tb_itasa.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lb_tipo4
            // 
            this.lb_tipo4.AutoSize = true;
            this.lb_tipo4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tipo4.Location = new System.Drawing.Point(260, 221);
            this.lb_tipo4.Name = "lb_tipo4";
            this.lb_tipo4.Size = new System.Drawing.Size(37, 18);
            this.lb_tipo4.TabIndex = 101;
            this.lb_tipo4.Text = "Tipo";
            // 
            // tb_tasa4
            // 
            this.tb_tasa4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_tasa4.Location = new System.Drawing.Point(112, 221);
            this.tb_tasa4.Name = "tb_tasa4";
            this.tb_tasa4.Size = new System.Drawing.Size(129, 24);
            this.tb_tasa4.TabIndex = 68;
            this.tb_tasa4.Validating += new System.ComponentModel.CancelEventHandler(this.tb_tasa4_Validating);
            // 
            // lb_tasa4
            // 
            this.lb_tasa4.AutoSize = true;
            this.lb_tasa4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tasa4.Location = new System.Drawing.Point(43, 221);
            this.lb_tasa4.Name = "lb_tasa4";
            this.lb_tasa4.Size = new System.Drawing.Size(56, 18);
            this.lb_tasa4.TabIndex = 99;
            this.lb_tasa4.Text = "N.Tasa";
            // 
            // tb_tipo3
            // 
            this.tb_tipo3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_tipo3.Location = new System.Drawing.Point(307, 189);
            this.tb_tipo3.MaxLength = 5;
            this.tb_tipo3.Name = "tb_tipo3";
            this.tb_tipo3.Size = new System.Drawing.Size(51, 24);
            this.tb_tipo3.TabIndex = 66;
            this.tb_tipo3.Validating += new System.ComponentModel.CancelEventHandler(this.tb_tipo3_Validating);
            this.tb_tipo3.Validated += new System.EventHandler(this.tb_tipo3_Validated);
            // 
            // lb_tipo3
            // 
            this.lb_tipo3.AutoSize = true;
            this.lb_tipo3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tipo3.Location = new System.Drawing.Point(260, 189);
            this.lb_tipo3.Name = "lb_tipo3";
            this.lb_tipo3.Size = new System.Drawing.Size(37, 18);
            this.lb_tipo3.TabIndex = 96;
            this.lb_tipo3.Text = "Tipo";
            // 
            // tb_tasa3
            // 
            this.tb_tasa3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_tasa3.Location = new System.Drawing.Point(112, 189);
            this.tb_tasa3.Name = "tb_tasa3";
            this.tb_tasa3.Size = new System.Drawing.Size(129, 24);
            this.tb_tasa3.TabIndex = 64;
            this.tb_tasa3.Validating += new System.ComponentModel.CancelEventHandler(this.tb_tasa3_Validating);
            // 
            // lb_tasa3
            // 
            this.lb_tasa3.AutoSize = true;
            this.lb_tasa3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tasa3.Location = new System.Drawing.Point(43, 189);
            this.lb_tasa3.Name = "lb_tasa3";
            this.lb_tasa3.Size = new System.Drawing.Size(56, 18);
            this.lb_tasa3.TabIndex = 94;
            this.lb_tasa3.Text = "N.Tasa";
            // 
            // tb_tipo2
            // 
            this.tb_tipo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_tipo2.Location = new System.Drawing.Point(307, 157);
            this.tb_tipo2.MaxLength = 5;
            this.tb_tipo2.Name = "tb_tipo2";
            this.tb_tipo2.Size = new System.Drawing.Size(51, 24);
            this.tb_tipo2.TabIndex = 62;
            this.tb_tipo2.Validating += new System.ComponentModel.CancelEventHandler(this.tb_tipo2_Validating);
            this.tb_tipo2.Validated += new System.EventHandler(this.tb_tipo2_Validated);
            // 
            // lb_tipo2
            // 
            this.lb_tipo2.AutoSize = true;
            this.lb_tipo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tipo2.Location = new System.Drawing.Point(260, 157);
            this.lb_tipo2.Name = "lb_tipo2";
            this.lb_tipo2.Size = new System.Drawing.Size(37, 18);
            this.lb_tipo2.TabIndex = 91;
            this.lb_tipo2.Text = "Tipo";
            // 
            // tb_tasa2
            // 
            this.tb_tasa2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_tasa2.Location = new System.Drawing.Point(112, 157);
            this.tb_tasa2.Name = "tb_tasa2";
            this.tb_tasa2.Size = new System.Drawing.Size(129, 24);
            this.tb_tasa2.TabIndex = 60;
            this.tb_tasa2.Validating += new System.ComponentModel.CancelEventHandler(this.tb_tasa2_Validating);
            // 
            // lb_tasa2
            // 
            this.lb_tasa2.AutoSize = true;
            this.lb_tasa2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tasa2.Location = new System.Drawing.Point(43, 157);
            this.lb_tasa2.Name = "lb_tasa2";
            this.lb_tasa2.Size = new System.Drawing.Size(56, 18);
            this.lb_tasa2.TabIndex = 89;
            this.lb_tasa2.Text = "N.Tasa";
            // 
            // lb_t_fra
            // 
            this.lb_t_fra.AutoSize = true;
            this.lb_t_fra.BackColor = System.Drawing.Color.LightSlateGray;
            this.lb_t_fra.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_t_fra.Location = new System.Drawing.Point(494, 308);
            this.lb_t_fra.Name = "lb_t_fra";
            this.lb_t_fra.Size = new System.Drawing.Size(116, 20);
            this.lb_t_fra.TabIndex = 84;
            this.lb_t_fra.Text = "Total Factura";
            // 
            // lb_tasa_fra
            // 
            this.lb_tasa_fra.AutoSize = true;
            this.lb_tasa_fra.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tasa_fra.Location = new System.Drawing.Point(310, 346);
            this.lb_tasa_fra.Name = "lb_tasa_fra";
            this.lb_tasa_fra.Size = new System.Drawing.Size(49, 18);
            this.lb_tasa_fra.TabIndex = 82;
            this.lb_tasa_fra.Text = "Tasas";
            // 
            // tb_p_iva
            // 
            this.tb_p_iva.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_p_iva.Location = new System.Drawing.Point(263, 340);
            this.tb_p_iva.MaxLength = 3;
            this.tb_p_iva.Name = "tb_p_iva";
            this.tb_p_iva.Size = new System.Drawing.Size(41, 24);
            this.tb_p_iva.TabIndex = 88;
            this.tb_p_iva.Validating += new System.ComponentModel.CancelEventHandler(this.tb_p_iva_Validating);
            this.tb_p_iva.Validated += new System.EventHandler(this.tb_p_iva_Validated);
            // 
            // tb_tasa_fra
            // 
            this.tb_tasa_fra.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_tasa_fra.Location = new System.Drawing.Point(365, 340);
            this.tb_tasa_fra.Name = "tb_tasa_fra";
            this.tb_tasa_fra.Size = new System.Drawing.Size(100, 24);
            this.tb_tasa_fra.TabIndex = 90;
            this.tb_tasa_fra.Validating += new System.ComponentModel.CancelEventHandler(this.tb_tasa_fra_Validating);
            this.tb_tasa_fra.Validated += new System.EventHandler(this.tb_tasa_fra_Validated);
            // 
            // lb_p_iva
            // 
            this.lb_p_iva.AutoSize = true;
            this.lb_p_iva.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_p_iva.Location = new System.Drawing.Point(213, 346);
            this.lb_p_iva.Name = "lb_p_iva";
            this.lb_p_iva.Size = new System.Drawing.Size(46, 18);
            this.lb_p_iva.TabIndex = 80;
            this.lb_p_iva.Text = "% IVA";
            // 
            // tb_hono
            // 
            this.tb_hono.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_hono.Location = new System.Drawing.Point(108, 308);
            this.tb_hono.Name = "tb_hono";
            this.tb_hono.Size = new System.Drawing.Size(100, 24);
            this.tb_hono.TabIndex = 84;
            this.tb_hono.Validating += new System.ComponentModel.CancelEventHandler(this.tb_base_Validating);
            this.tb_hono.Validated += new System.EventHandler(this.tb_base_Validated);
            // 
            // lb_hono
            // 
            this.lb_hono.AutoSize = true;
            this.lb_hono.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_hono.Location = new System.Drawing.Point(20, 308);
            this.lb_hono.Name = "lb_hono";
            this.lb_hono.Size = new System.Drawing.Size(83, 18);
            this.lb_hono.TabIndex = 78;
            this.lb_hono.Text = "Honorarios";
            // 
            // tb_descrip
            // 
            this.tb_descrip.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_descrip.Location = new System.Drawing.Point(112, 61);
            this.tb_descrip.MaxLength = 300;
            this.tb_descrip.Multiline = true;
            this.tb_descrip.Name = "tb_descrip";
            this.tb_descrip.Size = new System.Drawing.Size(512, 50);
            this.tb_descrip.TabIndex = 55;
            this.tb_descrip.Enter += new System.EventHandler(this.tb_descrip_Enter);
            this.tb_descrip.Validating += new System.ComponentModel.CancelEventHandler(this.tb_descrip_Validating);
            // 
            // lb_descrip
            // 
            this.lb_descrip.AutoSize = true;
            this.lb_descrip.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_descrip.Location = new System.Drawing.Point(36, 64);
            this.lb_descrip.Name = "lb_descrip";
            this.lb_descrip.Size = new System.Drawing.Size(63, 18);
            this.lb_descrip.TabIndex = 76;
            this.lb_descrip.Text = "Descrip.";
            // 
            // btt_facturar
            // 
            this.btt_facturar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_facturar.Location = new System.Drawing.Point(24, 19);
            this.btt_facturar.Name = "btt_facturar";
            this.btt_facturar.Size = new System.Drawing.Size(90, 24);
            this.btt_facturar.TabIndex = 50;
            this.btt_facturar.Text = "Facturar";
            this.btt_facturar.UseVisualStyleBackColor = true;
            this.btt_facturar.Click += new System.EventHandler(this.btt_facturar_Click);
            // 
            // tb_tipo
            // 
            this.tb_tipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_tipo.Location = new System.Drawing.Point(307, 123);
            this.tb_tipo.MaxLength = 5;
            this.tb_tipo.Name = "tb_tipo";
            this.tb_tipo.Size = new System.Drawing.Size(51, 24);
            this.tb_tipo.TabIndex = 58;
            this.tb_tipo.Validating += new System.ComponentModel.CancelEventHandler(this.tb_tipo_Validating);
            this.tb_tipo.Validated += new System.EventHandler(this.tb_tipo_Validated);
            // 
            // dtp_fec_fra
            // 
            this.dtp_fec_fra.Location = new System.Drawing.Point(203, 23);
            this.dtp_fec_fra.Name = "dtp_fec_fra";
            this.dtp_fec_fra.Size = new System.Drawing.Size(197, 20);
            this.dtp_fec_fra.TabIndex = 52;
            // 
            // lb_f_fra
            // 
            this.lb_f_fra.AutoSize = true;
            this.lb_f_fra.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_f_fra.Location = new System.Drawing.Point(130, 23);
            this.lb_f_fra.Name = "lb_f_fra";
            this.lb_f_fra.Size = new System.Drawing.Size(67, 18);
            this.lb_f_fra.TabIndex = 74;
            this.lb_f_fra.Text = "Fec. Fra.";
            // 
            // tb_fra
            // 
            this.tb_fra.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_fra.Location = new System.Drawing.Point(524, 20);
            this.tb_fra.Name = "tb_fra";
            this.tb_fra.Size = new System.Drawing.Size(100, 24);
            this.tb_fra.TabIndex = 54;
            this.tb_fra.Enter += new System.EventHandler(this.tb_fra_Enter);
            this.tb_fra.Leave += new System.EventHandler(this.tb_fra_Leave);
            this.tb_fra.Validating += new System.ComponentModel.CancelEventHandler(this.tb_fra_Validating);
            // 
            // tb_tasa
            // 
            this.tb_tasa.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_tasa.Location = new System.Drawing.Point(112, 123);
            this.tb_tasa.Name = "tb_tasa";
            this.tb_tasa.Size = new System.Drawing.Size(129, 24);
            this.tb_tasa.TabIndex = 56;
            this.tb_tasa.Validating += new System.ComponentModel.CancelEventHandler(this.tb_tasa_Validating);
            // 
            // lb_tasa
            // 
            this.lb_tasa.AutoSize = true;
            this.lb_tasa.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tasa.Location = new System.Drawing.Point(43, 126);
            this.lb_tasa.Name = "lb_tasa";
            this.lb_tasa.Size = new System.Drawing.Size(56, 18);
            this.lb_tasa.TabIndex = 56;
            this.lb_tasa.Text = "N.Tasa";
            // 
            // lb_fra
            // 
            this.lb_fra.AutoSize = true;
            this.lb_fra.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_fra.Location = new System.Drawing.Point(421, 22);
            this.lb_fra.Name = "lb_fra";
            this.lb_fra.Size = new System.Drawing.Size(98, 18);
            this.lb_fra.TabIndex = 72;
            this.lb_fra.Text = "Num. Factura";
            // 
            // lb_tipo
            // 
            this.lb_tipo.AutoSize = true;
            this.lb_tipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tipo.Location = new System.Drawing.Point(260, 126);
            this.lb_tipo.Name = "lb_tipo";
            this.lb_tipo.Size = new System.Drawing.Size(37, 18);
            this.lb_tipo.TabIndex = 58;
            this.lb_tipo.Text = "Tipo";
            // 
            // gb_t_fra
            // 
            this.gb_t_fra.Controls.Add(this.tb_base_imp);
            this.gb_t_fra.Controls.Add(this.tb_t_fra);
            this.gb_t_fra.Controls.Add(this.lb_d_col);
            this.gb_t_fra.Controls.Add(this.lb_base);
            this.gb_t_fra.Location = new System.Drawing.Point(15, 293);
            this.gb_t_fra.Name = "gb_t_fra";
            this.gb_t_fra.Size = new System.Drawing.Size(615, 83);
            this.gb_t_fra.TabIndex = 104;
            this.gb_t_fra.TabStop = false;
            // 
            // tb_base_imp
            // 
            this.tb_base_imp.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_base_imp.BackColor = System.Drawing.Color.LightBlue;
            this.tb_base_imp.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_base_imp.Enabled = false;
            this.tb_base_imp.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_base_imp.ForeColor = System.Drawing.Color.Black;
            this.tb_base_imp.Location = new System.Drawing.Point(93, 52);
            this.tb_base_imp.Name = "tb_base_imp";
            this.tb_base_imp.Size = new System.Drawing.Size(100, 22);
            this.tb_base_imp.TabIndex = 87;
            this.tb_base_imp.TabStop = false;
            this.tb_base_imp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tb_t_fra
            // 
            this.tb_t_fra.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.tb_t_fra.BackColor = System.Drawing.Color.LightBlue;
            this.tb_t_fra.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_t_fra.Enabled = false;
            this.tb_t_fra.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_t_fra.ForeColor = System.Drawing.Color.Black;
            this.tb_t_fra.Location = new System.Drawing.Point(469, 50);
            this.tb_t_fra.Name = "tb_t_fra";
            this.tb_t_fra.Size = new System.Drawing.Size(140, 22);
            this.tb_t_fra.TabIndex = 85;
            this.tb_t_fra.TabStop = false;
            this.tb_t_fra.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lb_d_col
            // 
            this.lb_d_col.AutoSize = true;
            this.lb_d_col.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_d_col.Location = new System.Drawing.Point(249, 15);
            this.lb_d_col.Name = "lb_d_col";
            this.lb_d_col.Size = new System.Drawing.Size(95, 18);
            this.lb_d_col.TabIndex = 22;
            this.lb_d_col.Text = "Dcho. Coleg.";
            // 
            // lb_base
            // 
            this.lb_base.AutoSize = true;
            this.lb_base.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_base.Location = new System.Drawing.Point(34, 50);
            this.lb_base.Name = "lb_base";
            this.lb_base.Size = new System.Drawing.Size(50, 20);
            this.lb_base.TabIndex = 86;
            this.lb_base.Text = "Base";
            // 
            // btt_ac_tl
            // 
            this.btt_ac_tl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_ac_tl.Location = new System.Drawing.Point(24, 282);
            this.btt_ac_tl.Name = "btt_ac_tl";
            this.btt_ac_tl.Size = new System.Drawing.Size(90, 24);
            this.btt_ac_tl.TabIndex = 28;
            this.btt_ac_tl.Text = "Activar Tel.";
            this.btt_ac_tl.UseVisualStyleBackColor = true;
            this.btt_ac_tl.Click += new System.EventHandler(this.btt_ac_tl_Click);
            // 
            // tb_nif
            // 
            this.tb_nif.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_nif.Location = new System.Drawing.Point(259, 320);
            this.tb_nif.Name = "tb_nif";
            this.tb_nif.Size = new System.Drawing.Size(107, 24);
            this.tb_nif.TabIndex = 36;
            this.tb_nif.Validating += new System.ComponentModel.CancelEventHandler(this.tb_nif_Validating);
            // 
            // lb_nif
            // 
            this.lb_nif.AutoSize = true;
            this.lb_nif.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nif.Location = new System.Drawing.Point(221, 322);
            this.lb_nif.Name = "lb_nif";
            this.lb_nif.Size = new System.Drawing.Size(31, 18);
            this.lb_nif.TabIndex = 64;
            this.lb_nif.Text = "NIF";
            // 
            // lb_bate_ant
            // 
            this.lb_bate_ant.AutoSize = true;
            this.lb_bate_ant.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_bate_ant.Location = new System.Drawing.Point(21, 322);
            this.lb_bate_ant.Name = "lb_bate_ant";
            this.lb_bate_ant.Size = new System.Drawing.Size(93, 18);
            this.lb_bate_ant.TabIndex = 62;
            this.lb_bate_ant.Text = "Bate Anterior";
            // 
            // tb_c_serv
            // 
            this.tb_c_serv.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_c_serv.Location = new System.Drawing.Point(479, 320);
            this.tb_c_serv.Name = "tb_c_serv";
            this.tb_c_serv.Size = new System.Drawing.Size(148, 24);
            this.tb_c_serv.TabIndex = 38;
            this.tb_c_serv.Validating += new System.ComponentModel.CancelEventHandler(this.tb_c_serv_Validating);
            // 
            // lb_c_serv
            // 
            this.lb_c_serv.AutoSize = true;
            this.lb_c_serv.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_c_serv.Location = new System.Drawing.Point(375, 323);
            this.lb_c_serv.Name = "lb_c_serv";
            this.lb_c_serv.Size = new System.Drawing.Size(98, 18);
            this.lb_c_serv.TabIndex = 60;
            this.lb_c_serv.Text = "Cambio Serv.";
            // 
            // dtp_fec_pre
            // 
            this.dtp_fec_pre.Location = new System.Drawing.Point(433, 280);
            this.dtp_fec_pre.Name = "dtp_fec_pre";
            this.dtp_fec_pre.Size = new System.Drawing.Size(197, 20);
            this.dtp_fec_pre.TabIndex = 32;
            // 
            // lb_f_pre
            // 
            this.lb_f_pre.AutoSize = true;
            this.lb_f_pre.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_f_pre.Location = new System.Drawing.Point(353, 280);
            this.lb_f_pre.Name = "lb_f_pre";
            this.lb_f_pre.Size = new System.Drawing.Size(76, 18);
            this.lb_f_pre.TabIndex = 53;
            this.lb_f_pre.Text = "Fec. Pres.";
            // 
            // tb_exp
            // 
            this.tb_exp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_exp.Location = new System.Drawing.Point(203, 280);
            this.tb_exp.Name = "tb_exp";
            this.tb_exp.Size = new System.Drawing.Size(144, 24);
            this.tb_exp.TabIndex = 30;
            this.tb_exp.Validating += new System.ComponentModel.CancelEventHandler(this.tb_exp_Validating);
            // 
            // cb_sec_int
            // 
            this.cb_sec_int.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_sec_int.FormattingEnabled = true;
            this.cb_sec_int.Items.AddRange(new object[] {
            "GESTASER",
            "EX",
            "AVPO",
            "A"});
            this.cb_sec_int.Location = new System.Drawing.Point(301, 186);
            this.cb_sec_int.Name = "cb_sec_int";
            this.cb_sec_int.Size = new System.Drawing.Size(99, 24);
            this.cb_sec_int.TabIndex = 24;
            // 
            // lb_sec_int
            // 
            this.lb_sec_int.AutoSize = true;
            this.lb_sec_int.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_sec_int.Location = new System.Drawing.Point(226, 189);
            this.lb_sec_int.Name = "lb_sec_int";
            this.lb_sec_int.Size = new System.Drawing.Size(69, 18);
            this.lb_sec_int.TabIndex = 32;
            this.lb_sec_int.Text = "Secc. Int.";
            // 
            // tb_matri
            // 
            this.tb_matri.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_matri.Location = new System.Drawing.Point(86, 196);
            this.tb_matri.Name = "tb_matri";
            this.tb_matri.Size = new System.Drawing.Size(100, 24);
            this.tb_matri.TabIndex = 22;
            this.tb_matri.Validating += new System.ComponentModel.CancelEventHandler(this.tb_matri_Validating);
            // 
            // lb_matri
            // 
            this.lb_matri.AutoSize = true;
            this.lb_matri.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_matri.Location = new System.Drawing.Point(3, 190);
            this.lb_matri.Name = "lb_matri";
            this.lb_matri.Size = new System.Drawing.Size(68, 18);
            this.lb_matri.TabIndex = 30;
            this.lb_matri.Text = "Matrícula";
            // 
            // cb_tram
            // 
            this.cb_tram.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_tram.FormattingEnabled = true;
            this.cb_tram.Location = new System.Drawing.Point(300, 153);
            this.cb_tram.Name = "cb_tram";
            this.cb_tram.Size = new System.Drawing.Size(195, 24);
            this.cb_tram.TabIndex = 20;
            // 
            // lb_tram
            // 
            this.lb_tram.AutoSize = true;
            this.lb_tram.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tram.Location = new System.Drawing.Point(237, 157);
            this.lb_tram.Name = "lb_tram";
            this.lb_tram.Size = new System.Drawing.Size(58, 18);
            this.lb_tram.TabIndex = 28;
            this.lb_tram.Text = "Trámite";
            // 
            // btt_ir_tit
            // 
            this.btt_ir_tit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_ir_tit.Location = new System.Drawing.Point(462, 99);
            this.btt_ir_tit.Name = "btt_ir_tit";
            this.btt_ir_tit.Size = new System.Drawing.Size(44, 24);
            this.btt_ir_tit.TabIndex = 14;
            this.btt_ir_tit.Text = "Ir";
            this.btt_ir_tit.UseVisualStyleBackColor = true;
            this.btt_ir_tit.Click += new System.EventHandler(this.btt_ir_tit_Click);
            // 
            // btt_ir_cte
            // 
            this.btt_ir_cte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_ir_cte.Location = new System.Drawing.Point(462, 66);
            this.btt_ir_cte.Name = "btt_ir_cte";
            this.btt_ir_cte.Size = new System.Drawing.Size(44, 24);
            this.btt_ir_cte.TabIndex = 10;
            this.btt_ir_cte.Text = "Ir";
            this.btt_ir_cte.UseVisualStyleBackColor = true;
            this.btt_ir_cte.Click += new System.EventHandler(this.btt_ir_cte_Click);
            // 
            // cb_sec
            // 
            this.cb_sec.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_sec.FormattingEnabled = true;
            this.cb_sec.Items.AddRange(new object[] {
            "Hacienda",
            "Seg. Social",
            "Extranjería",
            "Conductores",
            "Vehículos",
            "Transporte",
            "Sanciones Tráfico",
            "Escrituras",
            "Herencias",
            "Varios"});
            this.cb_sec.Location = new System.Drawing.Point(86, 163);
            this.cb_sec.Name = "cb_sec";
            this.cb_sec.Size = new System.Drawing.Size(129, 24);
            this.cb_sec.TabIndex = 18;
            this.cb_sec.SelectedIndexChanged += new System.EventHandler(this.cb_sec_SelectedIndexChanged);
            // 
            // lb_sec
            // 
            this.lb_sec.AutoSize = true;
            this.lb_sec.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_sec.Location = new System.Drawing.Point(9, 157);
            this.lb_sec.Name = "lb_sec";
            this.lb_sec.Size = new System.Drawing.Size(62, 18);
            this.lb_sec.TabIndex = 26;
            this.lb_sec.Text = "Sección";
            // 
            // btt_tit_buscar
            // 
            this.btt_tit_buscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_tit_buscar.Location = new System.Drawing.Point(396, 99);
            this.btt_tit_buscar.Name = "btt_tit_buscar";
            this.btt_tit_buscar.Size = new System.Drawing.Size(66, 24);
            this.btt_tit_buscar.TabIndex = 13;
            this.btt_tit_buscar.Text = "Buscar";
            this.btt_tit_buscar.UseVisualStyleBackColor = true;
            this.btt_tit_buscar.Click += new System.EventHandler(this.btt_tit_buscar_Click_1);
            // 
            // btt_cte_buscar
            // 
            this.btt_cte_buscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_cte_buscar.Location = new System.Drawing.Point(396, 66);
            this.btt_cte_buscar.Name = "btt_cte_buscar";
            this.btt_cte_buscar.Size = new System.Drawing.Size(66, 24);
            this.btt_cte_buscar.TabIndex = 8;
            this.btt_cte_buscar.Text = "Buscar";
            this.btt_cte_buscar.UseVisualStyleBackColor = true;
            this.btt_cte_buscar.Click += new System.EventHandler(this.btt_cte_buscar_Click);
            // 
            // tb_n_tit_rg
            // 
            this.tb_n_tit_rg.BackColor = System.Drawing.Color.LightSteelBlue;
            this.tb_n_tit_rg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_n_tit_rg.Enabled = false;
            this.tb_n_tit_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_n_tit_rg.ForeColor = System.Drawing.Color.Black;
            this.tb_n_tit_rg.Location = new System.Drawing.Point(192, 104);
            this.tb_n_tit_rg.Name = "tb_n_tit_rg";
            this.tb_n_tit_rg.Size = new System.Drawing.Size(200, 15);
            this.tb_n_tit_rg.TabIndex = 22;
            this.tb_n_tit_rg.TabStop = false;
            // 
            // tb_tit_rg
            // 
            this.tb_tit_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_tit_rg.Location = new System.Drawing.Point(86, 97);
            this.tb_tit_rg.Name = "tb_tit_rg";
            this.tb_tit_rg.Size = new System.Drawing.Size(100, 24);
            this.tb_tit_rg.TabIndex = 12;
            this.tb_tit_rg.Validating += new System.ComponentModel.CancelEventHandler(this.tb_tit_rg_Validating);
            // 
            // lb_tit_reg
            // 
            this.lb_tit_reg.AutoSize = true;
            this.lb_tit_reg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tit_reg.Location = new System.Drawing.Point(23, 91);
            this.lb_tit_reg.Name = "lb_tit_reg";
            this.lb_tit_reg.Size = new System.Drawing.Size(48, 18);
            this.lb_tit_reg.TabIndex = 20;
            this.lb_tit_reg.Text = "Titular";
            // 
            // tb_n_cte_rg
            // 
            this.tb_n_cte_rg.BackColor = System.Drawing.Color.LightSteelBlue;
            this.tb_n_cte_rg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_n_cte_rg.Enabled = false;
            this.tb_n_cte_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_n_cte_rg.ForeColor = System.Drawing.Color.Black;
            this.tb_n_cte_rg.Location = new System.Drawing.Point(192, 66);
            this.tb_n_cte_rg.Name = "tb_n_cte_rg";
            this.tb_n_cte_rg.Size = new System.Drawing.Size(200, 15);
            this.tb_n_cte_rg.TabIndex = 17;
            this.tb_n_cte_rg.TabStop = false;
            // 
            // tb_cte_rg
            // 
            this.tb_cte_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_cte_rg.Location = new System.Drawing.Point(86, 64);
            this.tb_cte_rg.Name = "tb_cte_rg";
            this.tb_cte_rg.Size = new System.Drawing.Size(100, 24);
            this.tb_cte_rg.TabIndex = 6;
            this.tb_cte_rg.Validating += new System.ComponentModel.CancelEventHandler(this.tb_cte_rg_Validating);
            // 
            // lb_cte_rg
            // 
            this.lb_cte_rg.AutoSize = true;
            this.lb_cte_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_cte_rg.Location = new System.Drawing.Point(18, 58);
            this.lb_cte_rg.Name = "lb_cte_rg";
            this.lb_cte_rg.Size = new System.Drawing.Size(53, 18);
            this.lb_cte_rg.TabIndex = 15;
            this.lb_cte_rg.Text = "Cliente";
            // 
            // lb_fec_ent
            // 
            this.lb_fec_ent.AutoSize = true;
            this.lb_fec_ent.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_fec_ent.Location = new System.Drawing.Point(226, 31);
            this.lb_fec_ent.Name = "lb_fec_ent";
            this.lb_fec_ent.Size = new System.Drawing.Size(49, 18);
            this.lb_fec_ent.TabIndex = 13;
            this.lb_fec_ent.Text = "Fecha";
            // 
            // dtp_fec_rg
            // 
            this.dtp_fec_rg.Location = new System.Drawing.Point(281, 31);
            this.dtp_fec_rg.Name = "dtp_fec_rg";
            this.dtp_fec_rg.Size = new System.Drawing.Size(197, 20);
            this.dtp_fec_rg.TabIndex = 4;
            // 
            // tb_n_reg
            // 
            this.tb_n_reg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_n_reg.Location = new System.Drawing.Point(86, 31);
            this.tb_n_reg.Name = "tb_n_reg";
            this.tb_n_reg.Size = new System.Drawing.Size(100, 24);
            this.tb_n_reg.TabIndex = 2;
            // 
            // lb_n_reg
            // 
            this.lb_n_reg.AutoSize = true;
            this.lb_n_reg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_n_reg.Location = new System.Drawing.Point(9, 25);
            this.lb_n_reg.Name = "lb_n_reg";
            this.lb_n_reg.Size = new System.Drawing.Size(62, 18);
            this.lb_n_reg.TabIndex = 11;
            this.lb_n_reg.Text = "Número";
            // 
            // gb_del
            // 
            this.gb_del.BackColor = System.Drawing.Color.LightBlue;
            this.gb_del.Controls.Add(this.cb_deleg);
            this.gb_del.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_del.Location = new System.Drawing.Point(517, 10);
            this.gb_del.Name = "gb_del";
            this.gb_del.Size = new System.Drawing.Size(134, 45);
            this.gb_del.TabIndex = 0;
            this.gb_del.TabStop = false;
            this.gb_del.Text = "Delegación";
            // 
            // cb_deleg
            // 
            this.cb_deleg.Enabled = false;
            this.cb_deleg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_deleg.FormattingEnabled = true;
            this.cb_deleg.Items.AddRange(new object[] {
            "YECLA",
            "ALBACETE",
            "MURCIA"});
            this.cb_deleg.Location = new System.Drawing.Point(6, 17);
            this.cb_deleg.Name = "cb_deleg";
            this.cb_deleg.Size = new System.Drawing.Size(124, 24);
            this.cb_deleg.TabIndex = 49;
            // 
            // gb_estado
            // 
            this.gb_estado.BackColor = System.Drawing.Color.LightBlue;
            this.gb_estado.Controls.Add(this.cb_estado);
            this.gb_estado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_estado.Location = new System.Drawing.Point(517, 58);
            this.gb_estado.Name = "gb_estado";
            this.gb_estado.Size = new System.Drawing.Size(134, 55);
            this.gb_estado.TabIndex = 0;
            this.gb_estado.TabStop = false;
            this.gb_estado.Text = "Estado";
            // 
            // gb_reg
            // 
            this.gb_reg.BackColor = System.Drawing.Color.LightSteelBlue;
            this.gb_reg.Controls.Add(this.gb_usu);
            this.gb_reg.Controls.Add(this.tb_n_col_rg);
            this.gb_reg.Controls.Add(this.lb_col_rg);
            this.gb_reg.Controls.Add(this.lb_vehic);
            this.gb_reg.Controls.Add(this.lb_matri);
            this.gb_reg.Controls.Add(this.lb_sec);
            this.gb_reg.Controls.Add(this.lb_tit_reg);
            this.gb_reg.Controls.Add(this.lb_cte_rg);
            this.gb_reg.Controls.Add(this.lb_n_reg);
            this.gb_reg.Controls.Add(this.lb_tram);
            this.gb_reg.Controls.Add(this.cb_tram);
            this.gb_reg.Controls.Add(this.lb_sec_int);
            this.gb_reg.Controls.Add(this.cb_sec_int);
            this.gb_reg.Location = new System.Drawing.Point(10, 10);
            this.gb_reg.Name = "gb_reg";
            this.gb_reg.Size = new System.Drawing.Size(501, 253);
            this.gb_reg.TabIndex = 0;
            this.gb_reg.TabStop = false;
            // 
            // gb_usu
            // 
            this.gb_usu.Controls.Add(this.btt_ir_hrg);
            this.gb_usu.Controls.Add(this.tb_usu);
            this.gb_usu.Location = new System.Drawing.Point(406, 182);
            this.gb_usu.Name = "gb_usu";
            this.gb_usu.Size = new System.Drawing.Size(89, 62);
            this.gb_usu.TabIndex = 70;
            this.gb_usu.TabStop = false;
            this.gb_usu.Text = "Usuario:";
            // 
            // btt_ir_hrg
            // 
            this.btt_ir_hrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_ir_hrg.Location = new System.Drawing.Point(24, 36);
            this.btt_ir_hrg.Name = "btt_ir_hrg";
            this.btt_ir_hrg.Size = new System.Drawing.Size(44, 24);
            this.btt_ir_hrg.TabIndex = 70;
            this.btt_ir_hrg.Text = "Ir";
            this.btt_ir_hrg.UseVisualStyleBackColor = true;
            this.btt_ir_hrg.Click += new System.EventHandler(this.btt_ir_hrg_Click);
            // 
            // tb_usu
            // 
            this.tb_usu.BackColor = System.Drawing.Color.LightSteelBlue;
            this.tb_usu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_usu.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_usu.Location = new System.Drawing.Point(3, 15);
            this.tb_usu.Name = "tb_usu";
            this.tb_usu.ReadOnly = true;
            this.tb_usu.Size = new System.Drawing.Size(83, 15);
            this.tb_usu.TabIndex = 50;
            // 
            // tb_n_col_rg
            // 
            this.tb_n_col_rg.BackColor = System.Drawing.Color.LightSteelBlue;
            this.tb_n_col_rg.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_n_col_rg.Enabled = false;
            this.tb_n_col_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_n_col_rg.ForeColor = System.Drawing.Color.Black;
            this.tb_n_col_rg.Location = new System.Drawing.Point(182, 121);
            this.tb_n_col_rg.Name = "tb_n_col_rg";
            this.tb_n_col_rg.Size = new System.Drawing.Size(200, 15);
            this.tb_n_col_rg.TabIndex = 69;
            this.tb_n_col_rg.TabStop = false;
            // 
            // lb_col_rg
            // 
            this.lb_col_rg.AutoSize = true;
            this.lb_col_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_col_rg.Location = new System.Drawing.Point(6, 124);
            this.lb_col_rg.Name = "lb_col_rg";
            this.lb_col_rg.Size = new System.Drawing.Size(65, 18);
            this.lb_col_rg.TabIndex = 72;
            this.lb_col_rg.Text = "Colabor.";
            // 
            // lb_vehic
            // 
            this.lb_vehic.AutoSize = true;
            this.lb_vehic.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_vehic.Location = new System.Drawing.Point(7, 223);
            this.lb_vehic.Name = "lb_vehic";
            this.lb_vehic.Size = new System.Drawing.Size(64, 18);
            this.lb_vehic.TabIndex = 70;
            this.lb_vehic.Text = "Vehículo";
            // 
            // lb_titulo_rg
            // 
            this.lb_titulo_rg.AutoSize = true;
            this.lb_titulo_rg.BackColor = System.Drawing.Color.LightBlue;
            this.lb_titulo_rg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_titulo_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_titulo_rg.ForeColor = System.Drawing.Color.Black;
            this.lb_titulo_rg.Location = new System.Drawing.Point(266, 9);
            this.lb_titulo_rg.Name = "lb_titulo_rg";
            this.lb_titulo_rg.Size = new System.Drawing.Size(141, 33);
            this.lb_titulo_rg.TabIndex = 0;
            this.lb_titulo_rg.Text = "Registros";
            // 
            // btt_last_rg
            // 
            this.btt_last_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_last_rg.Location = new System.Drawing.Point(358, 516);
            this.btt_last_rg.Name = "btt_last_rg";
            this.btt_last_rg.Size = new System.Drawing.Size(54, 34);
            this.btt_last_rg.TabIndex = 110;
            this.btt_last_rg.Text = ">|";
            this.btt_last_rg.UseVisualStyleBackColor = true;
            this.btt_last_rg.Click += new System.EventHandler(this.btt_last_rg_Click_1);
            // 
            // btt_next_rg
            // 
            this.btt_next_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_next_rg.Location = new System.Drawing.Point(299, 516);
            this.btt_next_rg.Name = "btt_next_rg";
            this.btt_next_rg.Size = new System.Drawing.Size(54, 34);
            this.btt_next_rg.TabIndex = 112;
            this.btt_next_rg.Text = ">>";
            this.btt_next_rg.UseVisualStyleBackColor = true;
            this.btt_next_rg.Click += new System.EventHandler(this.btt_next_rg_Click);
            // 
            // btt_back_rg
            // 
            this.btt_back_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_back_rg.Location = new System.Drawing.Point(72, 516);
            this.btt_back_rg.Name = "btt_back_rg";
            this.btt_back_rg.Size = new System.Drawing.Size(54, 34);
            this.btt_back_rg.TabIndex = 114;
            this.btt_back_rg.Text = "<<";
            this.btt_back_rg.UseVisualStyleBackColor = true;
            this.btt_back_rg.Click += new System.EventHandler(this.btt_back_rg_Click);
            // 
            // btt_first_rg
            // 
            this.btt_first_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_first_rg.Location = new System.Drawing.Point(12, 516);
            this.btt_first_rg.Name = "btt_first_rg";
            this.btt_first_rg.Size = new System.Drawing.Size(54, 34);
            this.btt_first_rg.TabIndex = 116;
            this.btt_first_rg.Text = "|<";
            this.btt_first_rg.UseVisualStyleBackColor = true;
            this.btt_first_rg.Click += new System.EventHandler(this.btt_first_rg_Click);
            // 
            // btt_consultar_rg
            // 
            this.btt_consultar_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_consultar_rg.Location = new System.Drawing.Point(580, 516);
            this.btt_consultar_rg.Name = "btt_consultar_rg";
            this.btt_consultar_rg.Size = new System.Drawing.Size(99, 34);
            this.btt_consultar_rg.TabIndex = 106;
            this.btt_consultar_rg.Text = "Consultar";
            this.btt_consultar_rg.UseVisualStyleBackColor = true;
            this.btt_consultar_rg.Click += new System.EventHandler(this.btt_consultar_rg_Click);
            // 
            // btt_buscar_rg
            // 
            this.btt_buscar_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_buscar_rg.Location = new System.Drawing.Point(456, 516);
            this.btt_buscar_rg.Name = "btt_buscar_rg";
            this.btt_buscar_rg.Size = new System.Drawing.Size(99, 34);
            this.btt_buscar_rg.TabIndex = 108;
            this.btt_buscar_rg.Text = "Buscar";
            this.btt_buscar_rg.UseVisualStyleBackColor = true;
            this.btt_buscar_rg.Click += new System.EventHandler(this.btt_buscar_rg_Click);
            // 
            // btt_cancelar_rg
            // 
            this.btt_cancelar_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_cancelar_rg.Location = new System.Drawing.Point(683, 421);
            this.btt_cancelar_rg.Name = "btt_cancelar_rg";
            this.btt_cancelar_rg.Size = new System.Drawing.Size(99, 34);
            this.btt_cancelar_rg.TabIndex = 104;
            this.btt_cancelar_rg.Text = "Cancelar";
            this.btt_cancelar_rg.UseVisualStyleBackColor = true;
            this.btt_cancelar_rg.Click += new System.EventHandler(this.btt_cancelar_rg_Click);
            // 
            // btt_borrar_rg
            // 
            this.btt_borrar_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_borrar_rg.Location = new System.Drawing.Point(683, 380);
            this.btt_borrar_rg.Name = "btt_borrar_rg";
            this.btt_borrar_rg.Size = new System.Drawing.Size(99, 34);
            this.btt_borrar_rg.TabIndex = 102;
            this.btt_borrar_rg.Text = "Borrar";
            this.btt_borrar_rg.UseVisualStyleBackColor = true;
            this.btt_borrar_rg.Click += new System.EventHandler(this.btt_borrar_rg_Click);
            // 
            // btt_modificar_rg
            // 
            this.btt_modificar_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_modificar_rg.Location = new System.Drawing.Point(683, 160);
            this.btt_modificar_rg.Name = "btt_modificar_rg";
            this.btt_modificar_rg.Size = new System.Drawing.Size(99, 34);
            this.btt_modificar_rg.TabIndex = 96;
            this.btt_modificar_rg.Text = "Modificar";
            this.btt_modificar_rg.UseVisualStyleBackColor = true;
            this.btt_modificar_rg.Click += new System.EventHandler(this.btt_modificar_rg_Click);
            // 
            // btt_guardar_rg
            // 
            this.btt_guardar_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_guardar_rg.Location = new System.Drawing.Point(683, 102);
            this.btt_guardar_rg.Name = "btt_guardar_rg";
            this.btt_guardar_rg.Size = new System.Drawing.Size(99, 34);
            this.btt_guardar_rg.TabIndex = 94;
            this.btt_guardar_rg.Text = "Guardar";
            this.btt_guardar_rg.UseVisualStyleBackColor = true;
            this.btt_guardar_rg.Click += new System.EventHandler(this.btt_guardar_rg_Click);
            // 
            // btt_nuevo_rg
            // 
            this.btt_nuevo_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_nuevo_rg.Location = new System.Drawing.Point(683, 51);
            this.btt_nuevo_rg.Name = "btt_nuevo_rg";
            this.btt_nuevo_rg.Size = new System.Drawing.Size(99, 34);
            this.btt_nuevo_rg.TabIndex = 92;
            this.btt_nuevo_rg.Text = "Nuevo";
            this.btt_nuevo_rg.UseVisualStyleBackColor = true;
            this.btt_nuevo_rg.Click += new System.EventHandler(this.btt_nuevo_rg_Click);
            // 
            // btt_imprimir_rg
            // 
            this.btt_imprimir_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_imprimir_rg.Location = new System.Drawing.Point(683, 252);
            this.btt_imprimir_rg.Name = "btt_imprimir_rg";
            this.btt_imprimir_rg.Size = new System.Drawing.Size(99, 34);
            this.btt_imprimir_rg.TabIndex = 98;
            this.btt_imprimir_rg.Text = "Imp. Reg.";
            this.btt_imprimir_rg.UseVisualStyleBackColor = true;
            this.btt_imprimir_rg.Click += new System.EventHandler(this.btt_imprimir_rg_Click);
            // 
            // btt_imprimir_fra
            // 
            this.btt_imprimir_fra.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_imprimir_fra.Location = new System.Drawing.Point(683, 292);
            this.btt_imprimir_fra.Name = "btt_imprimir_fra";
            this.btt_imprimir_fra.Size = new System.Drawing.Size(99, 34);
            this.btt_imprimir_fra.TabIndex = 100;
            this.btt_imprimir_fra.Text = "Imp. Fra.";
            this.btt_imprimir_fra.UseVisualStyleBackColor = true;
            this.btt_imprimir_fra.Click += new System.EventHandler(this.Btt_imprimir_fraClick);
            // 
            // lb_num_rg_rg
            // 
            this.lb_num_rg_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_num_rg_rg.Location = new System.Drawing.Point(131, 520);
            this.lb_num_rg_rg.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_num_rg_rg.Name = "lb_num_rg_rg";
            this.lb_num_rg_rg.Size = new System.Drawing.Size(161, 30);
            this.lb_num_rg_rg.TabIndex = 914;
            this.lb_num_rg_rg.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // tab_reg
            // 
            this.tab_reg.Controls.Add(this.tabPage1);
            this.tab_reg.Controls.Add(this.tabPage2);
            this.tab_reg.Controls.Add(this.tab_fra);
            this.tab_reg.Controls.Add(this.tab_lin);
            this.tab_reg.Location = new System.Drawing.Point(12, 25);
            this.tab_reg.Name = "tab_reg";
            this.tab_reg.SelectedIndex = 0;
            this.tab_reg.Size = new System.Drawing.Size(667, 485);
            this.tab_reg.TabIndex = 1;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.tabPage1.Controls.Add(this.gn_f_anul);
            this.tabPage1.Controls.Add(this.gb_enviado);
            this.tabPage1.Controls.Add(this.btt_ir_col);
            this.tabPage1.Controls.Add(this.btt_col_buscar);
            this.tabPage1.Controls.Add(this.tb_vehic);
            this.tabPage1.Controls.Add(this.lb_exp);
            this.tabPage1.Controls.Add(this.tb_observ);
            this.tabPage1.Controls.Add(this.tb_col_rg);
            this.tabPage1.Controls.Add(this.btt_ver);
            this.tabPage1.Controls.Add(this.tb_c_serv);
            this.tabPage1.Controls.Add(this.btt_explorar);
            this.tabPage1.Controls.Add(this.tb_pdf);
            this.tabPage1.Controls.Add(this.lb_bate_ant);
            this.tabPage1.Controls.Add(this.lb_c_serv);
            this.tabPage1.Controls.Add(this.tb_nif);
            this.tabPage1.Controls.Add(this.btt_tit_buscar);
            this.tabPage1.Controls.Add(this.lb_nif);
            this.tabPage1.Controls.Add(this.btt_cte_buscar);
            this.tabPage1.Controls.Add(this.tb_bate_ant);
            this.tabPage1.Controls.Add(this.tb_n_tit_rg);
            this.tabPage1.Controls.Add(this.cb_sec);
            this.tabPage1.Controls.Add(this.tb_tit_rg);
            this.tabPage1.Controls.Add(this.btt_ac_tl);
            this.tabPage1.Controls.Add(this.btt_ir_cte);
            this.tabPage1.Controls.Add(this.btt_ir_tit);
            this.tabPage1.Controls.Add(this.tb_n_cte_rg);
            this.tabPage1.Controls.Add(this.tb_cte_rg);
            this.tabPage1.Controls.Add(this.lb_fec_ent);
            this.tabPage1.Controls.Add(this.tb_matri);
            this.tabPage1.Controls.Add(this.dtp_fec_rg);
            this.tabPage1.Controls.Add(this.tb_n_reg);
            this.tabPage1.Controls.Add(this.gb_reg);
            this.tabPage1.Controls.Add(this.gb_del);
            this.tabPage1.Controls.Add(this.gb_estado);
            this.tabPage1.Controls.Add(this.dtp_fec_pre);
            this.tabPage1.Controls.Add(this.tb_exp);
            this.tabPage1.Controls.Add(this.lb_f_pre);
            this.tabPage1.Controls.Add(this.gb_tel);
            this.tabPage1.Controls.Add(this.gb_pdf);
            this.tabPage1.Controls.Add(this.gb_obs);
            this.tabPage1.Controls.Add(this.gp_exp_ntl);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(659, 459);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Registro";
            // 
            // gn_f_anul
            // 
            this.gn_f_anul.Controls.Add(this.tb_f_anul);
            this.gn_f_anul.Location = new System.Drawing.Point(517, 209);
            this.gn_f_anul.Name = "gn_f_anul";
            this.gn_f_anul.Size = new System.Drawing.Size(134, 54);
            this.gn_f_anul.TabIndex = 71;
            this.gn_f_anul.TabStop = false;
            this.gn_f_anul.Text = "Fecha anulación";
            // 
            // tb_f_anul
            // 
            this.tb_f_anul.BackColor = System.Drawing.Color.LightSteelBlue;
            this.tb_f_anul.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.tb_f_anul.Font = new System.Drawing.Font("Arial Narrow", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_f_anul.Location = new System.Drawing.Point(6, 19);
            this.tb_f_anul.Name = "tb_f_anul";
            this.tb_f_anul.ReadOnly = true;
            this.tb_f_anul.Size = new System.Drawing.Size(119, 25);
            this.tb_f_anul.TabIndex = 51;
            // 
            // gb_enviado
            // 
            this.gb_enviado.Controls.Add(this.tb_enviado);
            this.gb_enviado.Location = new System.Drawing.Point(517, 163);
            this.gb_enviado.Name = "gb_enviado";
            this.gb_enviado.Size = new System.Drawing.Size(134, 46);
            this.gb_enviado.TabIndex = 70;
            this.gb_enviado.TabStop = false;
            this.gb_enviado.Text = "Enviar por";
            // 
            // tb_enviado
            // 
            this.tb_enviado.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_enviado.Location = new System.Drawing.Point(6, 16);
            this.tb_enviado.Name = "tb_enviado";
            this.tb_enviado.Size = new System.Drawing.Size(124, 24);
            this.tb_enviado.TabIndex = 49;
            // 
            // btt_ir_col
            // 
            this.btt_ir_col.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_ir_col.Location = new System.Drawing.Point(462, 129);
            this.btt_ir_col.Name = "btt_ir_col";
            this.btt_ir_col.Size = new System.Drawing.Size(44, 24);
            this.btt_ir_col.TabIndex = 17;
            this.btt_ir_col.Text = "Ir";
            this.btt_ir_col.UseVisualStyleBackColor = true;
            this.btt_ir_col.Click += new System.EventHandler(this.btt_ir_col_Click);
            // 
            // btt_col_buscar
            // 
            this.btt_col_buscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_col_buscar.Location = new System.Drawing.Point(396, 129);
            this.btt_col_buscar.Name = "btt_col_buscar";
            this.btt_col_buscar.Size = new System.Drawing.Size(66, 24);
            this.btt_col_buscar.TabIndex = 16;
            this.btt_col_buscar.Text = "Buscar";
            this.btt_col_buscar.UseVisualStyleBackColor = true;
            this.btt_col_buscar.Click += new System.EventHandler(this.btt_col_buscar_Click);
            // 
            // tb_vehic
            // 
            this.tb_vehic.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_vehic.Location = new System.Drawing.Point(86, 229);
            this.tb_vehic.MaxLength = 100;
            this.tb_vehic.Name = "tb_vehic";
            this.tb_vehic.Size = new System.Drawing.Size(324, 24);
            this.tb_vehic.TabIndex = 26;
            this.tb_vehic.Validating += new System.ComponentModel.CancelEventHandler(this.tb_vehic_Validating);
            // 
            // lb_exp
            // 
            this.lb_exp.AutoSize = true;
            this.lb_exp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_exp.Location = new System.Drawing.Point(119, 280);
            this.lb_exp.Name = "lb_exp";
            this.lb_exp.Size = new System.Drawing.Size(80, 18);
            this.lb_exp.TabIndex = 68;
            this.lb_exp.Text = "Expediente";
            // 
            // tb_observ
            // 
            this.tb_observ.Location = new System.Drawing.Point(348, 383);
            this.tb_observ.MaxLength = 300;
            this.tb_observ.Multiline = true;
            this.tb_observ.Name = "tb_observ";
            this.tb_observ.Size = new System.Drawing.Size(289, 60);
            this.tb_observ.TabIndex = 46;
            this.tb_observ.Validating += new System.ComponentModel.CancelEventHandler(this.tb_observ_Validating);
            // 
            // tb_col_rg
            // 
            this.tb_col_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_col_rg.Location = new System.Drawing.Point(86, 130);
            this.tb_col_rg.Name = "tb_col_rg";
            this.tb_col_rg.Size = new System.Drawing.Size(100, 24);
            this.tb_col_rg.TabIndex = 15;
            this.tb_col_rg.Validating += new System.ComponentModel.CancelEventHandler(this.tb_col_rg_Validating);
            // 
            // btt_ver
            // 
            this.btt_ver.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_ver.Location = new System.Drawing.Point(211, 413);
            this.btt_ver.Name = "btt_ver";
            this.btt_ver.Size = new System.Drawing.Size(90, 24);
            this.btt_ver.TabIndex = 44;
            this.btt_ver.Text = "Ver";
            this.btt_ver.UseVisualStyleBackColor = true;
            this.btt_ver.Click += new System.EventHandler(this.btt_ver_Click);
            // 
            // btt_explorar
            // 
            this.btt_explorar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_explorar.Location = new System.Drawing.Point(18, 413);
            this.btt_explorar.Name = "btt_explorar";
            this.btt_explorar.Size = new System.Drawing.Size(90, 24);
            this.btt_explorar.TabIndex = 42;
            this.btt_explorar.Text = "Explorar";
            this.btt_explorar.UseVisualStyleBackColor = true;
            this.btt_explorar.Click += new System.EventHandler(this.btt_explorar_Click);
            // 
            // tb_pdf
            // 
            this.tb_pdf.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_pdf.Location = new System.Drawing.Point(18, 383);
            this.tb_pdf.MaxLength = 150;
            this.tb_pdf.Name = "tb_pdf";
            this.tb_pdf.Size = new System.Drawing.Size(283, 24);
            this.tb_pdf.TabIndex = 40;
            this.tb_pdf.Validating += new System.ComponentModel.CancelEventHandler(this.tb_pdf_Validating);
            // 
            // gb_tel
            // 
            this.gb_tel.Location = new System.Drawing.Point(8, 260);
            this.gb_tel.Name = "gb_tel";
            this.gb_tel.Size = new System.Drawing.Size(643, 100);
            this.gb_tel.TabIndex = 65;
            this.gb_tel.TabStop = false;
            // 
            // gb_pdf
            // 
            this.gb_pdf.Location = new System.Drawing.Point(8, 364);
            this.gb_pdf.Name = "gb_pdf";
            this.gb_pdf.Size = new System.Drawing.Size(318, 85);
            this.gb_pdf.TabIndex = 66;
            this.gb_pdf.TabStop = false;
            this.gb_pdf.Text = "PDF";
            // 
            // gb_obs
            // 
            this.gb_obs.Location = new System.Drawing.Point(336, 364);
            this.gb_obs.Name = "gb_obs";
            this.gb_obs.Size = new System.Drawing.Size(315, 85);
            this.gb_obs.TabIndex = 67;
            this.gb_obs.TabStop = false;
            this.gb_obs.Text = "Observaciones";
            // 
            // gp_exp_ntl
            // 
            this.gp_exp_ntl.Controls.Add(this.tb_exp_ntl);
            this.gp_exp_ntl.Location = new System.Drawing.Point(517, 113);
            this.gp_exp_ntl.Name = "gp_exp_ntl";
            this.gp_exp_ntl.Size = new System.Drawing.Size(134, 50);
            this.gp_exp_ntl.TabIndex = 69;
            this.gp_exp_ntl.TabStop = false;
            this.gp_exp_ntl.Text = "Exp. no tl.";
            // 
            // tb_exp_ntl
            // 
            this.tb_exp_ntl.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_exp_ntl.Location = new System.Drawing.Point(16, 13);
            this.tb_exp_ntl.Name = "tb_exp_ntl";
            this.tb_exp_ntl.Size = new System.Drawing.Size(100, 24);
            this.tb_exp_ntl.TabIndex = 49;
            this.tb_exp_ntl.Validating += new System.ComponentModel.CancelEventHandler(this.tb_exp_ntl_Validating);
            // 
            // tab_fra
            // 
            this.tab_fra.BackColor = System.Drawing.Color.LightSteelBlue;
            this.tab_fra.Controls.Add(this.gb_fra);
            this.tab_fra.Location = new System.Drawing.Point(4, 22);
            this.tab_fra.Name = "tab_fra";
            this.tab_fra.Padding = new System.Windows.Forms.Padding(3);
            this.tab_fra.Size = new System.Drawing.Size(659, 459);
            this.tab_fra.TabIndex = 1;
            this.tab_fra.Text = "Factura";
            // 
            // tab_lin
            // 
            this.tab_lin.BackColor = System.Drawing.Color.LightSteelBlue;
            this.tab_lin.Controls.Add(this.gb_det);
            this.tab_lin.Location = new System.Drawing.Point(4, 22);
            this.tab_lin.Name = "tab_lin";
            this.tab_lin.Size = new System.Drawing.Size(659, 459);
            this.tab_lin.TabIndex = 2;
            this.tab_lin.Text = "Detalle";
            // 
            // gb_det
            // 
            this.gb_det.Controls.Add(this.btt_det_cancel);
            this.gb_det.Controls.Add(this.gb_det3);
            this.gb_det.Controls.Add(this.btt_det_del);
            this.gb_det.Controls.Add(this.btt_det_save);
            this.gb_det.Controls.Add(this.btt_det_new);
            this.gb_det.Controls.Add(this.dgv_linfac);
            this.gb_det.Location = new System.Drawing.Point(3, 6);
            this.gb_det.Name = "gb_det";
            this.gb_det.Size = new System.Drawing.Size(653, 402);
            this.gb_det.TabIndex = 0;
            this.gb_det.TabStop = false;
            // 
            // btt_det_cancel
            // 
            this.btt_det_cancel.Location = new System.Drawing.Point(563, 355);
            this.btt_det_cancel.Name = "btt_det_cancel";
            this.btt_det_cancel.Size = new System.Drawing.Size(75, 23);
            this.btt_det_cancel.TabIndex = 84;
            this.btt_det_cancel.Text = "Cancelar";
            this.btt_det_cancel.UseVisualStyleBackColor = true;
            this.btt_det_cancel.Click += new System.EventHandler(this.btt_det_cancel_Click);
            // 
            // gb_det3
            // 
            this.gb_det3.Controls.Add(this.tb_det_cta);
            this.gb_det3.Controls.Add(this.lb_det_cta);
            this.gb_det3.Controls.Add(this.cb_det_iva);
            this.gb_det3.Controls.Add(this.tb_det_fra);
            this.gb_det3.Controls.Add(this.tb_det_descrip);
            this.gb_det3.Controls.Add(this.label2);
            this.gb_det3.Controls.Add(this.lb_det_descrip);
            this.gb_det3.Controls.Add(this.lb_det_iva);
            this.gb_det3.Controls.Add(this.tb_det_impor);
            this.gb_det3.Controls.Add(this.tb_det_lin);
            this.gb_det3.Controls.Add(this.lb_det_impor);
            this.gb_det3.Controls.Add(this.lb_det_lin);
            this.gb_det3.Location = new System.Drawing.Point(21, 19);
            this.gb_det3.Name = "gb_det3";
            this.gb_det3.Size = new System.Drawing.Size(617, 89);
            this.gb_det3.TabIndex = 81;
            this.gb_det3.TabStop = false;
            // 
            // tb_det_cta
            // 
            this.tb_det_cta.Enabled = false;
            this.tb_det_cta.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_det_cta.Location = new System.Drawing.Point(499, 53);
            this.tb_det_cta.Name = "tb_det_cta";
            this.tb_det_cta.Size = new System.Drawing.Size(100, 24);
            this.tb_det_cta.TabIndex = 86;
            this.tb_det_cta.Validating += new System.ComponentModel.CancelEventHandler(this.tb_det_cta_Validating);
            // 
            // lb_det_cta
            // 
            this.lb_det_cta.AutoSize = true;
            this.lb_det_cta.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_det_cta.Location = new System.Drawing.Point(462, 56);
            this.lb_det_cta.Name = "lb_det_cta";
            this.lb_det_cta.Size = new System.Drawing.Size(35, 18);
            this.lb_det_cta.TabIndex = 85;
            this.lb_det_cta.Text = "Cta.";
            this.lb_det_cta.Click += new System.EventHandler(this.lb_cta_Click);
            // 
            // cb_det_iva
            // 
            this.cb_det_iva.FormattingEnabled = true;
            this.cb_det_iva.Location = new System.Drawing.Point(538, 16);
            this.cb_det_iva.Name = "cb_det_iva";
            this.cb_det_iva.Size = new System.Drawing.Size(61, 21);
            this.cb_det_iva.TabIndex = 82;
            // 
            // tb_det_fra
            // 
            this.tb_det_fra.Enabled = false;
            this.tb_det_fra.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_det_fra.Location = new System.Drawing.Point(116, 16);
            this.tb_det_fra.Name = "tb_det_fra";
            this.tb_det_fra.Size = new System.Drawing.Size(100, 24);
            this.tb_det_fra.TabIndex = 75;
            // 
            // tb_det_descrip
            // 
            this.tb_det_descrip.Enabled = false;
            this.tb_det_descrip.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_det_descrip.Location = new System.Drawing.Point(116, 53);
            this.tb_det_descrip.Name = "tb_det_descrip";
            this.tb_det_descrip.Size = new System.Drawing.Size(339, 24);
            this.tb_det_descrip.TabIndex = 84;
            this.tb_det_descrip.Validating += new System.ComponentModel.CancelEventHandler(this.tb_det_descrip_Validating);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(36, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 18);
            this.label2.TabIndex = 77;
            this.label2.Text = "Num. Fra.";
            // 
            // lb_det_descrip
            // 
            this.lb_det_descrip.AutoSize = true;
            this.lb_det_descrip.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_det_descrip.Location = new System.Drawing.Point(23, 56);
            this.lb_det_descrip.Name = "lb_det_descrip";
            this.lb_det_descrip.Size = new System.Drawing.Size(87, 18);
            this.lb_det_descrip.TabIndex = 83;
            this.lb_det_descrip.Text = "Descripción";
            // 
            // lb_det_iva
            // 
            this.lb_det_iva.AutoSize = true;
            this.lb_det_iva.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_det_iva.Location = new System.Drawing.Point(487, 16);
            this.lb_det_iva.Name = "lb_det_iva";
            this.lb_det_iva.Size = new System.Drawing.Size(46, 18);
            this.lb_det_iva.TabIndex = 80;
            this.lb_det_iva.Text = "% IVA";
            // 
            // tb_det_impor
            // 
            this.tb_det_impor.Enabled = false;
            this.tb_det_impor.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_det_impor.Location = new System.Drawing.Point(393, 16);
            this.tb_det_impor.Name = "tb_det_impor";
            this.tb_det_impor.Size = new System.Drawing.Size(84, 24);
            this.tb_det_impor.TabIndex = 79;
            this.tb_det_impor.Validating += new System.ComponentModel.CancelEventHandler(this.tb_det_impor_Validating);
            // 
            // tb_det_lin
            // 
            this.tb_det_lin.Enabled = false;
            this.tb_det_lin.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_det_lin.Location = new System.Drawing.Point(277, 16);
            this.tb_det_lin.Name = "tb_det_lin";
            this.tb_det_lin.Size = new System.Drawing.Size(50, 24);
            this.tb_det_lin.TabIndex = 75;
            // 
            // lb_det_impor
            // 
            this.lb_det_impor.AutoSize = true;
            this.lb_det_impor.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_det_impor.Location = new System.Drawing.Point(333, 16);
            this.lb_det_impor.Name = "lb_det_impor";
            this.lb_det_impor.Size = new System.Drawing.Size(58, 18);
            this.lb_det_impor.TabIndex = 78;
            this.lb_det_impor.Text = "Importe";
            // 
            // lb_det_lin
            // 
            this.lb_det_lin.AutoSize = true;
            this.lb_det_lin.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_det_lin.Location = new System.Drawing.Point(228, 16);
            this.lb_det_lin.Name = "lb_det_lin";
            this.lb_det_lin.Size = new System.Drawing.Size(43, 18);
            this.lb_det_lin.TabIndex = 77;
            this.lb_det_lin.Text = "Linea";
            // 
            // btt_det_del
            // 
            this.btt_det_del.Location = new System.Drawing.Point(482, 355);
            this.btt_det_del.Name = "btt_det_del";
            this.btt_det_del.Size = new System.Drawing.Size(75, 23);
            this.btt_det_del.TabIndex = 83;
            this.btt_det_del.Text = "Borrar";
            this.btt_det_del.UseVisualStyleBackColor = true;
            this.btt_det_del.Click += new System.EventHandler(this.btt_det_del_Click);
            // 
            // btt_det_save
            // 
            this.btt_det_save.Location = new System.Drawing.Point(377, 355);
            this.btt_det_save.Name = "btt_det_save";
            this.btt_det_save.Size = new System.Drawing.Size(99, 23);
            this.btt_det_save.TabIndex = 82;
            this.btt_det_save.Text = "Guardar/Modif.";
            this.btt_det_save.UseVisualStyleBackColor = true;
            this.btt_det_save.Click += new System.EventHandler(this.btt_det_save_Click);
            // 
            // btt_det_new
            // 
            this.btt_det_new.Location = new System.Drawing.Point(296, 355);
            this.btt_det_new.Name = "btt_det_new";
            this.btt_det_new.Size = new System.Drawing.Size(75, 23);
            this.btt_det_new.TabIndex = 81;
            this.btt_det_new.Text = "Alta";
            this.btt_det_new.UseVisualStyleBackColor = true;
            this.btt_det_new.Click += new System.EventHandler(this.btt_det_new_Click);
            // 
            // dgv_linfac
            // 
            this.dgv_linfac.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_linfac.Location = new System.Drawing.Point(18, 127);
            this.dgv_linfac.Name = "dgv_linfac";
            this.dgv_linfac.Size = new System.Drawing.Size(620, 211);
            this.dgv_linfac.TabIndex = 79;
            this.dgv_linfac.SelectionChanged += new System.EventHandler(this.dgv_linfac_SelectionChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.LightSteelBlue;
            this.tabPage2.Controls.Add(this.gb_escri);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Size = new System.Drawing.Size(659, 459);
            this.tabPage2.TabIndex = 3;
            this.tabPage2.Text = "Escritura";
            // 
            // gb_escri
            // 
            this.gb_escri.Controls.Add(this.tb_firmado_por);
            this.gb_escri.Controls.Add(this.lb_firmado_por);
            this.gb_escri.Controls.Add(this.tb_impor_liq);
            this.gb_escri.Controls.Add(this.lb_impor_liq);
            this.gb_escri.Controls.Add(this.tb_notario);
            this.gb_escri.Controls.Add(this.lb_notario);
            this.gb_escri.Controls.Add(this.tb_n_operacion);
            this.gb_escri.Controls.Add(this.lb_n_opera);
            this.gb_escri.Controls.Add(this.tb_entidad);
            this.gb_escri.Controls.Add(this.lb_ent_bc);
            this.gb_escri.Location = new System.Drawing.Point(12, 9);
            this.gb_escri.Name = "gb_escri";
            this.gb_escri.Size = new System.Drawing.Size(633, 233);
            this.gb_escri.TabIndex = 0;
            this.gb_escri.TabStop = false;
            // 
            // tb_entidad
            // 
            this.tb_entidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_entidad.Location = new System.Drawing.Point(150, 33);
            this.tb_entidad.MaxLength = 100;
            this.tb_entidad.Name = "tb_entidad";
            this.tb_entidad.Size = new System.Drawing.Size(448, 24);
            this.tb_entidad.TabIndex = 71;
            this.tb_entidad.Validating += new System.ComponentModel.CancelEventHandler(this.tb_entidad_Validating);
            // 
            // lb_ent_bc
            // 
            this.lb_ent_bc.AutoSize = true;
            this.lb_ent_bc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ent_bc.Location = new System.Drawing.Point(17, 36);
            this.lb_ent_bc.Name = "lb_ent_bc";
            this.lb_ent_bc.Size = new System.Drawing.Size(119, 18);
            this.lb_ent_bc.TabIndex = 72;
            this.lb_ent_bc.Text = "Entidad Bancaria";
            // 
            // tb_n_operacion
            // 
            this.tb_n_operacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_n_operacion.Location = new System.Drawing.Point(150, 72);
            this.tb_n_operacion.MaxLength = 100;
            this.tb_n_operacion.Name = "tb_n_operacion";
            this.tb_n_operacion.Size = new System.Drawing.Size(156, 24);
            this.tb_n_operacion.TabIndex = 73;
            this.tb_n_operacion.Validating += new System.ComponentModel.CancelEventHandler(this.tb_n_operacion_Validating);
            // 
            // lb_n_opera
            // 
            this.lb_n_opera.AutoSize = true;
            this.lb_n_opera.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_n_opera.Location = new System.Drawing.Point(19, 75);
            this.lb_n_opera.Name = "lb_n_opera";
            this.lb_n_opera.Size = new System.Drawing.Size(117, 18);
            this.lb_n_opera.TabIndex = 74;
            this.lb_n_opera.Text = "Num. Operación";
            // 
            // tb_notario
            // 
            this.tb_notario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_notario.Location = new System.Drawing.Point(149, 111);
            this.tb_notario.MaxLength = 100;
            this.tb_notario.Name = "tb_notario";
            this.tb_notario.Size = new System.Drawing.Size(448, 24);
            this.tb_notario.TabIndex = 75;
            this.tb_notario.Validating += new System.ComponentModel.CancelEventHandler(this.tb_notario_Validating);
            // 
            // lb_notario
            // 
            this.lb_notario.AutoSize = true;
            this.lb_notario.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_notario.Location = new System.Drawing.Point(79, 114);
            this.lb_notario.Name = "lb_notario";
            this.lb_notario.Size = new System.Drawing.Size(57, 18);
            this.lb_notario.TabIndex = 76;
            this.lb_notario.Text = "Notario";
            // 
            // tb_impor_liq
            // 
            this.tb_impor_liq.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_impor_liq.Location = new System.Drawing.Point(150, 150);
            this.tb_impor_liq.MaxLength = 100;
            this.tb_impor_liq.Name = "tb_impor_liq";
            this.tb_impor_liq.Size = new System.Drawing.Size(133, 24);
            this.tb_impor_liq.TabIndex = 77;
            this.tb_impor_liq.Validating += new System.ComponentModel.CancelEventHandler(this.tb_impor_liq_Validating);
            // 
            // lb_impor_liq
            // 
            this.lb_impor_liq.AutoSize = true;
            this.lb_impor_liq.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_impor_liq.Location = new System.Drawing.Point(78, 153);
            this.lb_impor_liq.Name = "lb_impor_liq";
            this.lb_impor_liq.Size = new System.Drawing.Size(58, 18);
            this.lb_impor_liq.TabIndex = 78;
            this.lb_impor_liq.Text = "Importe";
            // 
            // tb_firmado_por
            // 
            this.tb_firmado_por.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_firmado_por.Location = new System.Drawing.Point(149, 189);
            this.tb_firmado_por.MaxLength = 100;
            this.tb_firmado_por.Name = "tb_firmado_por";
            this.tb_firmado_por.Size = new System.Drawing.Size(448, 24);
            this.tb_firmado_por.TabIndex = 79;
            this.tb_firmado_por.Validating += new System.ComponentModel.CancelEventHandler(this.tb_firmado_por_Validating);
            // 
            // lb_firmado_por
            // 
            this.lb_firmado_por.AutoSize = true;
            this.lb_firmado_por.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_firmado_por.Location = new System.Drawing.Point(47, 192);
            this.lb_firmado_por.Name = "lb_firmado_por";
            this.lb_firmado_por.Size = new System.Drawing.Size(89, 18);
            this.lb_firmado_por.TabIndex = 80;
            this.lb_firmado_por.Text = "Firmado por";
            // 
            // MRegistros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(784, 562);
            this.Controls.Add(this.lb_titulo_rg);
            this.Controls.Add(this.tab_reg);
            this.Controls.Add(this.lb_num_rg_rg);
            this.Controls.Add(this.btt_imprimir_fra);
            this.Controls.Add(this.btt_imprimir_rg);
            this.Controls.Add(this.btt_cancelar_rg);
            this.Controls.Add(this.btt_borrar_rg);
            this.Controls.Add(this.btt_modificar_rg);
            this.Controls.Add(this.btt_guardar_rg);
            this.Controls.Add(this.btt_nuevo_rg);
            this.Controls.Add(this.btt_consultar_rg);
            this.Controls.Add(this.btt_buscar_rg);
            this.Controls.Add(this.btt_last_rg);
            this.Controls.Add(this.btt_next_rg);
            this.Controls.Add(this.p_reg);
            this.Controls.Add(this.btt_back_rg);
            this.Controls.Add(this.btt_first_rg);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(800, 600);
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "MRegistros";
            this.Text = "Mantenimiento de Registros";
            this.Load += new System.EventHandler(this.MRegistros_Load);
            this.gb_fra.ResumeLayout(false);
            this.gb_fra.PerformLayout();
            this.gb_est_fra.ResumeLayout(false);
            this.gb_fac_a.ResumeLayout(false);
            this.gb_t_fra.ResumeLayout(false);
            this.gb_t_fra.PerformLayout();
            this.gb_del.ResumeLayout(false);
            this.gb_estado.ResumeLayout(false);
            this.gb_reg.ResumeLayout(false);
            this.gb_reg.PerformLayout();
            this.gb_usu.ResumeLayout(false);
            this.gb_usu.PerformLayout();
            this.tab_reg.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.gn_f_anul.ResumeLayout(false);
            this.gn_f_anul.PerformLayout();
            this.gb_enviado.ResumeLayout(false);
            this.gb_enviado.PerformLayout();
            this.gp_exp_ntl.ResumeLayout(false);
            this.gp_exp_ntl.PerformLayout();
            this.tab_fra.ResumeLayout(false);
            this.tab_lin.ResumeLayout(false);
            this.gb_det.ResumeLayout(false);
            this.gb_det3.ResumeLayout(false);
            this.gb_det3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_linfac)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.gb_escri.ResumeLayout(false);
            this.gb_escri.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        private System.Windows.Forms.Label lb_num_rg_rg;
        private System.Windows.Forms.Button btt_imprimir_fra;

        #endregion

        private System.Windows.Forms.Panel p_reg;
        private System.Windows.Forms.Label lb_titulo_rg;
        private System.Windows.Forms.Button btt_last_rg;
        private System.Windows.Forms.Button btt_next_rg;
        private System.Windows.Forms.Button btt_back_rg;
        private System.Windows.Forms.Button btt_first_rg;
        private System.Windows.Forms.Button btt_consultar_rg;
        private System.Windows.Forms.Button btt_buscar_rg;
        private System.Windows.Forms.Button btt_cancelar_rg;
        private System.Windows.Forms.Button btt_borrar_rg;
        private System.Windows.Forms.Button btt_modificar_rg;
        private System.Windows.Forms.Button btt_guardar_rg;
        private System.Windows.Forms.Button btt_nuevo_rg;
        private System.Windows.Forms.TextBox tb_n_reg;
        private System.Windows.Forms.Label lb_n_reg;
        private System.Windows.Forms.GroupBox gb_del;
        private System.Windows.Forms.Button btt_tit_buscar;
        private System.Windows.Forms.Button btt_cte_buscar;
        private System.Windows.Forms.TextBox tb_n_tit_rg;
        private System.Windows.Forms.Label lb_tit_reg;
        private System.Windows.Forms.TextBox tb_n_cte_rg;
        private System.Windows.Forms.TextBox tb_cte_rg;
        private System.Windows.Forms.Label lb_cte_rg;
        private System.Windows.Forms.Label lb_fec_ent;
        private System.Windows.Forms.DateTimePicker dtp_fec_rg;
        private System.Windows.Forms.ComboBox cb_sec;
        private System.Windows.Forms.Label lb_sec;
        private System.Windows.Forms.ComboBox cb_sec_int;
        private System.Windows.Forms.Label lb_sec_int;
        private System.Windows.Forms.TextBox tb_matri;
        private System.Windows.Forms.Label lb_matri;
        private System.Windows.Forms.ComboBox cb_tram;
        private System.Windows.Forms.Label lb_tram;
        private System.Windows.Forms.Button btt_ir_tit;
        private System.Windows.Forms.Button btt_ir_cte;
        private System.Windows.Forms.ComboBox cb_estado;
        private System.Windows.Forms.GroupBox gb_estado;
        private System.Windows.Forms.GroupBox gb_reg;
        private System.Windows.Forms.TextBox tb_exp;
        private System.Windows.Forms.DateTimePicker dtp_fec_pre;
        private System.Windows.Forms.Label lb_f_pre;
        private System.Windows.Forms.GroupBox gb_fra;
        private System.Windows.Forms.Button btt_ac_tl;
        private System.Windows.Forms.TextBox tb_d_col;
        private System.Windows.Forms.Label lb_d_col;
        private System.Windows.Forms.TextBox tb_nif;
        private System.Windows.Forms.Label lb_nif;
        private System.Windows.Forms.TextBox tb_bate_ant;
        private System.Windows.Forms.Label lb_bate_ant;
        private System.Windows.Forms.TextBox tb_c_serv;
        private System.Windows.Forms.Label lb_c_serv;
        private System.Windows.Forms.TextBox tb_tipo;
        private System.Windows.Forms.Label lb_tipo;
        private System.Windows.Forms.TextBox tb_tasa;
        private System.Windows.Forms.Label lb_tasa;
        private System.Windows.Forms.TextBox tb_descrip;
        private System.Windows.Forms.Label lb_descrip;
        private System.Windows.Forms.Button btt_facturar;
        private System.Windows.Forms.DateTimePicker dtp_fec_fra;
        private System.Windows.Forms.Label lb_f_fra;
        private System.Windows.Forms.TextBox tb_fra;
        private System.Windows.Forms.Label lb_fra;
        private System.Windows.Forms.TextBox tb_t_fra;
        private System.Windows.Forms.TextBox tb_tasa_fra;
        private System.Windows.Forms.Label lb_tasa_fra;
        private System.Windows.Forms.TextBox tb_p_iva;
        private System.Windows.Forms.Label lb_p_iva;
        private System.Windows.Forms.TextBox tb_hono;
        private System.Windows.Forms.Label lb_hono;
        private System.Windows.Forms.TextBox tb_tit_rg;
        private System.Windows.Forms.Button btt_imprimir_rg;
        private System.Windows.Forms.TabControl tab_reg;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tab_fra;
        private System.Windows.Forms.TextBox tb_observ;
        private System.Windows.Forms.TextBox tb_itasa;
        private System.Windows.Forms.TextBox tb_base_imp;
        private System.Windows.Forms.Label lb_base;
        private System.Windows.Forms.TextBox tb_itasa2;
        private System.Windows.Forms.TextBox tb_tipo2;
        private System.Windows.Forms.Label lb_tipo2;
        private System.Windows.Forms.TextBox tb_tasa2;
        private System.Windows.Forms.Label lb_tasa2;
        private System.Windows.Forms.TextBox tb_itasa4;
        private System.Windows.Forms.TextBox tb_tipo4;
        private System.Windows.Forms.Label lb_tipo4;
        private System.Windows.Forms.TextBox tb_tasa4;
        private System.Windows.Forms.Label lb_tasa4;
        private System.Windows.Forms.TextBox tb_itasa3;
        private System.Windows.Forms.TextBox tb_tipo3;
        private System.Windows.Forms.Label lb_tipo3;
        private System.Windows.Forms.TextBox tb_tasa3;
        private System.Windows.Forms.Label lb_tasa3;
        private System.Windows.Forms.Label lb_t_fra;
        private System.Windows.Forms.GroupBox gb_t_fra;
        private System.Windows.Forms.Button btt_ver;
        private System.Windows.Forms.Button btt_explorar;
        private System.Windows.Forms.TextBox tb_pdf;
        private System.Windows.Forms.GroupBox gb_tel;
        private System.Windows.Forms.GroupBox gb_pdf;
        private System.Windows.Forms.GroupBox gb_obs;
        private System.Windows.Forms.Label lb_exp;
        private System.Windows.Forms.Label lb_vehic;
        private System.Windows.Forms.TextBox tb_vehic;
        private System.Windows.Forms.ComboBox cb_cte_fra;
        private System.Windows.Forms.GroupBox gb_fac_a;
        private System.Windows.Forms.TabPage tab_lin;
        private System.Windows.Forms.GroupBox gb_det;
        private System.Windows.Forms.DataGridView dgv_linfac;
        private System.Windows.Forms.Button btt_det_del;
        private System.Windows.Forms.Button btt_det_save;
        private System.Windows.Forms.Button btt_det_new;
        private System.Windows.Forms.GroupBox gb_det3;
        private System.Windows.Forms.TextBox tb_det_descrip;
        private System.Windows.Forms.Label lb_det_descrip;
        private System.Windows.Forms.Label lb_det_iva;
        private System.Windows.Forms.TextBox tb_det_impor;
        private System.Windows.Forms.TextBox tb_det_lin;
        private System.Windows.Forms.Label lb_det_impor;
        private System.Windows.Forms.Label lb_det_lin;
        private System.Windows.Forms.TextBox tb_det_fra;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btt_det_cancel;
        private System.Windows.Forms.ComboBox cb_det_iva;
        private System.Windows.Forms.Button btt_col_buscar;
        private System.Windows.Forms.Button btt_ir_col;
        private System.Windows.Forms.TextBox tb_n_col_rg;
        private System.Windows.Forms.TextBox tb_col_rg;
        private System.Windows.Forms.Label lb_col_rg;
        private System.Windows.Forms.GroupBox gb_est_fra;
        private System.Windows.Forms.ComboBox cb_est_fra;
        private System.Windows.Forms.GroupBox gp_exp_ntl;
        private System.Windows.Forms.TextBox tb_exp_ntl;
        private System.Windows.Forms.TextBox tb_det_cta;
        private System.Windows.Forms.Label lb_det_cta;
        private System.Windows.Forms.GroupBox gb_usu;
        private System.Windows.Forms.TextBox tb_usu;
        private System.Windows.Forms.Button btt_ir_hrg;
        private System.Windows.Forms.ComboBox cb_deleg;
        private System.Windows.Forms.GroupBox gn_f_anul;
        private System.Windows.Forms.TextBox tb_f_anul;
        private System.Windows.Forms.GroupBox gb_enviado;
        private System.Windows.Forms.TextBox tb_enviado;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox gb_escri;
        private System.Windows.Forms.TextBox tb_entidad;
        private System.Windows.Forms.Label lb_ent_bc;
        private System.Windows.Forms.TextBox tb_firmado_por;
        private System.Windows.Forms.Label lb_firmado_por;
        private System.Windows.Forms.TextBox tb_impor_liq;
        private System.Windows.Forms.Label lb_impor_liq;
        private System.Windows.Forms.TextBox tb_notario;
        private System.Windows.Forms.Label lb_notario;
        private System.Windows.Forms.TextBox tb_n_operacion;
        private System.Windows.Forms.Label lb_n_opera;
    }
}
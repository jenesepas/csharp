﻿namespace Puche
{
    partial class Rpt_Registros
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_d_rg = new System.Windows.Forms.Label();
            this.tb_d_rg = new System.Windows.Forms.TextBox();
            this.lb_h_rg = new System.Windows.Forms.Label();
            this.tb_h_rg = new System.Windows.Forms.TextBox();
            this.gb_del_lrg = new System.Windows.Forms.GroupBox();
            this.rb_a_lrg = new System.Windows.Forms.RadioButton();
            this.rb_m_lrg = new System.Windows.Forms.RadioButton();
            this.rb_y_lrg = new System.Windows.Forms.RadioButton();
            this.btt_imp_lrg = new System.Windows.Forms.Button();
            this.gb_b_t_cte_lrg = new System.Windows.Forms.GroupBox();
            this.rb_titular_lrg = new System.Windows.Forms.RadioButton();
            this.rb_cte_lrg = new System.Windows.Forms.RadioButton();
            this.lb_d_cte = new System.Windows.Forms.Label();
            this.tb_d_cte = new System.Windows.Forms.TextBox();
            this.lb_h_cte = new System.Windows.Forms.Label();
            this.tb_h_cte = new System.Windows.Forms.TextBox();
            this.btt_cancelar_lrg = new System.Windows.Forms.Button();
            this.btt_buscar_lrg = new System.Windows.Forms.Button();
            this.btt_buscar2_lrg = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.gb_del_lrg.SuspendLayout();
            this.gb_b_t_cte_lrg.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_d_rg
            // 
            this.lb_d_rg.AutoSize = true;
            this.lb_d_rg.Location = new System.Drawing.Point(250, 19);
            this.lb_d_rg.Name = "lb_d_rg";
            this.lb_d_rg.Size = new System.Drawing.Size(44, 13);
            this.lb_d_rg.TabIndex = 0;
            this.lb_d_rg.Text = "D. Reg.";
            // 
            // tb_d_rg
            // 
            this.tb_d_rg.Location = new System.Drawing.Point(297, 19);
            this.tb_d_rg.Name = "tb_d_rg";
            this.tb_d_rg.Size = new System.Drawing.Size(79, 20);
            this.tb_d_rg.TabIndex = 1;
            // 
            // lb_h_rg
            // 
            this.lb_h_rg.AutoSize = true;
            this.lb_h_rg.Location = new System.Drawing.Point(250, 46);
            this.lb_h_rg.Name = "lb_h_rg";
            this.lb_h_rg.Size = new System.Drawing.Size(44, 13);
            this.lb_h_rg.TabIndex = 2;
            this.lb_h_rg.Text = "H. Reg.";
            // 
            // tb_h_rg
            // 
            this.tb_h_rg.Location = new System.Drawing.Point(297, 46);
            this.tb_h_rg.Name = "tb_h_rg";
            this.tb_h_rg.Size = new System.Drawing.Size(79, 20);
            this.tb_h_rg.TabIndex = 3;
            // 
            // gb_del_lrg
            // 
            this.gb_del_lrg.BackColor = System.Drawing.Color.LightBlue;
            this.gb_del_lrg.Controls.Add(this.rb_a_lrg);
            this.gb_del_lrg.Controls.Add(this.rb_m_lrg);
            this.gb_del_lrg.Controls.Add(this.rb_y_lrg);
            this.gb_del_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_del_lrg.Location = new System.Drawing.Point(22, 19);
            this.gb_del_lrg.Name = "gb_del_lrg";
            this.gb_del_lrg.Size = new System.Drawing.Size(219, 47);
            this.gb_del_lrg.TabIndex = 36;
            this.gb_del_lrg.TabStop = false;
            this.gb_del_lrg.Text = "Delegacion";
            // 
            // rb_a_lrg
            // 
            this.rb_a_lrg.AutoSize = true;
            this.rb_a_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_a_lrg.Location = new System.Drawing.Point(134, 20);
            this.rb_a_lrg.Name = "rb_a_lrg";
            this.rb_a_lrg.Size = new System.Drawing.Size(80, 19);
            this.rb_a_lrg.TabIndex = 26;
            this.rb_a_lrg.Text = "Albacete";
            this.rb_a_lrg.UseVisualStyleBackColor = true;
            // 
            // rb_m_lrg
            // 
            this.rb_m_lrg.AutoSize = true;
            this.rb_m_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_m_lrg.Location = new System.Drawing.Point(65, 20);
            this.rb_m_lrg.Name = "rb_m_lrg";
            this.rb_m_lrg.Size = new System.Drawing.Size(69, 19);
            this.rb_m_lrg.TabIndex = 25;
            this.rb_m_lrg.Text = "Murcia";
            this.rb_m_lrg.UseVisualStyleBackColor = true;
            // 
            // rb_y_lrg
            // 
            this.rb_y_lrg.AutoSize = true;
            this.rb_y_lrg.Checked = true;
            this.rb_y_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_y_lrg.Location = new System.Drawing.Point(6, 20);
            this.rb_y_lrg.Name = "rb_y_lrg";
            this.rb_y_lrg.Size = new System.Drawing.Size(60, 19);
            this.rb_y_lrg.TabIndex = 24;
            this.rb_y_lrg.TabStop = true;
            this.rb_y_lrg.Text = "Yecla";
            this.rb_y_lrg.UseVisualStyleBackColor = true;
            // 
            // btt_imp_lrg
            // 
            this.btt_imp_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_imp_lrg.Location = new System.Drawing.Point(12, 147);
            this.btt_imp_lrg.Name = "btt_imp_lrg";
            this.btt_imp_lrg.Size = new System.Drawing.Size(89, 34);
            this.btt_imp_lrg.TabIndex = 37;
            this.btt_imp_lrg.Text = "Imprimir";
            this.btt_imp_lrg.UseVisualStyleBackColor = true;
            this.btt_imp_lrg.Click += new System.EventHandler(this.btt_imp_lrg_Click);
            // 
            // gb_b_t_cte_lrg
            // 
            this.gb_b_t_cte_lrg.BackColor = System.Drawing.Color.LightBlue;
            this.gb_b_t_cte_lrg.Controls.Add(this.rb_titular_lrg);
            this.gb_b_t_cte_lrg.Controls.Add(this.rb_cte_lrg);
            this.gb_b_t_cte_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_b_t_cte_lrg.Location = new System.Drawing.Point(22, 72);
            this.gb_b_t_cte_lrg.Name = "gb_b_t_cte_lrg";
            this.gb_b_t_cte_lrg.Size = new System.Drawing.Size(185, 47);
            this.gb_b_t_cte_lrg.TabIndex = 38;
            this.gb_b_t_cte_lrg.TabStop = false;
            this.gb_b_t_cte_lrg.Text = "Tipo";
            // 
            // rb_titular_lrg
            // 
            this.rb_titular_lrg.AutoSize = true;
            this.rb_titular_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_titular_lrg.Location = new System.Drawing.Point(107, 20);
            this.rb_titular_lrg.Name = "rb_titular_lrg";
            this.rb_titular_lrg.Size = new System.Drawing.Size(70, 20);
            this.rb_titular_lrg.TabIndex = 25;
            this.rb_titular_lrg.Text = "Titular";
            this.rb_titular_lrg.UseVisualStyleBackColor = true;
            // 
            // rb_cte_lrg
            // 
            this.rb_cte_lrg.AutoSize = true;
            this.rb_cte_lrg.Checked = true;
            this.rb_cte_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_cte_lrg.Location = new System.Drawing.Point(27, 20);
            this.rb_cte_lrg.Name = "rb_cte_lrg";
            this.rb_cte_lrg.Size = new System.Drawing.Size(74, 20);
            this.rb_cte_lrg.TabIndex = 24;
            this.rb_cte_lrg.TabStop = true;
            this.rb_cte_lrg.Text = "Cliente";
            this.rb_cte_lrg.UseVisualStyleBackColor = true;
            // 
            // lb_d_cte
            // 
            this.lb_d_cte.AutoSize = true;
            this.lb_d_cte.Location = new System.Drawing.Point(250, 82);
            this.lb_d_cte.Name = "lb_d_cte";
            this.lb_d_cte.Size = new System.Drawing.Size(40, 13);
            this.lb_d_cte.TabIndex = 39;
            this.lb_d_cte.Text = "D. Cte.";
            // 
            // tb_d_cte
            // 
            this.tb_d_cte.Location = new System.Drawing.Point(297, 79);
            this.tb_d_cte.Name = "tb_d_cte";
            this.tb_d_cte.Size = new System.Drawing.Size(79, 20);
            this.tb_d_cte.TabIndex = 40;
            // 
            // lb_h_cte
            // 
            this.lb_h_cte.AutoSize = true;
            this.lb_h_cte.Location = new System.Drawing.Point(250, 106);
            this.lb_h_cte.Name = "lb_h_cte";
            this.lb_h_cte.Size = new System.Drawing.Size(40, 13);
            this.lb_h_cte.TabIndex = 41;
            this.lb_h_cte.Text = "H. Cte.";
            // 
            // tb_h_cte
            // 
            this.tb_h_cte.Location = new System.Drawing.Point(297, 105);
            this.tb_h_cte.Name = "tb_h_cte";
            this.tb_h_cte.Size = new System.Drawing.Size(79, 20);
            this.tb_h_cte.TabIndex = 42;
            // 
            // btt_cancelar_lrg
            // 
            this.btt_cancelar_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_cancelar_lrg.Location = new System.Drawing.Point(350, 147);
            this.btt_cancelar_lrg.Name = "btt_cancelar_lrg";
            this.btt_cancelar_lrg.Size = new System.Drawing.Size(89, 34);
            this.btt_cancelar_lrg.TabIndex = 43;
            this.btt_cancelar_lrg.Text = "Cancelar";
            this.btt_cancelar_lrg.UseVisualStyleBackColor = true;
            this.btt_cancelar_lrg.Click += new System.EventHandler(this.Btt_cancelar_lrgClick);
            // 
            // btt_buscar_lrg
            // 
            this.btt_buscar_lrg.Location = new System.Drawing.Point(382, 77);
            this.btt_buscar_lrg.Name = "btt_buscar_lrg";
            this.btt_buscar_lrg.Size = new System.Drawing.Size(50, 23);
            this.btt_buscar_lrg.TabIndex = 44;
            this.btt_buscar_lrg.Text = "Buscar";
            this.btt_buscar_lrg.UseVisualStyleBackColor = true;
            this.btt_buscar_lrg.Click += new System.EventHandler(this.btt_buscar_lrg_Click);
            // 
            // btt_buscar2_lrg
            // 
            this.btt_buscar2_lrg.Location = new System.Drawing.Point(382, 105);
            this.btt_buscar2_lrg.Name = "btt_buscar2_lrg";
            this.btt_buscar2_lrg.Size = new System.Drawing.Size(50, 23);
            this.btt_buscar2_lrg.TabIndex = 45;
            this.btt_buscar2_lrg.Text = "Buscar";
            this.btt_buscar2_lrg.UseVisualStyleBackColor = true;
            this.btt_buscar2_lrg.Click += new System.EventHandler(this.btt_buscar2_lrg_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Location = new System.Drawing.Point(12, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(427, 138);
            this.panel1.TabIndex = 46;
            // 
            // Rpt_Registros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(451, 187);
            this.Controls.Add(this.btt_buscar2_lrg);
            this.Controls.Add(this.btt_buscar_lrg);
            this.Controls.Add(this.btt_cancelar_lrg);
            this.Controls.Add(this.tb_h_cte);
            this.Controls.Add(this.lb_h_cte);
            this.Controls.Add(this.tb_d_cte);
            this.Controls.Add(this.lb_d_cte);
            this.Controls.Add(this.gb_b_t_cte_lrg);
            this.Controls.Add(this.btt_imp_lrg);
            this.Controls.Add(this.gb_del_lrg);
            this.Controls.Add(this.tb_h_rg);
            this.Controls.Add(this.lb_h_rg);
            this.Controls.Add(this.tb_d_rg);
            this.Controls.Add(this.lb_d_rg);
            this.Controls.Add(this.panel1);
            this.Name = "Rpt_Registros";
            this.Text = "Listado de Registros";
            this.Load += new System.EventHandler(this.Rpt_RegistrosLoad);
            this.gb_del_lrg.ResumeLayout(false);
            this.gb_del_lrg.PerformLayout();
            this.gb_b_t_cte_lrg.ResumeLayout(false);
            this.gb_b_t_cte_lrg.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        private System.Windows.Forms.Button btt_cancelar_lrg;
        private System.Windows.Forms.TextBox tb_h_cte;
        private System.Windows.Forms.Label lb_h_cte;
        private System.Windows.Forms.TextBox tb_d_cte;
        private System.Windows.Forms.Label lb_d_cte;
        private System.Windows.Forms.RadioButton rb_cte_lrg;
        private System.Windows.Forms.RadioButton rb_titular_lrg;
        private System.Windows.Forms.GroupBox gb_b_t_cte_lrg;

        #endregion

        private System.Windows.Forms.Label lb_d_rg;
        private System.Windows.Forms.TextBox tb_d_rg;
        private System.Windows.Forms.Label lb_h_rg;
        private System.Windows.Forms.TextBox tb_h_rg;
        private System.Windows.Forms.GroupBox gb_del_lrg;
        private System.Windows.Forms.RadioButton rb_a_lrg;
        private System.Windows.Forms.RadioButton rb_m_lrg;
        private System.Windows.Forms.RadioButton rb_y_lrg;
        private System.Windows.Forms.Button btt_imp_lrg;
        private System.Windows.Forms.Button btt_buscar_lrg;
        private System.Windows.Forms.Button btt_buscar2_lrg;
        private System.Windows.Forms.Panel panel1;
    }
}
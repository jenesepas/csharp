﻿namespace Asegest
{
    partial class Rpt_Registros
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Rpt_Registros));
            this.lb_d_rg = new System.Windows.Forms.Label();
            this.tb_d_rg = new System.Windows.Forms.TextBox();
            this.lb_h_rg = new System.Windows.Forms.Label();
            this.tb_h_rg = new System.Windows.Forms.TextBox();
            this.gb_del_lrg = new System.Windows.Forms.GroupBox();
            this.rb_a_lrg = new System.Windows.Forms.RadioButton();
            this.rb_m_lrg = new System.Windows.Forms.RadioButton();
            this.rb_y_lrg = new System.Windows.Forms.RadioButton();
            this.btt_imp_lrg = new System.Windows.Forms.Button();
            this.gb_b_t_cte_lrg = new System.Windows.Forms.GroupBox();
            this.rb_colab_lrg = new System.Windows.Forms.RadioButton();
            this.rb_titular_lrg = new System.Windows.Forms.RadioButton();
            this.rb_cte_lrg = new System.Windows.Forms.RadioButton();
            this.lb_d_cte = new System.Windows.Forms.Label();
            this.tb_d_cte = new System.Windows.Forms.TextBox();
            this.lb_h_cte = new System.Windows.Forms.Label();
            this.tb_h_cte = new System.Windows.Forms.TextBox();
            this.btt_cancelar_lrg = new System.Windows.Forms.Button();
            this.btt_buscar_lrg = new System.Windows.Forms.Button();
            this.btt_buscar2_lrg = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lb_tram = new System.Windows.Forms.Label();
            this.cb_tram = new System.Windows.Forms.ComboBox();
            this.lb_secc = new System.Windows.Forms.Label();
            this.cb_secc = new System.Windows.Forms.ComboBox();
            this.dtp_h_freg = new System.Windows.Forms.DateTimePicker();
            this.dtp_d_freg = new System.Windows.Forms.DateTimePicker();
            this.lb_h_freg = new System.Windows.Forms.Label();
            this.lb_d_freg = new System.Windows.Forms.Label();
            this.lb_treg = new System.Windows.Forms.Label();
            this.cb_treg = new System.Windows.Forms.ComboBox();
            this.lb_estado = new System.Windows.Forms.Label();
            this.cb_estado_lrg = new System.Windows.Forms.ComboBox();
            this.lb_s_int = new System.Windows.Forms.Label();
            this.cb_secc_lrg = new System.Windows.Forms.ComboBox();
            this.gb_del_lrg.SuspendLayout();
            this.gb_b_t_cte_lrg.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_d_rg
            // 
            this.lb_d_rg.AutoSize = true;
            this.lb_d_rg.Location = new System.Drawing.Point(314, 19);
            this.lb_d_rg.Name = "lb_d_rg";
            this.lb_d_rg.Size = new System.Drawing.Size(44, 13);
            this.lb_d_rg.TabIndex = 0;
            this.lb_d_rg.Text = "D. Reg.";
            // 
            // tb_d_rg
            // 
            this.tb_d_rg.Location = new System.Drawing.Point(361, 19);
            this.tb_d_rg.Name = "tb_d_rg";
            this.tb_d_rg.Size = new System.Drawing.Size(79, 20);
            this.tb_d_rg.TabIndex = 1;
            // 
            // lb_h_rg
            // 
            this.lb_h_rg.AutoSize = true;
            this.lb_h_rg.Location = new System.Drawing.Point(314, 46);
            this.lb_h_rg.Name = "lb_h_rg";
            this.lb_h_rg.Size = new System.Drawing.Size(44, 13);
            this.lb_h_rg.TabIndex = 2;
            this.lb_h_rg.Text = "H. Reg.";
            // 
            // tb_h_rg
            // 
            this.tb_h_rg.Location = new System.Drawing.Point(361, 46);
            this.tb_h_rg.Name = "tb_h_rg";
            this.tb_h_rg.Size = new System.Drawing.Size(79, 20);
            this.tb_h_rg.TabIndex = 3;
            // 
            // gb_del_lrg
            // 
            this.gb_del_lrg.BackColor = System.Drawing.Color.LightBlue;
            this.gb_del_lrg.Controls.Add(this.rb_a_lrg);
            this.gb_del_lrg.Controls.Add(this.rb_m_lrg);
            this.gb_del_lrg.Controls.Add(this.rb_y_lrg);
            this.gb_del_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_del_lrg.Location = new System.Drawing.Point(22, 19);
            this.gb_del_lrg.Name = "gb_del_lrg";
            this.gb_del_lrg.Size = new System.Drawing.Size(219, 47);
            this.gb_del_lrg.TabIndex = 36;
            this.gb_del_lrg.TabStop = false;
            this.gb_del_lrg.Text = "Delegacion";
            // 
            // rb_a_lrg
            // 
            this.rb_a_lrg.AutoSize = true;
            this.rb_a_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_a_lrg.Location = new System.Drawing.Point(134, 20);
            this.rb_a_lrg.Name = "rb_a_lrg";
            this.rb_a_lrg.Size = new System.Drawing.Size(80, 19);
            this.rb_a_lrg.TabIndex = 26;
            this.rb_a_lrg.Text = "Albacete";
            this.rb_a_lrg.UseVisualStyleBackColor = true;
            // 
            // rb_m_lrg
            // 
            this.rb_m_lrg.AutoSize = true;
            this.rb_m_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_m_lrg.Location = new System.Drawing.Point(65, 20);
            this.rb_m_lrg.Name = "rb_m_lrg";
            this.rb_m_lrg.Size = new System.Drawing.Size(69, 19);
            this.rb_m_lrg.TabIndex = 25;
            this.rb_m_lrg.Text = "Murcia";
            this.rb_m_lrg.UseVisualStyleBackColor = true;
            // 
            // rb_y_lrg
            // 
            this.rb_y_lrg.AutoSize = true;
            this.rb_y_lrg.Checked = true;
            this.rb_y_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_y_lrg.Location = new System.Drawing.Point(6, 20);
            this.rb_y_lrg.Name = "rb_y_lrg";
            this.rb_y_lrg.Size = new System.Drawing.Size(60, 19);
            this.rb_y_lrg.TabIndex = 24;
            this.rb_y_lrg.TabStop = true;
            this.rb_y_lrg.Text = "Yecla";
            this.rb_y_lrg.UseVisualStyleBackColor = true;
            // 
            // btt_imp_lrg
            // 
            this.btt_imp_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_imp_lrg.Location = new System.Drawing.Point(12, 256);
            this.btt_imp_lrg.Name = "btt_imp_lrg";
            this.btt_imp_lrg.Size = new System.Drawing.Size(89, 34);
            this.btt_imp_lrg.TabIndex = 37;
            this.btt_imp_lrg.Text = "Imprimir";
            this.btt_imp_lrg.UseVisualStyleBackColor = true;
            this.btt_imp_lrg.Click += new System.EventHandler(this.btt_imp_lrg_Click);
            // 
            // gb_b_t_cte_lrg
            // 
            this.gb_b_t_cte_lrg.BackColor = System.Drawing.Color.LightBlue;
            this.gb_b_t_cte_lrg.Controls.Add(this.rb_colab_lrg);
            this.gb_b_t_cte_lrg.Controls.Add(this.rb_titular_lrg);
            this.gb_b_t_cte_lrg.Controls.Add(this.rb_cte_lrg);
            this.gb_b_t_cte_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_b_t_cte_lrg.Location = new System.Drawing.Point(22, 72);
            this.gb_b_t_cte_lrg.Name = "gb_b_t_cte_lrg";
            this.gb_b_t_cte_lrg.Size = new System.Drawing.Size(219, 47);
            this.gb_b_t_cte_lrg.TabIndex = 38;
            this.gb_b_t_cte_lrg.TabStop = false;
            this.gb_b_t_cte_lrg.Text = "Tipo";
            // 
            // rb_colab_lrg
            // 
            this.rb_colab_lrg.AutoSize = true;
            this.rb_colab_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_colab_lrg.Location = new System.Drawing.Point(143, 20);
            this.rb_colab_lrg.Name = "rb_colab_lrg";
            this.rb_colab_lrg.Size = new System.Drawing.Size(71, 20);
            this.rb_colab_lrg.TabIndex = 26;
            this.rb_colab_lrg.Text = "Colab.";
            this.rb_colab_lrg.UseVisualStyleBackColor = true;
            // 
            // rb_titular_lrg
            // 
            this.rb_titular_lrg.AutoSize = true;
            this.rb_titular_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_titular_lrg.Location = new System.Drawing.Point(76, 20);
            this.rb_titular_lrg.Name = "rb_titular_lrg";
            this.rb_titular_lrg.Size = new System.Drawing.Size(70, 20);
            this.rb_titular_lrg.TabIndex = 25;
            this.rb_titular_lrg.Text = "Titular";
            this.rb_titular_lrg.UseVisualStyleBackColor = true;
            // 
            // rb_cte_lrg
            // 
            this.rb_cte_lrg.AutoSize = true;
            this.rb_cte_lrg.Checked = true;
            this.rb_cte_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_cte_lrg.Location = new System.Drawing.Point(6, 20);
            this.rb_cte_lrg.Name = "rb_cte_lrg";
            this.rb_cte_lrg.Size = new System.Drawing.Size(74, 20);
            this.rb_cte_lrg.TabIndex = 24;
            this.rb_cte_lrg.TabStop = true;
            this.rb_cte_lrg.Text = "Cliente";
            this.rb_cte_lrg.UseVisualStyleBackColor = true;
            // 
            // lb_d_cte
            // 
            this.lb_d_cte.AutoSize = true;
            this.lb_d_cte.Location = new System.Drawing.Point(314, 135);
            this.lb_d_cte.Name = "lb_d_cte";
            this.lb_d_cte.Size = new System.Drawing.Size(40, 13);
            this.lb_d_cte.TabIndex = 39;
            this.lb_d_cte.Text = "D. Cte.";
            // 
            // tb_d_cte
            // 
            this.tb_d_cte.Location = new System.Drawing.Point(361, 132);
            this.tb_d_cte.Name = "tb_d_cte";
            this.tb_d_cte.Size = new System.Drawing.Size(79, 20);
            this.tb_d_cte.TabIndex = 40;
            // 
            // lb_h_cte
            // 
            this.lb_h_cte.AutoSize = true;
            this.lb_h_cte.Location = new System.Drawing.Point(314, 159);
            this.lb_h_cte.Name = "lb_h_cte";
            this.lb_h_cte.Size = new System.Drawing.Size(40, 13);
            this.lb_h_cte.TabIndex = 41;
            this.lb_h_cte.Text = "H. Cte.";
            // 
            // tb_h_cte
            // 
            this.tb_h_cte.Location = new System.Drawing.Point(361, 158);
            this.tb_h_cte.Name = "tb_h_cte";
            this.tb_h_cte.Size = new System.Drawing.Size(79, 20);
            this.tb_h_cte.TabIndex = 42;
            // 
            // btt_cancelar_lrg
            // 
            this.btt_cancelar_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_cancelar_lrg.Location = new System.Drawing.Point(424, 256);
            this.btt_cancelar_lrg.Name = "btt_cancelar_lrg";
            this.btt_cancelar_lrg.Size = new System.Drawing.Size(89, 34);
            this.btt_cancelar_lrg.TabIndex = 43;
            this.btt_cancelar_lrg.Text = "Cancelar";
            this.btt_cancelar_lrg.UseVisualStyleBackColor = true;
            this.btt_cancelar_lrg.Click += new System.EventHandler(this.Btt_cancelar_lrgClick);
            // 
            // btt_buscar_lrg
            // 
            this.btt_buscar_lrg.Location = new System.Drawing.Point(446, 130);
            this.btt_buscar_lrg.Name = "btt_buscar_lrg";
            this.btt_buscar_lrg.Size = new System.Drawing.Size(50, 23);
            this.btt_buscar_lrg.TabIndex = 44;
            this.btt_buscar_lrg.Text = "Buscar";
            this.btt_buscar_lrg.UseVisualStyleBackColor = true;
            this.btt_buscar_lrg.Click += new System.EventHandler(this.btt_buscar_lrg_Click);
            // 
            // btt_buscar2_lrg
            // 
            this.btt_buscar2_lrg.Location = new System.Drawing.Point(446, 158);
            this.btt_buscar2_lrg.Name = "btt_buscar2_lrg";
            this.btt_buscar2_lrg.Size = new System.Drawing.Size(50, 23);
            this.btt_buscar2_lrg.TabIndex = 45;
            this.btt_buscar2_lrg.Text = "Buscar";
            this.btt_buscar2_lrg.UseVisualStyleBackColor = true;
            this.btt_buscar2_lrg.Click += new System.EventHandler(this.btt_buscar2_lrg_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lb_tram);
            this.panel1.Controls.Add(this.cb_tram);
            this.panel1.Controls.Add(this.lb_secc);
            this.panel1.Controls.Add(this.cb_secc);
            this.panel1.Controls.Add(this.dtp_h_freg);
            this.panel1.Controls.Add(this.dtp_d_freg);
            this.panel1.Controls.Add(this.lb_h_freg);
            this.panel1.Controls.Add(this.lb_d_freg);
            this.panel1.Controls.Add(this.lb_treg);
            this.panel1.Controls.Add(this.cb_treg);
            this.panel1.Controls.Add(this.lb_estado);
            this.panel1.Controls.Add(this.cb_estado_lrg);
            this.panel1.Controls.Add(this.lb_s_int);
            this.panel1.Controls.Add(this.cb_secc_lrg);
            this.panel1.Location = new System.Drawing.Point(12, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(501, 245);
            this.panel1.TabIndex = 46;
            // 
            // lb_tram
            // 
            this.lb_tram.AutoSize = true;
            this.lb_tram.Location = new System.Drawing.Point(12, 192);
            this.lb_tram.Name = "lb_tram";
            this.lb_tram.Size = new System.Drawing.Size(42, 13);
            this.lb_tram.TabIndex = 66;
            this.lb_tram.Text = "Trámite";
            // 
            // cb_tram
            // 
            this.cb_tram.FormattingEnabled = true;
            this.cb_tram.Location = new System.Drawing.Point(73, 192);
            this.cb_tram.Name = "cb_tram";
            this.cb_tram.Size = new System.Drawing.Size(175, 21);
            this.cb_tram.TabIndex = 67;
            // 
            // lb_secc
            // 
            this.lb_secc.AutoSize = true;
            this.lb_secc.Location = new System.Drawing.Point(12, 162);
            this.lb_secc.Name = "lb_secc";
            this.lb_secc.Size = new System.Drawing.Size(46, 13);
            this.lb_secc.TabIndex = 64;
            this.lb_secc.Text = "Sección";
            // 
            // cb_secc
            // 
            this.cb_secc.FormattingEnabled = true;
            this.cb_secc.Items.AddRange(new object[] {
            "Hacienda",
            "Seg. Social",
            "Extranjería",
            "Conductores",
            "Vehículos",
            "Transporte",
            "Sanciones Tráfico",
            "Escrituras",
            "Herencias",
            "Varios"});
            this.cb_secc.Location = new System.Drawing.Point(73, 162);
            this.cb_secc.Name = "cb_secc";
            this.cb_secc.Size = new System.Drawing.Size(116, 21);
            this.cb_secc.TabIndex = 65;
            this.cb_secc.SelectedIndexChanged += new System.EventHandler(this.cb_secc_SelectedIndexChanged);
            // 
            // dtp_h_freg
            // 
            this.dtp_h_freg.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_h_freg.Location = new System.Drawing.Point(348, 93);
            this.dtp_h_freg.Name = "dtp_h_freg";
            this.dtp_h_freg.Size = new System.Drawing.Size(90, 20);
            this.dtp_h_freg.TabIndex = 63;
            // 
            // dtp_d_freg
            // 
            this.dtp_d_freg.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_d_freg.Location = new System.Drawing.Point(348, 67);
            this.dtp_d_freg.Name = "dtp_d_freg";
            this.dtp_d_freg.Size = new System.Drawing.Size(90, 20);
            this.dtp_d_freg.TabIndex = 62;
            // 
            // lb_h_freg
            // 
            this.lb_h_freg.AutoSize = true;
            this.lb_h_freg.Location = new System.Drawing.Point(277, 93);
            this.lb_h_freg.Name = "lb_h_freg";
            this.lb_h_freg.Size = new System.Drawing.Size(68, 13);
            this.lb_h_freg.TabIndex = 61;
            this.lb_h_freg.Text = "H. Fec. Reg.";
            // 
            // lb_d_freg
            // 
            this.lb_d_freg.AutoSize = true;
            this.lb_d_freg.Location = new System.Drawing.Point(277, 67);
            this.lb_d_freg.Name = "lb_d_freg";
            this.lb_d_freg.Size = new System.Drawing.Size(68, 13);
            this.lb_d_freg.TabIndex = 60;
            this.lb_d_freg.Text = "D. Fec. Reg.";
            // 
            // lb_treg
            // 
            this.lb_treg.AutoSize = true;
            this.lb_treg.Location = new System.Drawing.Point(12, 131);
            this.lb_treg.Name = "lb_treg";
            this.lb_treg.Size = new System.Drawing.Size(51, 13);
            this.lb_treg.TabIndex = 47;
            this.lb_treg.Text = "Registros";
            // 
            // cb_treg
            // 
            this.cb_treg.FormattingEnabled = true;
            this.cb_treg.Items.AddRange(new object[] {
            "TODOS",
            "SIN FACTURAR",
            "FACTURADOS"});
            this.cb_treg.Location = new System.Drawing.Point(73, 131);
            this.cb_treg.Name = "cb_treg";
            this.cb_treg.Size = new System.Drawing.Size(116, 21);
            this.cb_treg.TabIndex = 50;
            // 
            // lb_estado
            // 
            this.lb_estado.AutoSize = true;
            this.lb_estado.Location = new System.Drawing.Point(301, 211);
            this.lb_estado.Name = "lb_estado";
            this.lb_estado.Size = new System.Drawing.Size(40, 13);
            this.lb_estado.TabIndex = 49;
            this.lb_estado.Text = "Estado";
            // 
            // cb_estado_lrg
            // 
            this.cb_estado_lrg.FormattingEnabled = true;
            this.cb_estado_lrg.Items.AddRange(new object[] {
            "",
            "PTE. CLIENTE",
            "PTE. GESTORÍA",
            "EN TRÁMITE",
            "TERMINADO",
            "ANULADO",
            "LIQUIDADO"});
            this.cb_estado_lrg.Location = new System.Drawing.Point(348, 211);
            this.cb_estado_lrg.Name = "cb_estado_lrg";
            this.cb_estado_lrg.Size = new System.Drawing.Size(116, 21);
            this.cb_estado_lrg.TabIndex = 48;
            // 
            // lb_s_int
            // 
            this.lb_s_int.AutoSize = true;
            this.lb_s_int.Location = new System.Drawing.Point(281, 184);
            this.lb_s_int.Name = "lb_s_int";
            this.lb_s_int.Size = new System.Drawing.Size(64, 13);
            this.lb_s_int.TabIndex = 47;
            this.lb_s_int.Text = "Sección Int.";
            // 
            // cb_secc_lrg
            // 
            this.cb_secc_lrg.FormattingEnabled = true;
            this.cb_secc_lrg.Items.AddRange(new object[] {
            "",
            "GESTASER",
            "EX",
            "AVPO",
            "A"});
            this.cb_secc_lrg.Location = new System.Drawing.Point(348, 184);
            this.cb_secc_lrg.Name = "cb_secc_lrg";
            this.cb_secc_lrg.Size = new System.Drawing.Size(116, 21);
            this.cb_secc_lrg.TabIndex = 0;
            // 
            // Rpt_Registros
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(525, 302);
            this.Controls.Add(this.btt_buscar2_lrg);
            this.Controls.Add(this.btt_buscar_lrg);
            this.Controls.Add(this.btt_cancelar_lrg);
            this.Controls.Add(this.tb_h_cte);
            this.Controls.Add(this.lb_h_cte);
            this.Controls.Add(this.tb_d_cte);
            this.Controls.Add(this.lb_d_cte);
            this.Controls.Add(this.gb_b_t_cte_lrg);
            this.Controls.Add(this.btt_imp_lrg);
            this.Controls.Add(this.gb_del_lrg);
            this.Controls.Add(this.tb_h_rg);
            this.Controls.Add(this.lb_h_rg);
            this.Controls.Add(this.tb_d_rg);
            this.Controls.Add(this.lb_d_rg);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Rpt_Registros";
            this.Text = "Listado de Registros";
            this.Load += new System.EventHandler(this.Rpt_RegistrosLoad);
            this.gb_del_lrg.ResumeLayout(false);
            this.gb_del_lrg.PerformLayout();
            this.gb_b_t_cte_lrg.ResumeLayout(false);
            this.gb_b_t_cte_lrg.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        private System.Windows.Forms.Button btt_cancelar_lrg;
        private System.Windows.Forms.TextBox tb_h_cte;
        private System.Windows.Forms.Label lb_h_cte;
        private System.Windows.Forms.TextBox tb_d_cte;
        private System.Windows.Forms.Label lb_d_cte;
        private System.Windows.Forms.RadioButton rb_cte_lrg;
        private System.Windows.Forms.RadioButton rb_titular_lrg;
        private System.Windows.Forms.GroupBox gb_b_t_cte_lrg;

        #endregion

        private System.Windows.Forms.Label lb_d_rg;
        private System.Windows.Forms.TextBox tb_d_rg;
        private System.Windows.Forms.Label lb_h_rg;
        private System.Windows.Forms.TextBox tb_h_rg;
        private System.Windows.Forms.GroupBox gb_del_lrg;
        private System.Windows.Forms.RadioButton rb_a_lrg;
        private System.Windows.Forms.RadioButton rb_m_lrg;
        private System.Windows.Forms.RadioButton rb_y_lrg;
        private System.Windows.Forms.Button btt_imp_lrg;
        private System.Windows.Forms.Button btt_buscar_lrg;
        private System.Windows.Forms.Button btt_buscar2_lrg;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rb_colab_lrg;
        private System.Windows.Forms.Label lb_s_int;
        private System.Windows.Forms.ComboBox cb_secc_lrg;
        private System.Windows.Forms.Label lb_estado;
        private System.Windows.Forms.ComboBox cb_estado_lrg;
        private System.Windows.Forms.Label lb_treg;
        private System.Windows.Forms.ComboBox cb_treg;
        private System.Windows.Forms.DateTimePicker dtp_h_freg;
        private System.Windows.Forms.DateTimePicker dtp_d_freg;
        private System.Windows.Forms.Label lb_h_freg;
        private System.Windows.Forms.Label lb_d_freg;
        private System.Windows.Forms.Label lb_tram;
        private System.Windows.Forms.ComboBox cb_tram;
        private System.Windows.Forms.Label lb_secc;
        private System.Windows.Forms.ComboBox cb_secc;
    }
}
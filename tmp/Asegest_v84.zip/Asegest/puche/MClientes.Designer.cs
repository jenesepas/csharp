﻿namespace Asegest
{
    partial class MClientes
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MClientes));
            this.panel1 = new System.Windows.Forms.Panel();
            this.tb_direccion = new System.Windows.Forms.TextBox();
            this.tb_provin = new System.Windows.Forms.TextBox();
            this.tb_cp = new System.Windows.Forms.TextBox();
            this.tb_tf1 = new System.Windows.Forms.TextBox();
            this.tb_email = new System.Windows.Forms.TextBox();
            this.tb_p_cont = new System.Windows.Forms.TextBox();
            this.cb_t_docu = new System.Windows.Forms.ComboBox();
            this.tb_nombre = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tb_cta = new System.Windows.Forms.TextBox();
            this.lb_cta = new System.Windows.Forms.Label();
            this.lb_ciudad = new System.Windows.Forms.Label();
            this.tb_ciudad = new System.Windows.Forms.TextBox();
            this.lb_p_cont = new System.Windows.Forms.Label();
            this.lb_direccion = new System.Windows.Forms.Label();
            this.lb_provin = new System.Windows.Forms.Label();
            this.lb_nombre = new System.Windows.Forms.Label();
            this.lb_t_docu = new System.Windows.Forms.Label();
            this.tb_tf2 = new System.Windows.Forms.TextBox();
            this.lb_email = new System.Windows.Forms.Label();
            this.lb_tf1 = new System.Windows.Forms.Label();
            this.lb_tf2 = new System.Windows.Forms.Label();
            this.lb_cp = new System.Windows.Forms.Label();
            this.tb_documento = new System.Windows.Forms.TextBox();
            this.tb_letra = new System.Windows.Forms.TextBox();
            this.lb_letra = new System.Windows.Forms.Label();
            this.lb_docu = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rb_colabora = new System.Windows.Forms.RadioButton();
            this.rb_titular = new System.Windows.Forms.RadioButton();
            this.rb_cte = new System.Windows.Forms.RadioButton();
            this.lb_id_cte = new System.Windows.Forms.Label();
            this.tb_id_cte = new System.Windows.Forms.TextBox();
            this.lb_titulo = new System.Windows.Forms.Label();
            this.btt_first = new System.Windows.Forms.Button();
            this.btt_back = new System.Windows.Forms.Button();
            this.btt_next = new System.Windows.Forms.Button();
            this.btt_last = new System.Windows.Forms.Button();
            this.btt_buscar = new System.Windows.Forms.Button();
            this.btt_consultar = new System.Windows.Forms.Button();
            this.btt_nuevo = new System.Windows.Forms.Button();
            this.btt_guardar = new System.Windows.Forms.Button();
            this.btt_modificar = new System.Windows.Forms.Button();
            this.btt_borrar = new System.Windows.Forms.Button();
            this.btt_cancelar = new System.Windows.Forms.Button();
            this.lb_num_rg = new System.Windows.Forms.Label();
            this.btt_imp_cte = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.groupBox3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(16, 41);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(667, 480);
            this.panel1.TabIndex = 0;
            // 
            // tb_direccion
            // 
            this.tb_direccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_direccion.Location = new System.Drawing.Point(99, 246);
            this.tb_direccion.Margin = new System.Windows.Forms.Padding(4);
            this.tb_direccion.Name = "tb_direccion";
            this.tb_direccion.Size = new System.Drawing.Size(519, 24);
            this.tb_direccion.TabIndex = 18;
            this.tb_direccion.Validating += new System.ComponentModel.CancelEventHandler(this.tb_direccion_Validating);
            // 
            // tb_provin
            // 
            this.tb_provin.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_provin.Location = new System.Drawing.Point(99, 338);
            this.tb_provin.Margin = new System.Windows.Forms.Padding(4);
            this.tb_provin.Name = "tb_provin";
            this.tb_provin.Size = new System.Drawing.Size(311, 24);
            this.tb_provin.TabIndex = 23;
            this.tb_provin.Validating += new System.ComponentModel.CancelEventHandler(this.tb_provin_Validating);
            // 
            // tb_cp
            // 
            this.tb_cp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_cp.Location = new System.Drawing.Point(99, 292);
            this.tb_cp.Margin = new System.Windows.Forms.Padding(4);
            this.tb_cp.Name = "tb_cp";
            this.tb_cp.Size = new System.Drawing.Size(104, 24);
            this.tb_cp.TabIndex = 19;
            this.tb_cp.Validating += new System.ComponentModel.CancelEventHandler(this.tb_cp_Validating);
            // 
            // tb_tf1
            // 
            this.tb_tf1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_tf1.Location = new System.Drawing.Point(101, 200);
            this.tb_tf1.Margin = new System.Windows.Forms.Padding(4);
            this.tb_tf1.Name = "tb_tf1";
            this.tb_tf1.Size = new System.Drawing.Size(177, 24);
            this.tb_tf1.TabIndex = 16;
            this.tb_tf1.Validating += new System.ComponentModel.CancelEventHandler(this.tb_tf1_Validating);
            // 
            // tb_email
            // 
            this.tb_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_email.Location = new System.Drawing.Point(101, 154);
            this.tb_email.Margin = new System.Windows.Forms.Padding(4);
            this.tb_email.Name = "tb_email";
            this.tb_email.Size = new System.Drawing.Size(321, 24);
            this.tb_email.TabIndex = 13;
            this.tb_email.Validating += new System.ComponentModel.CancelEventHandler(this.tb_email_Validating);
            // 
            // tb_p_cont
            // 
            this.tb_p_cont.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_p_cont.Location = new System.Drawing.Point(101, 108);
            this.tb_p_cont.Margin = new System.Windows.Forms.Padding(4);
            this.tb_p_cont.Name = "tb_p_cont";
            this.tb_p_cont.Size = new System.Drawing.Size(321, 24);
            this.tb_p_cont.TabIndex = 11;
            this.tb_p_cont.Validating += new System.ComponentModel.CancelEventHandler(this.tb_p_cont_Validating);
            // 
            // cb_t_docu
            // 
            this.cb_t_docu.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_t_docu.FormattingEnabled = true;
            this.cb_t_docu.Items.AddRange(new object[] {
            "DNI",
            "CIF",
            "NIF",
            "NIE",
            "OTRO"});
            this.cb_t_docu.Location = new System.Drawing.Point(101, 60);
            this.cb_t_docu.Margin = new System.Windows.Forms.Padding(4);
            this.cb_t_docu.Name = "cb_t_docu";
            this.cb_t_docu.Size = new System.Drawing.Size(132, 26);
            this.cb_t_docu.TabIndex = 4;
            // 
            // tb_nombre
            // 
            this.tb_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_nombre.Location = new System.Drawing.Point(101, 17);
            this.tb_nombre.Margin = new System.Windows.Forms.Padding(4);
            this.tb_nombre.Name = "tb_nombre";
            this.tb_nombre.Size = new System.Drawing.Size(439, 24);
            this.tb_nombre.TabIndex = 3;
            this.tb_nombre.Validating += new System.ComponentModel.CancelEventHandler(this.tb_nombre_Validating);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tb_provin);
            this.groupBox2.Controls.Add(this.tb_direccion);
            this.groupBox2.Controls.Add(this.tb_cp);
            this.groupBox2.Controls.Add(this.tb_cta);
            this.groupBox2.Controls.Add(this.lb_cta);
            this.groupBox2.Controls.Add(this.lb_ciudad);
            this.groupBox2.Controls.Add(this.tb_tf1);
            this.groupBox2.Controls.Add(this.tb_ciudad);
            this.groupBox2.Controls.Add(this.tb_email);
            this.groupBox2.Controls.Add(this.lb_p_cont);
            this.groupBox2.Controls.Add(this.tb_p_cont);
            this.groupBox2.Controls.Add(this.lb_direccion);
            this.groupBox2.Controls.Add(this.cb_t_docu);
            this.groupBox2.Controls.Add(this.lb_provin);
            this.groupBox2.Controls.Add(this.tb_nombre);
            this.groupBox2.Controls.Add(this.lb_nombre);
            this.groupBox2.Controls.Add(this.lb_t_docu);
            this.groupBox2.Controls.Add(this.tb_tf2);
            this.groupBox2.Controls.Add(this.lb_email);
            this.groupBox2.Controls.Add(this.lb_tf1);
            this.groupBox2.Controls.Add(this.lb_tf2);
            this.groupBox2.Controls.Add(this.lb_cp);
            this.groupBox2.Controls.Add(this.tb_documento);
            this.groupBox2.Controls.Add(this.tb_letra);
            this.groupBox2.Controls.Add(this.lb_letra);
            this.groupBox2.Controls.Add(this.lb_docu);
            this.groupBox2.Location = new System.Drawing.Point(8, 82);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(642, 387);
            this.groupBox2.TabIndex = 30;
            this.groupBox2.TabStop = false;
            // 
            // tb_cta
            // 
            this.tb_cta.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_cta.Location = new System.Drawing.Point(516, 338);
            this.tb_cta.Margin = new System.Windows.Forms.Padding(4);
            this.tb_cta.Name = "tb_cta";
            this.tb_cta.Size = new System.Drawing.Size(104, 24);
            this.tb_cta.TabIndex = 24;
            this.tb_cta.Validating += new System.ComponentModel.CancelEventHandler(this.tb_cta_Validating);
            // 
            // lb_cta
            // 
            this.lb_cta.AutoSize = true;
            this.lb_cta.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_cta.Location = new System.Drawing.Point(453, 341);
            this.lb_cta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_cta.Name = "lb_cta";
            this.lb_cta.Size = new System.Drawing.Size(55, 18);
            this.lb_cta.TabIndex = 28;
            this.lb_cta.Text = "Cuenta";
            // 
            // lb_ciudad
            // 
            this.lb_ciudad.AutoSize = true;
            this.lb_ciudad.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ciudad.Location = new System.Drawing.Point(222, 295);
            this.lb_ciudad.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_ciudad.Name = "lb_ciudad";
            this.lb_ciudad.Size = new System.Drawing.Size(54, 18);
            this.lb_ciudad.TabIndex = 20;
            this.lb_ciudad.Text = "Ciudad";
            // 
            // tb_ciudad
            // 
            this.tb_ciudad.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_ciudad.Location = new System.Drawing.Point(284, 292);
            this.tb_ciudad.Margin = new System.Windows.Forms.Padding(4);
            this.tb_ciudad.Name = "tb_ciudad";
            this.tb_ciudad.Size = new System.Drawing.Size(336, 24);
            this.tb_ciudad.TabIndex = 21;
            this.tb_ciudad.Validating += new System.ComponentModel.CancelEventHandler(this.tb_ciudad_Validating);
            // 
            // lb_p_cont
            // 
            this.lb_p_cont.AutoSize = true;
            this.lb_p_cont.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_p_cont.Location = new System.Drawing.Point(8, 111);
            this.lb_p_cont.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_p_cont.Name = "lb_p_cont";
            this.lb_p_cont.Size = new System.Drawing.Size(79, 18);
            this.lb_p_cont.TabIndex = 10;
            this.lb_p_cont.Text = "Pers. Con.";
            // 
            // lb_direccion
            // 
            this.lb_direccion.AutoSize = true;
            this.lb_direccion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_direccion.Location = new System.Drawing.Point(16, 249);
            this.lb_direccion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_direccion.Name = "lb_direccion";
            this.lb_direccion.Size = new System.Drawing.Size(71, 18);
            this.lb_direccion.TabIndex = 27;
            this.lb_direccion.Text = "Dirección";
            // 
            // lb_provin
            // 
            this.lb_provin.AutoSize = true;
            this.lb_provin.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_provin.Location = new System.Drawing.Point(18, 341);
            this.lb_provin.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_provin.Name = "lb_provin";
            this.lb_provin.Size = new System.Drawing.Size(69, 18);
            this.lb_provin.TabIndex = 22;
            this.lb_provin.Text = "Provincia";
            // 
            // lb_nombre
            // 
            this.lb_nombre.AutoSize = true;
            this.lb_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_nombre.Location = new System.Drawing.Point(25, 17);
            this.lb_nombre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_nombre.Name = "lb_nombre";
            this.lb_nombre.Size = new System.Drawing.Size(62, 18);
            this.lb_nombre.TabIndex = 1;
            this.lb_nombre.Text = "Nombre";
            // 
            // lb_t_docu
            // 
            this.lb_t_docu.AutoSize = true;
            this.lb_t_docu.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_t_docu.Location = new System.Drawing.Point(14, 63);
            this.lb_t_docu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_t_docu.Name = "lb_t_docu";
            this.lb_t_docu.Size = new System.Drawing.Size(73, 18);
            this.lb_t_docu.TabIndex = 5;
            this.lb_t_docu.Text = "Tipo Doc.";
            // 
            // tb_tf2
            // 
            this.tb_tf2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_tf2.Location = new System.Drawing.Point(443, 197);
            this.tb_tf2.Margin = new System.Windows.Forms.Padding(4);
            this.tb_tf2.Name = "tb_tf2";
            this.tb_tf2.Size = new System.Drawing.Size(177, 24);
            this.tb_tf2.TabIndex = 17;
            this.tb_tf2.Validating += new System.ComponentModel.CancelEventHandler(this.tb_tf2_Validating);
            // 
            // lb_email
            // 
            this.lb_email.AutoSize = true;
            this.lb_email.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_email.Location = new System.Drawing.Point(42, 157);
            this.lb_email.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_email.Name = "lb_email";
            this.lb_email.Size = new System.Drawing.Size(45, 18);
            this.lb_email.TabIndex = 12;
            this.lb_email.Text = "Email";
            // 
            // lb_tf1
            // 
            this.lb_tf1.AutoSize = true;
            this.lb_tf1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tf1.Location = new System.Drawing.Point(33, 203);
            this.lb_tf1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_tf1.Name = "lb_tf1";
            this.lb_tf1.Size = new System.Drawing.Size(54, 18);
            this.lb_tf1.TabIndex = 14;
            this.lb_tf1.Text = "Tfno. 1";
            // 
            // lb_tf2
            // 
            this.lb_tf2.AutoSize = true;
            this.lb_tf2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_tf2.Location = new System.Drawing.Point(371, 200);
            this.lb_tf2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_tf2.Name = "lb_tf2";
            this.lb_tf2.Size = new System.Drawing.Size(54, 18);
            this.lb_tf2.TabIndex = 15;
            this.lb_tf2.Text = "Tfno. 2";
            // 
            // lb_cp
            // 
            this.lb_cp.AutoSize = true;
            this.lb_cp.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_cp.Location = new System.Drawing.Point(22, 295);
            this.lb_cp.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_cp.Name = "lb_cp";
            this.lb_cp.Size = new System.Drawing.Size(65, 18);
            this.lb_cp.TabIndex = 18;
            this.lb_cp.Text = "C.Postal";
            // 
            // tb_documento
            // 
            this.tb_documento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_documento.Location = new System.Drawing.Point(340, 63);
            this.tb_documento.Margin = new System.Windows.Forms.Padding(4);
            this.tb_documento.Name = "tb_documento";
            this.tb_documento.Size = new System.Drawing.Size(200, 24);
            this.tb_documento.TabIndex = 6;
            this.tb_documento.Enter += new System.EventHandler(this.tb_documento_Enter);
            this.tb_documento.Validating += new System.ComponentModel.CancelEventHandler(this.tb_documento_Validating);
            this.tb_documento.Validated += new System.EventHandler(this.tb_documento_Validated);
            // 
            // tb_letra
            // 
            this.tb_letra.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_letra.Location = new System.Drawing.Point(595, 62);
            this.tb_letra.Margin = new System.Windows.Forms.Padding(4);
            this.tb_letra.MaxLength = 1;
            this.tb_letra.Name = "tb_letra";
            this.tb_letra.Size = new System.Drawing.Size(25, 24);
            this.tb_letra.TabIndex = 8;
            // 
            // lb_letra
            // 
            this.lb_letra.AutoSize = true;
            this.lb_letra.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_letra.Location = new System.Drawing.Point(546, 65);
            this.lb_letra.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_letra.Name = "lb_letra";
            this.lb_letra.Size = new System.Drawing.Size(41, 18);
            this.lb_letra.TabIndex = 6;
            this.lb_letra.Text = "Letra";
            // 
            // lb_docu
            // 
            this.lb_docu.AutoSize = true;
            this.lb_docu.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_docu.Location = new System.Drawing.Point(246, 65);
            this.lb_docu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_docu.Name = "lb_docu";
            this.lb_docu.Size = new System.Drawing.Size(86, 18);
            this.lb_docu.TabIndex = 7;
            this.lb_docu.Text = "Documento";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox1);
            this.groupBox3.Controls.Add(this.lb_id_cte);
            this.groupBox3.Controls.Add(this.tb_id_cte);
            this.groupBox3.Location = new System.Drawing.Point(8, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(642, 72);
            this.groupBox3.TabIndex = 31;
            this.groupBox3.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.LightBlue;
            this.groupBox1.Controls.Add(this.rb_colabora);
            this.groupBox1.Controls.Add(this.rb_titular);
            this.groupBox1.Controls.Add(this.rb_cte);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(99, 19);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(245, 42);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tipo";
            // 
            // rb_colabora
            // 
            this.rb_colabora.AutoSize = true;
            this.rb_colabora.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_colabora.Location = new System.Drawing.Point(147, 18);
            this.rb_colabora.Margin = new System.Windows.Forms.Padding(4);
            this.rb_colabora.Name = "rb_colabora";
            this.rb_colabora.Size = new System.Drawing.Size(93, 19);
            this.rb_colabora.TabIndex = 26;
            this.rb_colabora.Text = "Colaborador";
            this.rb_colabora.UseVisualStyleBackColor = true;
            // 
            // rb_titular
            // 
            this.rb_titular.AutoSize = true;
            this.rb_titular.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_titular.Location = new System.Drawing.Point(80, 18);
            this.rb_titular.Margin = new System.Windows.Forms.Padding(4);
            this.rb_titular.Name = "rb_titular";
            this.rb_titular.Size = new System.Drawing.Size(59, 19);
            this.rb_titular.TabIndex = 25;
            this.rb_titular.Text = "Titular";
            this.rb_titular.UseVisualStyleBackColor = true;
            // 
            // rb_cte
            // 
            this.rb_cte.AutoSize = true;
            this.rb_cte.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_cte.Location = new System.Drawing.Point(9, 18);
            this.rb_cte.Margin = new System.Windows.Forms.Padding(4);
            this.rb_cte.Name = "rb_cte";
            this.rb_cte.Size = new System.Drawing.Size(63, 19);
            this.rb_cte.TabIndex = 24;
            this.rb_cte.Text = "Cliente";
            this.rb_cte.UseVisualStyleBackColor = true;
            // 
            // lb_id_cte
            // 
            this.lb_id_cte.AutoSize = true;
            this.lb_id_cte.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_id_cte.Location = new System.Drawing.Point(412, 16);
            this.lb_id_cte.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_id_cte.Name = "lb_id_cte";
            this.lb_id_cte.Size = new System.Drawing.Size(56, 18);
            this.lb_id_cte.TabIndex = 0;
            this.lb_id_cte.Text = "Código";
            // 
            // tb_id_cte
            // 
            this.tb_id_cte.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_id_cte.Location = new System.Drawing.Point(374, 38);
            this.tb_id_cte.Margin = new System.Windows.Forms.Padding(4);
            this.tb_id_cte.Name = "tb_id_cte";
            this.tb_id_cte.Size = new System.Drawing.Size(132, 24);
            this.tb_id_cte.TabIndex = 2;
            // 
            // lb_titulo
            // 
            this.lb_titulo.AutoSize = true;
            this.lb_titulo.BackColor = System.Drawing.Color.LightBlue;
            this.lb_titulo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_titulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_titulo.ForeColor = System.Drawing.Color.Black;
            this.lb_titulo.Location = new System.Drawing.Point(284, 2);
            this.lb_titulo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_titulo.Name = "lb_titulo";
            this.lb_titulo.Size = new System.Drawing.Size(131, 35);
            this.lb_titulo.TabIndex = 1;
            this.lb_titulo.Text = "Clientes";
            // 
            // btt_first
            // 
            this.btt_first.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_first.Location = new System.Drawing.Point(16, 525);
            this.btt_first.Margin = new System.Windows.Forms.Padding(4);
            this.btt_first.Name = "btt_first";
            this.btt_first.Size = new System.Drawing.Size(54, 34);
            this.btt_first.TabIndex = 2;
            this.btt_first.Text = "|<";
            this.btt_first.UseVisualStyleBackColor = true;
            this.btt_first.Click += new System.EventHandler(this.btt_first_Click);
            // 
            // btt_back
            // 
            this.btt_back.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_back.Location = new System.Drawing.Point(73, 525);
            this.btt_back.Margin = new System.Windows.Forms.Padding(4);
            this.btt_back.Name = "btt_back";
            this.btt_back.Size = new System.Drawing.Size(54, 34);
            this.btt_back.TabIndex = 3;
            this.btt_back.Text = "<<";
            this.btt_back.UseVisualStyleBackColor = true;
            this.btt_back.Click += new System.EventHandler(this.btt_back_Click);
            // 
            // btt_next
            // 
            this.btt_next.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_next.Location = new System.Drawing.Point(231, 525);
            this.btt_next.Margin = new System.Windows.Forms.Padding(4);
            this.btt_next.Name = "btt_next";
            this.btt_next.Size = new System.Drawing.Size(54, 34);
            this.btt_next.TabIndex = 4;
            this.btt_next.Text = ">>";
            this.btt_next.UseVisualStyleBackColor = true;
            this.btt_next.Click += new System.EventHandler(this.btt_next_Click);
            // 
            // btt_last
            // 
            this.btt_last.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_last.Location = new System.Drawing.Point(289, 525);
            this.btt_last.Margin = new System.Windows.Forms.Padding(4);
            this.btt_last.Name = "btt_last";
            this.btt_last.Size = new System.Drawing.Size(54, 34);
            this.btt_last.TabIndex = 5;
            this.btt_last.Text = ">|";
            this.btt_last.UseVisualStyleBackColor = true;
            this.btt_last.Click += new System.EventHandler(this.btt_last_Click);
            // 
            // btt_buscar
            // 
            this.btt_buscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_buscar.Location = new System.Drawing.Point(461, 525);
            this.btt_buscar.Margin = new System.Windows.Forms.Padding(4);
            this.btt_buscar.Name = "btt_buscar";
            this.btt_buscar.Size = new System.Drawing.Size(99, 34);
            this.btt_buscar.TabIndex = 6;
            this.btt_buscar.Text = "Buscar";
            this.btt_buscar.UseVisualStyleBackColor = true;
            this.btt_buscar.Click += new System.EventHandler(this.btt_buscar_Click);
            // 
            // btt_consultar
            // 
            this.btt_consultar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_consultar.Location = new System.Drawing.Point(584, 525);
            this.btt_consultar.Margin = new System.Windows.Forms.Padding(4);
            this.btt_consultar.Name = "btt_consultar";
            this.btt_consultar.Size = new System.Drawing.Size(99, 34);
            this.btt_consultar.TabIndex = 7;
            this.btt_consultar.Text = "Consultar";
            this.btt_consultar.UseVisualStyleBackColor = true;
            this.btt_consultar.Click += new System.EventHandler(this.btt_consultar_Click);
            // 
            // btt_nuevo
            // 
            this.btt_nuevo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_nuevo.Location = new System.Drawing.Point(684, 66);
            this.btt_nuevo.Margin = new System.Windows.Forms.Padding(4);
            this.btt_nuevo.Name = "btt_nuevo";
            this.btt_nuevo.Size = new System.Drawing.Size(99, 34);
            this.btt_nuevo.TabIndex = 8;
            this.btt_nuevo.Text = "Nuevo";
            this.btt_nuevo.UseVisualStyleBackColor = true;
            this.btt_nuevo.Click += new System.EventHandler(this.btt_nuevo_Click);
            // 
            // btt_guardar
            // 
            this.btt_guardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_guardar.Location = new System.Drawing.Point(684, 129);
            this.btt_guardar.Margin = new System.Windows.Forms.Padding(4);
            this.btt_guardar.Name = "btt_guardar";
            this.btt_guardar.Size = new System.Drawing.Size(99, 34);
            this.btt_guardar.TabIndex = 9;
            this.btt_guardar.Text = "Guardar";
            this.btt_guardar.UseVisualStyleBackColor = true;
            this.btt_guardar.Click += new System.EventHandler(this.btt_guardar_Click);
            // 
            // btt_modificar
            // 
            this.btt_modificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_modificar.Location = new System.Drawing.Point(684, 201);
            this.btt_modificar.Margin = new System.Windows.Forms.Padding(4);
            this.btt_modificar.Name = "btt_modificar";
            this.btt_modificar.Size = new System.Drawing.Size(99, 34);
            this.btt_modificar.TabIndex = 10;
            this.btt_modificar.Text = "Modificar";
            this.btt_modificar.UseVisualStyleBackColor = true;
            this.btt_modificar.Click += new System.EventHandler(this.btt_modificar_Click_1);
            // 
            // btt_borrar
            // 
            this.btt_borrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_borrar.Location = new System.Drawing.Point(684, 415);
            this.btt_borrar.Margin = new System.Windows.Forms.Padding(4);
            this.btt_borrar.Name = "btt_borrar";
            this.btt_borrar.Size = new System.Drawing.Size(99, 34);
            this.btt_borrar.TabIndex = 11;
            this.btt_borrar.Text = "Borrar";
            this.btt_borrar.UseVisualStyleBackColor = true;
            this.btt_borrar.Click += new System.EventHandler(this.btt_borrar_Click);
            // 
            // btt_cancelar
            // 
            this.btt_cancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_cancelar.Location = new System.Drawing.Point(684, 478);
            this.btt_cancelar.Margin = new System.Windows.Forms.Padding(4);
            this.btt_cancelar.Name = "btt_cancelar";
            this.btt_cancelar.Size = new System.Drawing.Size(99, 34);
            this.btt_cancelar.TabIndex = 12;
            this.btt_cancelar.Text = "Cancelar";
            this.btt_cancelar.UseVisualStyleBackColor = true;
            this.btt_cancelar.Click += new System.EventHandler(this.btt_cancelar_Click);
            // 
            // lb_num_rg
            // 
            this.lb_num_rg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_num_rg.Location = new System.Drawing.Point(132, 529);
            this.lb_num_rg.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lb_num_rg.Name = "lb_num_rg";
            this.lb_num_rg.Size = new System.Drawing.Size(94, 30);
            this.lb_num_rg.TabIndex = 13;
            this.lb_num_rg.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // btt_imp_cte
            // 
            this.btt_imp_cte.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_imp_cte.Location = new System.Drawing.Point(684, 315);
            this.btt_imp_cte.Margin = new System.Windows.Forms.Padding(4);
            this.btt_imp_cte.Name = "btt_imp_cte";
            this.btt_imp_cte.Size = new System.Drawing.Size(99, 34);
            this.btt_imp_cte.TabIndex = 14;
            this.btt_imp_cte.Text = "Imprimir";
            this.btt_imp_cte.UseVisualStyleBackColor = true;
            this.btt_imp_cte.Click += new System.EventHandler(this.Btt_imp_cteClick);
            // 
            // MClientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(784, 562);
            this.Controls.Add(this.btt_imp_cte);
            this.Controls.Add(this.lb_num_rg);
            this.Controls.Add(this.btt_cancelar);
            this.Controls.Add(this.btt_borrar);
            this.Controls.Add(this.btt_modificar);
            this.Controls.Add(this.btt_guardar);
            this.Controls.Add(this.btt_nuevo);
            this.Controls.Add(this.btt_consultar);
            this.Controls.Add(this.btt_buscar);
            this.Controls.Add(this.btt_last);
            this.Controls.Add(this.btt_next);
            this.Controls.Add(this.btt_back);
            this.Controls.Add(this.btt_first);
            this.Controls.Add(this.lb_titulo);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(800, 600);
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "MClientes";
            this.Text = "Mantenimiento de Clientes";
            this.Load += new System.EventHandler(this.MClientes_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        private System.Windows.Forms.Button btt_imp_cte;
        private System.Windows.Forms.Label lb_num_rg;

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox tb_provin;
        private System.Windows.Forms.Label lb_provin;
        private System.Windows.Forms.TextBox tb_ciudad;
        private System.Windows.Forms.Label lb_ciudad;
        private System.Windows.Forms.TextBox tb_cp;
        private System.Windows.Forms.Label lb_cp;
        private System.Windows.Forms.TextBox tb_tf2;
        private System.Windows.Forms.TextBox tb_tf1;
        private System.Windows.Forms.Label lb_tf2;
        private System.Windows.Forms.Label lb_tf1;
        private System.Windows.Forms.TextBox tb_email;
        private System.Windows.Forms.Label lb_email;
        private System.Windows.Forms.TextBox tb_p_cont;
        private System.Windows.Forms.Label lb_p_cont;
        private System.Windows.Forms.TextBox tb_letra;
        private System.Windows.Forms.TextBox tb_documento;
        private System.Windows.Forms.Label lb_docu;
        private System.Windows.Forms.Label lb_letra;
        private System.Windows.Forms.Label lb_t_docu;
        private System.Windows.Forms.ComboBox cb_t_docu;
        private System.Windows.Forms.TextBox tb_nombre;
        private System.Windows.Forms.TextBox tb_id_cte;
        private System.Windows.Forms.Label lb_nombre;
        private System.Windows.Forms.Label lb_id_cte;
        private System.Windows.Forms.Label lb_titulo;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rb_titular;
        private System.Windows.Forms.RadioButton rb_cte;
        private System.Windows.Forms.Button btt_first;
        private System.Windows.Forms.Button btt_back;
        private System.Windows.Forms.Button btt_next;
        private System.Windows.Forms.Button btt_last;
        private System.Windows.Forms.Button btt_buscar;
        private System.Windows.Forms.Button btt_consultar;
        private System.Windows.Forms.Button btt_nuevo;
        private System.Windows.Forms.Button btt_guardar;
        private System.Windows.Forms.Button btt_modificar;
        private System.Windows.Forms.Button btt_borrar;
        private System.Windows.Forms.Button btt_cancelar;
        private System.Windows.Forms.TextBox tb_direccion;
        private System.Windows.Forms.Label lb_direccion;
        private System.Windows.Forms.RadioButton rb_colabora;
        private System.Windows.Forms.TextBox tb_cta;
        private System.Windows.Forms.Label lb_cta;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
    }
}
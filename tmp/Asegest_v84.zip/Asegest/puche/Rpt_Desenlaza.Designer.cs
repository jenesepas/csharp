﻿namespace Asegest
{
    partial class Rpt_Desenlaza
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Rpt_Desenlaza));
            this.btt_cancelar_lfra = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dtp_h_ffra = new System.Windows.Forms.DateTimePicker();
            this.dtp_d_ffra = new System.Windows.Forms.DateTimePicker();
            this.lb_h_ffra = new System.Windows.Forms.Label();
            this.lb_d_ffra = new System.Windows.Forms.Label();
            this.btt_buscar2_lrg = new System.Windows.Forms.Button();
            this.btt_buscar_lrg = new System.Windows.Forms.Button();
            this.tb_h_cte = new System.Windows.Forms.TextBox();
            this.lb_h_cte = new System.Windows.Forms.Label();
            this.tb_d_cte = new System.Windows.Forms.TextBox();
            this.lb_d_cte = new System.Windows.Forms.Label();
            this.tb_h_fra = new System.Windows.Forms.TextBox();
            this.lb_h_fra = new System.Windows.Forms.Label();
            this.tb_d_fra = new System.Windows.Forms.TextBox();
            this.lb_d_fra = new System.Windows.Forms.Label();
            this.gb_b_t_cte_lrg = new System.Windows.Forms.GroupBox();
            this.rb_colab_lrg = new System.Windows.Forms.RadioButton();
            this.rb_titular_lrg = new System.Windows.Forms.RadioButton();
            this.rb_cte_lrg = new System.Windows.Forms.RadioButton();
            this.gb_del_lrg = new System.Windows.Forms.GroupBox();
            this.rb_a_lrg = new System.Windows.Forms.RadioButton();
            this.rb_m_lrg = new System.Windows.Forms.RadioButton();
            this.rb_y_lrg = new System.Windows.Forms.RadioButton();
            this.btt_act_lfra = new System.Windows.Forms.Button();
            this.cb_accion = new System.Windows.Forms.ComboBox();
            this.lb_accion = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.gb_b_t_cte_lrg.SuspendLayout();
            this.gb_del_lrg.SuspendLayout();
            this.SuspendLayout();
            // 
            // btt_cancelar_lfra
            // 
            this.btt_cancelar_lfra.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_cancelar_lfra.Location = new System.Drawing.Point(356, 211);
            this.btt_cancelar_lfra.Name = "btt_cancelar_lfra";
            this.btt_cancelar_lfra.Size = new System.Drawing.Size(89, 34);
            this.btt_cancelar_lfra.TabIndex = 64;
            this.btt_cancelar_lfra.Text = "Cancelar";
            this.btt_cancelar_lfra.UseVisualStyleBackColor = true;
            this.btt_cancelar_lfra.Click += new System.EventHandler(this.btt_cancelar_lfra_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lb_accion);
            this.panel1.Controls.Add(this.cb_accion);
            this.panel1.Controls.Add(this.dtp_h_ffra);
            this.panel1.Controls.Add(this.dtp_d_ffra);
            this.panel1.Controls.Add(this.lb_h_ffra);
            this.panel1.Controls.Add(this.lb_d_ffra);
            this.panel1.Controls.Add(this.btt_buscar2_lrg);
            this.panel1.Controls.Add(this.btt_buscar_lrg);
            this.panel1.Controls.Add(this.tb_h_cte);
            this.panel1.Controls.Add(this.lb_h_cte);
            this.panel1.Controls.Add(this.tb_d_cte);
            this.panel1.Controls.Add(this.lb_d_cte);
            this.panel1.Controls.Add(this.tb_h_fra);
            this.panel1.Controls.Add(this.lb_h_fra);
            this.panel1.Controls.Add(this.tb_d_fra);
            this.panel1.Controls.Add(this.lb_d_fra);
            this.panel1.Controls.Add(this.gb_b_t_cte_lrg);
            this.panel1.Controls.Add(this.gb_del_lrg);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(442, 193);
            this.panel1.TabIndex = 62;
            // 
            // dtp_h_ffra
            // 
            this.dtp_h_ffra.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_h_ffra.Location = new System.Drawing.Point(312, 89);
            this.dtp_h_ffra.Name = "dtp_h_ffra";
            this.dtp_h_ffra.Size = new System.Drawing.Size(90, 20);
            this.dtp_h_ffra.TabIndex = 59;
            // 
            // dtp_d_ffra
            // 
            this.dtp_d_ffra.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_d_ffra.Location = new System.Drawing.Point(312, 62);
            this.dtp_d_ffra.Name = "dtp_d_ffra";
            this.dtp_d_ffra.Size = new System.Drawing.Size(90, 20);
            this.dtp_d_ffra.TabIndex = 58;
            // 
            // lb_h_ffra
            // 
            this.lb_h_ffra.AutoSize = true;
            this.lb_h_ffra.Location = new System.Drawing.Point(234, 89);
            this.lb_h_ffra.Name = "lb_h_ffra";
            this.lb_h_ffra.Size = new System.Drawing.Size(63, 13);
            this.lb_h_ffra.TabIndex = 57;
            this.lb_h_ffra.Text = "H. Fec. Fra.";
            // 
            // lb_d_ffra
            // 
            this.lb_d_ffra.AutoSize = true;
            this.lb_d_ffra.Location = new System.Drawing.Point(234, 62);
            this.lb_d_ffra.Name = "lb_d_ffra";
            this.lb_d_ffra.Size = new System.Drawing.Size(63, 13);
            this.lb_d_ffra.TabIndex = 56;
            this.lb_d_ffra.Text = "D. Fec. Fra.";
            // 
            // btt_buscar2_lrg
            // 
            this.btt_buscar2_lrg.Location = new System.Drawing.Point(370, 144);
            this.btt_buscar2_lrg.Name = "btt_buscar2_lrg";
            this.btt_buscar2_lrg.Size = new System.Drawing.Size(50, 23);
            this.btt_buscar2_lrg.TabIndex = 55;
            this.btt_buscar2_lrg.Text = "Buscar";
            this.btt_buscar2_lrg.UseVisualStyleBackColor = true;
            this.btt_buscar2_lrg.Click += new System.EventHandler(this.btt_buscar2_lrg_Click_1);
            // 
            // btt_buscar_lrg
            // 
            this.btt_buscar_lrg.Location = new System.Drawing.Point(370, 116);
            this.btt_buscar_lrg.Name = "btt_buscar_lrg";
            this.btt_buscar_lrg.Size = new System.Drawing.Size(50, 23);
            this.btt_buscar_lrg.TabIndex = 54;
            this.btt_buscar_lrg.Text = "Buscar";
            this.btt_buscar_lrg.UseVisualStyleBackColor = true;
            this.btt_buscar_lrg.Click += new System.EventHandler(this.btt_buscar_lrg_Click_1);
            // 
            // tb_h_cte
            // 
            this.tb_h_cte.Location = new System.Drawing.Point(285, 144);
            this.tb_h_cte.Name = "tb_h_cte";
            this.tb_h_cte.Size = new System.Drawing.Size(79, 20);
            this.tb_h_cte.TabIndex = 53;
            // 
            // lb_h_cte
            // 
            this.lb_h_cte.AutoSize = true;
            this.lb_h_cte.Location = new System.Drawing.Point(234, 144);
            this.lb_h_cte.Name = "lb_h_cte";
            this.lb_h_cte.Size = new System.Drawing.Size(40, 13);
            this.lb_h_cte.TabIndex = 52;
            this.lb_h_cte.Text = "H. Cte.";
            // 
            // tb_d_cte
            // 
            this.tb_d_cte.Location = new System.Drawing.Point(285, 118);
            this.tb_d_cte.Name = "tb_d_cte";
            this.tb_d_cte.Size = new System.Drawing.Size(79, 20);
            this.tb_d_cte.TabIndex = 51;
            // 
            // lb_d_cte
            // 
            this.lb_d_cte.AutoSize = true;
            this.lb_d_cte.Location = new System.Drawing.Point(234, 118);
            this.lb_d_cte.Name = "lb_d_cte";
            this.lb_d_cte.Size = new System.Drawing.Size(40, 13);
            this.lb_d_cte.TabIndex = 50;
            this.lb_d_cte.Text = "D. Cte.";
            // 
            // tb_h_fra
            // 
            this.tb_h_fra.Location = new System.Drawing.Point(312, 36);
            this.tb_h_fra.Name = "tb_h_fra";
            this.tb_h_fra.Size = new System.Drawing.Size(90, 20);
            this.tb_h_fra.TabIndex = 49;
            // 
            // lb_h_fra
            // 
            this.lb_h_fra.AutoSize = true;
            this.lb_h_fra.Location = new System.Drawing.Point(234, 36);
            this.lb_h_fra.Name = "lb_h_fra";
            this.lb_h_fra.Size = new System.Drawing.Size(67, 13);
            this.lb_h_fra.TabIndex = 48;
            this.lb_h_fra.Text = "H. Num. Fra.";
            // 
            // tb_d_fra
            // 
            this.tb_d_fra.Location = new System.Drawing.Point(312, 9);
            this.tb_d_fra.Name = "tb_d_fra";
            this.tb_d_fra.Size = new System.Drawing.Size(90, 20);
            this.tb_d_fra.TabIndex = 47;
            // 
            // lb_d_fra
            // 
            this.lb_d_fra.AutoSize = true;
            this.lb_d_fra.Location = new System.Drawing.Point(234, 9);
            this.lb_d_fra.Name = "lb_d_fra";
            this.lb_d_fra.Size = new System.Drawing.Size(67, 13);
            this.lb_d_fra.TabIndex = 46;
            this.lb_d_fra.Text = "D. Num. Fra.";
            // 
            // gb_b_t_cte_lrg
            // 
            this.gb_b_t_cte_lrg.BackColor = System.Drawing.Color.LightBlue;
            this.gb_b_t_cte_lrg.Controls.Add(this.rb_colab_lrg);
            this.gb_b_t_cte_lrg.Controls.Add(this.rb_titular_lrg);
            this.gb_b_t_cte_lrg.Controls.Add(this.rb_cte_lrg);
            this.gb_b_t_cte_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_b_t_cte_lrg.Location = new System.Drawing.Point(9, 62);
            this.gb_b_t_cte_lrg.Name = "gb_b_t_cte_lrg";
            this.gb_b_t_cte_lrg.Size = new System.Drawing.Size(219, 47);
            this.gb_b_t_cte_lrg.TabIndex = 40;
            this.gb_b_t_cte_lrg.TabStop = false;
            this.gb_b_t_cte_lrg.Text = "Tipo";
            // 
            // rb_colab_lrg
            // 
            this.rb_colab_lrg.AutoSize = true;
            this.rb_colab_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_colab_lrg.Location = new System.Drawing.Point(143, 20);
            this.rb_colab_lrg.Name = "rb_colab_lrg";
            this.rb_colab_lrg.Size = new System.Drawing.Size(71, 20);
            this.rb_colab_lrg.TabIndex = 26;
            this.rb_colab_lrg.Text = "Colab.";
            this.rb_colab_lrg.UseVisualStyleBackColor = true;
            // 
            // rb_titular_lrg
            // 
            this.rb_titular_lrg.AutoSize = true;
            this.rb_titular_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_titular_lrg.Location = new System.Drawing.Point(76, 20);
            this.rb_titular_lrg.Name = "rb_titular_lrg";
            this.rb_titular_lrg.Size = new System.Drawing.Size(70, 20);
            this.rb_titular_lrg.TabIndex = 25;
            this.rb_titular_lrg.Text = "Titular";
            this.rb_titular_lrg.UseVisualStyleBackColor = true;
            // 
            // rb_cte_lrg
            // 
            this.rb_cte_lrg.AutoSize = true;
            this.rb_cte_lrg.Checked = true;
            this.rb_cte_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_cte_lrg.Location = new System.Drawing.Point(6, 20);
            this.rb_cte_lrg.Name = "rb_cte_lrg";
            this.rb_cte_lrg.Size = new System.Drawing.Size(74, 20);
            this.rb_cte_lrg.TabIndex = 24;
            this.rb_cte_lrg.TabStop = true;
            this.rb_cte_lrg.Text = "Cliente";
            this.rb_cte_lrg.UseVisualStyleBackColor = true;
            // 
            // gb_del_lrg
            // 
            this.gb_del_lrg.BackColor = System.Drawing.Color.LightBlue;
            this.gb_del_lrg.Controls.Add(this.rb_a_lrg);
            this.gb_del_lrg.Controls.Add(this.rb_m_lrg);
            this.gb_del_lrg.Controls.Add(this.rb_y_lrg);
            this.gb_del_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_del_lrg.Location = new System.Drawing.Point(9, 9);
            this.gb_del_lrg.Name = "gb_del_lrg";
            this.gb_del_lrg.Size = new System.Drawing.Size(219, 47);
            this.gb_del_lrg.TabIndex = 39;
            this.gb_del_lrg.TabStop = false;
            this.gb_del_lrg.Text = "Delegacion";
            // 
            // rb_a_lrg
            // 
            this.rb_a_lrg.AutoSize = true;
            this.rb_a_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_a_lrg.Location = new System.Drawing.Point(134, 20);
            this.rb_a_lrg.Name = "rb_a_lrg";
            this.rb_a_lrg.Size = new System.Drawing.Size(80, 19);
            this.rb_a_lrg.TabIndex = 26;
            this.rb_a_lrg.Text = "Albacete";
            this.rb_a_lrg.UseVisualStyleBackColor = true;
            // 
            // rb_m_lrg
            // 
            this.rb_m_lrg.AutoSize = true;
            this.rb_m_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_m_lrg.Location = new System.Drawing.Point(65, 20);
            this.rb_m_lrg.Name = "rb_m_lrg";
            this.rb_m_lrg.Size = new System.Drawing.Size(69, 19);
            this.rb_m_lrg.TabIndex = 25;
            this.rb_m_lrg.Text = "Murcia";
            this.rb_m_lrg.UseVisualStyleBackColor = true;
            // 
            // rb_y_lrg
            // 
            this.rb_y_lrg.AutoSize = true;
            this.rb_y_lrg.Checked = true;
            this.rb_y_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_y_lrg.Location = new System.Drawing.Point(6, 20);
            this.rb_y_lrg.Name = "rb_y_lrg";
            this.rb_y_lrg.Size = new System.Drawing.Size(60, 19);
            this.rb_y_lrg.TabIndex = 24;
            this.rb_y_lrg.TabStop = true;
            this.rb_y_lrg.Text = "Yecla";
            this.rb_y_lrg.UseVisualStyleBackColor = true;
            // 
            // btt_act_lfra
            // 
            this.btt_act_lfra.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_act_lfra.Location = new System.Drawing.Point(22, 211);
            this.btt_act_lfra.Name = "btt_act_lfra";
            this.btt_act_lfra.Size = new System.Drawing.Size(93, 34);
            this.btt_act_lfra.TabIndex = 63;
            this.btt_act_lfra.Text = "Actualizar";
            this.btt_act_lfra.UseVisualStyleBackColor = true;
            this.btt_act_lfra.Click += new System.EventHandler(this.btt_act_lfra_Click);
            // 
            // cb_accion
            // 
            this.cb_accion.FormattingEnabled = true;
            this.cb_accion.Items.AddRange(new object[] {
            "FRAS. SIN LISTAR",
            "FRAS. LISTADAS",
            "FRAS. ENLAZADAS"});
            this.cb_accion.Location = new System.Drawing.Point(35, 136);
            this.cb_accion.Name = "cb_accion";
            this.cb_accion.Size = new System.Drawing.Size(121, 21);
            this.cb_accion.TabIndex = 65;
            // 
            // lb_accion
            // 
            this.lb_accion.AutoSize = true;
            this.lb_accion.Location = new System.Drawing.Point(45, 120);
            this.lb_accion.Name = "lb_accion";
            this.lb_accion.Size = new System.Drawing.Size(100, 13);
            this.lb_accion.TabIndex = 66;
            this.lb_accion.Text = "Dejar en estado de:";
            // 
            // Rpt_Desenlaza
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 252);
            this.Controls.Add(this.btt_cancelar_lfra);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btt_act_lfra);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Rpt_Desenlaza";
            this.Text = "Rpt_Desenlaza";
            this.Load += new System.EventHandler(this.Rpt_Desenlaza_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gb_b_t_cte_lrg.ResumeLayout(false);
            this.gb_b_t_cte_lrg.PerformLayout();
            this.gb_del_lrg.ResumeLayout(false);
            this.gb_del_lrg.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btt_cancelar_lfra;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DateTimePicker dtp_h_ffra;
        private System.Windows.Forms.DateTimePicker dtp_d_ffra;
        private System.Windows.Forms.Label lb_h_ffra;
        private System.Windows.Forms.Label lb_d_ffra;
        private System.Windows.Forms.Button btt_buscar2_lrg;
        private System.Windows.Forms.Button btt_buscar_lrg;
        private System.Windows.Forms.TextBox tb_h_cte;
        private System.Windows.Forms.Label lb_h_cte;
        private System.Windows.Forms.TextBox tb_d_cte;
        private System.Windows.Forms.Label lb_d_cte;
        private System.Windows.Forms.TextBox tb_h_fra;
        private System.Windows.Forms.Label lb_h_fra;
        private System.Windows.Forms.TextBox tb_d_fra;
        private System.Windows.Forms.Label lb_d_fra;
        private System.Windows.Forms.GroupBox gb_b_t_cte_lrg;
        private System.Windows.Forms.RadioButton rb_colab_lrg;
        private System.Windows.Forms.RadioButton rb_titular_lrg;
        private System.Windows.Forms.RadioButton rb_cte_lrg;
        private System.Windows.Forms.GroupBox gb_del_lrg;
        private System.Windows.Forms.RadioButton rb_a_lrg;
        private System.Windows.Forms.RadioButton rb_m_lrg;
        private System.Windows.Forms.RadioButton rb_y_lrg;
        private System.Windows.Forms.Button btt_act_lfra;
        private System.Windows.Forms.Label lb_accion;
        private System.Windows.Forms.ComboBox cb_accion;
    }
}
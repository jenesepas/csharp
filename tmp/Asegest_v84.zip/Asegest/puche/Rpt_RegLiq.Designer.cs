﻿namespace Asegest
{
    partial class Rpt_RegLiq
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btt_cancelar_lrg = new System.Windows.Forms.Button();
            this.btt_imp_lrg = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tb_titulo = new System.Windows.Forms.TextBox();
            this.lb_titulo = new System.Windows.Forms.Label();
            this.gb_del_lrg = new System.Windows.Forms.GroupBox();
            this.rb_a_lrg = new System.Windows.Forms.RadioButton();
            this.rb_m_lrg = new System.Windows.Forms.RadioButton();
            this.rb_y_lrg = new System.Windows.Forms.RadioButton();
            this.dtp_h_freg = new System.Windows.Forms.DateTimePicker();
            this.dtp_d_freg = new System.Windows.Forms.DateTimePicker();
            this.lb_h_freg = new System.Windows.Forms.Label();
            this.lb_d_freg = new System.Windows.Forms.Label();
            this.cb_liq = new System.Windows.Forms.CheckBox();
            this.panel1.SuspendLayout();
            this.gb_del_lrg.SuspendLayout();
            this.SuspendLayout();
            // 
            // btt_cancelar_lrg
            // 
            this.btt_cancelar_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_cancelar_lrg.Location = new System.Drawing.Point(386, 185);
            this.btt_cancelar_lrg.Name = "btt_cancelar_lrg";
            this.btt_cancelar_lrg.Size = new System.Drawing.Size(89, 34);
            this.btt_cancelar_lrg.TabIndex = 48;
            this.btt_cancelar_lrg.Text = "Cancelar";
            this.btt_cancelar_lrg.UseVisualStyleBackColor = true;
            this.btt_cancelar_lrg.Click += new System.EventHandler(this.btt_cancelar_lrg_Click);
            // 
            // btt_imp_lrg
            // 
            this.btt_imp_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_imp_lrg.Location = new System.Drawing.Point(12, 185);
            this.btt_imp_lrg.Name = "btt_imp_lrg";
            this.btt_imp_lrg.Size = new System.Drawing.Size(89, 34);
            this.btt_imp_lrg.TabIndex = 47;
            this.btt_imp_lrg.Text = "Imprimir";
            this.btt_imp_lrg.UseVisualStyleBackColor = true;
            this.btt_imp_lrg.Click += new System.EventHandler(this.btt_imp_lrg_Click_1);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cb_liq);
            this.panel1.Controls.Add(this.tb_titulo);
            this.panel1.Controls.Add(this.lb_titulo);
            this.panel1.Controls.Add(this.gb_del_lrg);
            this.panel1.Controls.Add(this.dtp_h_freg);
            this.panel1.Controls.Add(this.dtp_d_freg);
            this.panel1.Controls.Add(this.lb_h_freg);
            this.panel1.Controls.Add(this.lb_d_freg);
            this.panel1.Location = new System.Drawing.Point(12, 10);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(463, 169);
            this.panel1.TabIndex = 49;
            // 
            // tb_titulo
            // 
            this.tb_titulo.Location = new System.Drawing.Point(21, 97);
            this.tb_titulo.Name = "tb_titulo";
            this.tb_titulo.Size = new System.Drawing.Size(420, 20);
            this.tb_titulo.TabIndex = 65;
            // 
            // lb_titulo
            // 
            this.lb_titulo.AutoSize = true;
            this.lb_titulo.Location = new System.Drawing.Point(18, 81);
            this.lb_titulo.Name = "lb_titulo";
            this.lb_titulo.Size = new System.Drawing.Size(38, 13);
            this.lb_titulo.TabIndex = 64;
            this.lb_titulo.Text = "Título:";
            // 
            // gb_del_lrg
            // 
            this.gb_del_lrg.BackColor = System.Drawing.Color.LightBlue;
            this.gb_del_lrg.Controls.Add(this.rb_a_lrg);
            this.gb_del_lrg.Controls.Add(this.rb_m_lrg);
            this.gb_del_lrg.Controls.Add(this.rb_y_lrg);
            this.gb_del_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_del_lrg.Location = new System.Drawing.Point(15, 19);
            this.gb_del_lrg.Name = "gb_del_lrg";
            this.gb_del_lrg.Size = new System.Drawing.Size(219, 47);
            this.gb_del_lrg.TabIndex = 50;
            this.gb_del_lrg.TabStop = false;
            this.gb_del_lrg.Text = "Delegacion";
            // 
            // rb_a_lrg
            // 
            this.rb_a_lrg.AutoSize = true;
            this.rb_a_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_a_lrg.Location = new System.Drawing.Point(134, 20);
            this.rb_a_lrg.Name = "rb_a_lrg";
            this.rb_a_lrg.Size = new System.Drawing.Size(80, 19);
            this.rb_a_lrg.TabIndex = 26;
            this.rb_a_lrg.Text = "Albacete";
            this.rb_a_lrg.UseVisualStyleBackColor = true;
            // 
            // rb_m_lrg
            // 
            this.rb_m_lrg.AutoSize = true;
            this.rb_m_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_m_lrg.Location = new System.Drawing.Point(65, 20);
            this.rb_m_lrg.Name = "rb_m_lrg";
            this.rb_m_lrg.Size = new System.Drawing.Size(69, 19);
            this.rb_m_lrg.TabIndex = 25;
            this.rb_m_lrg.Text = "Murcia";
            this.rb_m_lrg.UseVisualStyleBackColor = true;
            // 
            // rb_y_lrg
            // 
            this.rb_y_lrg.AutoSize = true;
            this.rb_y_lrg.Checked = true;
            this.rb_y_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_y_lrg.Location = new System.Drawing.Point(6, 20);
            this.rb_y_lrg.Name = "rb_y_lrg";
            this.rb_y_lrg.Size = new System.Drawing.Size(60, 19);
            this.rb_y_lrg.TabIndex = 24;
            this.rb_y_lrg.TabStop = true;
            this.rb_y_lrg.Text = "Yecla";
            this.rb_y_lrg.UseVisualStyleBackColor = true;
            // 
            // dtp_h_freg
            // 
            this.dtp_h_freg.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_h_freg.Location = new System.Drawing.Point(351, 46);
            this.dtp_h_freg.Name = "dtp_h_freg";
            this.dtp_h_freg.Size = new System.Drawing.Size(90, 20);
            this.dtp_h_freg.TabIndex = 63;
            // 
            // dtp_d_freg
            // 
            this.dtp_d_freg.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_d_freg.Location = new System.Drawing.Point(351, 20);
            this.dtp_d_freg.Name = "dtp_d_freg";
            this.dtp_d_freg.Size = new System.Drawing.Size(90, 20);
            this.dtp_d_freg.TabIndex = 62;
            // 
            // lb_h_freg
            // 
            this.lb_h_freg.AutoSize = true;
            this.lb_h_freg.Location = new System.Drawing.Point(277, 49);
            this.lb_h_freg.Name = "lb_h_freg";
            this.lb_h_freg.Size = new System.Drawing.Size(68, 13);
            this.lb_h_freg.TabIndex = 61;
            this.lb_h_freg.Text = "H. Fec. Reg.";
            // 
            // lb_d_freg
            // 
            this.lb_d_freg.AutoSize = true;
            this.lb_d_freg.Location = new System.Drawing.Point(277, 23);
            this.lb_d_freg.Name = "lb_d_freg";
            this.lb_d_freg.Size = new System.Drawing.Size(68, 13);
            this.lb_d_freg.TabIndex = 60;
            this.lb_d_freg.Text = "D. Fec. Reg.";
            // 
            // cb_liq
            // 
            this.cb_liq.AutoSize = true;
            this.cb_liq.Location = new System.Drawing.Point(21, 134);
            this.cb_liq.Name = "cb_liq";
            this.cb_liq.Size = new System.Drawing.Size(63, 17);
            this.cb_liq.TabIndex = 67;
            this.cb_liq.Text = "Liquidar";
            this.cb_liq.UseVisualStyleBackColor = true;
            // 
            // Rpt_RegLiq
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(489, 238);
            this.Controls.Add(this.btt_cancelar_lrg);
            this.Controls.Add(this.btt_imp_lrg);
            this.Controls.Add(this.panel1);
            this.Name = "Rpt_RegLiq";
            this.Text = "Reg. Liquidación";
            this.Load += new System.EventHandler(this.Rpt_RegLiq_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gb_del_lrg.ResumeLayout(false);
            this.gb_del_lrg.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btt_cancelar_lrg;
        private System.Windows.Forms.Button btt_imp_lrg;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DateTimePicker dtp_h_freg;
        private System.Windows.Forms.DateTimePicker dtp_d_freg;
        private System.Windows.Forms.Label lb_h_freg;
        private System.Windows.Forms.Label lb_d_freg;
        private System.Windows.Forms.GroupBox gb_del_lrg;
        private System.Windows.Forms.RadioButton rb_a_lrg;
        private System.Windows.Forms.RadioButton rb_m_lrg;
        private System.Windows.Forms.RadioButton rb_y_lrg;
        private System.Windows.Forms.TextBox tb_titulo;
        private System.Windows.Forms.Label lb_titulo;
        private System.Windows.Forms.CheckBox cb_liq;
    }
}
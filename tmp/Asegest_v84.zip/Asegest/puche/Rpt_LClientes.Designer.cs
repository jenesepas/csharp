﻿namespace Asegest
{
    partial class Rpt_Ctes
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Rpt_Ctes));
            this.btt_cancelar_ts = new System.Windows.Forms.Button();
            this.btt_imp_ts = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btt_buscar2_lrg = new System.Windows.Forms.Button();
            this.btt_buscar_lrg = new System.Windows.Forms.Button();
            this.tb_h_cte = new System.Windows.Forms.TextBox();
            this.lb_h_cte = new System.Windows.Forms.Label();
            this.tb_d_cte = new System.Windows.Forms.TextBox();
            this.lb_d_cte = new System.Windows.Forms.Label();
            this.gb_b_t_cte_lrg = new System.Windows.Forms.GroupBox();
            this.rb_colab_lrg = new System.Windows.Forms.RadioButton();
            this.rb_titular_lrg = new System.Windows.Forms.RadioButton();
            this.rb_cte_lrg = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.gb_b_t_cte_lrg.SuspendLayout();
            this.SuspendLayout();
            // 
            // btt_cancelar_ts
            // 
            this.btt_cancelar_ts.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_cancelar_ts.Location = new System.Drawing.Point(191, 147);
            this.btt_cancelar_ts.Name = "btt_cancelar_ts";
            this.btt_cancelar_ts.Size = new System.Drawing.Size(89, 34);
            this.btt_cancelar_ts.TabIndex = 10;
            this.btt_cancelar_ts.Text = "Cancelar";
            this.btt_cancelar_ts.UseVisualStyleBackColor = true;
            this.btt_cancelar_ts.Click += new System.EventHandler(this.btt_cancelar_ts_Click);
            // 
            // btt_imp_ts
            // 
            this.btt_imp_ts.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btt_imp_ts.Location = new System.Drawing.Point(12, 147);
            this.btt_imp_ts.Name = "btt_imp_ts";
            this.btt_imp_ts.Size = new System.Drawing.Size(89, 34);
            this.btt_imp_ts.TabIndex = 9;
            this.btt_imp_ts.Text = "Imprimir";
            this.btt_imp_ts.UseVisualStyleBackColor = true;
            this.btt_imp_ts.Click += new System.EventHandler(this.btt_imp_lrg_Click);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btt_buscar2_lrg);
            this.panel1.Controls.Add(this.btt_buscar_lrg);
            this.panel1.Controls.Add(this.tb_h_cte);
            this.panel1.Controls.Add(this.lb_h_cte);
            this.panel1.Controls.Add(this.tb_d_cte);
            this.panel1.Controls.Add(this.lb_d_cte);
            this.panel1.Controls.Add(this.gb_b_t_cte_lrg);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(268, 129);
            this.panel1.TabIndex = 54;
            // 
            // btt_buscar2_lrg
            // 
            this.btt_buscar2_lrg.Location = new System.Drawing.Point(150, 89);
            this.btt_buscar2_lrg.Name = "btt_buscar2_lrg";
            this.btt_buscar2_lrg.Size = new System.Drawing.Size(50, 23);
            this.btt_buscar2_lrg.TabIndex = 61;
            this.btt_buscar2_lrg.Text = "Buscar";
            this.btt_buscar2_lrg.UseVisualStyleBackColor = true;
            this.btt_buscar2_lrg.Click += new System.EventHandler(this.btt_buscar2_lrg_Click);
            // 
            // btt_buscar_lrg
            // 
            this.btt_buscar_lrg.Location = new System.Drawing.Point(150, 61);
            this.btt_buscar_lrg.Name = "btt_buscar_lrg";
            this.btt_buscar_lrg.Size = new System.Drawing.Size(50, 23);
            this.btt_buscar_lrg.TabIndex = 60;
            this.btt_buscar_lrg.Text = "Buscar";
            this.btt_buscar_lrg.UseVisualStyleBackColor = true;
            this.btt_buscar_lrg.Click += new System.EventHandler(this.btt_buscar_lrg_Click);
            // 
            // tb_h_cte
            // 
            this.tb_h_cte.Location = new System.Drawing.Point(65, 89);
            this.tb_h_cte.Name = "tb_h_cte";
            this.tb_h_cte.Size = new System.Drawing.Size(79, 20);
            this.tb_h_cte.TabIndex = 59;
            // 
            // lb_h_cte
            // 
            this.lb_h_cte.AutoSize = true;
            this.lb_h_cte.Location = new System.Drawing.Point(14, 89);
            this.lb_h_cte.Name = "lb_h_cte";
            this.lb_h_cte.Size = new System.Drawing.Size(40, 13);
            this.lb_h_cte.TabIndex = 58;
            this.lb_h_cte.Text = "H. Cte.";
            // 
            // tb_d_cte
            // 
            this.tb_d_cte.Location = new System.Drawing.Point(65, 63);
            this.tb_d_cte.Name = "tb_d_cte";
            this.tb_d_cte.Size = new System.Drawing.Size(79, 20);
            this.tb_d_cte.TabIndex = 57;
            // 
            // lb_d_cte
            // 
            this.lb_d_cte.AutoSize = true;
            this.lb_d_cte.Location = new System.Drawing.Point(14, 63);
            this.lb_d_cte.Name = "lb_d_cte";
            this.lb_d_cte.Size = new System.Drawing.Size(40, 13);
            this.lb_d_cte.TabIndex = 56;
            this.lb_d_cte.Text = "D. Cte.";
            // 
            // gb_b_t_cte_lrg
            // 
            this.gb_b_t_cte_lrg.BackColor = System.Drawing.Color.LightBlue;
            this.gb_b_t_cte_lrg.Controls.Add(this.rb_colab_lrg);
            this.gb_b_t_cte_lrg.Controls.Add(this.rb_titular_lrg);
            this.gb_b_t_cte_lrg.Controls.Add(this.rb_cte_lrg);
            this.gb_b_t_cte_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_b_t_cte_lrg.Location = new System.Drawing.Point(11, 3);
            this.gb_b_t_cte_lrg.Name = "gb_b_t_cte_lrg";
            this.gb_b_t_cte_lrg.Size = new System.Drawing.Size(219, 47);
            this.gb_b_t_cte_lrg.TabIndex = 55;
            this.gb_b_t_cte_lrg.TabStop = false;
            this.gb_b_t_cte_lrg.Text = "Tipo";
            // 
            // rb_colab_lrg
            // 
            this.rb_colab_lrg.AutoSize = true;
            this.rb_colab_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_colab_lrg.Location = new System.Drawing.Point(143, 20);
            this.rb_colab_lrg.Name = "rb_colab_lrg";
            this.rb_colab_lrg.Size = new System.Drawing.Size(71, 20);
            this.rb_colab_lrg.TabIndex = 26;
            this.rb_colab_lrg.Text = "Colab.";
            this.rb_colab_lrg.UseVisualStyleBackColor = true;
            // 
            // rb_titular_lrg
            // 
            this.rb_titular_lrg.AutoSize = true;
            this.rb_titular_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_titular_lrg.Location = new System.Drawing.Point(76, 20);
            this.rb_titular_lrg.Name = "rb_titular_lrg";
            this.rb_titular_lrg.Size = new System.Drawing.Size(70, 20);
            this.rb_titular_lrg.TabIndex = 25;
            this.rb_titular_lrg.Text = "Titular";
            this.rb_titular_lrg.UseVisualStyleBackColor = true;
            // 
            // rb_cte_lrg
            // 
            this.rb_cte_lrg.AutoSize = true;
            this.rb_cte_lrg.Checked = true;
            this.rb_cte_lrg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_cte_lrg.Location = new System.Drawing.Point(6, 20);
            this.rb_cte_lrg.Name = "rb_cte_lrg";
            this.rb_cte_lrg.Size = new System.Drawing.Size(74, 20);
            this.rb_cte_lrg.TabIndex = 24;
            this.rb_cte_lrg.TabStop = true;
            this.rb_cte_lrg.Text = "Cliente";
            this.rb_cte_lrg.UseVisualStyleBackColor = true;
            // 
            // Rpt_Ctes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(296, 199);
            this.Controls.Add(this.btt_cancelar_ts);
            this.Controls.Add(this.btt_imp_ts);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Rpt_Ctes";
            this.Text = "Listado de Clientes";
            this.Load += new System.EventHandler(this.Rpt_Ctes_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.gb_b_t_cte_lrg.ResumeLayout(false);
            this.gb_b_t_cte_lrg.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btt_cancelar_ts;
        private System.Windows.Forms.Button btt_imp_ts;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox gb_b_t_cte_lrg;
        private System.Windows.Forms.RadioButton rb_colab_lrg;
        private System.Windows.Forms.RadioButton rb_titular_lrg;
        private System.Windows.Forms.RadioButton rb_cte_lrg;
        private System.Windows.Forms.Button btt_buscar2_lrg;
        private System.Windows.Forms.Button btt_buscar_lrg;
        private System.Windows.Forms.TextBox tb_h_cte;
        private System.Windows.Forms.Label lb_h_cte;
        private System.Windows.Forms.TextBox tb_d_cte;
        private System.Windows.Forms.Label lb_d_cte;
    }
}
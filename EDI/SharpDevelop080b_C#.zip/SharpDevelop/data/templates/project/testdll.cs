using System;
using System.Collections;
using System.IO;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Resources;
using System.Windows.Forms;
using System.Xml;

using SharpDevelop.Gui;
using SharpDevelop.Internal.Modules;
using SharpDevelop.Internal.Project;
using SharpDevelop.Internal.Templates;
using SharpDevelop.Tool.Data;
using SharpDevelop.Tool.Function;
using SharpDevelop.Tool.Text;

public class Bla : Form, IWizard
{
	public void StartWizard(Form mainWindow, SharpDevelop.Internal.Templates.IFileCreator creator)
	{
		Owner = mainWindow;
		ShowDialog();
	}
}


// GACBrowser.cs
// Copyright (C) 2001 Torsten Bergmann based on Work by Mattias Sj�grens
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

using System;
using System.IO;
using System.Text;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using SharpDevelop.Gui;
using SharpDevelop.Actions;
using SharpDevelop.Actions.Menu;
using SharpDevelop.Internal.Plugin;
using SharpDevelop.Gui.Edit.Text;
using SharpDevelop.Internal.Text;
using SharpDevelop.Internal.Messages;
using MSjogren.GacTool.FusionNative;

namespace Astares {
	
	/// <summary>
	/// This is a sample menu plugin.
	/// It Removes all trailing white space characters in the current buffer
	/// </summary>
	public class GACBrowser : System.Windows.Forms.Form, ISdPlugin 
	{	

		private ListView list;		

		public GACBrowser() {
			InitializeComponents();
		}
		

		// provide methods for communication with the IDE
		//

		public ISdMessageHandler MessageHandler {
			get {
				return null;
			}
		}	

		public void Execute(ISdPluginExecutor executor)
		{
			GACBrowser dlg = new GACBrowser();
			dlg.PrintCache();
			dlg.ShowDialog();
		}

		public void InitializeComponents() {


			ColumnHeader h0 = new ColumnHeader();
			ColumnHeader h1 = new ColumnHeader();
			ColumnHeader h2 = new ColumnHeader();
			ColumnHeader h3 = new ColumnHeader();
			ColumnHeader h4 = new ColumnHeader();

			list = new ListView();
			
			h0.Text = "Global Assembly Name";		// TODO: exchange list header names with resource strings
			h1.Text = "Type";
			h2.Text = "Version";	
			h3.Text = "Culture";
			h4.Text = "Public Key Token";

			h0.Width = 250;
			h1.Width = 50;
			h2.Width = 70;
			h3.Width = 50;
			h4.Width = 150;

			list.Columns.Add(h0);		// add list headers 
			list.Columns.Add(h1);		
			list.Columns.Add(h2);		 
			list.Columns.Add(h3);
			list.Columns.Add(h4);
			list.View = View.Details; 		
			list.Location = new Point(8, 8);
			Rectangle r = this.ClientRectangle;
			r.Inflate(-10,-10);
		
			list.Size = r.Size;

			list.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;			
			list.Activation = ItemActivation.Standard;
			list.MultiSelect = false;
			list.FullRowSelect = true;
			list.GridLines   = true;
			list.HideSelection = false;

			this.Controls.Add(list);

			this.Size = new Size(650, 600);
			this.Location = new Point(40,40);
			this.Text = "Global Assembly Cache Browser";								
		}





		private void PrintCache()
		{
		      	IApplicationContext ac = null;
      			IAssemblyEnum ae;
			IAssemblyName an;
			uint nChars;
			StringBuilder sb;
			int nAssemblies;
			string[] info;
			string[] allInfo;
			String aName;
			String aVersion;
			String aLanguage;
			String aToken;
			String aType;
	
			for ( uint i = 1; i <= 2; i++ ) {
			        Fusion.CreateAssemblyEnum( out ae, null, null, i, 0 );
								
				if ( ae == null )
			          continue;

			        if ( i == 1 )
			          aType = "PreJit";
			        else
			          aType = "";


			        nAssemblies = 0;
				
        			while ( ae.GetNextAssembly( out ac, out an, 0 ) == 0 ) 
			        {
			          	nChars = 0;
					an.GetDisplayName( null, ref nChars, 0 );

					sb = new StringBuilder( (int) nChars );
					an.GetDisplayName( sb, ref nChars, 0 );					 
					++nAssemblies;
					
					info = sb.ToString().Split( ',' );
					aName = info[0];
					aVersion = info[1].Substring(info[1].LastIndexOf('=')+1);
					aLanguage = info[2].Substring(info[2].LastIndexOf('=')+1);
					if (aLanguage.Equals("neutral")) 
						aLanguage = "";


					aToken = info[3].Substring(info[3].LastIndexOf('=')+1);

					allInfo = new string[] { aName, aType ,aVersion, aLanguage, aToken };

					list.Items.Add(new ListViewItem(allInfo));
				}
			}
		} // end of PrintCache     
	} // end of class 
} // end of namespace




// TextTools.cs
// Copyright (C) 2000 Mike Krueger
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

using System;
using System.Diagnostics;
using System.Drawing;
using SharpDevelop.Gui;
using SharpDevelop.Actions;
using SharpDevelop.Actions.Menu;
using SharpDevelop.Internal.Plugin;
using SharpDevelop.Gui.Edit.Text;
using SharpDevelop.Internal.Text;
using SharpDevelop.Internal.Messages;

namespace TextTools {
	
	/// <summary>
	/// This is a sample menu plugin.
	/// It Removes all trailing white space characters in the current buffer
	/// </summary>
	public class RemoveTrailingWS : ISdPlugin
	{
		public ISdMessageHandler MessageHandler {
			get {
				return null;
			}
		}
		
		public void Execute(ISdPluginExecutor executor)
		{
			if (!executor.Main.ActiveContentWindow.HasTextArea)
				return;
			
			TextAreaControl textarea    = executor.Main.ActiveContentWindow.TextArea;

			int           redocounter = 0; // must count how many Delete operations occur
			Point         p1 = new Point();
			Point         p2 = new Point();
			for (int i = 0; i < textarea.Buffer.Length; ++i) {
				int x = textarea.Buffer[i].Text.Length - 1;
				p1.Y = p2.Y = i;
				while (x >= 0 && Char.IsWhiteSpace(textarea.Buffer[i].Text[x])) {
					p1.X = x;
					p2.X = x + 1;
					textarea.Buffer.Delete(p1, p2);
					++redocounter;                  // count deletes
					--x;                            // length changed
				}
			}
			textarea.Caret.CheckCaretPos();                       // current cursor position may be invalid
			textarea.Buffer.UndoStack.UndoLast(redocounter); // redo the whole operation (not the single deletes)
			textarea.Refresh();
		}
	}
	
	/// <summary>
	/// This is a sample editaction plugin, it indents the selected area.
	/// </summary>
	public class IndentSelection : ISdEditAction
	{
		public void Execute(ISdEditActionExecutor executor)
		{
			if (executor.TextArea.Buffer.ReadOnly) 
				return;
			if (executor.TextArea.Selection.HasSomethingSelected) {
				int y1 = executor.TextArea.Selection.RealStart.Y;
				int y2 = executor.TextArea.Selection.RealEnd.Y;
				Indent.IndentLines(executor.TextArea.Buffer, y1, y2, executor.TextArea.Options.IndentStyle);
				executor.TextArea.Refresh();
			}
		}
	}
}
